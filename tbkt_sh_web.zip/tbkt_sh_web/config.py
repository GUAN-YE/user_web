# coding:utf8
import os
import sys
import uuid
import json
import hashlib
import random
import pymysql
import base64
import time
from aliyunsdkcore.client import AcsClient
from aliyunsdkdysmsapi.request.v20170525 import SendSmsRequest
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../../..')))
# 自动导入家长数据文件所在的地址
G_IMPORT_DIR = '/data/'
# 本地测试数据库配置
# DB_HOST = "122.114.40.76"
# DB_UID = "wangjianbin"
# DB_PWD = "jianbin@tbkt2017!"
# DB_NAME = 'tbkt_ketang'
# DB_PORT = 3306
# 河南阿里云测试库地址
# DB_HOST = "rm-2zekkuf62c6477n70.mysql.rds.aliyuncs.com"
# DB_UID = "hn_tbkt_cms_user"
# DB_PWD = "cms@TbKt!2017RDS"
# DB_NAME = 'tbkt_ketang'
# DB_PORT = 3306
# # 河南阿里云正式库地址
DB_HOST = 'rm-2ze7fsacj5q360kt7.mysql.rds.aliyuncs.com'
DB_UID = 'tbkt_sh_user'
DB_PWD = 'shSCriPT@!2017TbKt'
DB_NAME = 'tbkt_ketang'
DB_PORT = 3306
# # # 河南阿里云从库
DB_SLAVE_HOST = '10.25.141.231'
DB_SLAVE_UID = 'hn_tbkt_cms_user'
DB_SLAVE_PWD = 'cms@TbKt!2017RDS'
DB_SLAVE_NAME = 'tbkt_ketang'
DB_SLAVE_PORT = 3306



def get_ketang_conn():
    """
    功能            建立ketang库的mysql连接
    -----------------------------------
    添加人          添加时间           作用
    -----------------------------------
    杜祖永           2016-06-28
    """
    conn = pymysql.connect(host=DB_HOST,
                           db=DB_NAME,
                           user=DB_UID,
                           passwd=DB_PWD,
                           port=DB_PORT,
                           charset="utf8")
    return conn


def get_slave_conn():
    """
    功能            建立slave库连接
    -----------------------------------
    添加人          添加时间           作用
    -----------------------------------
    杜祖永           2016-06-28
    """
    conn = pymysql.connect(host=DB_SLAVE_HOST,
                           db=DB_SLAVE_NAME,
                           user=DB_SLAVE_UID,
                           passwd=DB_SLAVE_PWD,
                           port=DB_SLAVE_PORT,
                           charset="utf8")
    return conn


def get_manage_conn():
     """
     功能:建立tbkt_manage库连接
     ------------------------
     添加人:宋国洋
     ------------------------
     添加时间:2016-11-30
     """
     DB_NAME = 'tbkt_manage'
     conn = pymysql.connect(host=DB_HOST,
                            db=DB_NAME,
                            user=DB_UID,
                            passwd=DB_PWD,
                            charset="utf8",
                            autocommit=True)
     return conn


def call_proc(proc_name, parameter):
    """
    功能            执行存储过程
    -----------------------------------
    添加人          添加时间           作用
    -----------------------------------
    杜祖永           2016-06-28
    ------------------------------------
    宋国洋       2018-03-19  添加存储过程执行完毕关闭游标和链接操作
    """
    conn = get_ketang_conn()
    cursor = conn.cursor()
    cursor.callproc(proc_name, parameter)
    results = cursor.fetchone()
    # 执行完关闭游标和链接
    cursor.close()
    conn.close()
    return results


def send_system_sms(open_subject, system_sms, user_type, phone_number, batch_id):
    """
    功能            下发系统短信
    -----------------------------------
    添加人          添加时间           作用
    -----------------------------------
    杜祖永           2015-03-01
    """
    system_sms = str(system_sms)
    user_type = int(user_type)
    open_subject = str(open_subject)

    stu_sms_list = ["同步课堂亮点一【名师一对一辅导孩子学习】提供省内一线名师对教材配套练习册习题讲解，轻松解决作业不会做的难题。所有课本里知识都有名师讲解，孩子上课没听懂，那里不会看哪里，直到看懂看会，看知识点视频提前预习功课，提高课堂学习效率。",
                    "同步课堂亮点二【准确掌握孩子每天学习情况】。拒绝做“三不知”家长，不知道孩子学习情况、不知道孩子学习能力、不知道孩子学习习惯。您只需将老师批改作业的结果在网站上提交，就可以轻松准确掌握孩子学习的情况、能力和习惯，促进家长有效和孩子沟通，让学习的各种问题早发现，早解决。",
                    "同步课堂亮点三【花最少时间让孩子成为数学尖子】。根据孩子的学习情况，有针对性的为孩子制定属于自己的学习方案，只需学习不会的知识，科学的为孩子补习培优，让孩子快速成为数学尖子。"]
    tea_sms_list = ["使用同步课堂好处一：【作业不用改 学情全掌握】同步课堂提供多元化作业布置方式，作业内容通过短信告知家长，学生只需在网站或手机端提交作业，老师即可准确掌握全班的学习情况。为老师第二天教学提供有效参考。",
                    "使用同步课堂好处二：【替您一对一辅导 中下生提高10-30分】。同步课堂提供省内一线名师录制的知识讲解和试题讲解，及时解决学生知识没掌握，作业不会做的辅导问题。根据学生各自的学习情况，制定针对性的学习方案，科学的为学生补习培优，快速提高成绩。",
                    "使用同步课堂好处三：【伴您备课 替您讲课】。同步课堂提供配套的知识讲解和视频讲解，作为老师平时备课的参考，为我所用；许多具备电子白板的学校，老师用同步课堂视频替自己讲课讲题，老师关注学生听讲，效果极好。"]

    if system_sms == '1' and open_subject.find('2') > -1:
        if user_type == 1:
            for msg_txt in stu_sms_list:
                result = call_proc("sp_send_sms", (phone_number, msg_txt, '10657050500001', batch_id))
                if result[0] > 0:
                    print 'write system sms end, mp_sms_record_id=%s' % result[0]
                    print msg_txt
        elif user_type == 3:
            for msg_txt in tea_sms_list:
                result = call_proc("sp_send_sms", (phone_number, msg_txt, '10657050500001', batch_id))
                if result[0] > 0:
                    print 'write system sms end, mp_sms_record_id=%s' % result[0]
                    print msg_txt


# def unit_class_chonfu_username(unit_class_id, user_name, phone_number):
#     """班级内姓名重复判断"""
#     if not unit_class_id:
#         return ""
#     conn = get_ketang_conn()
#     cur = conn.cursor()
#     user_name = user_name.replace("'", '')
#     # 学生
#     username = ''
#     sql = """
#         select DISTINCT b.username,s.`status`,r.id,r.school_id,r.school_name,r.unit_class_id,su.unit_name from tbkt_ketang.mobile_order_region r
#         INNER join tbkt_user.auth_user b on r.user_id=b.id
#         INNER JOIN tbkt_com.school_unit_class su ON su.id=r.unit_class_id
#         left join tbkt_ketang.mobile_subject_detail_hn s on s.phone_number=b.phone
#         where r.unit_class_id=%s and b.real_name='%s' and b.phone<>'%s' and b.type=1
#     """ % (unit_class_id, user_name, phone_number)
#     cur.execute(sql)
#     user_list = cur.fetchall()
#     tmp_user = {}
#     no_open_region = []
#     for u_obj in user_list:
#         if u_obj[1] in [2, 9]:
#             tmp_user[u_obj[0]] = '已开通'
#         else:
#             # 未开通
#             sch = {'region_id': u_obj[2],'sch_id':u_obj[3],'sch_name':u_obj[4],'unit_class_id':u_obj[5],'unit_name':u_obj[6]}
#             if sch not in no_open_region:
#                 no_open_region.append(sch)
#
#     tmp_msg = ''
#     if len(tmp_user.keys()) > 0:
#         # 存在重名
#         tmp_msg = '班级内存在重名'
#
#         for key in tmp_user.keys():
#             tmp_msg += '%s:%s ' % (key, tmp_user[key])
#         print tmp_msg.encode('utf8')
#     for sch in no_open_region:
#         # 存在重名未开通用户设置为待分班级
#         sql = "update tbkt_ketang.mobile_order_region set unit_class_id=0 where id=%s" % sch['region_id']
#         cur.execute(sql)
#         conn.commit()
#     return tmp_msg
#
#
# def phone_has_two_account(phone_number, user_name):
#     """学生手机号是否可以创建账号"""
#     conn = get_ketang_conn()
#     cur = conn.cursor()
#     user_name = user_name.replace("'", '')
#     tmp_msg = ''  # 错误信息
#     username = ''  # 账号
#     # 学生
#     sql = "select DISTINCT b.username,s.status,b.real_name from tbkt_user.auth_user b left join tbkt_ketang.mobile_subject_detail_hn s on b.phone=s.phone_number and s.status in (0,1,2,9) where b.type=1 and b.phone='%s'" % phone_number
#     cur.execute(sql)
#     user_list = cur.fetchall()
#     tmp_user = {}
#     for u_obj in user_list:
#         if not tmp_user.has_key(u_obj[0]):
#             tmp_user[u_obj[0]] = '未开通'
#         if u_obj[1] in [2, 9]:
#             tmp_user[u_obj[0]] = '已开通'
#         if u_obj[2] == user_name:
#             # 有账号的姓名和要导入的一样则修改班级范围
#             username = u_obj[0]
#     if len(tmp_user.keys()) >= 2 and username == '':
#         # 已经有两个以上账号，不能再创建账号
#         tmp_msg = '两个以上账号：'
#         for key in tmp_user.keys():
#             tmp_msg += '%s:%s ' % (key, tmp_user[key])
#         # 修改第一个账号的信息
#         username = user_list[0][0]
#
#     elif len(tmp_user.keys()) == 1 and username == '':
#         xs_num = tmp_user.keys()[0][13:]
#         if xs_num:
#             username = '%sxs' % phone_number
#         else:
#             username = '%sxs1' % phone_number
#     elif username == '':
#         username = '%sxs' % phone_number
#     return username, tmp_msg


def unit_class_has_other_teacher(unit_class_id, subject_id, phone_number):
    """
    功能: 创建教师账号时判断相应班级是否已经有任课教师,有了设置成待分
    -------------------------------------------------------
    参数: unit_class_id 班级ID, subject_id 学科ID, phone_number 教师手机号
    -----------------------------------------------------------------
    返回: phone_number,id--即为用户的user_id
    """
    if unit_class_id == 0:
        return ''
    conn = get_ketang_conn()
    cur = conn.cursor()

    sql = """
        select DISTINCT b.phone, r.id from tbkt_user.auth_user b INNER JOIN tbkt_ketang.mobile_order_region r on b.id=r.user_id and b.type=3
        and b.sid=%s and r.unit_class_id='%s' and b.phone<>'%s';""" % (subject_id, unit_class_id, phone_number)
    cur.execute(sql)
    data_list = cur.fetchall()
    tmp_data = []
    region_ids = []
    for obj in data_list:
        tmp_data.append(str(obj[0]))
        region_ids.append(str(obj[1]))
    # 把此班现有老师设置待分
    if region_ids:
        sql = """
            UPDATE tbkt_ketang.mobile_order_region r SET r.unit_class_id=0 WHERE r.id IN (%s)
        """ % ",".join(region_ids)
        cur.execute(sql)
        conn.commit()
    return ','.join(tmp_data)


def unit_class_tea_handle(tea_data, subject_id):
    """
    -------------------------------
    功能:保留本次添加教师所有数据,并删除教师多余班级数据
    ---------------------------------------------
    参数:tea_data:[[phone_number, unit_class_id], []..], subject_id:学科id
    ------------------------------------------
    返回:成功返回ok,失败返回error信息
    ----------------------------------------
    添加人:宋国洋
    ------------------------
    添加时间:2017-09-07
    """
    try:
        conn = get_ketang_conn()
        cur = conn.cursor()
        # 对获取的数据结果进行排序
        tea_list = sorted(tea_data, key=lambda tea_data: tea_data["phone_number"])
        phone_list = [obj["phone_number"] for obj in tea_list]
        tea_dict = {}
        for phone_number in phone_list:
            tea_dict[phone_number] = [tea["unit_class_id"] for tea in tea_list if tea["phone_number"] == phone_number]
        for phone, unit_list in tea_dict.items():
            in_unit = ""
            for the_unit in unit_list:
                if in_unit:
                    in_unit += ",%s" % the_unit
                else:
                    in_unit = "%s" % the_unit
            print "this time teacher unit:", [in_unit]
            # 除本次添加教师外,该教师该学科所在其他班级的数据均删除
            sql = """SELECT r.id FROM tbkt_user.auth_user b INNER JOIN tbkt_ketang.mobile_order_region r ON b.id=r.user_id AND b.type=3
                    AND b.sid=%s AND r.unit_class_id NOT IN (%s) AND b.phone='%s' GROUP BY r.id;""" % (subject_id, in_unit, phone)
            cur.execute(sql)
            regions_list = cur.fetchall()
            id_list = [str(obj[0]) for obj in regions_list if regions_list]
            print "delete unit teacher list:", id_list
            for region_id in id_list:
                print "use sp_delete_other_unit_tea:", region_id
                # 调用存储过程删除其他班级教师数据
                call_proc("sp_delete_other_unit_tea", (region_id,))
        return "ok"
    except Exception as e:
        return e
    
  
def subject_tea_exist(phone_number, subject_id):
    """
    功能:判断该学科教师账号是否已经存在,存在返回教师账号,不存在返回默认教师账号
    :param phone_number: 教师手机号
    :param subject_id: 学科ID
    :return:
    """
    try:
        conn = get_ketang_conn()
        cur = conn.cursor()
        sql = """SELECT username FROM tbkt_user.auth_user WHERE phone="%s" AND sid=%s AND type=3;""" % (phone_number, subject_id)
        cur.execute(sql)
        user_tea = cur.fetchone()
        # 默认教师账号
        username = '%sjs' % phone_number
        if user_tea:
            username = user_tea[0]
            print "use the exist teacher username:%s" % username
        else:
            sql_other = """SELECT username FROM tbkt_user.auth_user WHERE phone="%s" AND type=3;""" % phone_number
            cur.execute(sql_other)
            other_tea = cur.fetchall()
            if other_tea:
                end_list = [int(str(obj[0]).split("s")[1]) if str(obj[0]).split("s")[1] else 0 for obj in other_tea]
                js_end = max(end_list) + 1
                username = "%sjs%s" % (phone_number, js_end)
                print "create new teacher username:%s" % username
            else:
                print "auth_user has no this username"
                username = username
        return username
    except Exception as e:
        print e
        return ""


def old_username_password_exist(username):
    """
    功能:检测账号旧密码
    ------------------
    参数:教师账号
    -------------------
    处理逻辑:根据账号查询数据是否存在,存在获取账号base64密码和明文密码并返回
            不存在生成新的base64密码和明文密码返回
    """
    try:
        conn = get_ketang_conn()
        cur = conn.cursor()
        sql = """SELECT ap.`password` FROM tbkt_user.auth_user au
                 INNER JOIN tbkt_user.auth_profile ap ON ap.user_id=au.id
                 AND au.username='%s';""" % username
        cur.execute(sql)
        data_pw = cur.fetchone()
        pw = random.randint(123456, 987654)
        pw_encode = base64.b64encode(str(pw))
        if data_pw:
            pw_encode = data_pw[0].encode("utf-8")
            pw = base64.b64decode(pw_encode)
        return pw, pw_encode
    except Exception as e:
        print e
        return "", ""


# 密码不可逆加密
def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except Exception as e:
        print 'encode_password:', password, "error:", e
        return ''
    return "sha1$%s$%s" % (salt, hash)


def send_sms(phone_number):
    """
    功能:阿里云校方管理员注册成功短信下发
    :param phone_number: 接收验证码手机号
    :return: 成功返回ok,失败或者报错返回''
    添加人:宋国洋
    添加时间:2018-01-27
    """
    ret_val = ''    # 默认参数
    try:
        # 地域code值
        region_code = "cn-hangzhou"
        # 阿里云产品key
        access_key_id = "LTAItXF1DTVACUot"
        # 阿里云产品密钥
        access_key_secret = "3weh781asymAiL6nTL4Rv8Feb2e2Am"
        # 短信请求服务器注册
        acs_client = AcsClient(access_key_id, access_key_secret, region_code)
        sms_request = SendSmsRequest.SendSmsRequest()
        # 短信模板编码
        template_code = "SMS_123797337"
        sms_request.set_TemplateCode(template_code)
        # 设置业务请求流水号,直接指定
        business_id = uuid.uuid1()
        sms_request.set_OutId(business_id)
        # 短信签名, 默认写死
        sign_name = "创恒同步课堂"
        sms_request.set_SignName(sign_name)
        # 短信发送的号码
        sms_request.set_PhoneNumbers(phone_number)
        # 发送请求
        sms_response = acs_client.do_action_with_exception(sms_request)
        res = json.loads(sms_response)
        ret_val = 'ok' if res['Code'] == 'OK' else ret_val
        return ret_val
    except Exception as e:
        import traceback
        traceback.print_exc()
        return ret_val


def unix_timestamp(dt):
    """
    功能:datetime或date转时间戳
    --------------------------
    添加人:宋国洋
    --------------------------
    添加时间:2018-01-30
    """
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        return int(time.mktime(t))
    except Exception as e:
        print e
        return 0
