# coding:utf-8
# """
# 功能:校方管理员注销
# -----------------------
# 添加人:宋国洋
# -----------------------
# 修改时间:2018-01-29
# """
import os
import time
import datetime
import sys

# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
# 引入数据库配置文件
from twisted.internet import reactor
from twisted.application import service
from db_mysql import db


class UpdateManagerStatus(object):
    @staticmethod
    def deal_cancel_user():
        try:
            # 解除学校关系满90天注销
            cancel_time = int(time.time()) - 7776000
            user_data = db.tbkt_manage.school_auth_user.filter(status=1, date_joined__lt=cancel_time).select('phone_number')[:]
            if user_data:
                print "需要处理的数据为:", user_data
                for obj in user_data:
                    phone_number = obj['phone_number']
                    # 更新school_auth_user中的状态
                    db.tbkt_manage.school_auth_user.filter(phone_number=phone_number).update(status=2)
                    # 并且将sore_user表中的数据清零
                    db.tbkt_manage.score_user.filter(phone_number=phone_number).update(score=0)
            print "未找到需要处理的数据"
        except Exception as e:
            print e


def start():
    while True:
        print '程序开始时间:', datetime.datetime.now()
        begin = time.time()
        do_create = UpdateManagerStatus()
        do_create.deal_cancel_user()
        print '程序耗时:', time.time() - begin
        time.sleep(5*60)


if __name__ == "__main__":
    start()
elif __name__ == '__builtin__':
    print '__builtin__'
    reactor.callInThread(start)
    application = service.Application('batch_cancel_school_manager')