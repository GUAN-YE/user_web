#! /usr/bin/env sh
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/batch_cancel_school_manager.py
logfile=/var/log/batch_cancel_school_manager.log
case $1 in
    start)
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/batch_cancel_school_manager.pid --logfile=$logfile
        ;;
    stop)
        kill -9 `cat /var/run/batch_cancel_school_manager.pid`
        ;;
    restart)
        kill -9 `cat /var/run/batch_cancel_school_manager.pid`
        sleep 1
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/batch_cancel_school_manager.pid --logfile=$logfile
        ;;
    log)
        tail -f $logfile
        ;;
    *)
        echo "Usage: ./batch_cancel_school_manager.sh start | stop | restart | log"
        ;;
esac