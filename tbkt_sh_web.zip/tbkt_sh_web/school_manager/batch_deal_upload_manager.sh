#! /usr/bin/env sh
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/batch_deal_upload_manager.py
logfile=/var/log/batch_deal_upload_manager.log
case $1 in
    start)
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/batch_deal_upload_manager.pid --logfile=$logfile
        ;;
    stop)
        kill -9 `cat /var/run/batch_deal_upload_manager.pid`
        ;;
    restart)
        kill -9 `cat /var/run/batch_deal_upload_manager.pid`
        sleep 1
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/batch_deal_upload_manager.pid --logfile=$logfile
        ;;
    log)
        tail -f $logfile
        ;;
    *)
        echo "Usage: ./batch_deal_upload_manager.sh start | stop | restart | log"
        ;;
esac