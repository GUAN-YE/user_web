# coding:utf-8
"""
功能:校方管理员每月返费数据处理
----------------------------
添加人:宋国洋
----------------------------
添加时间:2018-01-24
"""
import os
import sys
import time
import datetime
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
from db_mysql import db
from twisted.internet import reactor
from twisted.application import service
from config import *


class DealManagerScore(object):

    @staticmethod
    def write_manager_score(month_fee_id, school_id, phone_number, score):
        """
        功能:写入返还金豆数据
        ----------------------
        添加人:宋国洋
        ----------------------
        添加时间:2018-01-24
        """
        try:
            now = str(datetime.datetime.now())[:10]
            # 明细数据直接写入
            db.tbkt_manage.score_user_detail.create(
                month_fee_id=month_fee_id,
                school_id=school_id,
                phone_number=phone_number,
                item_no='school_bak',
                score=score,
                remark=u'%s系统返还' % now,
                add_date=int(time.time()),
                app_id=7,
                add_username='system',
                status=1
            )
            # 金豆总量数据首先判断score_user表中是否存在该手机号的金豆数据
            phone_data = db.tbkt_manage.score_user.filter(phone_number=phone_number, app_id=7).get()
            if phone_data:
                # 更新金豆数据
                add_score = phone_data['score'] + score
                db.tbkt_manage.score_user.filter(phone_number=phone_number, app_id=7).update(
                    score=add_score
                )
            else:
                # 写入金豆数据
                db.tbkt_manage.score_user.create(
                    phone_number=phone_number,
                    score=score,
                    app_id=7
                )
        except Exception as e:
            print e

    @staticmethod
    def get_month_fee_id():
        """
        功能:获取以成功生成的返费数据month_fee_id
        :return: month_fee_id
        """
        now_date = datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        # 当月初
        begin_date = now_date.replace(day=1)
        # 结束时间
        end_date = (begin_date + datetime.timedelta(days=10))
        begin_time = unix_timestamp(begin_date)
        end_time = unix_timestamp(end_date)
        fee_data = db.tbkt_manage.month_fee_data.filter(add_date__range=[begin_time, end_time]).get()
        month_fee_id = fee_data['month_fee_id'] if fee_data else ''
        print "month_fee_id为:", month_fee_id
        return month_fee_id

    def get_fee_data(self, month_fee_id):
        """
        功能:获取返费数据
        :return:
        """
        ret_val = ""  # 初始化返回参数
        # 首先需要查score_user_detail表中是否已经生成了该月的返还的金豆数据
        data_exist = db.tbkt_manage.score_user_detail.filter(month_fee_id=month_fee_id, status=1).exists()
        if data_exist:
            # 已生成返还金豆数据
            return ret_val
        else:
            # 未生成返还金豆数据,继续处理
            # 获取每个学校的返费金额
            sql = """SELECT school_id,COUNT(DISTINCT phone_number) FROM tbkt_manage.school_auth_user 
                  WHERE manager_type>=2 AND status=0 GROUP BY school_id;"""
            manager_data = db.tbkt_manage.fetchall(sql)
            print "管理员数据:", manager_data
            manger_dict = {obj[0]: obj[1] for obj in manager_data if manager_data}
            for k, v in manger_dict.items():
                school_id = k
                manager_num = v
                print "学校ID为:%s,管理员人数:%s" % (school_id, manager_num)
                school_sql = """SELECT
                CASE 
                WHEN fs.all_num <=99 THEN 0
                WHEN fs.all_num <=299 THEN 50
                WHEN fs.all_num <=499 THEN 100
                WHEN fs.all_num <=799 THEN 150
                WHEN fs.all_num <=1499 THEN 200
                WHEN fs.all_num <=1999 THEN 300
                ELSE 400 END AS fee_num
                FROM tbkt_ketang.n_fanfei_school_num fs WHERE fs.month_fee_id=%s AND fs.sch_id=%s;
                """ % (month_fee_id, school_id)
                school_data = db.tbkt_ketang.fetchone(school_sql)
                print "学校返还金豆总数据:", school_data
                if school_data:
                    score_num = school_data[0]
                    # 查看是否做过返还金额调整
                    restore_data = db.tbkt_manage.update_restore_detail.filter(
                        month_fee_id=month_fee_id, school_id=school_id).select('phone_number', 'restore_num')[:]
                    if restore_data:
                        print "调整过返还金额数据:", restore_data
                        # 根据调整的返还金额进行返还金豆
                        for obj_data in restore_data:
                            phone_number = obj_data['phone_number']
                            user_status = db.tbkt_manage.school_auth_user.filter(phone_number=phone_number, manager_type__gte=2, status=0).get()
                            score = obj_data['restore_num']
                            if score > 0 and user_status:
                                # 只返还金币数>0并且是正常状态下的管理员
                                user_status = db.tbkt_manage.school_auth_user.filter(phone_number=phone_number, manager_type__gte=2, status=0).get()
                                self.write_manager_score(month_fee_id, school_id, phone_number, score)
                        ret_val = True
                    else:
                        print "根据管理员人数返还"
                        # 根据管理员人数返还, 只返还正常状态下的管理人员
                        phone_data = db.tbkt_manage.school_auth_user.filter(school_id=school_id, manager_type__gte=2, status=0)[:]
                        if phone_data:
                            if manager_num == 1:
                                # 一个全部返还
                                phone_number = phone_data[0]['phone_number']
                                score = score_num
                                if score > 0:
                                    # 只返还金币数>0并且是正常状态下的管理员
                                    self.write_manager_score(month_fee_id, school_id, phone_number, score)
                                ret_val = True
                            else:
                                # 两个各占一半,只返还两个
                                for obj_phone in phone_data[:2]:
                                    phone_number = obj_phone['phone_number']
                                    score = score_num / 2
                                    if score > 0:
                                        # 只返还金币数>0并且是正常状态下的管理员
                                        self.write_manager_score(month_fee_id, school_id, phone_number, score)
                                ret_val = True
            return ret_val

    def loop_handle(self):
        """
        功能:循环处理,处理一次休眠一个小时
        :return:
        """
        while True:
            now_date = datetime.datetime.now()
            print "当前时间:", now_date
            if now_date.day == 11:
                month_fee_id = self.get_month_fee_id()
                if month_fee_id:
                    # 存在待处理的month_fee_id继续处理
                    ret_val = self.get_fee_data(month_fee_id=month_fee_id)
                    if ret_val:
                        print "本次数据处理完成,休眠24小时"
                        time.sleep(60 * 60 * 24)
                    else:
                        print "本次数据已处理过,休眠24小时"
                        time.sleep(60 * 60 * 24)
                else:
                    print "没有待处理的数据,休眠一小时"
                    time.sleep(60 * 60)
            else:
                print "不在数据生成日,休眠1小时"
                time.sleep(60 * 60* 12)


def start():
    print "开始处理程序"
    pro = DealManagerScore()
    pro.loop_handle()
    print "结束处理程序"


if __name__ == "__main__":
    start()
elif __name__ == '__builtin__':
    print '__builtin__'
    reactor.callInThread(start)
    application = service.Application('batch_deal_manager_score')