#! /usr/bin/env sh
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/batch_deal_manager_score.py
logfile=/var/log/batch_deal_manager_score.log
case $1 in
    start)
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/batch_deal_manager_score.pid --logfile=$logfile
        ;;
    stop)
        kill -9 `cat /var/run/batch_deal_manager_score.pid`
        ;;
    restart)
        kill -9 `cat /var/run/batch_deal_manager_score.pid`
        sleep 1
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/batch_deal_manager_score.pid --logfile=$logfile
        ;;
    log)
        tail -f $logfile
        ;;
    *)
        echo "Usage: ./batch_deal_manager_score.sh start | stop | restart | log"
        ;;
esac