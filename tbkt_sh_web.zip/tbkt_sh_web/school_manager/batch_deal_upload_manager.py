# coding:utf-8
import os
import sys
import xlrd
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 引入数据库配置文件
from db_mysql import db
from twisted.internet import reactor
from twisted.application import service
from xlutils.copy import copy
from config import *
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')


def modify_file(wb, file_full_path, arr=[]):
    """
    功能:修改文件
    ---------------
    添加人:宋国洋
    """
    try:
        sheet = wb.get_sheet(0)
        i = 0
        for obj in arr:
            try:
                i += 1
                sheet.write(obj['row'], obj['col'], obj['msg'].decode('utf8'))
                print "文件修改成功"
            except Exception, e:
                print '修改文件第:%s行,异常err:%s' % (i, e)
        wb.save(file_full_path)
    except Exception, e:
        print e


class BatchDealManager(object):
    """
    功能:校方管理员批量注册
    """
    @staticmethod
    def get_file():
        """
        功能:获取上传的文件路径
        ----------------------
        添加人:宋国洋
        """
        file_data = db.tbkt_ketang.mp_batch_request.filter(batch_type=5, data_source=5, status=0).get()
        res_data = []
        if file_data:
            res_data = [file_data['id'], file_data['file_name'], json.loads(file_data['affix_info'])]
        return res_data

    def deal_data(self, res_data):
        """
        功能:处理文件数据
        ---------------
        添加人:宋国洋
        """
        try:
            err_msg = []  # 错误日志
            batch_id = res_data[0]
            file_path = res_data[1]
            is_send = int(res_data[2]['is_send']) if res_data[2] else 0
            bk = xlrd.open_workbook(file_path)  # 打开excel文件
            wb = copy(bk)  # 复制工作表
            sh = bk.sheets()[0]
            rows = sh.nrows
            all_num = rows - 3
            row = 2        # 当前处理第几行
            ok_num = 0     # 处理成功的条数
            print '待处理文件的总记录数:', all_num
            # 将文件更新为待处理的状态
            db.tbkt_ketang.mp_batch_request.filter(id=batch_id).update(status=1)
            # 首先解除本次导入学校已存在的所有管理员账号的学校归属
            self.remove_school_bond(data_sh=sh)
            for r in range(3, rows):
                row += 1
                try:
                    school_name = str(sh.row(r)[0].value).strip()
                    real_name = str(sh.row(r)[1].value).strip()
                    post_name = str(sh.row(r)[2].value).strip()
                    phone_number = str(sh.row(r)[3].value).strip()[:11]
                    manager_type = sh.row(r)[4].value
                    # 数据参数验证
                    # 学校验证
                    if not school_name:
                        err_msg.append({'row': row, 'col': 10, 'msg': '失败:学校名字未填写'})
                        continue
                    else:
                        school_data = call_proc("sp_get_school", ('', school_name))
                        school_id = school_data[5] if school_data else ''
                        if not school_id:
                            err_msg.append({'row': row, 'col': 10, 'msg': '失败:未找到对应的学校'})
                            continue
                        print "本次创建的管理员学校ID为:", school_id
                    # 手机号验证
                    if not phone_number:
                        err_msg.append({'row': row, 'col': 10, 'msg': '失败:手机号码未填写'})
                        continue
                    # 管理员类型验证
                    if not manager_type:
                        err_msg.append({'row': row, 'col': 10, 'msg': '失败:学校名字未选择'})
                        continue
                    manager_type = int(manager_type)
                    # 管理员姓名验证
                    if not real_name:
                        err_msg.append({'row': row, 'col': 10, 'msg': '失败:管理员姓名未填写'})
                        continue
                    # 管理员职务
                    if not post_name:
                        post_name = '管理员'   # 设置成默认
                    ret_val, m = self.insert_user(school_name, school_id, real_name, post_name, phone_number, manager_type)
                    if ret_val:
                        ok_num += 1
                        if is_send == 1:
                            # 下发校方管理员注册成功短信
                            send_sms(phone_number=phone_number)
                    err_msg.append({'row': row, 'col': 10, 'msg': m})
                except Exception as e:
                    print e
                    err_msg.append({'row': row, 'col': 10, 'msg': 'process_error'})
                content = '总记录:%s条,成功处理%s条' % (all_num, ok_num)
                print "处理结果:", content
            # 处理结束更新文件处理状态
            db.tbkt_ketang.mp_batch_request.filter(id=batch_id).update(status=2, num_all=all_num, num_ok=ok_num)
            # 写入处理结果
            modify_file(wb, file_path, err_msg)
        except Exception as e:
            import traceback
            traceback.print_exc()

    @staticmethod
    def insert_user(school_name, school_id, real_name, post_name, phone_number, manager_type):
        """
        功能：插入数据
        ---------------
        添加人:王建彬
        """
        try:
            manger_data = db.tbkt_manage.school_auth_user.filter(phone_number=phone_number).get()      # 是否存在已注册用户
            manager_num = db.tbkt_manage.school_auth_user.filter(school_id=school_id,
                                                                 manager_type__in=[2, 3],
                                                                 status=0).count()
            if manger_data:
                # 如果是老用户
                if manager_type == 1:
                    # 管理员账号
                    # 如果该手机号已经存在,更新数据
                    db.tbkt_manage.school_auth_user.filter(phone_number=phone_number).update(
                        real_name=real_name,
                        post_name=post_name,
                        school_id=school_id,
                        school_name=school_name,
                        manager_type=manager_type,
                        date_joined=int(time.time()),
                        status=0
                    )
                    ret_val, m = True, '成功:管理员权限账号已更新[替换老账号的权限数据]'
                else:
                    # 金币账号
                    if manager_num >= 2:
                        ret_val, m = False, '失败:金币权限账号已有两个'
                    else:
                        # 直接更新其数据
                        db.tbkt_manage.school_auth_user.filter(phone_number=phone_number).update(
                            real_name=real_name,
                            post_name=post_name,
                            school_id=school_id,
                            school_name=school_name,
                            manager_type=manager_type,
                            date_joined=int(time.time()),
                            status=0
                        )
                        ret_val, m = True, '成功:金币权限或双权限账号已更新[替换老账号的权限数据]'
            else:
                # 如果是新用户
                if manager_type == 1:
                    # 管理员账号
                    db.tbkt_manage.school_auth_user.create(
                        phone_number=phone_number,
                        username=phone_number + 'gly',
                        password='sha1$95718$93af5a5fa8b5a4a376e2a85e3f1368649ae8fc8e',
                        real_password='111111',
                        real_name=real_name,
                        post_name=post_name,
                        school_id=school_id,
                        school_name=school_name,
                        manager_type=manager_type,
                        date_joined=int(time.time()),
                        status=0
                    )
                    ret_val, m = True, '成功:管理员权限账号已创建'
                else:
                    # 金币账号
                    if manager_num >= 2:
                        ret_val, m = False, '失败:金币权限账号已有两个'
                    else:
                        # 直接创建新账号
                        db.tbkt_manage.school_auth_user.create(
                            phone_number=phone_number,
                            username=phone_number + 'gly',
                            password='sha1$95718$93af5a5fa8b5a4a376e2a85e3f1368649ae8fc8e',
                            real_password='111111',
                            real_name=real_name,
                            post_name=post_name,
                            school_id=school_id,
                            school_name=school_name,
                            manager_type=manager_type,
                            date_joined=int(time.time()),
                            status=0
                        )
                        ret_val, m = True, '成功:金币权限或双权限账号已创建'
            return ret_val, m
        except Exception as e:
            import traceback
            traceback.print_exc()
            print e

    @staticmethod
    def remove_school_bond(data_sh):
        """
        功能:解绑学校的所有用户归属
        -----------------
        修改人:王建彬
        -----------------
        修改时间:2018-01-19
        """
        rows = data_sh.nrows
        school_list = []
        for r in range(1, rows):
            school_name = str(data_sh.row(r)[0].value).strip()
            school_data = call_proc("sp_get_school", ('', school_name))
            school_id = school_data[5] if school_data else ''
            if school_id:
                school_list.append(school_id)
        # 解除学校用户归属
        db.tbkt_manage.school_auth_user.filter(school_id__in=school_list).update(status=1)

    def loop_deal(self):
        """
        数据循环处理,每十分钟处理一次
        """
        while True:
            res_data = self.get_file()
            if res_data:
                self.deal_data(res_data)
                print "本次文件处理完成,休眠1分钟"
                time.sleep(60)
            else:
                print "没有相关文件处理,休眠1钟继续"
                time.sleep(60)


def start():
    """程序启动入口"""
    print "开始处理数据"
    pro = BatchDealManager()
    pro.loop_deal()
    print "结束处理数据"


if __name__ == "__main__":
    start()
elif __name__ == '__builtin__':
    print '__builtin__'
    reactor.callInThread(start)
    application = service.Application('batch_deal_upload_manager')