# coding:utf-8
"""
功能:同步课堂用户数据清理脚本
------------------------
时间:2017-11-29
------------------------
操作人:宋国洋
"""
from db_mysql import db


class UserForbidden(object):
	"""
	功能:禁用用户数据
	"""
	@staticmethod
	def forbidden_1():
		"""
		功能:禁用用户姓名为学科名,仅限当前是非开通状态的用户,且只针对学生用户
		"""
		# 禁用姓名为学科的用户账号
		code_name = ['语文', '数学', '英语', '物理', '化学']
		user_id_list = []
		for obj in code_name:
			sql = "SELECT id FROM tbkt_user.auth_user WHERE status !=2 AND type=1 AND real_name='%s';" % obj
			data_id = db.tbkt_user.fetchall(sql)
			data_user = [int(obj[0]) for obj in data_id if data_id]
			user_id_list += data_user
		return user_id_list
	
	@staticmethod
	def forbidden_2():
		"""
		功能:禁用用户姓名为手机号,仅限当前是非开通状态的用户,且只针对学生用户
		"""
		sql = "SELECT id FROM tbkt_user.auth_user WHERE status !=2 AND type=1 AND real_name=phone;"
		data_id = db.tbkt_user.fetchall(sql)
		user_id_list = [int(obj[0]) for obj in data_id if data_id]
		return user_id_list
	
	@staticmethod
	def forbidden_3():
		"""
		功能:禁用用户姓名为学生,仅限当前是非开通状态的用户,且只针对学生用户
		"""
		sql = "SELECT id FROM tbkt_user.auth_user WHERE status !=2 AND type=1 AND real_name LIKE '学生%';"
		data_id = db.tbkt_user.fetchall(sql)
		user_id_list = [int(obj[0]) for obj in data_id if data_id]
		return user_id_list
	
	@staticmethod
	def forbidden_4():
		"""
		功能:禁用用户姓名为空,仅限当前是非开通状态的用户,且只针对学生用户
		"""
		sql = "SELECT id FROM tbkt_user.auth_user WHERE status !=2 AND type=1 AND real_name = '';"
		data_id = db.tbkt_user.fetchall(sql)
		user_id_list = [int(obj[0]) for obj in data_id if data_id]
		return user_id_list
	
	@staticmethod
	def forbidden():
		"""
		功能:同一个手机号,有两个或两个以上的账号在相同班级,按照最后登录时间,保留最近登录账号,其余的禁用
		"""
		sql = "SELECT phone_number"
	
	def get_user_list(self):
		"""
		功能:获取所有待禁用的用户ID集
		"""
		user_1 = self.forbidden_1()
		user_2 = self.forbidden_2()
		user_3 = self.forbidden_3()
		user_4 = self.forbidden_4()
		user_id_list = user_1 + user_2 + user_3 + user_4
		return user_id_list
		

if __name__ == "__main__":
	c = UserForbidden()
	user_list = c.get_user_list()
	print len(user_list)