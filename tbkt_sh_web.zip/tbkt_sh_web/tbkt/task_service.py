#coding: utf-8
import datetime, os, time, sys
import MySQLdb
import simplejson as json

# 设置工作目录
sys_base_path = os.path.abspath(__file__)
print os.path.normpath(os.path.join(sys_base_path, '../..'))
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')

from twisted.internet import reactor
from twisted.application import service

from config import *

from sms.SMSInfo import SMSInfo

smsInfo = SMSInfo()


def get_students(uclass_id, subject_id=0, conn=None):
    """
    获得班级学生手机号. 若设置subject_id科目ID, 则只取已开通此科目学生的手机号.
    -------------------------------------------------
    修改人                     修改时间
    -------------------------------------------------
    王晨光                     2015-06-02
    """
    if subject_id:
        code = {2: 'A', 3: 'B', 4: 'C', 9: 'D'}.get(subject_id, '')
        sql = """
        select bind.user_id, bind.id, bind.order_id, bind.username, bind.password, bind.phone_number from ketang.mobile_order_region reg 
        inner join ketang.mobile_user_bind bind on bind.id=reg.user_bind_id and bind.type=1
        inner join ketang.mobile_subject sub on sub.order_id=bind.order_id and sub.code='%s' and sub.status in (2,9)
        where reg.unit_class_id=%s
        """ % (code, uclass_id)
    else:
        sql = """
        select bind.user_id, bind.id, bind.order_id, bind.username, bind.password, bind.phone_number from ketang.mobile_order_region reg
        inner join ketang.mobile_user_bind bind on bind.id=reg.user_bind_id and bind.type=1
        where reg.unit_class_id=%s
        """ % (uclass_id)
    cur = conn.cursor()
    cur.execute(sql)
    rows = cur.fetchall()
    return rows

def get_phone_number(conn, user_id):
    sql = """
    select phone_number from ketang.mobile_user_bind where user_id=%s
    """ % user_id
    cur = conn.cursor()
    cur.execute(sql)
    row = cur.fetchone()
    cur.close()
    return row[0] if row else ''

def send_pwd(conn, username, password, phone_number, order_id, bind_id, sender_phone=''):
    "下发帐号密码"
    sms_content = "您的同步课堂账号是:%s 密码是：%s" % (username, password)
    smsInfo.send_one(phone_number, sms_content, sender={'send_phone':sender_phone})
    now = datetime.datetime.now()
    sql = """
    INSERT INTO ketang.mp_account_record (order_id, bind_id, batch_id, username, password, phone_number, send_status, add_time, add_user_name, send_date)
    VALUES (%s, %s, 0, '%s', '%s', '%s', 1, "%s", '下发账号', '%s');
    """ %(order_id, bind_id, username, password, phone_number, now, now)
    cur = conn.cursor()
    r = cur.execute(sql)
    sql = "update ketang.mobile_user_bind set send_flag=1 where id=%s" % bind_id
    cur.execute(sql)
    cur.close()
    conn.commit()

def send_im(conn, user_ids, config_id, title, content, payload={}):
    """
    发推送消息
    --------------------
    2017-2-26   王晨光
    --------------------
    :param user_ids: [用户ID]
    :param config_id: 1Demo 2APP学生 3APP教师
    :param title: 消息标题
    :param content: 消息内容
    :param payload: 透传参数
    """
    messages = []
    nowt = int(time.time())
    for user_id in user_ids:
        if user_id:
            m = (user_id, config_id, 1, title, content, json.dumps(payload), 0, nowt, '', 0)
            messages.append(m)
    if messages:
        sql = """
        insert into tbkt_web.gt_message (user_id, config_id, template_type, title, content, transmission_content,
        push_status, add_time, return_value, success_time) values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cur = conn.cursor()
        cur.executemany(sql, messages)
        cur.close()
        conn.commit()

def handle(conn):
    print "开始处理", datetime.datetime.now()
    cur = conn.cursor()
    sql = """select id, sms_content, subject_id, add_user, is_sendpwd from tbkt.u_task where status=2 and begin_time <= now() limit 100"""
    cur.execute(sql)
    tasks = cur.fetchall()
    #print 'tasks', tasks
    for task in tasks:
        id, content, subject_id, add_user, is_sendpwd = task
        tea_phone = get_phone_number(conn, add_user)
        sql = "update tbkt.u_task set status=1 where id=%s" % id
        cur.execute(sql)
        conn.commit()
        
        sql = "select unit_class_id, type from tbkt.u_task_class where task_id=%s" % id
        cur.execute(sql)
        rows = cur.fetchall()
        phone_list = []
        user_ids = []
        for row in rows:
            uclass_id, type = row
            if type == 0:
                students = get_students(uclass_id, 0, conn)
            else:
                students = get_students(uclass_id, subject_id/10, conn)
            phone_list += [s[5] for s in students]
            user_ids += [s[0] for s in students if s[0]]
            # 逐个下发帐号密码
            if is_sendpwd:
                for user_id, bind_id, order_id, username, password, phone_number in students:
                    try:
                        send_pwd(conn, username, password, phone_number, order_id, bind_id, tea_phone)
                    except Exception, e:
                        print e
                        pass
        print 'phone_list:', phone_list
        # 发送作业短信
        try:
            smsInfo.send_many(phone_list, content, sender={'send_phone':tea_phone})
        except Exception, e:
            print e
            pass

        # send im
        send_im(conn, user_ids, 2, '新作业', '你的老师布置作业了,快来看看吧!', payload={'type':1})
    
    cur.close()


def loop():
    while 1:
        try:
            conn = get_ketang_conn()
            handle(conn)
            conn.close()
        except MySQLdb.OperationalError, e:
            print 'connect error!', e
        time.sleep(30)
    
    
if __name__ == "__main__":
    print 'main'
    loop()
    
elif __name__ == '__builtin__':
    print '__builtin__'
    reactor.callInThread(loop)
    application = service.Application('task_service')
