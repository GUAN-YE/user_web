# coding: utf-8
"""导江西知识点试题表, u_sx_knowledge_question"""
import time
from collections import OrderedDict

import sys; sys.path.insert(0, '..')
import base

class Worker:

    def __init__(self, dbname):
        self.default = base.connect(dbname)
        self.zy = self.default.dup(database='ziyuan_new')
        self.insert_buf = []

    def get_ck(self):
        """获得所有大小章节下的知识点"""
        sql = """
        select c.book_id, r.knowledge_id, c.path from ziyuan_new.sx_text_book_catalog_relate_knowledge r
        inner join ziyuan_new.sx_text_book_catalog c on c.id=r.catalog_id
        """
        rows = self.zy.fetchall(sql)
        ckmap = OrderedDict() # {cid:[kid]}
        cbmap = {} # {cid:book_id}
        for book_id, kid, path in rows:
            cids = map(int, path[1:-1].split('|'))
            for cid in cids:
                kids = ckmap.get(cid, [])
                kids.append(kid)
                ckmap[cid] = kids
                cbmap[cid] = book_id
        # 去重
        for cid, kids in ckmap.items():
            unikids = list(set(kids))
            if len(unikids) != len(kids):
                ckmap[cid] = unikids
        return ckmap, cbmap

    def get_kq(self, kids):
        """
        获取某一知识点范围的题目
        :return: {kid: qids}
        """
        kids_s = ','.join(str(i) for i in kids)
        sql = """
       select DISTINCT k.knowledge_id, q.id from ziyuan_new.sx_ask_relate_knowledge_new k
       inner join ziyuan_new.sx_question q on k.question_id = q.id and k.knowledge_id in (%s) and q.display_new = 1;
        """ % kids_s
        rows = self.zy.fetchall(sql)
        out = {}
        for kid, qid in rows:
            row = out.get(kid) or []
            row.append(qid)
            out[kid] = row
        for kid, qids in out.items():
            uniqids = list(set(qids))
            if len(uniqids) != len(qids):
                out[kid] = uniqids
        return out

    def insert(self, book_id, cid, kid, qids):
        if not qids:
            return
        qids_s = ','.join(str(i) for i in qids)
        nowt = int(time.time())
        arg = (book_id, cid, kid, qids_s, nowt)
        self.insert_buf.append(arg)

    def flush(self):
        if not self.insert_buf:
            return
        sql = """
        insert into tbkt_web.u_sx_knowledge_question_new (book_id, catalog_id, knowledge_id, question_ids, add_time)
        values (%s, %s, %s, %s, %s)
        """
        self.default.execute_many(sql, self.insert_buf)
        print 'flush', len(self.insert_buf)
        self.insert_buf = []

    def start(self):
        self.default.execute("truncate tbkt_web.u_sx_knowledge_question_new")
        ckmap, cbmap = self.get_ck()
        for cid, kids in ckmap.iteritems():
            kq = self.get_kq(kids)
            book_id = cbmap.get(cid)
            for kid in kids:
                qids = kq.get(kid) or []
                self.insert(book_id, cid, kid, qids)
                # 每100条写一次数据库
                if len(self.insert_buf) >= 100:
                    self.flush()
        self.flush()
        print 'finish!'

if __name__ == '__main__':
    worker = Worker('112')
    worker.start()