# coding: utf-8
"""
迁移运 系统返回2000积分
"""
import time
from db_config import get_db

db = get_db(250)

remark = "系统返回2000积分"


class Worker(object):

    @staticmethod
    def start(active_id):
        now = int(time.time())
        minid = 0
        psize = 200
        while 1:
            score = db.tbkt_active.active_score_user.filter(active_id=active_id, id__gt=minid)[:psize]
            if not score:
                break
            minid = score[-1].id
            score_details = []
            for i in score:
                d = dict(
                    user_id=i.user_id,
                    item_no="system_refund",
                    score=2000,
                    remark=remark,
                    add_date=now,
                    active_id=i.active_id,
                    add_username="system",
                    affix_info=""
                )
                score_details.append(d)
                db.tbkt_active.active_score_user.filter(id=i.id).update(score=i.score+2000)
                time.sleep(1)
            db.tbkt_active.active_score_user_detail.bulk_create(score_details, ignore=True)
            print "add score success active_id=%s, len=%s" % (active_id, len(score_details))
        print "over active=%s " % active_id

if __name__ == '__main__':
    Worker.start(1)
    Worker.start(2)
    Worker.start(3)
    Worker.start(4)
    Worker.start(5)
