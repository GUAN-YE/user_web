# coding=utf-8
import time
from twisted.internet import reactor
from twisted.application import service

from db_config import get_db

db = get_db(250)

user_ids = []

class Worker:
    def handler(self):
        tea_type_map = {1: 'tea_usual', 2: 'tea_paper', 4: 'tea_video', 5: 'tea_susuan'}
        remark_map = {1: u'发布日常作业，每天只统计一次', 2: u'发布试卷作业，每天只统计一次', 4: u'发布知识点视频，每天只统计一次', 5: u'发布速算作业，每天只统计一次'}
        db.tbkt_active.active_score_user_detail.filter(active_id=2, item_no='tea_usual', score__in=(10, 5)).update(
            item_no='stu_usual')
        db.tbkt_active.active_score_user_detail.filter(active_id=2, item_no='tea_paper', score__in=(10, 5)).update(
            item_no='stu_paper')
        db.tbkt_active.active_score_user_detail.filter(active_id=2, item_no='tea_susuan', score__in=(10, 5)).update(
            item_no='stu_susuan')
        db.tbkt_active.active_score_user_detail.filter(active_id=2, item_no='tea_video', score__in=(10, 5)).update(
            item_no='stu_video')

        sql = """SELECT add_user user_id,DATE(FROM_UNIXTIME(add_time)) add_date,`type` ,add_time FROM tbkt_shuxue.sx_task
                        where begin_time>=1506614400 AND `type` IN (1,2,4,5) AND status=1"""
        rows = db.tbkt_yingyu.fetchall_dict(sql)
        for task_info in rows:
            _no = tea_type_map.get(task_info.type)
            remark = remark_map.get(task_info.type)

            sql = """select 1 from tbkt_active.active_score_user_detail  where active_id=2 and user_id=%s and item_no='%s' and
                            DATE(FROM_UNIXTIME(add_date))='%s'""" % (task_info.user_id, _no, task_info.add_date)
            detail = db.tbkt_yingyu.fetchone(sql)
            if not detail:
                self.add_score(task_info.user_id, _no, remark, task_info.add_time)

    def add_score(self, user_id, item_no, remark, add_date):
        with db.tbkt_active as da:
            tea_score = da.active_score_user.get(user_id=user_id, active_id=2)
            if not tea_score:
                return
            a_score = 100 if item_no != 'tea_video' else 200
            score = tea_score.score + a_score
            da.active_score_user.filter(user_id=user_id, active_id=2).update(score=score)
            da.active_score_user_detail.create(
                user_id=user_id,
                item_no=item_no,
                score=a_score,
                active_id=2,
                remark=remark,
                add_username=user_id,
                add_date=add_date,
                affix_info=''
            )
        print 'add_score:%s' % item_no
        user_ids.append(user_id)

    def start(self):
        # try:
        self.handler()
        # except Exception, e:
        #     print e
        print 'update done user_ids=%s' % user_ids


if __name__ == '__main__':
    worker = Worker()
    worker.start()

elif __name__ == '__builtin__':
    print '__builtin__'
    worker = Worker()
    reactor.callInThread(worker.start)
    application = service.Application('active_revise_service')
