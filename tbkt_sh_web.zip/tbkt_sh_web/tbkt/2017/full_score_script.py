# coding: utf-8
import json
from collections import Counter, defaultdict

import time

import datetime

from db_config import get_db, source, Struct
from twisted.application import service
from twisted.internet import reactor

db = get_db(1)
zy = source()


def get_task_text():
    min_id = 25756381
    qids = []
    total = []
    while 1:
        today = datetime.datetime.today()
        hour = range(0, 5)
        hour.append(23)
        if today.hour not in hour:
            time.sleep(200)
            continue
        data = db.tbkt_shuxue.sx_task_test_detail.select("text", "id").filter(id__gt=min_id)[:1000]
        if not data:
            break
        min_id = data[-1].id
        for i in data:
            try:
                txt = map(Struct, json.loads(i.text))
                for t in txt:
                    if t.result == 0:
                        qids.append(t.qid)
                    total.append(t.qid)

                if len(qids) >= 50:
                    print min_id, len(qids)
                    get_kid(dict(Counter(qids)), dict(Counter(total)))
                    qids = []
                    total = []
            except:
                continue


def get_kid(qid_stat, total):
    print total
    data = zy.ziyuan_new.sx_ask_relate_knowledge.select("knowledge_id", "question_id")\
        .filter(question_id__in=qid_stat.keys()).group_by("knowledge_id")[:]
    if not data:
        return
    k = []
    queston_id = []
    for i in data:
        if i.question_id in qid_stat:
            a = (i.knowledge_id, i.question_id, qid_stat.get(i.question_id, 0), total.get(i.question_id, 0))
            queston_id.append(i.question_id)
            k.append(a)

    if not k:
        return

    added = db.tbkt_active.full_score_source.select("id", "qid").filter(qid__in=queston_id)[:]
    added_map = {i.qid: i.id for i in added}

    create_data = []
    for kid, qid, count, total_num in k:
        if qid in added_map:
            add_id = added_map.get(qid)
            if not add_id:
                continue
            add = db.tbkt_active.full_score_source.select("count", "total").filter(id=add_id)
            if not add:
                continue
            add.update(count=add[0].count+count, total=add[0].total+total_num)

        else:
            create_data.append(
                dict(
                    kid=kid,
                    qid=qid,
                    count=count,
                    total=total_num,
                    add_time=int(time.time())
                ))
    if create_data:
        db.tbkt_active.full_score_source.bulk_create(create_data)

if __name__ == '__main__':
    get_task_text()

elif __name__ == '__builtin__':
    print '__builtin__'
    reactor.callInThread(get_task_text)
    application = service.Application('full_score_script')
