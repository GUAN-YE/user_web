# coding=utf-8
import datetime
import time

from twisted.application import service
from twisted.internet import reactor

from db_config import get_db

db = get_db(250)


def month_first_day():
    first_day = datetime.date(datetime.date.today().year, datetime.date.today().month, 1)
    time_array = time.strptime(str(first_day), "%Y-%m-%d")
    return int(time.mktime(time_array))


def active_back(no):
    """
    Returns:
    """
    sql = """
    select sum(c.lottery_join_num) lot_num, sum(c.sign_gold) gold, u.add_time, u.type, u.user_id, c.id, c.name
    from excita_config c inner join excita_sign_up u on  c.id = u.excita_id 
    and u.batch_id = 0 and c.status = 0 and c.id in (13) group by user_id, type, c.id;
    """
    # 按照活动奖品id 用户id 报名类型 分组排名
    rows = db.tbkt_active.fetchall_dict(sql)

    if not rows:
        return True

    gold = []  # 金币返回数组
    lot = []   # 抽奖券返回数组
    for i in rows:
        if i.type == 1:
            # 金币报名
            d = dict(
                user_id=i.user_id,
                num=i.gold,
                act_id=i.id,
                name=i.name
            )
            gold.append(d)
        elif i.type == 2:
            # 抽奖券报名
            if i.add_time < month_first_day():
                # 抽奖券每月清空
                continue
            d = dict(
                user_id=i.user_id,
                num=i.lot_num,
                act_id=i.id
            )
            # lot.append(d)

    for i in gold:
        user_id = i.get("user_id")
        num = i.get("num")
        act_id = i.get("act_id")
        name = i.get("name")
        if not user_id or not num or not act_id:
            continue
        back_gold(user_id, num, act_id, name)

    for k in lot:
        user_id = k.get("user_id")
        num = k.get("num")
        act_id = k.get("act_id")
        if not user_id or not num or not act_id:
            continue
        # back_lot(user_id, num, act_id)


def back_gold(user_id, num, act_id, award_name):
    # 返回金币
    now = int(time.time())
    score = db.tbkt_com.score_user.get(user_id=user_id, app_id=7)
    if not score:
        return
    db.tbkt_active.excita_sign_up.filter(user_id=user_id, excita_id=act_id, batch_id=0).update(batch_id=-1)
    with db.tbkt_com as dc:
        remark = u'"%s"活动报名费用返还' % award_name
        dc.score_user_detail.create(
            user_id=user_id,
            item_no="tea_voucher_bak",
            score=num,
            cycle_num=1,
            remark=remark,
            add_date=now,
            app_id=7,
        )
        dc.score_user.filter(id=score.id).update(score=score.score+num)
        print "system back gold user_id=%s, num=%s" % (user_id, act_id)


def back_lot(user_id, num, act_id):
    # 返回抽奖券
    now = int(time.time())
    score = db.tbkt_active.excita_lottery.get(user_id=user_id)
    if not score:
        return
    remark = "活动结束返还奖券, act_id=%s" % act_id
    with db.tbkt_active as dc:
        if dc.excita_lottery.filter(user_id=user_id, remark=remark).exists():
            return
        dc.excita_lottery.filter(id=score.id).update(num=score.num+num)
        dc.excita_lottery_detail.create(
            user_id=user_id,
            type=2,
            num=num,
            remark=remark,
            add_time=now
        )
        print "system back lot user_id=%s, num=%s" % (user_id, act_id)


def start():
    no = 1
    while 1:
        status = active_back(no)
        if not status:
            no += 1
        else:
            print "not data sleep 2000 ms"
            time.sleep(2000)
            no = 1
        print "current page_no=%s" % no


if __name__ == "__main__":
    no = 1
    status = active_back(no)

elif __name__ == '__builtin__':
    print '__builtin__'
    reactor.callInThread(start)
    application = service.Application('excita_active_back')