#coding: utf-8
"""驰声录音同步(sink)到本地"""
import sys
import os
import time
import requests
import simplejson as json
import hashlib
import datetime
import pymysql
from db import Hub

UPLOAD_FILE_KEY_VALUE = 'bannei_upload'

from twisted.internet import reactor
from twisted.application import service

from db_config import get_db
db = get_db(250)

# # 本地新库
# db.add_pool('tbkt_yingyu',
#     host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_yingyu',
#     charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
# )

def create_upload_key():
    now = datetime.datetime.now()
    m = hashlib.md5()
    m.update('%s%s' % (UPLOAD_FILE_KEY_VALUE, now.strftime("%Y%m%d")))
    return m.hexdigest()

class Worker:

    def get_jobs(self, id, id1):
        # 找到未经转变的数据
        return db.tbkt_yingyu.yy_study_detail.filter(is_change=0, id__range=(id, id1)).select('id', 'text')
        #.order_by('-id')[:n]

    def readfile(self, url):
        url = url.strip()
        if not url:
            return
        if not url.startswith('http'):
            url = 'http://' + url
        try:
            r = requests.get(url)
            return r.content
        except Exception, e:
            print 'READFILE ERROR)', e
            return

    def upload(self, url, data):
        try:
            fn = url.rsplit('/', 1)[1]
            files = {'file': (fn, data)}
            upload_key = create_upload_key()
            up_url = 'http://upload.m.xueceping.cn/swf_upload/?upType=yy&upcheck=%s' % upload_key
            r = requests.post(up_url, files=files)
            text = r.text.replace("'", '"')
            results = json.loads(text)
            return results[0]['file_url']
        except Exception, e:
            print 'UPLOAD ERROR)', e

    def handle(self, id, id1):
        jobs = self.get_jobs(id, id1)
        for job in jobs:
            text = json.loads(job.text)
            for obj in text:
                data = self.readfile(obj['remote_audio'])
                if not data:
                    # 如果读取失败就清空远程地址
                    obj['remote_audio'] = ''
                    continue
                fn = self.upload(obj['remote_audio'], data)
                if not fn:
                    continue
                obj['local_audio'] = fn
            db.tbkt_yingyu.yy_study_detail.filter(id=job.id).update(text=json.dumps(text), is_change=1)
            print 'UPLOAD OK)', job.id
        return len(jobs)

    def get_count(self):
        """查询表中所有数据"""
        return db.tbkt_yingyu.yy_study_detail.filter().count()

    def start(self):
        while 1:
            num1 = self.get_count()
            num = 1
            print "all_num", num1
            while 1:
                n = self.handle(num, num+200)
                num = num + 200
                print "id", num, num1
                # 一次扫描结束后
                if num >= num1:
                    print "11111"
                    break
                # if n <= 0:
                #     print '.'
                #     time.sleep(10)
            print "sleep 1h ok"
            time.sleep(60*60)
            # 一小时扫描一次

def main(dbname=''):
    worker = Worker()
    worker.start()

if __name__ == '__main__':
    main('130jx')

elif __name__ == '__builtin__':
    # application = base.twisted_run(main, app_name='yy_audio_sink')
    print '__builtin__'
    worker = Worker()
    reactor.callInThread(worker.start)
    application = service.Application('yy_audio_sink')
