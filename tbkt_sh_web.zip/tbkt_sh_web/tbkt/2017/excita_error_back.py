# coding=utf-8
import datetime
import time

from twisted.application import service
from twisted.internet import reactor

from db_config import get_db

db = get_db(250)


def month_first_day():
    first_day = datetime.date(datetime.date.today().year, datetime.date.today().month, 1)
    time_array = time.strptime(str(first_day), "%Y-%m-%d")
    return int(time.mktime(time_array))


def active_back(no):
    """
    Returns:
    """
    sql = """
    select c.sign_gold*(count(1) - 1) gold, u.add_time, u.type, u.user_id, c.id, count(1) - 1
    from excita_config c inner join excita_sign_up u on  c.id = u.excita_id 
    and u.batch_id = 0 and c.status = 0 GROUP BY user_id, c.id HAVING count(1) > 1;
    """
    rows = db.tbkt_active.fetchall_dict(sql)

    if not rows:
        return True

    gold = []
    for i in rows:
        if i.type == 1:
            d = dict(
                user_id=i.user_id,
                num=i.gold,
                act_id=i.id
            )
            gold.append(d)

    for i in gold:
        user_id = i.get("user_id")
        num = i.get("num")
        act_id = i.get("act_id")
        if not user_id or not num or not act_id:
            continue
        back_gold(user_id, num, act_id)


def back_gold(user_id, num, act_id):
    now = int(time.time())
    score = db.tbkt_com.score_user.get(user_id=user_id, app_id=7)
    if not score:
        return
    with db.tbkt_com as dc:
        dc.score_user.filter(id=score.id).update(score=score.score+num)
        dc.score_user_detail.create(
            user_id=user_id,
            item_no="tea_voucher_bak",
            score=num,
            cycle_num=1,
            remark="教师抽奖活动未开奖报名费用返回",
            add_date=now,
            affix_info=act_id,
            app_id=7,
        )
        print "system back gold user_id=%s, num=%s" % (user_id, act_id)


def start():
    no = 1
    while 1:
        status = active_back(no)
        if not status:
            no += 1
        else:
            print "not data sleep 2000 ms"
            time.sleep(2000)
            no = 1
        print "current page_no=%s" % no


if __name__ == "__main__":
    status = active_back(0)

elif __name__ == '__builtin__':
    print '__builtin__'
    reactor.callInThread(start)
    application = service.Application('excita_active_back')