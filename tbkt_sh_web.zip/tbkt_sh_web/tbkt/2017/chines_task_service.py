#coding: utf-8
"""
作业服务
"""
import datetime, requests
import json
import time
import random
import hashlib
import base64
from db_config import get_db

from twisted.internet import reactor
from twisted.application import service

db = get_db(250)
# sx_task status = 1/2  正常/定时
# sx_task is_sendpwd 0/1是否下发短信
# sx_task_class


SMS_URL = 'http://sms.m.tbkt.cn/sms/send'

RESTARTFLAG = False

class Worker:

    def handler(self):
        now = int(time.time())
        begin_time = now - 60 * 30

        # 更新2天外的作业状态， 只修改状态，不做下步操作
        global RESTARTFLAG
        if RESTARTFLAG:
            self.update_2_task(begin_time)
            RESTARTFLAG = False
        task = db.tbkt_yuwen.yw_task_new.filter(status=0, begin_time__gte=begin_time).select('id', 'begin_time').order_by('begin_time')[:50]
        db.tbkt_yuwen.yw_task_new.filter(status=0, begin_time__lt=begin_time).update(status=1)

        print task
        update_task_ids = []

        for t in task:
            if int(t.begin_time) <= now:
                update_task_ids.append(t.id)

        if update_task_ids:
            # 更新作业状态
            print 'start update sx task'
            db.tbkt_yuwen.yw_task_new.filter(id__in=update_task_ids, status__ne=-1).update(status=1)
            db.tbkt_yuwen.yw_task_class_new.filter(task_id__in=update_task_ids, status__ne=-1).update(status=1)

            task_ids = ','.join(str(i) for i in update_task_ids)

            sql = """
            select c.unit_class_id, t.title, t.id, c.is_all, c.is_password, t.add_user
            from yw_task_new t, yw_task_class_new c
            where t.id = c.task_id and t.id in (%s) and c.status != -1
            """ % task_ids
            print 'start select sx task info'
            rows = db.tbkt_yuwen.fetchall_dict(sql)

            for r in rows:
                if not r.unit_class_id:
                    # 作业必须要班级id
                    continue

                # mor = db.tbkt_ketang.mobile_order_region.get(user_id=r.add_user)
                # if mor.city == '411400':
                #     # 屏蔽商丘短信功能
                #     continue

                stu_ids = self.get_class_student(r.unit_class_id)

                if not stu_ids:
                    # 班级没有学生
                    continue

                if r.is_all == 0:
                    # 仅发给开通学科学生
                    stu_ids = self.get_unit_open_stu(stu_ids)

                if stu_ids:
                    # 发送短信
                    self.send_sms(stu_ids, r.title)
                    # 发送个推信息
                    self.send_im(stu_ids)

                if r.is_password == 1:
                    # 下发账号密码
                    self.send_pwd(stu_ids)

    @staticmethod
    def update_2_task(timeStamp):
        """更新2天外的作业状态， 只修改状态，不做下步操作"""
        print "update_2_task"
        if db.tbkt_yuwen.yw_task_new.filter(status=2, begin_time__lte=timeStamp).exists():
            db.tbkt_yuwen.yw_task_new.filter(status=2, begin_time__lte=timeStamp).update(status=1)

    @staticmethod
    def get_unit_open_stu(user_ids):
        # 获取班级下开通学生
        now = int(time.time())
        ids = ','.join(str(i) for i in user_ids)
        sql = """
        select user_id from mobile_subject t 
        where t.user_id in (%s) and t.subject_id = 5 and t.open_date <= %s
        and (t.cancel_date <=0 or t.cancel_date > %s)
        """ % (ids, now, now)
        rows = db.tbkt_ketang.fetchall(sql)
        return [i[0] for i in rows if i[0]]

    @staticmethod
    def get_class_student(unit_id):
        # 获取班级学生信息
        return db.tbkt_ketang.mobile_order_region.filter(unit_class_id=unit_id, user_type=1, is_update=0).flat('user_id')[:]

    @staticmethod
    def send_sms(user_ids, content):
        # 发送作业短信
        ids = ','.join(str(i) for i in user_ids)
        data = dict(user_id=ids,
                    content=content)
        requests.post(SMS_URL, data=data)
        print 'send sms'

    def send_pwd(self, user_ids):
        # 下发账号密码
        ids = ','.join(str(i) for i in user_ids)
        sql = """
        SELECT u.id, u.username, p.password, u.phone FROM auth_profile p, auth_user u
        where p.user_id = u.id and p.user_id in (%s);
        """ % ids
        rows = db.tbkt_user.fetchall_dict(sql)
        print 'send pwd'
        for i in rows:
            # 解析密码
            password = self.decode_pwd(i.password)
            if not password:
                continue
            sms_content = u"您的同步课堂账号是:%s 密码是：%s,做作业(除数学知识点视频作业外)功能免费，请放心使用。" \
                          u"客户端点此m.tbkt.cn下载安装。咨询电话：12556185" % (i.username, password)
            # print sms_content
            requests.post(SMS_URL, data={'phone': i.phone, 'content': sms_content})

    @staticmethod
    def send_im(user_ids):
        # 发送im消息
        messages = []
        nowt = int(time.time())
        for user_id in user_ids:
            if user_id:
                m = {
                    'user_id': user_id,
                    'config_id': 2,
                    'template_type': 1,
                    'title': '新作业1',
                    'content': '你的老师布置作业了,快来看看吧!',
                    'transmission_content': json.dumps({'type': 1}),
                    'push_status': 0,
                    'add_time': nowt,
                    'return_value': '',
                    'success_time': 0
                }
                messages.append(m)
        if messages:
            print 'create im'
            db.tbkt_com.gt_message.bulk_create(messages)

    @staticmethod
    def decode_pwd(pwd):
        # 返回明文密码
        try:
            return base64.b64decode(pwd)
        except:
            return ''

    def start(self):
        while 1:
            try:
                self.handler()
            except Exception,e:
                print e
            time.sleep(5)


if __name__ == '__main__':
    RESTARTFLAG = True
    worker = Worker()
    worker.start()

elif __name__ == '__builtin__':
    print '__builtin__'
    RESTARTFLAG = True
    worker = Worker()
    reactor.callInThread(worker.start)
    application = service.Application('chines_task_service')
