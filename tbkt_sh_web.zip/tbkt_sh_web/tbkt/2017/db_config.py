# coding: utf-8
import pymysql
from db import Hub

db = Hub(pymysql)
databases = ['tbkt_com', 'tbkt_ketang', 'tbkt_user', 'tbkt_shuxue', 'tbkt_yingyu', 'tbkt_yuwen','tbkt_active', 'tbkt_weixin', 'tbkt_operate', 'tbkt_yw']


def get_db(args):
    # 获取不同环境数据库连接
    # 默认本地250
    port = 3306

    # host = '122.114.40.76'
    # user = 'renwanxing'
    # password = 'ohStjN6DKXqdfBAfhGzdz'

    # host = '192.168.0.111'
    # user = 'duzuyong'
    # password = 'ohStjN6DK$XqBAfhGzdz'

    # 阿里云数据库配置
    # host = 'rm-2ze7fsacj5q360kt7o.mysql.rds.aliyuncs.com'
    host = 'rm-2ze7fsacj5q360kt7.mysql.rds.aliyuncs.com'
    user = 'tbkt_sh_user'
    password = 'shSCriPT@!2017TbKt'


    # host = '122.114.40.76'
    # user = 'renwanxing'
    # password = 'ohStjN6DKXqdfBAfhGzdz'

    # host = 'rm-2zekkuf62c6477n70o.mysql.rds.aliyuncs.com'
    # user = 'wangshicheng'
    # password = 'wangshicheng@123'

    for table in databases:
        db.add_pool(table,
                    host=host,
                    port=port,
                    user=user,
                    passwd=password,
                    db=table,
                    charset='utf8',
                    autocommit=True,
                    pool_size=16,
                    wait_timeout=29)
    return db


def source():
    host = 'rr-2zewk88p8mu5c3m40.mysql.rds.aliyuncs.com'
    user = 'jx_tbkt_zy'
    password = 'fPhTisS3DvTZZgD'
    port = 3306

    db.add_pool("ziyuan_new",
                host=host,
                port=port,
                user=user,
                passwd=password,
                db="ziyuan_new",
                charset='utf8',
                autocommit=True,
                pool_size=16,
                wait_timeout=29)
    return db


class Struct(dict):
    """
    - 为字典加上点语法. 例如:
    >>> o = Struct({'a':1})
    >>> o.a
    >>> 1
    >>> o.b
    >>> None
    """
    def __init__(self, *e, **f):
        if e:
            self.update(e[0])
        if f:
            self.update(f)

    def __getattr__(self, name):
        # Pickle is trying to get state from your object, and dict doesn't implement it.
        # Your __getattr__ is being called with "__getstate__" to find that magic method,
        # and returning None instead of raising AttributeError as it should.
        if name.startswith('__'):
            raise AttributeError
        return self.get(name)

    def __setattr__(self, name, val):
        self[name] = val

    def __delattr__(self, name):
        self.pop(name, None)

    def __hash__(self):
        return id(self)