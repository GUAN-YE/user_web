# coding:utf8
import time

from db_config import get_db


# 1、先从auth_user表中读取到这写dept_id 不为 1，或2 的数据 一次取10条，直至没有
# 2、根据用户id查询用户班级判断年级，判断出正确的dept_id
# 3、修改用户正确的dept_id 入库
# unit_class_id--mobile_order_region
# school_unit_class--tbkt_com

page_size = 500

db = get_db(1)


def user_info(maxid, minid):
    sql = """
    select id user_id, dept_id from auth_user where id > %s and id <= %s and dept_id in (127, 0);
    """ % (minid, maxid)
    rows = db.tbkt_user.fetchall_dict(sql)
    user_ids = [i.user_id for i in rows]
    if not user_ids:
        return

    sql = """
    select r.user_id, class.type type from tbkt_ketang.mobile_order_region r inner join  tbkt_com.school_unit_class class
    on r.unit_class_id = class.id and r.user_id in (%s) group by r.user_id
    """ % ",".join(str(i) for i in user_ids)
    class_rows = db.tbkt_ketang.fetchall_dict(sql)

    class_map = {i.user_id: i.type for i in class_rows}
    update_args = []
    for i in rows:
        dept_id = class_map.get(i.user_id, 1)
        update_args.append((dept_id, i.user_id))

    if update_args:
        update_sql = """
        update tbkt_user.auth_user set dept_id = %s where id = %s 
        """
        db.tbkt_user.execute_many(update_sql, update_args)
    print "update success %s" % len(update_args)
    return


if __name__ == '__main__':
    rows = db.tbkt_user.auth_user.select("max(id) max_id").first()
    max_id = rows.max_id
    no = 1
    while 1:
        maxid = no * 500
        minid = (no - 1) * 500
        user_info(maxid, minid)
        no += 1
        print "maxid=", maxid, "minid=", minid
        time.sleep(0.1)
        # break
        if max_id <= maxid:
            break
