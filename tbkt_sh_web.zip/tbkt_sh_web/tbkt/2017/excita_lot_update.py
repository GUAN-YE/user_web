# coding=utf-8
import datetime
import time

from twisted.application import service
from twisted.internet import reactor

from db_config import get_db

db = get_db(250)


def get_month_first_day():
    return datetime.date(datetime.date.today().year, datetime.date.today().month, 16)


def get_table_max_month():
    data = db.tbkt_active.excita_lottery.select("month").order_by("-add_time").first()
    if data:
        return data.month
    return datetime.datetime.today().month


def update(month):
    page_no = 1
    while 1:
        min_id = page_no * 200
        max_id = (page_no - 1) * 200

        sql = """
        update excita_lottery set month = %s, num = 0 where id > %s and id <= %s 
        """ % (month, max_id, min_id)
        rows_num, _ = db.tbkt_active.execute(sql)

        if not rows_num:
            break
        page_no += 1
        print "update success num=%s" % rows_num
    return True


def start():
    lastd = datetime.date.today()
    while 1:
        today = get_month_first_day()
        if lastd == today:
            update(today.month)
        else:
            print "today not equal to month_first_day sleep 1000"
            time.sleep(1000)
        lastd = datetime.date.today() + datetime.timedelta(days=1)


if __name__ == "__main__":
    start()

elif __name__ == '__builtin__':
    print '__builtin__'
    reactor.callInThread(start)
    application = service.Application('winter_service')




