# coding=utf-8
import calendar
import datetime
import time

from twisted.application import service
from twisted.internet import reactor

from db_config import get_db

db = get_db(250)


def month_first_day():
    first_day = datetime.date(datetime.date.today().year, datetime.date.today().month, 1)
    time_array = time.strptime(str(first_day), "%Y-%m-%d")
    return int(time.mktime(time_array))


def update(no):
    sql = """
    select count(id) send_num, add_user from tbkt_com.message 
    where begin_time >= %s and type in (2, 7, 8, 9, 101) and status = 1 
    group by add_user limit %s, %s
    """ % (month_first_day(), (no - 1) * 50, no*50)
    # 批次获得教师发作业测试
    rows = db.tbkt_com.fetchall_dict(sql)
    if not rows:
        return True

    for i in rows:
        if i.send_num == 0:
            # 未发送作业
            continue
        # 增加邀请判断
        add_invite(i.add_user)
        if i.send_num <= 4:
            # 作业小于4次 不增加奖券
            continue
        add_log(i.add_user, i.send_num)


def add_log(user_id, num):
    today = datetime.datetime.today()
    now = int(time.time())
    with db.tbkt_active as dt:
        detail = dt.excita_lottery_detail.select("id", "send_task_num")\
            .filter(user_id=user_id, type=2, send_task_num__gt=0,
                    add_time__range=get_month_first_last()).order_by("-send_task_num").first()

        if not detail:
            add_num = num - 4
            if add_num >= 5:
                add_num = 5
        else:
            send_num = detail.send_task_num
            if send_num > 9:
                return

            if send_num == num:
                return
            # num = 用户此时发作业次数
            # send_num = 已发抽奖券作业统计数量
            # 用户应算发作业次数
            if num <= 4:
                return
            # 判断是否大于5   大于5 强制转为5 规则限制  最多五张 小于等于4  不满足发抽奖券
            data = num - 4
            if data >= 5:
                data = 5
            # 用户不算发作业次数
            if send_num <= 4:
                return
            add_num = send_num - 4  # 小于等于4  用户未发抽奖券 大于4  用户已发抽奖券数量
            add_num = data - add_num   # 用户应得抽奖券 - 用户以得抽奖券 = 用户改得抽奖券

        if add_num <= 0:
            return
        user = dt.excita_lottery.get(user_id=user_id, month=today.month)
        if not user:
            dt.excita_lottery.create(
                user_id=user_id,
                num=add_num,
                month=today.month,
                add_time=now
            )
        else:
            if user.num < 0:
                lot_num = 0
            else:
                lot_num = user.num+add_num
            dt.excita_lottery.filter(id=user.id).update(num=lot_num)

        dt.excita_lottery_detail.create(
            user_id=user_id,
            type=2,
            num=add_num,
            remark="发作业奖励",
            add_time=now,
            send_task_num=num
        )
        print "add lot user_id=%s lot_num=%s" % (user_id, add_num)


def add_invite(user_id):
    inv = db.tbkt_active.excita_invite_tea.get(add_time__gte=month_first_day(), invite_user_id=user_id)
    if not inv:
        return
    if inv:
        if inv.is_add == 0:
            if db.tbkt_com.message.get(add_user=user_id, begin_time__gte=inv.add_time, type__in=(2, 7, 8, 9, 101)):
                add_lot(user_id, 1)
                add_lot(inv.user_id, 1)
                db.tbkt_active.excita_invite_tea.filter(id=inv.id).update(is_add=1)
                print "inv tea add num"
    return 0


def add_lot(user_id, num):
    today = datetime.datetime.today()
    now = int(time.time())
    with db.tbkt_active as dt:
        user = dt.excita_lottery.get(user_id=user_id, month=today.month)
        if not user:
            dt.excita_lottery.create(
                user_id=user_id,
                num=num,
                month=today.month,
                add_time=now
            )
        else:
            dt.excita_lottery.filter(id=user.id).update(num=user.num + 1)

        dt.excita_lottery_detail.create(
            user_id=user_id,
            type=2,
            num=num,
            remark="邀请老师奖励1张奖券",
            add_time=now,
            send_task_num=0
        )


def get_month_first_last(year=None, month=None):
    """
    :param year: 年份，默认是本年，可传int或str类型
    :param month: 月份，默认是本月，可传int或str类型
    :return: firstDay: 当月的第一天，datetime.date类型
              lastDay: 当月的最后一天，datetime.date类型
    """
    if year:
        year = int(year)
    else:
        year = datetime.date.today().year

    if month:
        month = int(month)
    else:
        month = datetime.date.today().month

    # 获取当月第一天的星期和当月的总天数
    first_day_week_day, month_range = calendar.monthrange(year, month)

    # 获取当月的第一天
    first_day = datetime.date(year=year, month=month, day=1)
    last_day = datetime.date(year=year, month=month, day=month_range)

    return str_time_to_stamp(str(first_day)), str_time_to_stamp(str(last_day)) + 86399


def str_time_to_stamp(str_time):
    time_array = time.strptime(str_time, "%Y-%m-%d")
    return int(time.mktime(time_array))


def start():
    print get_month_first_last()
    no = 1
    while 1:
        status = update(no)
        if not status:
            no += 1
        else:
            print "not data sleep 2000 ms"
            time.sleep(60*5)
            no = 1
        print "current page_no=%s" % no


if __name__ == "__main__":
    start()

elif __name__ == '__builtin__':
    print '__builtin__'
    reactor.callInThread(start)
    application = service.Application('excita_task')

