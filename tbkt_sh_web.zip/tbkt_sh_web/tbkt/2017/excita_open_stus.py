# coding=utf-8
import datetime
import time
from collections import defaultdict

from twisted.application import service
from twisted.internet import reactor

from db_config import get_db

db = get_db(250)


def month_first_day():
    first_day = datetime.date(datetime.date.today().year, datetime.date.today().month, 1)
    time_array = time.strptime(str(first_day), "%Y-%m-%d")
    return int(time.mktime(time_array))


def active_excita_stu():
    # 读取老师邀请信息
    min_id = 0
    p_size = 50
    while 1:
        invites = db.tbkt_active.excita_invite_open.select("user_id", "stu_user_id").filter(
            id__gt=min_id, is_open=0, add_time__gte=month_first_day())[:p_size]

        if not invites:
            print "not data sleep 1000"
            time.sleep(1000)
            continue

        min_id = invites[-1].id
        open_map = defaultdict(list)
        for i in invites:
            open_map[i.user_id].append(i.stu_user_id)
        if open_map:
            user_open_info(open_map)


def user_open_info(open_map):
    # 用户开通信息
    if not open_map:
        return
    for tea_id,  stu_list in open_map.iteritems():
        if not tea_id or not stu_list:
            return
        now = int(time.time())
        sql = """
        select user_id from mobile_subject 
        where user_id in (%s) and subject_id in (2,5,9) and open_date >= %s
        and (cancel_date <=0 or cancel_date > %s) group by user_id
        """ % (','.join(str(i) for i in stu_list), month_first_day(), now)

        rows = db.tbkt_ketang.fetchall_dict(sql)
        if not rows:
            return

        args = []
        for i in rows:
            args.append((tea_id, i.user_id))

        if args:
            sql = """
            update excita_invite_open set is_open = 1 
            where user_id = %s and stu_user_id = %s
            """
            print args
            db.tbkt_active.execute_many(sql, args)

            today = datetime.datetime.today()
            tea_lot = db.tbkt_active.excita_lottery.filter(user_id=tea_id, month=today.month)
            if tea_lot:
                tea_lot.update(num=tea_lot[0].num + len(rows))
            else:
                db.tbkt_active.excita_lottery.create(
                    user_id=tea_id,
                    num=len(rows),
                    month=today.month,
                    add_time=now
                )
            remark = "%s月份邀请%s名学生开通获得%s张奖券" % (today.month, len(stu_list), len(rows))
            db.tbkt_active.excita_lottery_detail.create(
                user_id=tea_id,
                type=1,
                num=len(rows),
                remark=remark,
                add_time=now
            )
            print "update success open=%s, tea_id=%s" % (len(rows), tea_id)


def join(o):
    if isinstance(o, (list, tuple)):
        return ','.join(str(i) for i in o)
    return str(o)


if __name__ == "__main__":
    print active_excita_stu()


elif __name__ == '__builtin__':
    print '__builtin__'
    reactor.callInThread(active_excita_stu)
    application = service.Application('excita_open_stu')

