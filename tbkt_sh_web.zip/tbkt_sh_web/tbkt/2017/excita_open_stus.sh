#! /usr/bin/env sh
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/excita_open_stus.py
logfile=/var/log/excita_open_stus.log
case $1 in
    start)
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/excita_open_stus.pid --logfile=$logfile
        ;;
    stop)
        kill -9 `cat /var/run/excita_open_stus.pid`
        ;;
    restart)
        kill -9 `cat /var/run/excita_open_stus.pid`
        sleep 1
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/excita_open_stus.pid --logfile=$logfile
        ;;
    log)
        tail -f $logfile
        ;;
    *)
        echo "Usage: ./excita_open_stus.sh start | stop | restart | log"
        ;;
esac