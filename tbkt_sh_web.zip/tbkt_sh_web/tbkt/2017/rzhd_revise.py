# coding: utf-8
"""
汝州活动修正
"""
import time
from db_config import get_db

from twisted.internet import reactor
from twisted.application import service

db = get_db(250)


def get_open_status(user_ids):
    mslist = db.tbkt_ketang.mobile_subject.filter(
        user_id__in=user_ids, subject_id=9).select('user_id', 'open_date', 'cancel_date')[:]
    stu_map = {}
    nowt = int(time.time())
    for m in mslist:
        status = 1 if nowt >= m.open_date and (m.cancel_date <= 0 or nowt < m.cancel_date) and m.open_date > 0 else 0
        stu_map[m.user_id] = status
    return stu_map


def day_range(ctime):
    _time = time.localtime(ctime)
    t1 = (_time.tm_year, _time.tm_mon, _time.tm_mday, 0, 0, 0, 0, 0, 0)
    t2 = (_time.tm_year, _time.tm_mon, _time.tm_mday, 23, 59, 59, 0, 0, 0)
    return [int(time.mktime(t1)), int(time.mktime(t2))]


def get_tea_send_task():
    sql = """
    SELECT t.add_user user_id, begin_time,c.grade_id,r.unit_class_id FROM `yy_task` t
    JOIN tbkt_ketang.mobile_order_region r ON r.user_id=t.add_user
	JOIN tbkt_com.school_unit_class c ON c.id=r.unit_class_id
    WHERE r.county=410482 AND t.add_time>1512057599 AND t.status=1 AND c.grade_id in (3,4,5,6)
    GROUP BY t.id;
    """
    rows = db.tbkt_yingyu.fetchall_dict(sql)
    for r in rows:
        send_range = day_range(r.begin_time)
        if not db.tbkt_active.active_score_user_detail.filter(user_id=r.user_id, item_no='send_task', active_id=7,
                                                              add_date__range=send_range).exists():
            add_score(r.user_id, 'send_task', 20, u'教师发作业加分', r.begin_time, 7, r.user_id, 410400, r.unit_class_id,
                      r.grade_id)


def get_stu_do_task():
    sql = """
    SELECT t.user_id, t.update_time,c.grade_id,r.unit_class_id,yy_task.add_user FROM `yy_task_progress` t
    JOIN yy_task  on yy_task.id=t.task_id
    JOIN tbkt_ketang.mobile_order_region r ON r.user_id=t.user_id
	JOIN tbkt_com.school_unit_class c ON c.id=r.unit_class_id
    WHERE r.county=410482 AND t.update_time>1512057599 AND t.status=1 AND c.grade_id in (3,4,5,6)
    GROUP BY t.id;
    """
    rows = db.tbkt_yingyu.fetchall_dict(sql)
    stu_id = list(set([r.user_id for r in rows]))
    stu_map = get_open_status(stu_id)
    for r in rows:
        status = stu_map.get(r.user_id, 0)
        tea_add_score = 1
        stu_add_score = 10

        if status:
            tea_add_score = 5
            stu_add_score = 20

        add_score(r.add_user, 'stu_do_task', tea_add_score, u'班级学生做作业，开通5， 未开通 1', r.update_time, 7, r.user_id, 410400,
                  r.unit_class_id,
                  r.grade_id)
        add_score(r.user_id, 'task', stu_add_score, u'完成作业加分，每日上限5次，每次+10分  开通翻倍', r.update_time, 6, r.user_id, 410400,
                  r.unit_class_id,
                  r.grade_id)


def get_stu_do_test():
    sql = """
    SELECT t.user_id,t.test_time,c.grade_id,r.unit_class_id FROM `yy_test` t
    JOIN tbkt_ketang.mobile_order_region r ON r.user_id=t.user_id
    JOIN tbkt_com.school_unit_class c ON c.id=r.unit_class_id
    WHERE r.county=410482 AND t.test_time>1512057599 AND t.status=1 AND c.grade_id in (3,4,5,6) and t.catalog_id<>0
    GROUP BY t.id;
    """
    rows = db.tbkt_yingyu.fetchall_dict(sql)
    stu_id = list(set([r.user_id for r in rows]))
    stu_map = get_open_status(stu_id)
    for r in rows:
        status = stu_map.get(r.user_id, 0)
        send_range = day_range(r.test_time)
        stu_add_score = 10
        if status:
            stu_add_score = 20
        if len(db.tbkt_active.active_score_user_detail.filter(
                user_id=r.user_id, item_no='test', active_id=6, add_date__range=send_range)[:]) < 5:
            add_score(r.user_id, 'test', stu_add_score, u'同步习题，每日上限5次，每次+10分  开通翻倍', r.test_time, 6, r.user_id, 410400,
                      r.unit_class_id,
                      r.grade_id)

    sql = """
    SELECT t.user_id,t.test_time,c.grade_id,r.unit_class_id,t.type FROM `yy_word_test` t
    JOIN tbkt_ketang.mobile_order_region r ON r.user_id=t.user_id
    JOIN tbkt_com.school_unit_class c ON c.id=r.unit_class_id
    WHERE r.county=410482 AND t.test_time>1512057599 AND t.status=1 AND c.grade_id in (3,4,5,6) and t.object_id<>0
    GROUP BY t.id;
    """

    rows = db.tbkt_yingyu.fetchall_dict(sql)
    stu_id = list(set([r.user_id for r in rows]))
    stu_map = get_open_status(stu_id)
    for r in rows:
        status = stu_map.get(r.user_id, 0)
        send_range = day_range(r.test_time)
        item = 'mouse'
        remark = u'打地鼠，每日上限5次，每次+10分  开通翻倍'
        if r.type == 1:
            item = 'ballon'
            remark = u'打气球，每日上限5次，每次+10分  开通翻倍'

        stu_add_score = 10
        if status:
            stu_add_score = 20
        if len(db.tbkt_active.active_score_user_detail.filter(
                user_id=r.user_id, item_no=item, active_id=6, add_date__range=send_range)[:]) < 5:
            add_score(r.user_id, item, stu_add_score, remark, r.test_time, 6, r.user_id, 410400,
                      r.unit_class_id,
                      r.grade_id)


def add_score(user_id, item_no, score, remark, add_date, active_id, add_user, city, unit_id, grade_id=0):
    """加减分处理"""
    print '----------------add_score   user_id:%s  item_no:%s  score:%s active_id:%s ----------------- '%(user_id,item_no,score,active_id)
    with db.tbkt_active as tbkt_active:
        tbkt_active.active_score_user_detail.create(
            user_id=user_id,
            item_no=item_no,
            remark=remark,
            add_date=add_date,
            active_id=active_id,
            score=score,
            add_username=add_user
        )
        if tbkt_active.active_score_user.filter(user_id=user_id, active_id=active_id).exists():
            sql = """ UPDATE active_score_user SET score = score+%s ,city=%s, unit_id=%s ,grade_id=%s WHERE active_id = %s AND user_id=%s;""" % (
                score, city, unit_id, grade_id, active_id, user_id)
            tbkt_active.execute(sql)
        else:
            tbkt_active.active_score_user.create(
                user_id=user_id,
                score=score,
                active_id=active_id,
                city=city,
                unit_id=unit_id,
                grade_id=grade_id
            )


def start():
    get_tea_send_task()
    print 'tea - send - task - over'
    get_stu_do_task()
    print 'stu - do - task - over'
    get_stu_do_test()
    print 'stu - do - test - over'
    print'over!'

if __name__ == '__main__':
    start()

elif __name__ == '__builtin__':
    print '__builtin__'
    reactor.callInThread(start)
    application = service.Application('yy_task_service')
