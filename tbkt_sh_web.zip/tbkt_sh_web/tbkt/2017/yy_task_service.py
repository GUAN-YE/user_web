# coding=utf-8

"""
@varsion: ??
@author: 张帅男
@file: yy_task_service.py
@time: 2017/8/4 11:26
"""

import json
import time
import base64
import requests
import datetime

from twisted.internet import reactor
from twisted.application import service
from db_config import get_db

db = get_db(250)

SMS_URL = 'http://sms.m.jxtbkt.cn/sms/send'


def get_ling_time():
    now = time.time()
    ling_time = now - now % 86400 + time.timezone
    return ling_time


class Worker:
    def handler(self):
        now = int(time.time())
        begin_time = now - 60 * 30
        ling_time = get_ling_time()
        task = db.tbkt_yingyu.yy_task.filter(status=2, begin_time__gte=begin_time).select('id', 'begin_time').order_by(
            'begin_time')[:50]
        no_task = db.tbkt_yingyu.yy_task.filter(status=2, begin_time__lt=begin_time, begin_time__gte=ling_time).select(
            'id')[:]
        no_task_ids = [t.id for t in no_task]
        db.tbkt_yingyu.yy_task.filter(status=2, id__in=no_task_ids).update(status=1)
        update_task_ids = []

        for t in task:
            if int(t.begin_time) <= now:
                update_task_ids.append(t.id)

        if update_task_ids:
            # 更新作业状态
            print 'start update yy task'
            db.tbkt_yingyu.yy_task.filter(id__in=update_task_ids).update(status=1)
            db.tbkt_yingyu.yy_task_class.filter(task_id__in=update_task_ids,status=2).update(status=1)

            task_ids = ','.join(str(i) for i in update_task_ids)
            sql = """
                  select t.add_user,c.unit_class_id, t.sms_content, t.id, c.student_id, t.is_sendpwd, c.type, t.add_user, t.type jiang
                  from yy_task t, yy_task_class c
                  where t.id = c.task_id and t.id in (%s) and c.status !=-1
                  """ % task_ids

            rows = db.tbkt_yingyu.fetchall_dict(sql)
            for r in rows:
                if not r.unit_class_id:
                    # 作业必须要班级id
                    continue

                # mor = db.tbkt_ketang.mobile_order_region.get(user_id=r.add_user)
                # if mor.city == '411400':
                #     # 屏蔽商丘短信功能
                #     continue

                # 汝州活动加分
                try:
                    self.add_score(r.add_user, 7)
                except Exception as e:
                    print e
                stu_ids = self.get_class_student(r.unit_class_id)

                if not stu_ids:
                    # 班级没有学生
                    continue

                if r.jiang == 102:
                    # 定时发期中作业给奖券 期中作业type = 102
                    self.get_ticket(r.add_user)

                if r.type == 1:
                    # 仅发给开通学科学生
                    stu_ids = self.get_unit_open_stu(stu_ids)

                if stu_ids:
                    # 发送短信
                    self.send_sms(stu_ids, r.sms_content)
                    # 发送个推信息
                    self.send_im(stu_ids)

                if r.is_sendpwd == 1:
                    # 下发账号密码
                    self.send_pwd(stu_ids)

                    # self.create_message(update_task_ids)
        else:
            print 'no info'

    @staticmethod
    def get_unit_open_stu(user_ids):
        # 获取班级下开通学生
        now = int(time.time())
        ids = ','.join(str(i) for i in user_ids)
        sql = """
        select user_id from mobile_subject t 
        where t.user_id in (%s) and t.subject_id = 2 and t.open_date <= %s
        and (t.cancel_date <=0 or t.cancel_date > %s)
        """ % (ids, now, now)
        rows = db.tbkt_ketang.fetchall(sql)
        return [i[0] for i in rows if i[0]]

    @staticmethod
    def get_ticket(user_id):
        nowt = int(time.time())
        now_month = time.localtime(nowt).tm_mon
        lottery_detail = db.tbkt_active.excita_lottery_detail.select('id').filter(type=102, user_id=user_id)[:]
        if len(lottery_detail) > 36:
            return
        with get_db(250).tbkt_active as da:
            lottery_num = da.excita_lottery.select('num').get(user_id=user_id, month=now_month)
            if not lottery_num:
                da.excita_lottery.create(
                    user_id=user_id,
                    month=now_month,
                    num=1,
                    add_time=nowt
                )
            else:
                lottery_num = lottery_num.num + 1
                da.excita_lottery.filter(user_id=user_id, month=now_month).update(num=lottery_num)
            da.excita_lottery_detail.create(
                user_id=user_id,
                type=102,
                num=1,
                remark=u'发放期中试卷奖励1个抽奖券',
                send_task_num=0,
                add_time=nowt
            )

    @staticmethod
    def get_class_student(unit_id):
        # 获取班级学生信息
        return db.tbkt_ketang.mobile_order_region.filter(unit_class_id=unit_id, user_type=1, is_update=0).flat(
            'user_id')[:]

    @staticmethod
    def send_sms(user_ids, content):
        # 发送作业短信
        ids = ','.join(str(i) for i in user_ids)
        data = dict(user_id=ids,
                    content=content)
        requests.post(SMS_URL, data=data)
        print 'send sms'

    def send_pwd(self, user_ids):
        # 下发账号密码
        ids = ','.join(str(i) for i in user_ids)
        sql = """
        SELECT u.id, u.username, p.password, u.phone FROM auth_profile p, auth_user u
        where p.user_id = u.id and p.user_id in (%s);
        """ % ids
        rows = db.tbkt_user.fetchall_dict(sql)
        print 'send pwd'
        for i in rows:
            # 解析密码
            password = self.decode_pwd(i.password)
            if not password:
                continue
            sms_content = u"您的同步课堂账号是:%s 密码是：%s,做作业(除数学知识点视频作业外)功能免费，请放心使用。" \
                          u"客户端点此m.tbkt.cn下载安装。咨询电话：12556185" % (i.username, password)
            requests.post(SMS_URL, data={'phone': i.phone, 'content': sms_content})

    @staticmethod
    def send_im(user_ids):
        # 发送im消息
        messages = []
        nowt = int(time.time())
        for user_id in user_ids:
            if user_id:
                m = {
                    'user_id': user_id,
                    'config_id': 2,
                    'template_type': 1,
                    'title': '新作业',
                    'content': '你的老师布置作业了,快来看看吧!',
                    'transmission_content': json.dumps({'type': 2}),
                    'push_status': 0,
                    'add_time': nowt,
                    'return_value': '',
                    'success_time': 0
                }
                messages.append(m)
        if messages:
            print 'create im'
            db.tbkt_com.gt_message.bulk_create(messages)

    @staticmethod
    def decode_pwd(pwd):
        # 返回明文密码
        try:
            return base64.b64decode(pwd)
        except:
            return ''

    @staticmethod
    def create_message(task_ids):
        # 写入message
        if not task_ids:
            return

        tasks = db.tbkt_yingyu.yy_task.filter(id__in=task_ids, status=1)
        # {task_id:message_id}
        msg_map = {}
        for task in tasks:
            # 对task.type进行转存
            # message.type = 1 通知 2.普通作业
            msg_type = 1
            if task.type == 0:
                msg_type = 1
            elif task.type == 1:
                msg_type = 2

            msg_id = db.tbkt_com.message.create(
                type=msg_type,
                subject_id=91,
                object_id=task.id,
                add_user=task.add_user,
                title=task.title,
                content=task.sms_content,
                status=1,
                add_time=task.begin_time,
                end_time=task.end_time
            )
            msg_map[task.id] = msg_id

        task_ids = msg_map.keys()
        classes = db.tbkt_yingyu.yy_task_class.filter(task_id__in=task_ids)
        details = []
        for cls in classes:
            msg_id = msg_map.get(cls.task_id)
            stu_ids = cls.student_id
            if stu_ids:
                stu_ids = '|' + '|'.join(str(i) for i in stu_ids.split(',')) + '|'
            d = {'message_id': msg_id, 'unit_class_id': cls.unit_class_id, 'student_ids': stu_ids}
            details.append(d)
        db.tbkt_com.message_class.bulk_create(details)


    @staticmethod
    def add_score(user_id,active_id):

        tea_region = db.tbkt_ketang.mobile_order_region.select('city', 'unit_class_id', 'county').get(user_id=user_id)
        if not tea_region or  int(tea_region.county) != 410482:
            return
        school = db.tbkt_com.school_unit_class.select('grade_id').get(id=tea_region.unit_class_id)
        if not school or int(school.grade_id) < 3 or int(school.grade_id) > 6:
            return
        add_score_url = """http://mapihd.m.jxtbkt.cn/huodong/active/add_score"""
        token = create_token(user_id,240897)
        data = {
            "item_no": 'send_task',
            "user_id": user_id,
            "active_id": active_id,
            "city": tea_region.city or "",
            "is_open": 0,
            "unit_id": tea_region.unit_class_id,
            'grade_id': school.grade_id,
            'tbkt_token':token
        }
        cookies = {'tbkt_token':token}
        requests.post(add_score_url, data=data,cookies=cookies)



    def start(self):
        while 1:
            try:
                self.handler()
            except Exception, e:
                print e
            time.sleep(5)


def create_token(user_id, key):
    def strxor(s, key):
        "异或加密"
        key = key & 0xff
        a = bytearray(s)
        b = bytearray(len(a))
        for i, c in enumerate(a):
            b[i] = c ^ key
        return str(b)

    expire_time = int(time.time()) + 60 * 60 * 24 * 7
    code = int(user_id) ^ int(expire_time) ^ int(key)
    token = "%s|%s|%s" % (user_id, expire_time, code)
    token = strxor(token, int(key))

    token = base64.b64encode(token).rstrip('=')
    return token

if __name__ == '__main__':
    worker = Worker()
    worker.start()

elif __name__ == '__builtin__':
    print '__builtin__'
    worker = Worker()
    reactor.callInThread(worker.start)
    application = service.Application('yy_task_service')
