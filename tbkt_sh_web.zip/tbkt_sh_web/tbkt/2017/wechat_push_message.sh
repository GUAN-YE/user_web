#! /usr/bin/env sh
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/wechat_push_message.py
logfile=/var/log/wechat_push_message.log
case $1 in
    start)
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/wechat_push_message.pid --logfile=$logfile
        ;;
    stop)
        kill -9 `cat /var/run/wechat_push_message.pid`
        ;;
    restart)
        kill -9 `cat /var/run/wechat_push_message.pid`
        sleep 1
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/wechat_push_message.pid --logfile=$logfile
        ;;
    log)
        tail -f $logfile
        ;;
    *)
        echo "Usage: ./wechat_push_message.sh start | stop | restart | log"
        ;;
esac
