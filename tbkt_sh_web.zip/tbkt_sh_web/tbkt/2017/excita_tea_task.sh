#! /usr/bin/env sh  
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/excita_tea_task.py
logfile=/var/log/excita_tea_task.log
case $1 in  
    start)  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/excita_tea_task.pid --logfile=$logfile
        ;;  
    stop)  
        kill -9 `cat /var/run/excita_tea_task.pid`
        ;;  
    restart)  
        kill -9 `cat /var/run/excita_tea_task.pid`
        sleep 1  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/excita_tea_task.pid --logfile=$logfile
        ;;  
    log)  
        tail -f $logfile
        ;;  
    *)  
        echo "Usage: ./excita_tea_task.sh start | stop | restart | log"
        ;;  
esac  
