# _*_ coding: utf-8 _*_
# @时间    : 2017/12/11 15:15
# @作者  : 梁佳霖
# @文件名    : delete_pk.py

import requests
import json
import time
import traceback
import sys
from db_config import get_db

db = get_db(250)

class Worker:
    def hander(self, id, range):
        sql = '''
            SELECT id,text from yw_test_detail_new where id > %s limit %s
        ''' % (id, range)
        data = db.tbkt_yuwen.fetchall_dict(sql)
        if not data:
            print 'over id:%s ' % id
        for i in data:
            if "https://file.m.tbkt.cn" in i.text \
                    or "http://tbktfile.jxrrt.cn" in i.text \
                    or "http://user.tbkt.cn" in i.text \
                    or "http://file.tbkt.cn" in i.text \
                    or "http://res.m.tbkt.cn" in i.text \
                    or "http://res-hn.m.jxtbkt.cn" in i.text \
                    or "http://file.m.xueceping.cn" in i.text \
                    or "http://res-hn-beta.m.jxtbkt.cn" in i.text \
                    or "http://res-hn.m.tbkt.cn" in i.text:
                text = i.text.replace("https://file.m.tbkt.cn", "")
                text = text.replace("http://tbktfile.jxrrt.cn", "")
                text = text.replace("http://user.tbkt.cn", "")
                text = text.replace("http://file.tbkt.cn", "")
                text = text.replace("http://res.m.tbkt.cn", "")
                text = text.replace("http://res-hn.m.tbkt.cn", "")
                text = text.replace("http://res-hn.m.jxtbkt.cn", "")
                text = text.replace("http://res-hn-beta.m.jxtbkt.cn", "")
                text = text.replace("http://file.m.xueceping.cn", "")
                db.tbkt_yuwen.yw_test_detail_new.filter(id=i.id).update(text=text)
                print 'update id%s' % (i.id)

    def start(self):
        begin = 0
        range = 200
        while 1:
            try:
                self.hander(begin, range)
                begin += range
            except Exception, e:
                print e
            time.sleep(2)


if __name__ == '__main__':
    worker = Worker()
    worker.start()
