#! /usr/bin/env sh  
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/full_score_script.py
logfile=/var/log/full_score_script.log
case $1 in  
    start)  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/full_score_script.pid --logfile=$logfile
        ;;  
    stop)  
        kill -9 `cat /var/run/full_score_script.pid`
        ;;  
    restart)  
        kill -9 `cat /var/run/full_score_script.pid`
        sleep 1  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/full_score_script.pid --logfile=$logfile
        ;;  
    log)  
        tail -f $logfile
        ;;  
    *)  
        echo "Usage: ./full_score_script.sh start | stop | restart | log"
        ;;  
esac  
