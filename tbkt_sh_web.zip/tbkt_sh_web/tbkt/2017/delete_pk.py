# _*_ coding: utf-8 _*_
# @时间    : 2017/12/11 15:15
# @作者  : 梁佳霖
# @文件名    : delete_pk.py

import requests
import json
import time
import traceback
import sys
from db_config import get_db

db = get_db(250)

class Worker:
    def hander(self, id, range):
        sql = '''
            SELECT id,user_object,pk_user from yw_pk_record_new where id > %s limit %s
        ''' % (id, range)
        data = db.tbkt_yuwen.fetchall_dict(sql)
        if not data:
            print 'over id:%s ' % id
        for i in data:

            pk_user = i.pk_user.replace("https://file.m.tbkt.cn", "")  # 删除头像域名                 换成2天以内
            pk_user = pk_user.replace("http://res.m.tbkt.cn", "")      # 删除头像域名                 换成FILE_MEDIA_URLROOT
            pk_user = pk_user.replace("http://res-hn.m.tbkt.cn", "")      # 删除头像域名              换成FILE_MEDIA_URLROOT
            pk_user = pk_user.replace("http://user.tbkt.cn", "")      # 删除头像域名                  换成FILE_MEDIA_URLROOT
            pk_user = pk_user.replace("http://tbktfile.jxrrt.cn", "")      # 删除头像域名             换成2天以内
            pk_user = pk_user.replace("http://file.tbkt.cn", "")      # 删除头像域名                  换成2天以内
            pk_user = pk_user.replace("http://res-hn.m.jxtbkt.cn", "")      # 删除头像域名                  换成2天以内
            pk_user = pk_user.replace("http://file.m.xueceping.cn", "")      # 删除头像域名                  换成2天以内
            pk_user = pk_user.replace("http://res-hn-beta.m.jxtbkt.cn", "")      # 删除头像域名                  换成2天以内

            user_object = i.user_object.replace("https://file.m.tbkt.cn", "")     # 删除头像域名      换成2天以内
            user_object = user_object.replace("http://res.m.tbkt.cn", "")         # 删除头像域名      换成FILE_MEDIA_URLROOT
            user_object = user_object.replace("http://res-hn.m.tbkt.cn", "")         # 删除头像域名   换成FILE_MEDIA_URLROOT
            user_object = user_object.replace("http://user.tbkt.cn", "")         # 删除头像域名       换成FILE_MEDIA_URLROOT
            user_object = user_object.replace("http://tbktfile.jxrrt.cn", "")         # 删除头像域名  换成2天以内
            user_object = user_object.replace("http://file.tbkt.cn", "")         # 删除头像域名       换成2天以内
            user_object = user_object.replace("http://res-hn.m.jxtbkt.cn", "")         # 删除头像域名       换成2天以内
            user_object = user_object.replace("http://file.m.xueceping.cn", "")         # 删除头像域名       换成2天以内
            user_object = user_object.replace("http://res-hn-beta.m.jxtbkt.cn", "")         # 删除头像域名       换成2天以内

            db.tbkt_yuwen.yw_pk_record_new.filter(id=i.id).update(pk_user=pk_user, user_object=user_object)
        print 'update id%s  number :%s' % (id, range)

    def start(self):
        begin = 0
        range = 200
        while 1:
            try:
                self.hander(begin, range)
                begin += range
            except Exception, e:
                print e
            time.sleep(2)


if __name__ == '__main__':
    worker = Worker()
    worker.start()
