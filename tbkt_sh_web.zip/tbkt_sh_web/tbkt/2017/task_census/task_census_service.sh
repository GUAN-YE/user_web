#! /usr/bin/env sh
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/task_census_service.py
logfile=/var/log/task_census_service.log
case $1 in
    start)
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/task_census_service.pid --logfile=$logfile
        ;;
    stop)
        kill -9 `cat /var/run/task_census_service.pid`
        ;;
    restart)
        kill -9 `cat /var/run/task_census_service.pid`
        sleep 1
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/task_census_service.pid --logfile=$logfile
        ;;
    log)
        tail -f $logfile
        ;;
    *)
        echo "Usage: ./task_census_service.sh start | stop | restart | log"
        ;;
esac
