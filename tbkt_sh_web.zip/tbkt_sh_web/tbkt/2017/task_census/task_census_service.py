# coding=utf-8

"""
@varsion: ??
@author: 张帅男
@file: task_census.py 作业统计脚本
@time: 2017/12/14 16:56
"""
"""
每天凌晨1点，进行统计（月初到昨晚的23:59:59）， 数据存放到tbkt_com.task_census表里面
	CREATE TABLE `task_census` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `year` int(11) NOT NULL DEFAULT '0' COMMENT '年份（2017）',
  `month` int(11) NOT NULL DEFAULT '0' COMMENT '月份（1，2，3....12）',
  `text` varchar(255) NOT NULL DEFAULT '' COMMENT '{1:1,2:3,3:0,7:12,8:11,9:55}
  key 1：发通知，2：网上作业； 3：资源推送； 4：课前预习；5：课后练习；6：阅读理解；7：试卷作业；8 速算作业；9 知识点视频作业',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`,`year`,`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='作业通知统计';

只是统计当月的。
"""

import sys
import json
import time
import datetime

from twisted.internet import reactor
from twisted.application import service

sys.path.append("../")

from db_config import get_db

db = get_db(250)

# message 表中的数据1：发通知， 3：资源推送2：网上作业； 7：试卷作业；8 速算作业；9 知识点视频作业',
TYPE = (1, 2, 3, 7, 8, 9)

# tbkt_yuwen.yw_task_new    1：课前预习；2：课后练习；  3：阅读理解
YW_TYPE = (1, 2, 3)

ALL_TYPE = (1, 2, 3, 4, 5, 6, 7, 8, 9)

# 每天几点处理作业统计
HOUR_TO_DEAL_TASK = 1

# 语文作业类型 对应统计表中的类型
YW_CENSUS = {
    1: 4,
    2: 5,
    3: 6
}


def get_month_begin():
    """
        获取要处理月的1号00：00：00分的时间戳
        返回 处理月的1号00：00：00分的时间戳， 月份， 年份
    """
    now_day = datetime.date.today().day
    now_year = int(datetime.date.today().year)
    now_month = int(datetime.date.today().month)
    if int(now_day) == 1:               # 1号的， 获取上月月初
        if now_month == 1:
            now_month = 12
        else:
            now_month = now_month - 1
        now_datetime = datetime.datetime(now_year, now_month, 1, 00, 00, 00)
    else:                               # 非1号的，获取当月月初
        now_datetime = datetime.datetime(now_year, now_month, 1, 00, 00, 00)
    now_time = int(time.mktime(now_datetime.timetuple()))
    return now_time, int(now_year), int(now_month)


def get_time_end():
    """获取处理时的结束时间"""
    now_day = datetime.date.today().day
    if int(now_day) == 1:               # 1号的，获取上月月底
        tmp_datetime = datetime.datetime(datetime.date.today().year, datetime.date.today().month, 1, 23, 59, 59)
        new_datetime = tmp_datetime - datetime.timedelta(days=1)
        end_time = int(time.mktime(new_datetime.timetuple()))
    else:                               # 非一号的， 获取当前时间
        end_time = int(time.time())
    return end_time


class Worker:
    def handler(self):
        self.truncate_file()
        begin_time, hand_year, hand_month = get_month_begin()
        end_time = get_time_end()

        get_user_ids_sql = """
            SELECT DISTINCT(add_user) FROM message WHERE type in %s AND `status`=1
            AND begin_time BETWEEN %s AND %s;
        """ % (TYPE, begin_time, end_time)

        user_ids_dict = db.tbkt_com.fetchall_dict(get_user_ids_sql)             # 得到处理月月初，到现在时间的 操作过的id集合
        if len(user_ids_dict) < 1:
            return
        self.write_file(user_ids_dict)
        del user_ids_dict
        self.handle_file(begin_time, end_time, hand_year, hand_month)

    def write_file(self, user_ids_dict):
        """把user_ids 放进文件"""
        with open('task_census.txt', 'w') as f:  # 把user_ids写进文件中
            for user_dict in user_ids_dict:
                user_id = user_dict["add_user"]
                if user_id:
                    f.write(str(user_id) + '\n')
        f.close()
        del user_ids_dict

    def handle_file(self, begin_time, end_time, hand_year, hand_month):
        """处理message 即英语和数学的， 以及通知和资源推送的"""
        f = open("task_census.txt", 'r')
        for user_id in f:
            if not user_id:
                continue
            mem_sql = """
                SELECT count(id) as num, `type` FROM message WHERE add_user = %s AND `status` = 1 AND type in %s
                and begin_time BETWEEN %s AND %s GROUP BY `type`;
            """ % (user_id, TYPE, begin_time, end_time)
            mem_dicts = db.tbkt_com.fetchall_dict(mem_sql)

            yuwen_sql = """
                SELECT COUNT(id) as num, `type` FROM yw_task_new WHERE add_user = %s AND `status` = 1 AND type in %s
                AND begin_time BETWEEN %s AND %s GROUP BY `type`
            """ % (user_id, YW_TYPE, begin_time, end_time)
            yw_dicts = db.tbkt_yuwen.fetchall_dict(yuwen_sql)

            self.update_data(user_id, mem_dicts, yw_dicts, hand_year, hand_month)
        f.close()

    def truncate_file(self):
        """ 清空文件内容 """
        f = open("task_census.txt", 'w')
        f.truncate()
        f.close()

    def update_data(self, user_id, mem_dicts, yw_dicts, hand_year, hand_month):
        all_dict = {}
        for obj in mem_dicts:
            all_dict[int(obj.type)] = int(obj.num)

        for obj in yw_dicts:
            rel_type = YW_CENSUS.get(int(obj.type))
            all_dict[rel_type] = int(obj.num)

        for obj in ALL_TYPE:
            if not all_dict.has_key(obj):
                all_dict[obj] = 0

        text = json.dumps(all_dict)
        if db.tbkt_com.task_census.filter(user_id=user_id, year=hand_year, month=hand_month).exists():
            db.tbkt_com.task_census.filter(user_id=user_id, year=hand_year, month=hand_month).update(text=text)
        else:
            db.tbkt_com.task_census.create(
                user_id=user_id,
                year=hand_year,
                month=hand_month,
                text=text
            )

    def start(self):
        while 1:
            try:
                hour = int(time.strftime("%H", time.localtime()))
                if hour == HOUR_TO_DEAL_TASK:
                    print "begin handler"
                    self.handler()
                    self.truncate_file()
                    print "handler over"
                    time.sleep(60*60)                # 处理完了 睡一小时， 保证每天肯定能成功执行一次（除非项目挂了）
                else:
                    print "hour is not 1:00"
                    time.sleep(4)                # 不是1点的话，睡4秒
            except Exception, e:
                print "handle error: %s" % e
                time.sleep(1)                          # 报错睡1秒， 继续进行


if __name__ == '__main__':
    worker = Worker()
    worker.start()

elif __name__ == '__builtin__':
    print '__builtin__'
    worker = Worker()
    reactor.callInThread(worker.start)
    application = service.Application('task_census_service')