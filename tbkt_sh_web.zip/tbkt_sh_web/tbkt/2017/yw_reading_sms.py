# coding: utf-8
"""
语文阅读训练卷脚本
"""
import json
import time
import datetime
import base64
import requests
import logging

from db_config import get_db
from collections import defaultdict

from twisted.internet import reactor
from twisted.application import service

db = get_db(250)

RESTARTFLAG = False




SMS_URL = 'http://sms-rc.m.jxtbkt.cn/sms/send'

class Worker:

    def handler(self):
        now = int(time.time())


        task = db.tbkt_active.yw_reading_sms.select('id', 'object_id', 'unit_id', 'add_user', 'is_sendpwd', 'sendscope', 'title').filter(status=2, begin_time__lte=now).order_by('begin_time')[:50]
        ids = [t.id for t in task]
        print ids
        db.tbkt_active.yw_reading_sms.filter(id__in=ids).update(status=3, add_time=now)

        '''
        data = {
            add_user : {
                            unit_id:{
                                        object_id : [object_id,object_id,object_id],
                                        send_scope : 1,
                                        send_pwd : 1,
                                        title : '战斗'
                                    },
                            unit_id:{
                                        object_id : [object_id,object_id,object_id],
                                        send_scope : 1,
                                        send_pwd : 1,
                                        title : '战斗'
                                    },
                        },
            add_user : {
                            unit_id:{
                                        object_id : [object_id,object_id,object_id],
                                        send_scope : 1,
                                        send_pwd : 1,
                                        title : '战斗'
                                    },
                        },
        
        
        }
        '''
        data = {}
        for t in task:
            if data.has_key(t.add_user):
                if data[t.add_user].has_key(t.unit_id):
                    data[t.add_user][t.unit_id]['object_id'].append(t.object_id)
                    data[t.add_user][t.unit_id]['title'].append(t.title)
                else:
                    data[t.add_user][t.unit_id] = {}
                    data[t.add_user][t.unit_id]['object_id'] = [t.object_id]
                    data[t.add_user][t.unit_id]['is_sendpwd'] = t.is_sendpwd
                    data[t.add_user][t.unit_id]['sendscope'] = t.sendscope
                    data[t.add_user][t.unit_id]['title'] = [t.title]
            else:
                data[t.add_user] = {}
                data[t.add_user][t.unit_id] = {}
                data[t.add_user][t.unit_id]['object_id'] = [t.object_id]
                data[t.add_user][t.unit_id]['is_sendpwd'] = t.is_sendpwd
                data[t.add_user][t.unit_id]['sendscope'] = t.sendscope
                data[t.add_user][t.unit_id]['title'] = [t.title]
        print data

        for i in data.keys():
            for k in data[i].keys():
                # k = 班级id   data[i][k][object_id] = 章节id
                logging.error(k, data[i][k])
                titles_str = ','.join(s for s in data[i][k]['title'])
                logging.error(titles_str)
                self.send_sms_method_with_ids(k, data[i][k]['sendscope'], titles_str, data[i][k]['is_sendpwd'])

    def send_sms_method_with_ids(self, unit_id, sendscope, title, sendpwd):
        # 利用班级id发送短信
        if sendscope:
            students = self.get_unit_open_stu(unit_id)
        else:
            students = self.get_class_student(unit_id)

        content = u'家长您好，我使用同步课堂给孩子布置了阅读理解训练卷%s的阅读，请让孩子按时完成，好的阅读习惯有助于开阔孩子的视野，APP下载地址:m.tbkt.cn' % title
        logging.error(content)
        self.send_sms(students, content)
        # send password
        if sendpwd:
            self.send_pwd(students)


    @staticmethod
    def get_class_student(unit_id):
        # 获取班级学生信息
        return db.tbkt_ketang.mobile_order_region.filter(unit_class_id=unit_id, user_type=1, is_update=0).flat(
            'user_id')[:]

    @staticmethod
    def get_unit_open_stu(user_ids):
        # 获取班级下开通学生
        now = int(time.time())
        ids = ','.join(str(i) for i in user_ids)
        sql = """
        select user_id from mobile_subject t
        where t.user_id in (%s) and t.subject_id = 2 and t.open_date <= %s
        and (t.cancel_date <=0 or t.cancel_date > %s)
        """ % (ids, now, now)
        rows = db.tbkt_ketang.fetchall(sql)
        return [i[0] for i in rows if i[0]]


    @staticmethod
    def send_sms(user_ids, content):
        # 发送作业短信
        ids = ','.join(str(i) for i in user_ids)
        data = dict(user_id=ids,
                    content=content)
        requests.post(SMS_URL, data=data)
        print 'send sms'

    def send_pwd(self, user_ids):
        # 下发账号密码
        ids = ','.join(str(i) for i in user_ids)
        sql = """
        SELECT u.id, u.username, p.password, u.phone FROM auth_profile p, auth_user u
        where p.user_id = u.id and p.user_id in (%s);
        """ % ids
        rows = db.tbkt_user.fetchall_dict(sql)
        print 'send pwd'
        for i in rows:
            # 解析密码
            password = self.decode_pwd(i.password)
            if not password:
                continue
            sms_content = u"您的同步课堂账号是:%s 密码是：%s,做作业(除数学知识点视频作业外)功能免费，请放心使用。" \
                          u"客户端点此m.tbkt.cn下载安装。咨询电话：12556185" % (i.username, password)
            requests.post(SMS_URL, data={'phone': i.phone, 'content': sms_content})


    def start(self):
        while 1:
            try:
                self.handler()
            except Exception as e:
                print e
            time.sleep(5)


if __name__ == '__main__':
    RESTARTFLAG = True
    worker = Worker()
    worker.start()

elif __name__ == '__builtin__':
    print '__builtin__'
    RESTARTFLAG = True
    worker = Worker()
    reactor.callInThread(worker.start)
    application = service.Application('sx2_task_service')
