#coding: utf-8
"""
导入特殊帐号
001  
002 
003
004
005
006
007
008


语文教师
009
数学教师
010
英语教师
011 
前8个是学生，后3个是教师。密码都是111111，加到一个班级中。
"""
import datetime
import time
import random
import hashlib
import base64
import MySQLdb
from db import Hub

HN_HOST = '192.168.7.250'
HN_USER = 'dba_user'
HN_PASSWORD = 'tbkt123456'

# HN_HOST = '116.255.220.112'
# HN_USER = 'renwanxing'
# HN_PASSWORD = 'ohStjN6DKXqdfBAfhGzdz'

db = Hub(MySQLdb)
# 河南大网老库
db.add_pool('tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('ketang',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)

def register(username, type, subject_id):
    now = datetime.datetime.now()
    user_id = db.tbkt.auth_user.create(
        username=username,
        first_name='',
        last_name='',
        email='',
        password='sha1$Qf7167vv5IA1$ef6c27e4f640001f9b1a6a1639fed07c219530dc',
        is_staff=0,
        is_active=1,
        is_superuser=0,
        last_login=now,
        date_joined=now,
        logins=0,
        type=type,
        real_name=username,
        nick_name='',
        portrait='',
        status=1,
        grade_id=0,
        #phone='',
    )
    db.tbkt.account_profile.create(
        type=type,
        user_id=user_id,
        nickname=username,
        portrait='',
        mobile_phone=username,
        reg_type=type,
        last_login_ip='',
        scores=0,
        register_active=0,
    )
    bind_id = db.ketang.mobile_user_bind.create(
        user_id=user_id,
        username=username,
        password='111111',
        phone_number=username,
        status=1,
        send_flag=0,
        send_num=0,
        send_date=0,
        order_id=0,
        user_name=username,
        par_name='',
        type=type,
        sex=1,
        phone_type=0,
        add_user_id=0,
        add_username='',
        add_user_type=0,
        subject_id=subject_id,
        shield_date=now,
        remark='',
        is_shield=1,
        last_login_time=now,
        last_login_ip='',
        login_time=0,
        open_time=0,
    )
    db.ketang.mobile_order_region.create(
        province='410000',
        city='411700',
        county='411702',
        school_id=178610,
        school_name='创恒中学',
        school_type=2,
        unit_class_id=556146,
        unit_name='201班',
        unit_type=1,
        grade_id=2,
        class_id=1,
        is_update=0,
        path='|150|556145|556146',
        level_id=3,
        add_date=now,
        del_state=0,
        user_bind_id=bind_id,
        user_name=username,
        user_type=type,
        add_user_id=0,
        add_username='',
        add_user_type=2,
        province_id=0,
        city_id=0,
        county_id=0,
        user_id=0,
    )
    print 'register:', user_id, bind_id

def open_subject(username, sid):
    user = db.tbkt.auth_user.get(username=username)
    if not user:
        return
    now = datetime.datetime.now()
    nowt = int(time.time())
    order = db.ketang.mobile_phone_order.get(phone_number=username)
    if not order:
        order_id = db.ketang.mobile_phone_order.create(
            phone_number=username,
            add_user_id=0,
            add_user_type=1,
            add_date=now,
            del_state=0,
            data_type=0,
            add_type=0,
            add_username='',
        )
    else:
        order_id = order.id
    # 
    bind = db.ketang.mobile_user_bind.get(user_id=user.id)
    if bind:
        db.ketang.mobile_user_bind.filter(id=bind.id).update(order_id=order_id)
    #
    STUDENT_CODES = {2:'A', 3:'B', 4:'C', 9:'D', 5:'E'}
    TEACHER_CODES = {2:'J', 3:'K', 4:'L', 9:'M', 5:'N'}
    if user.type == 1:
        code = STUDENT_CODES[sid]
    else:
        code = TEACHER_CODES[sid]
    ms = db.ketang.mobile_subject.get(order_id=order_id, code=code)
    if ms:
        ms_id = ms.id
        db.ketang.mobile_subject.filter(id=ms.id).update(status=2)
    else:
        ms_id = db.ketang.mobile_subject.create(
            order_id=order_id,
            add_date=now,
            open_date=now,
            cancel_date=None,
            status=2,
            ftp_status=1,
            ftp_num=0,
            ftp_date=now,
            code=code,
            open_type=0,
            sp_number='',
            sign_flag=1,
            ECID='',
            phone_number=username,
            fee_type=1,
        )
    #
    uo = db.tbkt.tbkt_user_open.get(user_id=user.id, subject_id=sid)
    if uo:
        uo_id = uo.id
        db.tbkt.tbkt_user_open.filter(id=uo.id).update(mobile_status=1)
    else:
        uo_id = db.tbkt.tbkt_user_open.create(
            user_id=user.id,
            subject_id=sid,
            mobile_status=1,
            add_time=nowt,
        )
        
    print 'open:', order_id, ms_id, uo_id


if __name__ == '__main__':
    # for i in xrange(2, 9):
    #     username = '%03d' % i
    #     register(username, 1, 0)
    # register('009', 3, 5)
    # register('010', 3, 2)
    # register('011', 3, 9)
    # 开通
    for i in xrange(1, 9):
        username = '%03d' % i
        for sid in [2,3,4,5,9]:
            open_subject(username, sid)
