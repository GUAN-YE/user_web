# coding: utf-8
"""
作业服务
"""
import json
import time, datetime
import base64

import datetime
import requests

from twisted.internet import reactor
from twisted.application import service
from db_config import get_db

db = get_db(250)

# sx_task status = 1/2  正常/定时定时
# sx_task is_sendpwd 0/1是否下发短信
# sx_task_class


SMS_URL = 'http://sms.m.jxtbkt.cn/sms/send'
RESTARTFLAG = False

class Worker:
    def handler(self):
        now = int(time.time())

        # 先获得时间数组格式的日期
        threeDayAgo = (datetime.datetime.now() - datetime.timedelta(days=2))
        # 转换为时间戳:
        timeStamp = int(time.mktime(threeDayAgo.timetuple()))
        # 更新2天外的作业状态， 只修改状态，不做下步操作
        global RESTARTFLAG
        if RESTARTFLAG:
            self.update_2_task(timeStamp)
            RESTARTFLAG = False

        task = get_db(250).tbkt_shuxue.sx_task.filter(status=2, begin_time__gte=timeStamp).select(
            'id', 'begin_time', 'add_user', 'type').order_by('begin_time')[:50]

        update_task_ids = []
        send_task_ids = []
        for t in task:
            if int(t.begin_time) <= now:
                update_task_ids.append(t.id)
                if now - int(t.begin_time) <= 60 * 60:
                    send_task_ids.append(t.id)

        if update_task_ids:
            # 更新作业状态
            print 'start update sx task status'
            db.tbkt_shuxue.sx_task.filter(id__in=update_task_ids).update(status=1)
            db.tbkt_shuxue.sx_task_class.filter(task_id__in=update_task_ids, status=2).update(status=1)

            # score_tasks = [i for i in task if i.id in update_task_ids]
            # for i in score_tasks:
            #     # 活动期间增加积分
            #     try:
            #         self.add_score(i.add_user, i.begin_time, i.type)
            #     except Exception as e:
            #         print e
        if send_task_ids:
            print 'start send sx task sms'
            task_ids = ','.join(str(i) for i in update_task_ids)
            sql = """
            select c.unit_class_id, t.sms_content, t.id, c.student_id, t.is_sendpwd, c.type, t.add_user, t.type jiang
            from sx_task t, sx_task_class c
            where t.id = c.task_id and t.id in (%s) and c.status != -1
            """ % task_ids

            rows = db.tbkt_shuxue.fetchall_dict(sql)

            for r in rows:
                if not r.unit_class_id:
                    # 作业必须要班级id
                    continue

                # mor = db.tbkt_ketang.mobile_order_region.get(user_id=r.add_user)
                # if mor.city == '411400':
                #     # 屏蔽商丘短信功能
                #     continue

                stu_ids = self.get_class_student(r.unit_class_id)

                if not stu_ids:
                    # 班级没有学生
                    continue

                if r.jiang == 102:
                    # 定时发期中作业给奖券 期中作业type = 102
                    self.get_ticket(r.add_user)

                if r.type == 1:
                    # 仅发给开通学科学生
                    stu_ids = self.get_unit_open_stu(stu_ids)

                if stu_ids:
                    # 发送短信
                    self.send_sms(stu_ids, r.sms_content)
                    # 发送个推信息
                    self.send_im(stu_ids)

                if r.is_sendpwd == 1:
                    # 下发账号密码
                    self.send_pwd(stu_ids)

    @staticmethod
    def update_2_task(timeStamp):
        """更新2天外的作业状态， 只修改状态，不做下步操作"""
        print "update_2_task"
        if get_db(250).tbkt_shuxue.sx_task.filter(status=2, begin_time__lte=timeStamp).exists():
            get_db(250).tbkt_shuxue.sx_task.filter(status=2, begin_time__lte=timeStamp).update(status=1)

    @staticmethod
    def get_unit_open_stu(user_ids):
        # 获取班级下开通学生
        now = int(time.time())
        ids = ','.join(str(i) for i in user_ids)
        sql = """
        select user_id from mobile_subject t 
        where t.user_id in (%s) and t.subject_id = 2 and t.open_date <= %s
        and (t.cancel_date <=0 or t.cancel_date > %s)
        """ % (ids, now, now)
        rows = db.tbkt_ketang.fetchall(sql)
        return [i[0] for i in rows if i[0]]

    @staticmethod
    def get_class_student(unit_id):
        # 获取班级学生信息
        return db.tbkt_ketang.mobile_order_region.filter(unit_class_id=unit_id, user_type=1, is_update=0).flat(
            'user_id')[:]

    @staticmethod
    def get_ticket(user_id):
        nowt = int(time.time())
        now_month = time.localtime(nowt).tm_mon
        lottery_detail = db.tbkt_active.excita_lottery_detail.select('id').filter(type=102, user_id=user_id)[:]
        if len(lottery_detail) > 36:
            return
        with get_db(250).tbkt_active as da:
            lottery_num = da.excita_lottery.select('num').get(user_id=user_id, month=now_month)
            if not lottery_num:
                da.excita_lottery.create(
                    user_id=user_id,
                    month=now_month,
                    num=1,
                    add_time=nowt
                )
            else:
                lottery_num = lottery_num.num + 1
                da.excita_lottery.filter(user_id=user_id, month=now_month).update(num=lottery_num)
            da.excita_lottery_detail.create(
                user_id=user_id,
                type=102,
                num=1,
                remark=u'发放期中试卷奖励1个抽奖券',
                send_task_num=0,
                add_time=nowt
            )

    @staticmethod
    def send_sms(user_ids, content):
        # 发送作业短信
        ids = ','.join(str(i) for i in user_ids)
        data = dict(user_id=ids,
                    content=content)
        requests.post(SMS_URL, data=data)
        print 'send sms'

    def send_pwd(self, user_ids):
        # 下发账号密码
        ids = ','.join(str(i) for i in user_ids)
        sql = """
        SELECT u.id, u.username, p.password, u.phone FROM auth_profile p, auth_user u
        where p.user_id = u.id and p.user_id in (%s);
        """ % ids
        rows = db.tbkt_user.fetchall_dict(sql)
        print 'send pwd'
        for i in rows:
            # 解析密码
            password = self.decode_pwd(i.password)
            if not password:
                continue
            sms_content = u"您的同步课堂账号是:%s 密码是：%s,做作业(除数学知识点视频作业外)功能免费，请放心使用。" \
                          u"客户端点此m.tbkt.cn下载安装。咨询电话：12556185" % (i.username, password)
            requests.post(SMS_URL, data={'phone': i.phone, 'content': sms_content})

    @staticmethod
    def send_im(user_ids):
        # 发送im消息
        messages = []
        nowt = int(time.time())
        for user_id in user_ids:
            if user_id:
                m = {
                    'user_id': user_id,
                    'config_id': 2,
                    'template_type': 1,
                    'title': '新作业',
                    'content': '你的老师布置作业了,快来看看吧!',
                    'transmission_content': json.dumps({'type': 2}),
                    'push_status': 0,
                    'add_time': nowt,
                    'return_value': '',
                    'success_time': 0
                }
                messages.append(m)
        if messages:
            print 'create im'
            db.tbkt_com.gt_message.bulk_create(messages)

    @staticmethod
    def create_message(task_ids):
        # 写入message
        if not task_ids:
            return

        tasks = db.tbkt_shuxue.sx_task.filter(id__in=task_ids, status=1)
        # {task_id:message_id}
        msg_map = {}
        for task in tasks:
            # 对task.type进行转存
            # message.type = 1 通知 2.普通作业 7 数学试卷
            msg_type = 1
            if task.type == 0:
                msg_type = 1
            elif task.type == 1:
                msg_type = 2
            elif task.type == 2:
                msg_type = 7

            msg_id = db.tbkt_com.message.create(
                type=msg_type,
                subject_id=21,
                object_id=task.id,
                add_user=task.add_user,
                title=task.title,
                content=task.sms_content,
                status=1,
                add_time=task.begin_time,
                end_time=task.end_time
            )
            msg_map[task.id] = msg_id

        task_ids = msg_map.keys()
        classes = db.tbkt_shuxue.sx_task_class.filter(task_id__in=task_ids)
        details = []
        for cls in classes:
            msg_id = msg_map.get(cls.task_id)
            stu_ids = cls.student_id
            if stu_ids:
                stu_ids = '|' + '|'.join(str(i) for i in stu_ids.split(',')) + '|'
            d = {'message_id': msg_id, 'unit_class_id': cls.unit_class_id, 'student_ids': stu_ids}
            details.append(d)
        db.tbkt_com.message_class.bulk_create(details)

    @staticmethod
    def decode_pwd(pwd):
        # 返回明文密码
        try:
            return base64.b64decode(pwd)
        except:
            return ''

    @staticmethod
    def today_temp():
        to_day = datetime.datetime.now()
        d = datetime.datetime(to_day.year, to_day.month, to_day.day, 0, 0, 0)
        return int(time.mktime(d.timetuple()))

    @staticmethod
    def add_score(user_id, task_begin_time, task_type):
        tea_active_id = 9
        task_type = task_type or 1
        # 作业类型对应item_no
        type_map = {
            1: 'tea_usual',
            2: 'tea_paper',
            4: 'tea_video',
            5: 'tea_susuan'
        }

        # 作业类型分数
        type_score = {
            1: 100,
            2: 100,
            4: 200,
            5: 100
        }

        # 作业名字
        task_name = {
            1: "日常",
            2: "试卷",
            4: "视频",
            5: "速算"
        }

        active = db.tbkt_active.active.get(id=tea_active_id)
        if not active or active.end_time <= int(task_begin_time):
            return

        tea_region = get_db(250).tbkt_ketang.mobile_order_region.select('city', 'unit_class_id').get(user_id=user_id)
        if tea_region and tea_region.city != '411200':
            return

        item_no = type_map.get(task_type)  # 活动item_no  active_score_item
        score = type_score.get(task_type)  # 类型作业分数
        name = task_name.get(task_type)  # 类型作业名字
        if not item_no or not score or not task_name:
            print 'add_score'
            return

        to_day = datetime.datetime.now()
        d = datetime.datetime(to_day.year, to_day.month, to_day.day, 0, 0, 0)
        today_temp = int(time.mktime(d.timetuple()))

        with get_db(250).tbkt_active as da:
            sql = """
                select id from active_score_user_detail where 
                user_id = %s  and item_no = '%s' and add_date >= %s
                """ % (user_id, item_no, today_temp)
            # 查询当天指定类型作业是否已加分
            row = da.fetchone(sql)
            print row
            if row:
                # 当天该类型作业已经加过分
                return
            tea_remark = '发送%s作业，每天只统计一次' % name

            # 教师总积分
            tea_score = da.active_score_user.get(user_id=user_id, active_id=tea_active_id)
            if tea_score:
                # 更新用户总分
                da.active_score_user.filter(id=tea_score.id).update(score=(tea_score.score + score))
            else:
                city = tea_region.city if tea_region else ''
                unit_id = tea_region.unit_class_id if tea_region else 0
                # 创建用户总积分记录
                da.active_score_user.create(
                    user_id=user_id,
                    score=score,
                    active_id=tea_active_id,
                    city=city,
                    unit_id=unit_id
                )

            # 添加积分明细
            da.active_score_user_detail.create(
                user_id=user_id,
                item_no=item_no,
                score=score,
                active_id=tea_active_id,
                remark=tea_remark,
                add_username=user_id,
                add_date=task_begin_time,
                affix_info=''
            )
        return

    def start(self):
        while 1:
            print 'handler'
            # try:
            self.handler()
            # except Exception as e:
            #     print e
            time.sleep(5)



if __name__ == '__main__':
    RESTARTFLAG = True
    worker = Worker()
    worker.start()

elif __name__ == '__builtin__':
    print '__builtin__'
    RESTARTFLAG = True
    worker = Worker()
    reactor.callInThread(worker.start)
    application = service.Application('sx_task_service')
