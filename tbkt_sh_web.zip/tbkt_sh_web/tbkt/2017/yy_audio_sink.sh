#! /usr/bin/env sh  
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/yy_audio_sink.py
logfile=/var/log/yy_audio_sink.log
case $1 in  
    start)  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/yy_audio_sink.pid --logfile=$logfile
        ;;  
    stop)  
        kill -9 `cat /var/run/yy_audio_sink.pid`
        ;;  
    restart)  
        kill -9 `cat /var/run/yy_audio_sink.pid`
        sleep 1  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/yy_audio_sink.pid --logfile=$logfile
        ;;  
    log)  
        tail -f $logfile
        ;;  
    *)  
        echo "Usage: ./yy_audio_sink.sh start | stop | restart | log"
        ;;  
esac  
