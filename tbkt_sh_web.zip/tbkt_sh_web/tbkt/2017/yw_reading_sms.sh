#! /usr/bin/env sh  
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/yw_reading_sms.py
logfile=/var/log/yw_reading_sms.log
case $1 in  
    start)  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/yw_reading_sms1.pid --logfile=$logfile
        ;;  
    stop)  
        kill -9 `cat /var/run/yw_reading_sms1.pid`
        ;;  
    restart)  
        kill -9 `cat /var/run/yw_reading_sms1.pid`
        sleep 1  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/yw_reading_sms1.pid --logfile=$logfile
        ;;  
    log)  
        tail -f $logfile
        ;;  
    *)  
        echo "Usage: ./yw_reading_sms.sh start | stop | restart | log"
        ;;  
esac  
