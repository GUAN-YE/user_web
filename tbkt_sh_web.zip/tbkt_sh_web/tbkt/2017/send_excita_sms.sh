#! /usr/bin/env sh  
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/send_excita_sms.py
logfile=/var/log/send_excita_sms.log
case $1 in  
    start)  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/send_excita_sms.pid --logfile=$logfile
        ;;  
    stop)  
        kill -9 `cat /var/run/send_excita_sms.pid`
        ;;  
    restart)  
        kill -9 `cat /var/run/send_excita_sms.pid`
        sleep 1  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/send_excita_sms.pid --logfile=$logfile
        ;;  
    log)  
        tail -f $logfile
        ;;  
    *)  
        echo "Usage: ./send_excita_sms.sh start | stop | restart | log"
        ;;  
esac  
