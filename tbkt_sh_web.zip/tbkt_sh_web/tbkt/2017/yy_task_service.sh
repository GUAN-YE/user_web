#! /usr/bin/env sh
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/yy_task_service.py
logfile=/var/log/yy_task_service.log
case $1 in
    start)
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/yy_task_service1.pid --logfile=$logfile
        ;;
    stop)
        kill -9 `cat /var/run/yy_task_service1.pid`
        ;;
    restart)
        kill -9 `cat /var/run/yy_task_service1.pid`
        sleep 1
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/yy_task_service1.pid --logfile=$logfile
        ;;
    log)
        tail -f $logfile
        ;;
    *)
        echo "Usage: ./yy_task_service.sh start | stop | restart | log"
        ;;
esac
