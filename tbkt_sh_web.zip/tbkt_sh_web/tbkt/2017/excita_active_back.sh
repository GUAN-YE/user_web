#! /usr/bin/env sh
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/excita_active_back.py
logfile=/var/log/excita_active_back.log
case $1 in
    start)
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/excita_active_back.pid --logfile=$logfile
        ;;
    stop)
        kill -9 `cat /var/run/excita_active_back.pid`
        ;;
    restart)
        kill -9 `cat /var/run/excita_active_back.pid`
        sleep 1
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/excita_active_back.pid --logfile=$logfile
        ;;
    log)
        tail -f $logfile
        ;;
    *)
        echo "Usage: ./excita_active_back.sh start | stop | restart | log"
        ;;
esac