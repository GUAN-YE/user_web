#coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import time
import random
import hashlib
import base64
# import MySQLdb
import pymysql
from db import Hub
import json

LOCAL_HOST = '192.168.7.250'
LOCAL_USER = 'dba_user'
LOCAL_PASSWORD = 'tbkt123456'

# HN_HOST = '192.168.7.250'
# HN_USER = 'dba_user'
# HN_PASSWORD = 'tbkt123456'

# LOCAL_HOST = 'rm-2zepdx4436e041l3so.mysql.rds.aliyuncs.com'
# LOCAL_USER = 'dba_china'
# LOCAL_PASSWORD = 'D2zepdx4436e041l3so'


HN_HOST = '116.255.220.112'
HN_USER = 'renwanxing'
HN_PASSWORD = 'ohStjN6DKXqdfBAfhGzdz'

JX_HOST = 'rm-2zeso7flj7kkik72r.mysql.rds.aliyuncs.com'
JX_USER = 'jx_tbkt_db'
JX_PASSWORD = 'fPhTisS3DvTZZgD'

db = Hub(pymysql)
# 本地新库
db.add_pool('local_user',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_user',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_ketang',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_com',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_com',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_yingyu',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_yingyu',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 河南大网老库
db.add_pool('hn_tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_tbktweb',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt_web',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_ketang',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 江西大网库
db.add_pool('jx_tbkt',
    host=JX_HOST, port=3306, user=JX_USER, passwd=JX_PASSWORD, db='jxtbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)


def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        return int(time.mktime(t))
    except:
        return 0

def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except:
        print 'encode_password:', password
        return ''
    return "sha1$%s$%s" % (salt, hash)

def encode_plain_password(password):
    try:
        return base64.b64encode(password)
    except:
        return ''


class HNWorker:
    """
    河南导入类
    """
    def __init__(self):
        self.provinced = {} # {旧地市ID: 新地市ID}
        self.schoold = {} # {旧学校ID: 新学校ID}
        self.classd = {} # {旧班级ID: 新班级ID}

        print 'init ok.'

    def load_schoold(self):
        if not self.schoold:
            rows = db.hn_tbkt.school[:]
            self.schoold = {r.id: r.id for r in rows}

    def load_classd(self):
        if not self.classd:
            rows = db.hn_tbkt.school_unit_class[:]
            self.classd = {r.id: r.id for r in rows}

    def import_province(self):
        """导省市县"""
        provinces = db.hn_tbkt.common_provincecity[:]
        rows = []
        for p in provinces:
            rows.append({
                'id': p.id,
                'cityId': p.cityId,
                'name': p.name,
                'fatherId': p.fatherId,
                'parentId': p.parentId,
                'levelId': p.levelId,
                'path': p.path,
            })
            if len(rows) >= 2000:
                db.local_com.common_provincecity.bulk_create(rows)
                rows = []
        if rows:
            db.local_com.common_provincecity.bulk_create(rows)

    def import_school(self):
        """导学校"""
        schools = db.hn_tbkt.school[:]
        rows = []
        for s in schools:
            rows.append({
                'id': s.id,
                'county': s.county.strip(),
                'name': s.name,
                'learn_length': s.learn_length,
                'type': s.type,
                'address': s.address or '',
                'fix_tel': s.fix_tel or '',
                'user_id': s.user_id or 0,
                'add_date': unix_timestamp(s.add_date),
                'link_man': s.link_man or '',
                'notes': s.notes or '',
                'status': s.status,
                'view_count': s.view_count or 0,
                'contact_mode': s.contact_mode or 0,
                'contact_object': s.contact_object or '',
                'handle_result': s.handle_result or '',
                'image_url': s.image_url or '',
                'ecid': s.ecid or '',
            })
            if len(rows) >= 2000:
                db.local_com.school.bulk_create(rows)
                rows = []
        if rows:
            db.local_com.school.bulk_create(rows)

    def import_class(self):
        """班级信息表"""
        minid = 0       # 老表分页ID
        psize = 2000    # 每页多少条
        self.load_schoold()
        while 1:
            units = db.hn_tbkt.school_unit_class.filter(id__gt=minid)[:psize]
            if not units:
                break
            minid = units[-1].id

            rows = []
            for u in units:
                rows.append({
                    'id': u.id,
                    'school_id': u.school_id,
                    'unit_type': u.unit_type,
                    'unit_name': u.unit_name,
                    'learn_length': u.learn_length,
                    'type': u.type,
                    'grade_id': u.grade_id,
                    'class_id': u.class_id,
                    'parent_id': u.parent_id,
                    'level_id': u.level_id,
                    'is_leaf': u.is_leaf,
                    'path': u.path,
                    'is_update': u.is_update,
                    'max_class': u.max_class,
                    'add_time': unix_timestamp(u.add_time),
                    'sms_num': u.sms_num,
                    'real_num': u.real_num,
                    'upgrade_date': u.upgrade_date,
                })
            db.local_com.school_unit_class.bulk_create(rows)
        print 'class over', len(self.classd)

    def import_user1(self):
        """导入auth_user用户, 保证user_id不变"""
        minid = 0
        print 'import user1', minid
        psize = 2000
        while 1:
            sql = """
            select u.id, b.id bind_id, b.phone_number phone, b.username, b.password plain_password,
                b.type, b.user_name real_name, u.last_login, u.date_joined, u.status, 
                u.grade_id, b.subject_id sid, u.password, b.sex, u.portrait
            from mobile_user_bind b
            inner join tbkt.auth_user u on u.id=b.user_id
            where u.id>%s
            order by u.id
            limit %s
            """ % (minid, psize)
            users = db.hn_ketang.fetchall_dict(sql)
            if not users:
                break
            minid = users[-1].id

            rows = []
            profile_rows = []
            for u in users:
                plain_password = u.plain_password or "111111"
                if not u.password:
                    u.password = encode_password(u.plain_password)
                rows.append({
                    'id': u.id,
                    'username': u.username,
                    'password': u.password,
                    'type': u.type,
                    'real_name': u.real_name,
                    'last_login': unix_timestamp(u.last_login),
                    'date_joined': unix_timestamp(u.date_joined),
                    'status': u.status or 0,
                    'phone': u.phone,
                    'platform_id': 1,
                    'grade_id': u.grade_id or 0,
                    'sid': u.sid or 0,
                    'dept_id': 0,
                })
                profile_rows.append({
                    'user_id': u.id,
                    'nickname': '',
                    'portrait': u.portrait or '',
                    'sex': u.sex,
                    'password': encode_plain_password(u.plain_password),
                })
            db.local_user.auth_user.bulk_create(rows, ignore=True)
            db.local_user.auth_profile.bulk_create(profile_rows, ignore=True)
            print 'importing user1', u.id

    def import_user2(self):
        """导入bind里关联不到auth_user的用户"""
        minid = 0
        print 'import user2', minid
        psize = 2000
        row = db.local_user.auth_user.last()
        pk = row.id+1 if row else 1
        print 'import user2: pk=', pk
        while 1:
            sql = """
            select u.id, b.id bind_id, b.phone_number phone, b.username, b.password plain_password,
                b.type, b.user_name real_name, u.last_login, u.date_joined, u.status, 
                u.grade_id, b.subject_id sid, u.password, b.sex, u.portrait
            from mobile_user_bind b
            left join tbkt.auth_user u on u.id=b.user_id
            where b.id>%s and u.id is null
            order by b.id
            limit %s
            """ % (minid, psize)
            users = db.hn_ketang.fetchall_dict(sql)
            if not users:
                break
            minid = users[-1].bind_id

            rows = []
            profile_rows = []
            for u in users:
                plain_password = u.plain_password or ""
                if not u.password:
                    u.password = encode_password(u.plain_password)
                rows.append({
                    'id': pk,
                    'username': u.username,
                    'password': u.password,
                    'type': u.type,
                    'real_name': u.real_name,
                    'last_login': unix_timestamp(u.last_login),
                    'date_joined': unix_timestamp(u.date_joined),
                    'status': u.status or 0,
                    'phone': u.phone,
                    'platform_id': 1,
                    'grade_id': u.grade_id or 0,
                    'sid': u.sid or 0,
                    'dept_id': 0,
                })
                profile_rows.append({
                    'user_id': pk,
                    'nickname': '',
                    'portrait': u.portrait or '',
                    'sex': u.sex,
                    'password': encode_plain_password(u.plain_password),
                })
                pk += 1
            db.local_user.auth_user.bulk_create(rows, ignore=True)
            db.local_user.auth_profile.bulk_create(profile_rows, ignore=True)
            print 'importing user2', pk

    def import_order_region(self):
        """导入用户班级关系"""
        minid = 0
        psize = 2000
        self.load_schoold()
        self.load_classd()
        print 'schoold:', len(self.schoold)
        print 'classd:', len(self.classd)
        while 1:
            sql = """
            select r.*, b.username, b.type
            from mobile_order_region r
            inner join mobile_user_bind b on b.id=r.user_bind_id
            where r.id>%s
            order by r.id
            limit %s
            """ % (minid, psize)
            regions = db.hn_ketang.fetchall_dict(sql)
            if not regions:
                break
            minid = regions[-1].id

            usernames = [r.username for r in regions]
            users = db.local_user.auth_user.filter(username__in=usernames).select('id','username')[:]
            # {username: new_user_id}
            usernamed = {u.username:u.id for u in users}

            rows = []
            for r in regions:
                if r.unit_class_id not in self.classd:
                    print 'warning: unit_class_id not exists:', r.unit_class_id
                    continue
                if r.username not in usernamed:
                    continue
                rows.append({
                    'id': r.id,
                    'province': r.province,
                    'city': r.city,
                    'county': r.county,
                    'school_id': r.school_id,
                    'school_name': r.school_name,
                    'school_type': r.school_type,
                    'unit_class_id': r.unit_class_id,
                    'is_update': r.is_update,
                    'add_date': unix_timestamp(r.add_date),
                    'del_state': 0,
                    'user_type': r.type,
                    'user_id': usernamed[r.username],
                })
            if rows:
                db.local_ketang.mobile_order_region.bulk_create(rows, ignore=True)
        print 'order_region over.'

    def get_phoned(self, phones):
        """
        获取电话相关用户ID
        :return: {phone: [用户ID]}
        """
        if not phones:
            return {}
        users = db.local_user.auth_user.filter(phone__in=phones).select('id', 'phone')[:]
        groups = {}
        for u in users:
            rows = groups.get(u.phone) or []
            rows.append(u.id)
            groups[u.phone] = rows
        return groups

    def import_mobile_subject(self):
        """导入学科开通记录"""
        minid = 0
        psize = 200
        while 1:
            sql = """
            select m.id, m.code, m.open_date, o.phone_number, m.status, m.add_date
            from mobile_subject m
            inner join mobile_phone_order o on o.id=m.order_id
            where status in (2,9) and m.id>%s
            order by m.id
            limit %s
            """ % (minid, psize)
            mslist = db.hn_ketang.fetchall_dict(sql)
            if not mslist:
                break
            minid = mslist[-1].id

            # 过滤掉多余学科代码
            mslist = [m for m in mslist if m.code in ('A','B','C','D','E')]
            if not mslist:
                print 'reject invalid code.'
                continue

            phones = [m.phone_number for m in mslist]
            phoned = self.get_phoned(phones)
            print 'phoned:', len(phoned)

            rows = []
            for m in mslist:
                user_ids = phoned.get(m.phone_number) or []
                #print 'phone user_ids:', user_ids
                sid = {'A':2, 'B':3, 'C':4, 'D':9, 'E':5}[m.code]
                for user_id in user_ids:
                    rows.append({
                        'user_id': user_id,
                        'phone_number': m.phone_number,
                        'subject_id': sid,
                        'open_date': unix_timestamp(m.open_date),
                        'cancel_date': 0,
                        'pay_type': 2,
                        'platform_id': 1,
                        'add_date': unix_timestamp(m.add_date),
                    })
            if rows:
                db.local_ketang.mobile_subject.bulk_create(rows, ignore=True)
            print 'importing subject:', minid
        print 'subject over.'

    def update_dept_id(self):
        """更新学生用户dept_id, 1是小学 2是初中, 如果没班级默认1"""
        minid = 0
        psize = 2000
        while 1:
            users = db.local_user.auth_user.select('id','type').filter(id__gt=minid)[:psize]
            if not users:
                break
            minid = users[-1].id

            user_ids = [u.id for u in users if u.type == 1]
            if not user_ids:
                continue

            # 批量查用户班级类型
            regions = db.local_ketang.mobile_order_region.filter(user_id__in=user_ids).select('unit_class_id','user_id')[:]
            if not regions:
                continue
            unit_ids = [r.unit_class_id for r in regions]
            units = db.local_com.school_unit_class.filter(id__in=unit_ids, type__in=(1, 2)).select('id', 'type')[:]

            units_map = {i.id: i.type for i in units}

            args = []
            for i in regions:
                type = units_map.get(i.unit_class_id, 1)
                args.append((type, i.user_id))

            sql = """
            update auth_user set dept_id = %s where id = %s
            """
            if args:
                db.local_user.execute_many(sql, args)
                print 'update auth_user dept_id:', len(args)

        print 'update dept_id over.'

    def import_shared(self):
        """
        导入共享资源表
        """
        self.load_schoold()
        self.load_classd()
        rows = db.hn_tbkt.shared[:]
        details = []
        for r in rows:
            r.upload_date = unix_timestamp(r.upload_date)
            r.edit_date = unix_timestamp(r.edit_date)
            details.append(r)
        db.local_com.shared.bulk_create(details)
        print 'import shared:', len(details)

        rows = db.hn_tbkt.shared_push[:]
        details = []
        for r in rows:
            r.add_date = unix_timestamp(r.add_date)
            details.append(r)
        db.local_com.shared_push.bulk_create(details)
        print 'import shared_push:', len(details)

        rows = db.hn_tbkt.shared_push_class[:]
        details = []
        for r in rows:
            try:
                r.unit_class_id = r.unit_class_id
            except:
                print '[shared_push_class]', r.unit_class_id
                continue
            details.append(r)
        db.local_com.shared_push_class.bulk_create(details)
        print 'import shared_push_class:', len(details)

        rows = db.hn_tbkt.share_user_hit[:]
        details = []
        for r in rows:
            r.add_date = unix_timestamp(r.add_date)
            details.append(r)
        db.local_com.share_user_hit.bulk_create(details, ignore=True)
        print 'import share_user_hit:', len(details)

    def import_table(self, localtable, remotetable, converter={}, callback=None):
        """
        :param localtable: 目标db表(QuerySet)
        :param remotetable: 来源db表(QuerySet)
        :param converter: {'字段名':转换类型('user_id'转为新用户ID, 'unixtime'转为时间戳, 'ignore':忽略该字段, ...)}
        :param callback: 过滤器函数
        """
        minid = 0
        psize = 2000
        while 1:
            rows = remotetable.filter(id__gt=minid)[:psize]
            if not rows:
                break
            minid = rows[-1].id
            details = []
            for r in rows:
                if callback and callable(callback):
                    r = callback(r)
                for fieldname, type in converter.iteritems():
                    if type == 'user_id_strict':
                        pass
                    elif type == 'user_id':
                        pass
                    elif type == 'unixtime':
                        r[fieldname] = unix_timestamp(r[fieldname])
                    elif type == 'ignore':
                        r.pop(fieldname, None)
                if r.has_key('update_date') and not r.update_date:
                    r.update_date = 0
                details.append(r)
            localtable.bulk_create(details, ignore=True)
            print "import table %s: %s %s" % (localtable.table_name, minid, len(details))
        print "import table %s over" % localtable.table_name

    def start(self):
        # 清记录
        print 'start henan worker'


        # 导入省市班级

        # print 'start common_provincecity', datetime.datetime.now()
        # db.local_com.execute("truncate common_provincecity")
        # self.import_province()
        # print 'start school', datetime.datetime.now()
        # db.local_com.execute("truncate school")
        # self.import_school()
        # print 'start school_unit_class', datetime.datetime.now()
        # db.local_com.execute("truncate school_unit_class")
        # self.import_class()
        # print 'end school_unit_class', datetime.datetime.now()


        # 导用户
        db.local_user.execute("truncate auth_user")
        db.local_user.execute("truncate auth_profile")
        print 'start import_user1', datetime.datetime.now()
        self.import_user1()
        print 'start import_user2', datetime.datetime.now()
        self.import_user2()
        print 'end import_user2', datetime.datetime.now()
        # 导入用户班级
        # db.local_ketang.execute("truncate mobile_order_region")
        # self.import_order_region()
        # self.update_dept_id() # 更新auth_user.dept_id

        # 导入学科开通
        # db.local_ketang.execute("truncate mobile_subject")
        # self.import_mobile_subject()
        
        # 导入共享资源
        # db.local_com.execute("truncate shared")
        # db.local_com.execute("truncate shared_push")
        # db.local_com.execute("truncate shared_push_class")
        # db.local_com.execute("truncate share_user_hit")
        # self.import_shared()

        # 导金豆商城和积分表
        # db.local_com.execute("truncate score_app")
        # self.import_table(db.local_com.score_app, db.hn_tbkt.score_app)
        # db.local_com.execute("truncate score_gift")
        # self.import_table(db.local_com.score_gift, db.hn_tbkt.score_gift, {'add_date':'unixtime'})
        # db.local_com.execute("truncate score_gift_category")
        # self.import_table(db.local_com.score_gift_category, db.hn_tbkt.score_gift_category, {'add_date':'unixtime'})
        db.local_com.execute("truncate score_gift_order")
        self.import_table(db.local_com.score_gift_order, db.hn_tbkt.score_gift_order, {'user_id':'user_id', 'account_date':'ignore', 'account_number':'ignore'})
        # db.local_com.execute("truncate score_item")
        # self.import_table(db.local_com.score_item, db.hn_tbkt.score_item)
        # db.local_com.execute("truncate score_user")
        # def f_score_user(r):
        #     r['unit_class_id'] = r['unit_id']
        #     r.pop('unit_id', None)
        #     return r
        # self.import_table(db.local_com.score_user, db.hn_tbkt.score_user, {'user_id':'user_id', 'city':'ignore'}, f_score_user)
        # db.local_com.execute("truncate score_user_detail")
        # self.import_table(db.local_com.score_user_detail, db.hn_tbkt.score_user_detail, {'add_date':'unixtime'})


if __name__ == '__main__':
    hnworker = HNWorker()
    st = time.time()
    hnworker.start()
    print 'took:', time.time()-st