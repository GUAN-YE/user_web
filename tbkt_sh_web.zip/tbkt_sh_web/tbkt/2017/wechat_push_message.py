# coding: utf-8
import json
import time

import datetime

import requests
from twisted.application import service
from twisted.internet import reactor

from db_config import get_db

db = get_db(250)
api_url = "http://mapiwebchat.m.jxtbkt.cn"
wx_push_url = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token="
detail_url = "http://webchat.m.jxtbkt.cn?message_id=%s&state=2"


class PushMessage(object):

    def handler(self, access_token, no):
        sql = """
        select tbkt_user_id user_id, open_id from tbkt_bind b where user_type = 1 and 
        not %s (select 1 from push_temp tmp where tmp.user_id = b.tbkt_user_id and add_time >= %s) limit %s, 50
        """ % ("exists", self.get_day_stamp(), (no-1)*50)
        user_binds = db.tbkt_weixin.fetchall_dict(sql)
        if not user_binds:
            return False
        for i in user_binds:
            now = int(time.time())
            user_id = i.user_id
            open_id = i.open_id

            study_num = self.get_knowledge_num(user_id)
            test_count, test_rate, catalog_weak_know = self.get_catalog_test(user_id)
            personal_count, personal_rate, personal_weak_know = self.get_personal_test(user_id)
            think_count, think_rate = self.get_think_test(user_id)

            message_id = db.tbkt_weixin.message_push_detail.create(
                open_id=open_id,
                user_id=user_id,
                study_knowledge=study_num,
                workbook_test=json.dumps({"num": test_count, "rate": test_rate}),
                personal_test=json.dumps({"num": personal_count, "rate": personal_rate}),
                think_test=json.dumps({"num": think_count, "rate": think_rate}),
                weak_knowledge=json.dumps(list(set(catalog_weak_know+personal_weak_know))),
                add_time=now
            )
            self.insert_temp(user_id, now)
            unit_name = self.user_class_info(user_id)
            url = detail_url % message_id
            self.push_msg(access_token, open_id, url, unit_name, time.strftime("%Y-%m-%d", time.gmtime(now)))
        return True

    def get_catalog_test(self, user_id):
        # 获取一周内练习册测试信息
        start, end = self.get_week_stamp()

        tests = db.tbkt_shuxue.sx_test_detail.select('text', 'weak_knowledge') \
            .filter(user_id=user_id, add_time__range=(start, end))[:]

        if not tests:
            return 0, 0, []

        count = len(tests)
        right_num = 0
        question_count = 0
        weak_know = set()
        for i in tests:
            txt = json.loads(i.text)
            weak = json.loads(i.weak_knowledge)
            question_count += len(txt)
            right_num += sum(1 for i in txt if int(i.get('result')) == 1)
            for w in weak:
                weak_know.add(w.get('kid'))
        return count, int(right_num / float(question_count) * 100), list(weak_know)

    def get_personal_test(self, user_id):
        # 获取一周内个性化测试信息
        start, end = self.get_week_stamp()
        tests = db.tbkt_shuxue.sx_special_test_detail.select('text', 'weak_knowledge') \
            .filter(user_id=user_id, add_time__range=(start, end))[:]

        if not tests:
            return 0, 0, []

        count = len(tests)
        question_count = 0
        right_num = 0
        weak_know = set()
        for i in tests:
            txt = json.loads(i.text)
            wk = i.weak_knowledge or "{}"
            weak = json.loads(wk)
            question_count += len(txt)
            right_num += sum(1 for i in txt if int(i.get('result')) == 1)
            for w in weak:
                weak_know.add(w.get('kid'))
        return count, int(right_num / float(question_count) * 100), list(weak_know)

    def user_class_info(self, user_id):
        region = db.tbkt_ketang.mobile_order_region.select("unit_class_id").get(user_id=user_id)
        if not region:
            return
        unit_id = region.unit_class_id
        if not unit_id:
            return
        unit = db.tbkt_com.school_unit_class.get(id=unit_id)
        return unit.unit_name if unit else ""

    def get_think_test(self, user_id):
        # 获取一周内奥数测试信息
        start, end = self.get_week_date()
        sql = """
        select count(1) count, sum(if(d.status=1, 1, 0)) right_num from think_test t, think_test_detail d
        where t.id = d.study_id and t.user_id = %s and t.add_time between "%s" and "%s";
        """ % (user_id, start, end)
        think_test = db.tbkt_shuxue.fetchone_dict(sql)
        if not think_test or not think_test.count:
            return 0, 0
        return think_test.count, int(float(think_test.right_num) / int(think_test.count) * 100)

    def get_knowledge_num(self, user_id):
        start, end = self.get_week_stamp()
        study = db.tbkt_shuxue.sx_study_knowledge.select("count(1) num").get(user_id=user_id, add_time__range=(start, end))
        return study.num

    @staticmethod
    def get_week_stamp():
        # 获取一周起止的时间戳
        today = datetime.datetime.now()
        end_stamp = int(time.mktime(today.timetuple()))
        start = today - datetime.timedelta(days=7)
        start_stamp = int(time.mktime(start.timetuple()))
        return start_stamp, end_stamp

    @staticmethod
    def get_day_stamp():
        # 获取一周起止的时间戳
        today = datetime.datetime.now()
        temp = datetime.datetime(year=today.year, month=today.month, day=today.day, hour=0, minute=0, second=0)
        stamp = int(time.mktime(temp.timetuple()))
        return stamp

    @staticmethod
    def get_week_date():
        # 获取一周起止的时间格式
        today = datetime.datetime.now()
        start = today - datetime.timedelta(days=7)
        return start.strftime("%Y-%m-%d 00:00:00"), today.strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def get_access_token():
        # 获取微信access_token
        print api_url + '/access_token/'
        r = requests.get(api_url + '/access_token/')
        result = r.json()
        return result.get('data')

    @staticmethod
    def insert_temp(user_id, add_time):
        db.tbkt_weixin.push_temp.create(
            user_id=user_id,
            add_time=add_time
        )

    @staticmethod
    def push_msg(access_token, open_id, url, unit_name, date):
        print url
        # g7fBEaxtWG6U2vBWuGhl745g8DuF5rUt4r1MVdZkjXM 正式
        # QwM5HMc5XCRLoiG96A-_L_0LqDViNZJBL0ZaH76XBSw 测试
        data = {
                "touser": open_id,
                "template_id": "g7fBEaxtWG6U2vBWuGhl745g8DuF5rUt4r1MVdZkjXM",
                "url": url,
                "data": {
                        "first": {
                            "value": "家长您好，这是本周您孩子的学习情况！",
                            "color": "#173177"
                        },
                        "keyword1": {
                            "value": unit_name,
                            "color": "#173177"
                        },
                        "keyword2": {
                            "value": "同步课堂专家组",
                            "color": "#173177"
                        },
                        "keyword3": {
                            "value": date,
                            "color": "#173177"
                        },
                        "keyword4": {
                            "value": "您孩子本周的学习情况汇总分析！",
                            "color": "#173177"
                        }
                }
        }
        url = wx_push_url + access_token
        print url
        r = requests.post(url, data=json.dumps(data), verify=False)
        print r.json()

    def start(self):
        get_token_time = 0
        access_token = ""
        no = 1
        while True:
            now = int(time.time())
            today = datetime.datetime.now()
            weekday = today.weekday() + 1
            hour = today.hour
            if weekday == 5 and hour >= 10:
                if not access_token:
                    access_token = self.get_access_token()
                    get_token_time = now
                if now - get_token_time > 60 * 60 * 2:
                    access_token = self.get_access_token()
                    get_token_time = now
                if access_token:
                    status = self.handler(access_token, no)
                    if status:
                        no += 1
                    else:
                        no = 1
                        time.sleep(50)
                    print "push msg ok, ", no
            else:
                print 'Time has not arrived'
            time.sleep(2)

    def test(self):
        access_token = self.get_access_token()
        self.push_msg(access_token, "oJvIws1rYTYJfgl5sS7QvLOutTBw", detail_url%1, "230班", time.strftime("%Y-%m-%d", time.gmtime(int(time.time()))))


if __name__ == "__main__":
    PushMessage().start()

elif __name__ == '__builtin__':
    print '__builtin__'
    worker = PushMessage()
    reactor.callInThread(worker.start)
    application = service.Application('wechat_push_message')