# _*_ coding: utf-8 _*_
import logging
import time
import requests

from twisted.internet import reactor
from twisted.application import service
from db_config import get_db


db = get_db(250)

SMS_URL = 'http://sms.m.jxtbkt.cn/sms/send'



class Worker:
    def handler(self):
        nowt = int(time.time())
        print nowt
        unprocessed_data = db.tbkt_operate.excita_sms_config.select('id').get(send_status=0, send_time__lt=nowt)
        if not unprocessed_data:
            print 'There hasnot unprocess text, the program will sleep 60 seconds'
            time.sleep(60)
            return
        else:
            print unprocessed_data
        data_id = unprocessed_data.id
        unprocessed_contents = db.tbkt_operate.excita_sms_content.select('type', 'content').filter(sms_config_id=unprocessed_data.id)[:]
        type_array = []
        first_content = ''
        have_used_phone = []
        db.tbkt_operate.excita_sms_config.filter(id=unprocessed_data.id).update(send_status=1)
        for unprocessed_content in unprocessed_contents:
            # 1：0张抽奖券用户  2 1-5张抽奖券用户  3 5张以上抽奖券用户
            if unprocessed_content.type == 1:
                type_array.append(unprocessed_content.type)
                first_content = unprocessed_content.content
                continue
            elif unprocessed_content.type == 2:
                user_ids = self.get_send_user(nowt, 1, 5)
                used_phone = self.send_sms(user_ids, unprocessed_content.content, unprocessed_content.type, data_id)
                # used_phone = self.test_print_phone(user_ids, unprocessed_content.content)
                if used_phone:
                    for phone in used_phone:
                        have_used_phone.append(phone)
                type_array.append(unprocessed_content.type)
            elif unprocessed_content.type == 3:
                user_ids = self.get_send_user(nowt, 6, 999999)
                used_phone = self.send_sms(user_ids, unprocessed_content.content, unprocessed_content.type, data_id)
                # used_phone = self.test_print_phone(user_ids, unprocessed_content.content)
                if used_phone:
                    for phone in used_phone:
                        have_used_phone.append(phone)
                type_array.append(unprocessed_content.type)
        # print have_used_phone
        if 1 in type_array and first_content:
            # self.test_print_all_phone(have_used_phone, first_content)
            self.send_all_sms(have_used_phone, first_content, data_id)

    @staticmethod
    def get_send_user(nowt, min, max):
        now_month = time.localtime(nowt).tm_mon
        user_ids = db.tbkt_active.excita_lottery.select('user_id').filter(month=now_month, num__gte=min, num__lte=max)
        user_ids = [id.user_id for id in user_ids]
        # 上RC时候对这个这个这个这个啥啥啥用户做限制 , 再上正式注释掉下面两行
        # user_ids = db.tbkt_ketang.mobile_order_region.select('user_id').filter(user_id__in=user_ids, user_type=3, school_id=178610, unit_class_id=2873956)
        # user_ids = [id.user_id for id in user_ids]

        return user_ids

    # @staticmethod
    # def test_print_phone(user_ids, content):
    #     # This function is used by test get user_id to print text content
    #     have_used_phone = []
    #     len_num = len(user_ids)
    #     len_slice = len_num // 50 if len_num % 50 == 0 else len_num // 50 + 1
    #     with open('kaitongjiaoshiduanxin.txt', 'w') as f:
    #         for i in range(len_slice):
    #             if i < len_slice - 1:
    #                 user_array = user_ids[i*50:(i+1)*50]
    #             else:
    #                 user_array = user_ids[(i-1)*50:]
    #             phone_array = db.tbkt_user.auth_user.select('phone').filter(id__in=user_array)
    #             [have_used_phone.append(ph.phone) for ph in phone_array]
    #             user_ids = ','.join([str(user_id) for user_id in user_ids])
    #             f.write(user_ids)
    #             f.write(content.encode('utf-8'))
    #             f.write('\n')
    #     return have_used_phone
    #
    # @staticmethod
    # def test_print_all_phone(have_used_phone, first_content):
    #     sql = '''
    #     select id, phone
    #     from auth_user
    #     where type=3 and status!=2
    #     '''
    #     result = db.tbkt_user.fetchall_dict(sql)
    #     user_id_array = []
    #     with open('suoyoujiaoshiduanxin.txt', 'w') as f:
    #         for i in result:
    #             if i.phone in have_used_phone:
    #                 break
    #             else:
    #                 user_id_array.append(i.id)
    #             if len(user_id_array) >= 50:
    #                 user_ids = ','.join([str(user_id) for user_id in user_id_array])
    #                 f.write(user_ids)
    #                 f.write(first_content.encode('utf-8'))
    #                 f.write('\n')
    #                 user_id_array = []
    #         user_ids = ''.join([str(user_id) for user_id in user_id_array])
    #         f.write(user_ids)
    #         f.write(first_content.encode('utf-8'))



    @staticmethod
    def send_sms(user_ids, content, type, data_id):
        send_num = 0
        have_used_phone = []
        len_num = len(user_ids)
        len_slice = len_num // 50 if len_num % 50 == 0 else len_num // 50 + 1
        for i in range(len_slice):
            if i < len_slice - 1:
                user_array = user_ids[i*50:(i+1)*50]
            else:
                user_array = user_ids[i*50:]
            phone_array = db.tbkt_user.auth_user.select('phone').filter(id__in=user_array)
            [have_used_phone.append(ph.phone) for ph in phone_array]
            send_num += len(user_ids)
            send_sms(user_ids, content)
        db.tbkt_operate.excita_sms_content.filter(sms_config_id=data_id, type=type).update(send_num=send_num)
        return have_used_phone

    @staticmethod
    def send_all_sms(have_used_phone, first_content, data_id):
        sql = '''
        select ms.user_id id,ms.phone_number phone
        FROM mobile_subject ms left join mobile_order_region mor on mor.user_id = ms.user_id
        where mor.user_type = 3 and mor.city != 411200 and ms.status in (2,9);
        '''
        # result = db.tbkt_user.fetchall_dict(sql)
        # 上RC的时候做限制的SQL   正式用的时候用上面那个！！！！
        send_num = 0
        # sql = '''
        #     select ms.user_id id,ms.phone_number phone
        #     FROM mobile_subject ms left join mobile_order_region mor on mor.user_id = ms.user_id
        #     where mor.user_type = 3 and mor.city != 411200 and ms.status in (2,9) and mor.school_id=178610 and mor.unit_class_id=2873956;
        # '''
        result = db.tbkt_ketang.fetchall_dict(sql)

        # user_ids = db.tbkt_ketang.mobile_order_region.select('user_id').filter(school_id=178610, user_type=3)
        # user_ids = [int(user_id.user_id) for user_id in user_ids]
        # result = db.tbkt_user.auth_user.select('id', 'phone').filter(id__in=user_ids, type=3)[:]

        user_id_array = []
        # print result
        for i in result:
            if i.phone in have_used_phone:
                continue
            elif i.phone not in have_used_phone:
                user_id_array.append(i.id)
            if len(user_id_array) >= 50:
                send_num += len(user_id_array)
                send_sms(user_id_array, first_content)
                user_id_array = []
        send_num += len(user_id_array)
        db.tbkt_operate.excita_sms_content.filter(sms_config_id=data_id, type=1).update(send_num=send_num)
        send_sms(user_id_array, first_content)

    def start(self):
        while 1:
            try:
              self.handler()
            except Exception, e:
                print e
            time.sleep(5)


def send_sms(user_ids, content):
    # 发送作业短信
    ids = ','.join(str(i) for i in user_ids)
    data = dict(user_id=ids,
                content=content)
    print data
    a = requests.post(SMS_URL, data=data)
    # print 'send sms'



if __name__ == '__main__':
    worker = Worker()
    worker.start()

elif __name__ == '__builtin__':
    print '__builtin__'
    worker = Worker()
    reactor.callInThread(worker.start)
    application = service.Application('yy_task_service')
