# coding: utf-8

# 获取生产环境 数学作业记录 修改为新格式插入192.168.7.250数据库
# u_task           -->  sx_task
# u_task_class     -->  sx_task_class
# u_task_detail    -->  sx_task_content
# u_sx_test        -->  sx_task_test
# u_sx_test_detail -->  sx_task_test_detail
import json
import logging
from collections import defaultdict

from common import db
from common.util import unix_to_time

page_size = 20


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
handler = logging.FileHandler('run_db.log')
handler.setLevel(logging.INFO)
logger.addHandler(handler)


def get_task_info(page_no):
    """
    获取作业信息 
    ___________________________
    主记录，作业班级信息，作业详情信息，
    做作业主记录，作业详情记录

    每20条作业插入一次
    ___________________________
    """
    sql = """ 
    select id, type, subject_id, object_id, add_user, title, sms_content, status, add_time, begin_time, end_time
    from u_task where subject_id = 21 limit %s,%s
    """ % ((page_no - 1) * page_size, page_size)
    rows = db.prod.fetchall_dict(sql)
    if not rows:
        return False

    # 查询作业主记录
    task_ids = [i.id for i in rows]
    # 作业添加时间
    task_time_map = {}
    # 新表 sx_task insert values
    new_task = []
    for i in rows:
        i.title = i.title
        i.sms_content = i.sms_content
        i.add_time = unix_to_time(i.add_time)
        i.begin_time = unix_to_time(i.begin_time)
        i.end_time = unix_to_time(i.end_time)
        new_task.append(i)
        task_time_map[i.id] = i.add_time

    # 作业发送班级
    task_class = db.prod.u_task_class.filter(task_id__in=task_ids)
    new_task_class = []
    for i in task_class:
        i.add_time = unix_to_time(i.add_time)
        new_task_class.append(i)

    # 作业详情
    detail = db.prod.u_task_detail.filter(task_id__in=task_ids)
    new_detail = []
    if detail:
        detail_map = defaultdict(list)
        for i in detail:
            new_json = dict(cid=i.catalog_id, qid=i.question_id, tcid=i.text_catalog_id)
            detail_map[i.task_id].append(new_json)

        for task_id, new_json in detail_map.iteritems():
            d = dict(task_id=task_id,
                     text=json.dumps(new_json),
                     add_time=task_time_map.get(task_id, 0))
            new_detail.append(d)

    # 学生做作业信息
    stu_test = db.prod.u_sx_test.filter(object_id__in=task_ids, type=5, subject_id=21). \
        select('id', 'user_id', 'object_id', 'title', 'score', 'status', 'test_time', 'add_time', 'wrong_status', 'agent')[:]

    new_task_test = []
    new_task_detail = []
    if stu_test:
        for i in stu_test:
            d = dict(id=i.id,
                     user_id=i.user_id,
                     task_id=i.object_id,
                     title=i.title,
                     score=i.score,
                     status=i.status,
                     test_time=unix_to_time(i.test_time),
                     add_time=unix_to_time(i.add_time),
                     wrong_status=i.wrong_status,
                     agent=i.agent)
            new_task_test.append(d)

        # 学生做作业详情信息

        test_ids = [i.id for i in stu_test]

        stu_test_detail = db.prod.u_sx_test_detail.filter(test_study_id__in=test_ids). \
            select('id', 'test_study_id', 'question_id', 'question_ask_id', 'answer', 'result', 'option_id', 'add_time')

        detail_add_time = {i.test_study_id: unix_to_time(i.add_time) for i in stu_test_detail}
        if stu_test_detail:
            test_detail_map = defaultdict(list)
            for i in stu_test_detail:
                detail_json = dict(qid=i.question_id,
                                   aid=i.question_ask_id,
                                   answer=i.answer,
                                   result=i.result,
                                   oid=i.option_id)
                test_detail_map[i.test_study_id].append(detail_json)
            for test_id, detail_json in test_detail_map.iteritems():
                d = dict(test_id=test_id,
                         text=json.dumps(detail_json),
                         add_time=detail_add_time.get(test_id, 0))
                new_task_detail.append(d)
    try:
        with db.local as l:
            l.sx_task.bulk_create(new_task)
            if new_task_class:
                # insert sx_task_class
                l.sx_task_class.bulk_create(new_task_class)
            if new_detail:
                # insert sx_task_content
                l.sx_task_content.bulk_create(new_detail)

            if new_task_test:
                # insert sx_task_test
                l.sx_task_test.bulk_create(new_task_test)

            if new_task_detail:
                # insert sx_task_test_detail
                l.sx_task_test_detail.bulk_create(new_task_detail)
    except Exception, e:
        # logger.removeFilter(handler)
        logger.info(e)
        logger.info(page_no)
        return False
    return True


if __name__ == '__main__':
    # get_task_info(1)

    with open('run_db.log', 'r') as f:  # 打开文件
        lines = f.readlines()  # 读取所有行
        last_line = int(lines[-1]) if lines else 1  # 取最后一行

    while last_line:
        print last_line
        status = get_task_info(last_line)
        if status:
            last_line += 1
        else:
            print 'error'
            break
        print last_line
