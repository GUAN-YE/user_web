# coding=utf-8
import datetime
import json
import time

import requests
from twisted.application import service
from twisted.internet import reactor
from collections import OrderedDict

from db_config import get_db

db = get_db(250)

SMS_URL = 'http://sms.m.jxtbkt.cn/sms/send'


class GenerateTop(object):
    def get_current_week_id(self):
        """
        获取当前week_id
        Returns:
        """
        start, end = self._time_stamp()
        week = db.tbkt_active.full_score_week_list.filter(begin_time__lt=start).last()
        if not week:
            return 0
        return week.id

    @staticmethod
    def _time_stamp():
        """
        获取本周周六0和下周一点时间戳
        Returns:
        """
        today = datetime.datetime.today()
        saturday = (today - datetime.timedelta(days=time.localtime().tm_wday - 5)).strftime("%Y-%m-%d")
        sunday = (today - datetime.timedelta(days=time.localtime().tm_wday - 7)).strftime("%Y-%m-%d")
        return int(time.mktime(time.strptime(saturday, "%Y-%m-%d"))), int(time.mktime(time.strptime(sunday, "%Y-%m-%d")))

    def _get_test_info(self):
        """
        获取本次
        Returns:
        """
        week_id = self.get_current_week_id()
        data = db.tbkt_active.full_score_test.select('grade_id',
                                                     'city').filter(week_id=week_id, type=3).group_by("grade_id", "city")[:]
        return week_id, data

    @staticmethod
    def _get_rank(week_id, city, grade_id):
        """
        获取当前课程积分排名
        Args:
            week_id: 当前课程id
            city: 城市id
            grade_id: 年级id
        Returns:
        """
        data = db.tbkt_active.full_score_test.select("user_id", "city", "score")\
            .filter(week_id=week_id, type=3, city=city, grade_id=grade_id).order_by("-score", "id", "use_time")[:300]

        _temp = []
        out = OrderedDict()
        for i in data:
            if i.user_id in _temp:
                continue
            else:
                if len(out) >= 100:
                    break
                out.update({i.user_id: i.score})
                _temp.append(i.user_id)
        return out

    def counter(self):
        """
        进行查询统计
        Returns:
        """
        week_id, data = self._get_test_info()
        for i in data:
            if not i.city or not i.grade_id:
                continue
            temp = self._get_rank(week_id, i.city, i.grade_id)
            self._create_top(week_id, i.city, i.grade_id, temp)
        self.back_border()
        self.error_border()

    @staticmethod
    def _create_top(week_id, city, grade_id, data):
        """
        如果数据不存在则写入full_score_top
        Args:
            week_id: 
            city: 
            grade_id: 
            data: 
        Returns:
        """
        with db.tbkt_active as active:
            if active.full_score_top.filter(city=city, grade_id=grade_id, week_id=week_id).exists():
                return
            active.full_score_top.create(
                city=city,
                grade_id=grade_id,
                week_id=week_id,
                user_ids=json.dumps(data),
                add_time=int(time.time())
            )
            print "create top finish week_id=%s city=%s grade_id=%s" % (week_id, city, grade_id)

    @staticmethod
    def back_border():
        """
        收回边框
        :return:
        """
        print "start execute back border"
        # 收回边框 update status once_border_id
        week_day = datetime.date.today().weekday()
        monday = (datetime.datetime.today() - datetime.timedelta(days=time.localtime().tm_wday)).strftime("%Y-%m-%d")
        temp_monday = int(time.mktime(time.strptime(monday, "%Y-%m-%d")))
        if week_day == 0:
            # 周一删除边框
            border = db.tbkt_com.border.get(remark="竞技", status=1)
            if not border:
                return
            db.tbkt_com.user_border_detail.filter(border_id=border.id, add_time__lt=temp_monday).delete()
            db.tbkt_com.user_border_detail.filter(once_border_id=1).update(status=1, once_border_id=0)
            print "delete status once_border_id finish"

    @staticmethod
    def error_border():
        """
        错误边框处理
        :return:
        """
        nowt = int(time.time())
        # 查找用户等级 user_level--用户等级
        level_info = db.tbkt_active.assign_score_user.filter(user_level=14)[:]
        # 取出等级为14的用户应该拥有的边框
        border = db.tbkt_com.border.filter(status=1, id__lte=106)
        border_id = [i.id for i in border]
        # 添加用户缺失边框
        for i in level_info:
            user_border = db.tbkt_com.user_border_detail.filter(user_id=i.user_id)
            user_border_id = [i.border_id for i in user_border]
            for b in border_id:
                if b not in user_border_id:
                    db.tbkt_com.user_border_detail.create(
                        user_id=i.user_id,
                        border_id=b,
                        status=0,
                        add_time=nowt,
                    )
                    print "add border success user_id = %s" % i.user_id

    def start(self):
        """
        入口函数
        Returns:
        """
        while 1:
            today = datetime.datetime.today()
            if today.weekday() != 0 or today.hour not in (0, 1):
                print "time sleep"
                time.sleep(1000)
                continue

            try:
                self.counter()
                time.sleep(60*60*2)
            except Exception as e:
                print e
                self.send_sms()

    @staticmethod
    def send_sms():
        data = dict(phone="15738839207",
                    content="项目着火了！！！")
        requests.post(SMS_URL, data=data)
        print 'send sms'


if __name__ == "__main__":
    GenerateTop().start()

elif __name__ == '__builtin__':
    print '__builtin__'
    work = GenerateTop()
    reactor.callInThread(work.start)
    application = service.Application('excita_task')
