# coding=utf-8
from db_config import get_db

db = get_db(250)


def update_detail(name, score):
    """
    Returns:
    """
    data = db.tbkt_com.score_user_detail.select("id").filter(app_id=7, remark__contains=name).flat("id")
    rows = db.tbkt_com.score_user_detail.filter(id__in=data).update(score=score)
    print "update success len = %s" % rows


def start():
    update_detail("韩国现代", 5)
    update_detail("霾表屏幕显示", 5)
    update_detail("38升大容量", 2)
    update_detail("HUAWEI", 10)


if __name__ == "__main__":
    start()
