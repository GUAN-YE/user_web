# coding: utf-8
import sys
import os
# import pymysql
import MySQLdb

# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')



def get_ketang_conn(db):
    """
    功能            建立ketang库的mysql连接
    -----------------------------------
    添加人          添加时间           作用
    -----------------------------------
    杜祖永           2015-02-12
    """
    if int(db) == 113:
        conn = MySQLdb.connect(host='116.255.220.113',
                               db='ketang',
                               user='duzuyong',
                               passwd='ohStjN6DK$XqBAfhGzdz',
                               charset="utf8")
    elif int(db) == 76:
        conn = MySQLdb.connect(host='122.114.40.76',
                               db='ketang',
                               user='bannei',
                               passwd='bannei60279052',
                               charset="utf8")
    else:
        conn = MySQLdb.connect(host='localhost',
                               db='ketang',
                               user='root',
                               passwd='root',
                               charset="utf8")
    return conn


class Worker:
    def __init__(self):
        self.conn = None

    def execute(self, sql, db=113):
        self.conn = get_ketang_conn(db)
        cur = self.conn.cursor()
        r = cur.execute(sql)
        cur.close()
        self.conn.commit()
        return r

    def fetchone(self, sql, db=113):
        self.conn = get_ketang_conn(db)
        cur = self.conn.cursor()
        cur.execute(sql)
        row = cur.fetchone()
        cur.close()
        return row

    def fetchall(self, sql, db=113):
        self.conn = get_ketang_conn(db)
        cur = self.conn.cursor()
        cur.execute(sql)
        rows = cur.fetchall()
        cur.close()
        return rows

    def call_proc(self,proc_name, parameter, db=113):
        """
        功能            执行存储过程
        """
        self.conn = get_ketang_conn(db)
        cursor = self.conn.cursor()
        cursor.callproc(proc_name, parameter)
        results = cursor.fetchone()
        return results

    def user_add(self,sch_name, user_name, phone_number, sch_id):
        """
        功能          执行添加用户方法
        """
        context = {}
        try:
            context['sch_name'] = sch_name
            sch_name = sch_name
            context['user_name'] = user_name
            user_name = user_name
            context['phone_number'] = phone_number
            phone_number = phone_number
            context['sch_id'] = sch_id
            sch_id = sch_id

            user_type = 1  # 用户身份
            sex = 1  # 性别
            username = phone_number + 'xs'  # 账号
            password = phone_number  # 密码
            add_username = ''
            add_user_id = 0
            data_operate_type = 'change_all'  # 全网替换
            option_select = ''
            result = self.call_proc("sp_add_phone_order",
                               (0, '', '', '',
                                sch_id, sch_name,
                                0,
                                0,
                                '',
                                0,
                                0,
                                0,
                                '',
                                user_name,
                                user_type,
                                sex,
                                phone_number,
                                data_operate_type,
                                username,
                                password,
                                option_select,
                                1,
                                'xiaoxintongdaoshuju'))
        except Exception as e:
            print e
            return ""

        return result

    def join_unit_class_by_id(self, user_id, user_bind_id, school_id, grade_id, class_id):
        """
        功能          执行用户加入班级方法
        """
        result = self.call_proc("sp_get_unit_class", (school_id, 2, 1, grade_id, class_id, ''))
        result = self.call_proc("sp_get_unit_class", (result[0], 2, 3, grade_id, class_id, ''))
        unit_class_id = result[0]
        result = {"success": True, "data": {}, "message": ""}
        self.call_proc("sp_join_unit_class_by_id", (user_id, user_bind_id, unit_class_id, 0, 0))

        return result

    def xxt_data(self):
        sql = """SELECT school_name,user_name,phone_number,sch_id,is_exists,grade_name,unit_name FROM xxt_data where status =0 LIMIT 1000;"""

        data = self.fetchall(sql, 76)
        grade_s = {u"学前班": 0, u"一年级": 1, u"二年级": 2, u"三年级": 3, u"四年级": 4, u"五年级": 5, u"六年级": 6, u"七年级": 7, u"八年级": 8,
                   u"九年级": 9}

        status = -1
        for obj in data:
            try:
                print obj[2]
                sch_name = obj[0]
                user_name = obj[1]
                phone_number = obj[2]
                sch_id = obj[3]
                is_exists = obj[4]
                grade_name = obj[5]
                unit_name_ = obj[6]
                class_id = unit_name_
                grade_id = grade_s.get(grade_name)
                # 判断用户是否存在(0-不存在,1-存在)
                if is_exists == 0:
                    # 添加用户
                    s1 = self.user_add(sch_name=sch_name, user_name=user_name, phone_number=phone_number, sch_id=sch_id)
                    status = 1
                    # 获取user_bind_id 和 school_id
                    user_bind_id = s1[0]
                    school_id = sch_id
    
                    # 根据user_bind_id获取user_id
                    sql1 = """SELECT user_id FROM mobile_user_bind WHERE id=%s """ % user_bind_id
                    data1 = self.fetchall(sql1)
                    if data1:
                        user_id = data1[0][0]
                        # 判断是否加入班级
                        if sch_id > 0:
                            self.join_unit_class_by_id(user_id, user_bind_id, school_id, grade_id, class_id)
                            status = 2
                        else:
                            status = 6

                else:
                    # 获取xxt_data用户信息
                    sql2 = """SELECT phone_number,is_open,is_login FROM xxt_data WHERE phone_number='%s'
                              ORDER BY phone_number DESC LIMIT 1""" % phone_number
                    data2 = self.fetchall(sql2)
                    if data2:
                        phone_number2 = data2[0][0]
                        is_open = data2[0][1]
                        is_login = data2[0][2]
    
                        # 判断用户是否开通(0-未开通,1开通),是否登录(0-登录,1未登录)
                        if is_open > 0 or is_login > 0:
                            status = 4
                        else:
                            sql3 = """SELECT mub.user_id,mub.id FROM mobile_user_bind mub
                            where mub.phone_number = '%s' LIMIT 1""" % phone_number2
    
                            data3 = self.fetchall(sql3)
                            if data3:
                                user_id = data3[0][0]
                                user_bind_id = data3[0][1]
    
                                if sch_id > 0:
                                    status = 3
                                    self.join_unit_class_by_id(user_id, user_bind_id, sch_id, grade_id, class_id)
                                else:
                                    status = 5
            except Exception, e:
                print e
            sql = """update xxt_data set status = %s where phone_number = '%s'""" % (status, phone_number)
            self.execute(sql, 76)  # 1创建用户 2 新建用户 并加入班级 3 老用户换班  4 开通或三个月登录用户不处理  5 老用户新数据无学校  6 新建用户 无学校

    def start(self):
        a = True
        b = 0
        while a:
            self.xxt_data()
            b += 1
            if b >= 170:
                sql = """SELECT count(1) FROM xxt_data WHERE status=0"""
                data = self.fetchall(sql, 76)
                if not data:
                    a = False

if __name__ == "__main__":
    print 'main'
    worker = Worker()
    import time
    t1 = time.time()
    worker.start()
    print "------------------------"
    print "the process is taken:",
    print time.time() - t1
    print "------------------------"
