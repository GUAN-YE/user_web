# coding: utf-8
import time
from collections import OrderedDict

import sys;
from collections import defaultdict
import simplejson as json


sys.path.insert(0, '..')
import base
# from sms.SMSInfo import SMSInfo

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')


# 速算数据迁移脚本

class Worker:
    def __init__(self, dbname):
        self.default = base.connect(dbname)
        self.tbkt_web = self.default.dup(database='tbkt_web')

    def insert_new_table(self):
        # 插入tbkt.s_susuan_test 主记录
        for i in range(1, 7):
            grade_num, ch_grade = Worker.grade_transition(i)
            print grade_num, ' grade insert start'
            sql = """
            select t.* from (
            select t.score, t.take_time, t.user_id, q.type,t.test_time
            from tbkt_web.active_test t, tbkt.a_susuan_question q where active_id = 5
            and t.object_id = q.id and q.grade_id = %s and title like "%s%%%%"  order by score desc,take_time) t
            group by t.user_id, t.type;
            """ % (grade_num, ch_grade)
            # 查询每个年级用户在每个章节下成绩最高 用时最短的记录 每个章节只取一条
            rows = self.tbkt_web.fetchall_dict(sql)

            # 插入新表 SQL
            insert = """
            insert into tbkt_web.susuan_test (user_id,grade_id,catalog_id,score,use_time,test_time) values (%s, %s, %s, %s, %s, %s)
            """

            n = 0
            insert_args = []
            for r in rows:
                n += 1
                args = (r.user_id, i, r.type, r.score, r.take_time, r.test_time)
                insert_args.append(args)

                if n == 100:
                    self.tbkt_web.execute(insert, insert_args)
                    n = 0
                    insert_args = []
            if insert_args:
                self.tbkt_web.execute(insert, insert_args)

    def add_susuan_first(self):
        # 获取每个章节第一名信息 并插入新表 tbkt_web.susuan_test
        # 年级知识点信息
        sql = """
        select grade_id,type type from tbkt.a_susuan_question group by grade_id,type
        """
        rows = self.default.fetchall_dict(sql)

        # 返回年级个知识点第一名 并写入susuan_first
        for i in rows:
            sql = """
            select t.user_id,t.grade_id,t.catalog_id,t.score,t.use_time,t.num,t.test_time  from
            (select t.user_id,grade_id,catalog_id,score,use_time,(@row:=@row+1) num,t.test_time from tbkt_web.susuan_test t,(select @row:=0) b
            where grade_id = %s and catalog_id =%s order by score desc, use_time)t
            where num  = 1;
            """ % (i.grade_id, i.type)
            r = self.default.fetchall_dict(sql)
            if not r:
                continue
            insert_sql = """
            insert into tbkt_web.susuan_first (user_id,use_time,grade_id,catalog_id,score,add_time)
            values(%s,%s,%s,%s,%s,%s)
            """ % (r.user_id, r.use_time, r.grade_id, r.catalog_id, r.score, r.test_time)
            self.tbkt_web.fetchall_dict(insert_sql)

    @staticmethod
    def grade_transition(obj):
        # 中文年级转换数字
        ch_grade = {1: "一", 2: '二', 3: '三', 4: '四', 5: '五', 6: '六'}
        return obj, ch_grade.get(obj)

    def start(self):
        self.insert_new_table()
        print 'add first'
        self.add_susuan_first()
        print 'finish!'

if __name__ == '__main__':
    worker = Worker()
    worker.start()