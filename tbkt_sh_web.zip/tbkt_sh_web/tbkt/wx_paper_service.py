# coding: utf-8
"""导江西知识点试题表, u_sx_knowledge_question"""
import time
from collections import OrderedDict

import sys;
from collections import defaultdict
import simplejson as json


sys.path.insert(0, '..')
import base
from sms.SMSInfo import SMSInfo

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')

# 短信内容
CONTENT = u'【同步课堂】温县小学生举办“同步课堂数学做题大赛”活动，比赛当日发布试题。统一时间进行解题比赛，每个年级各评选20名学生进入决赛。决赛名单公布在网站上，决赛当日只有入围学生才能参赛解题。决赛时间：6月2日17:30(线上比赛)。请您及时督促孩子登录网站（www.tbkt.cn）或者是手机客户端（下载地址：m.tbkt.cn）完成试卷，并进行核对提交。'


class Worker:
    def __init__(self, dbname):
        self.default = base.connect(dbname)
        self.tbkt_web = self.default.dup(database='tbkt_web')
        self.ketang = self.default.dup(database='ketang')
        self.tbkt = self.default.dup(database='tbkt')
        self.insert_buf = []

    def get_student(self):
        # 获取温县下所有正常小学用户
        print 'select wx student'
        sql = """
        select unit_class_id, b.user_id, b.phone_number from ketang.mobile_user_bind b,ketang.mobile_order_region r
        where b.id = r.user_bind_id and b.user_id > 0 and r.county = 410825 and school_type = 1 and user_type = 1
        and is_update = 0 and unit_class_id > 0;
        """
        rows = self.ketang.fetchall_dict(sql)
        return rows

    def insert_task(self):
        # 插入u_task 主记录
        print 'insert u_task'
        sql = """
        insert into tbkt.u_task
        (
            type,
            title,
            subject_id,
            add_user,
            sms_content,
            text,
            status,
            add_time,
            begin_time,
            end_time
        )
        value(
        0,
        '温县小学数学解题大赛(决赛)',
        '21',
        -1,
        '【同步课堂】温县小学生举办“同步课堂数学做题大赛”活动，比赛当日发布试题。统一时间进行解题比赛，每个年级各评选20名学生进入决赛。决赛名单公布在网站上，决赛当日只有入围学生才能参赛解题。决赛时间：6月2日17:30(线上比赛)。请您及时督促孩子登录网站（www.tbkt.cn）或者是手机客户端（下载地址：m.tbkt.cn）完成试卷，并进行核对提交。',
        '',
        1,
        now(),
        now(),
        now()
        )
        """
        return self.default.execute(sql)

    def insert_detail(self):
        # 插入班级详情
        rows, task_id = self.insert_task()
        if not rows:
            print 'error: u_task insert defeated '
            return
        task_id = 724782
        stu = self.get_student()
        phone_list = [i.phone_number for i in stu]   # 发送短信使用
        user_list = [i.user_id for i in stu]         # 发送IM使用

        stu_map = defaultdict(list)
        [i for i in stu if stu_map[i.unit_class_id].append(i.user_id)]

        sql = """
        insert into u_task_class (task_id,unit_class_id,student_id,type,add_time)
        values(%s,%s,%s,2,now())
        """

        args = []
        n = 0
        for unit_id, uids in stu_map.items():
            exits_sql = """
                select unit_class_id from u_task_class where task_id = %s
                            """ % task_id
            result = self.tbkt.fetchone_dict(exits_sql)
            if result:
                if unit_id in result:
                    continue
            n += 1
            user_ids = ','.join(str(i) for i in uids)
            a = (task_id, unit_id, user_ids)
            args.append(a)
            if n == 100:
                self.tbkt.execute_many(sql, args)
                args = []
                n = 0
        if args:
            self.tbkt.execute_many(sql, args)

        if phone_list:
            # 批发短信
            self.wx_send(phone_list)
        if user_list:
            # 批发IM
            self.send_im(user_list)
        print 'all right'

    def wx_send(self, phone_list):
        # 向温县学生发送短信
        print 'send SMS'
        sms = SMSInfo()
        sms.send_many(phone_list, CONTENT)

    def send_im(self, user_ids):
        # 发送im消息
        print 'send IM'

        sql = """
        insert into gt_message(
            user_id,
            config_id,
            template_type,
            title,
            content,
            transmission_content,
            push_status,
            add_time,
            return_value,
            success_time)
        values(
            %s, 2, 1, '新通知', %s, %s,0,%s,'', 0
        )
        """
        n = 0
        args = []
        for i in user_ids:
            n += 1
            a = (i, CONTENT, json.dumps({'type': 1}), int(time.time()))
            args.append(a)
            if n == 100:
                self.tbkt_web.execute_many(sql, args)
                args = []
                n = 0
        if args:
            self.tbkt_web.execute_many(sql, args)

    def start(self):
        print self.insert_detail()
        print 'finish!'

if __name__ == '__main__':
    worker = Worker('')
    worker.start()