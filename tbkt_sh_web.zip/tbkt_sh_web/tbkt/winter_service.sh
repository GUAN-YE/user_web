#! /usr/bin/env sh  
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/winter_service.py
logfile=/var/log/winter_service.log
case $1 in  
    start)  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/winter_service.pid --logfile=$logfile
        ;;  
    stop)  
        kill -9 `cat /var/run/winter_service.pid`
        ;;  
    restart)  
        kill -9 `cat /var/run/winter_service.pid`
        sleep 1  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/winter_service.pid --logfile=$logfile
        ;;  
    log)  
        tail -f $logfile
        ;;  
    *)  
        echo "Usage: ./winter_service.sh start | stop | restart | log"
        ;;  
esac  
