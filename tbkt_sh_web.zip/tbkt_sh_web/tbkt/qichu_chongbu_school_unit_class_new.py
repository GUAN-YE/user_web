#coding=utf8
import os,sys, datetime, MySQLdb

def get_ketang_conn():
    """
    功能            建立ketang库的mysql连接
    -----------------------------------
    添加人          添加时间           作用
    -----------------------------------
    杜祖永           2015-02-12
    """
    conn = MySQLdb.connect(host='122.114.40.79',
                           db='tbkt_ketang',
                           user='duzuyong',
                           passwd='ohStjN6DK$XqBAfhGzdz',
                           port=6033,
                           charset="utf8")
    return conn

def qichu_chongfu_school_unit_class_by_school_id(school_id, level_id=1):
    """去除重复的school_unit_class数据"""
    conn = get_ketang_conn()
    cursor = conn.cursor()

    # 找到相应学校相应级别下有重复的节点数据
    sql = """
    select school_id, grade_id,class_id,is_update,type, num from (
    select school_id, grade_id,class_id,is_update, type, COUNT(id) as num from tbkt_com.school_unit_class
    where school_id=%s and unit_type=1 and level_id=%s group by school_id,  type, grade_id,class_id, is_update
    ) ss where num>1
    """ % (school_id, level_id)
    print sql
    cursor.execute(sql)
    class_list = cursor.fetchall()
    print u'level_id=%s 共找到 %s 个重复的数据' % (level_id, len(class_list))
    i = 0
    for cls in class_list:
        i += 1
        print u'------------------合并第  %s 个重复数据-----------------------------------' % i

        grade_id = cls[1]       # 年级序号
        class_id = cls[2]       # 班级序号
        is_update = cls[3]
        type = cls[4]
        sql = """
        select id,path,grade_id, class_id, is_update from tbkt_com.school_unit_class  where
        school_id=%s and type=%s and grade_id=%s and class_id=%s and is_update=%s and level_id=%s and unit_type=1
        """ % (school_id, type, grade_id, class_id, is_update, level_id)

        cursor.execute(sql)
        unit_ids_list = cursor.fetchall()

        unit_id = unit_ids_list[0][0]       # 保留第一个ID
        unit_path = unit_ids_list[0][0]

        for del_cls in unit_ids_list[1:]:
            # 合并非第一条数据到第一条数据
            unit_id_del = del_cls[0]   # 需要合并数据ID
            if level_id == 3:
                # 更新订单范围班级信息
                update_rs_sql = "update tbkt_ketang.mobile_order_region set unit_class_id=%s  where unit_class_id=%s" % (unit_id, unit_id_del)
                # 删除重复班级
                del_suc_sql = "delete from  tbkt_com.school_unit_class  where id=%s" % unit_id_del

                print update_rs_sql
                print del_suc_sql
                cursor.execute(update_rs_sql)
                cursor.execute(del_suc_sql)
                conn.commit()
            else:
                # 更新子节点的parent_id path
                up_sql = "update tbkt_com.school_unit_class set parent_id=%s,path='%s' where parent_id=%s" % (unit_id, unit_path, unit_id_del)
                print up_sql
                cursor.execute(up_sql)
                conn.commit()

                # 更新订单范围班级信息
                update_rs_sql = "update tbkt_ketang.mobile_order_region set unit_class_id=%s  where unit_class_id=%s" % (unit_id,unit_id_del)
                print update_rs_sql
                cursor.execute(update_rs_sql)
                conn.commit()

                for obj2 in unit_ids_list:
                    # 查询是否有子节点,没有删除当前节点
                    sql = "select 1 from  tbkt_com.school_unit_class  where school_id=%s and parent_id=%s" % (school_id, obj2[0])
                    print sql
                    cursor.execute(sql)
                    fetchone = cursor.fetchone()
                    if not fetchone:
                        # 删除重复年级
                        sql = "delete from  tbkt_com.school_unit_class  where id=%s and level_id=%s" %  (obj2[0],level_id)
                        print sql
                        cursor.execute(sql)
                        conn.commit()


if __name__ =="__main__":
    argv = sys.argv
    school_id = int(argv[1])
    lelve_id = int(argv[2])
    print '----school_id=%s----------lelve_id=%s-------' % (school_id, lelve_id)
    sql = """
        select school_id, grade_id,class_id,is_update,type, num from (
    select school_id, grade_id,class_id,is_update, type, COUNT(id) as num from tbkt_com.school_unit_class
    where  unit_type=1 and level_id=%s group by school_id,  type, grade_id,class_id, is_update
    ) ss where num>1
    """ % lelve_id
    print sql
    conn = get_ketang_conn()
    cursor = conn.cursor()
    cursor.execute(sql)
    class_list = cursor.fetchall()
    num = 0
    for obj in class_list:
        school_id = obj[0]
        num += 1
        print school_id, lelve_id, num
        qichu_chongfu_school_unit_class_by_school_id(school_id, lelve_id)
    # qichu_chongfu_school_unit_class_by_school_id(school_id, lelve_id)
