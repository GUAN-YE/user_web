#coding: utf-8
"""补充录音时长服务"""
import MySQLdb
import urllib
import math
from mutagen.mp3 import MP3, MPEGInfo
from cStringIO import StringIO
import time

FILE_WEB_URLROOT = 'http://file.tbkt.cn'

def create_db_conn():
    conn = MySQLdb.connect(
                host='218.206.205.35',
                db='ziyuan_new',
                user='dba_user',
                passwd='tbkt123456',
                charset="utf8"
            )
    return conn

def get_table_rows(conn, table_name, audio_field='female_audio'):
    "获得一批待填数据"
    sql = """
    select id, %s from %s where %s!='' and duration<=0 limit 10
    """ % (audio_field, table_name, audio_field)
    cur = conn.cursor()
    cur.execute(sql)
    rows = cur.fetchall()
    cur.close()
    return rows

def save_duration(conn, table_name, id, duration):
    sql = """
    update %s set duration=%s where id=%s
    """ % (table_name, duration, id)
    cur = conn.cursor()
    cur.execute(sql)
    cur.close()
    conn.commit()

def handle(conn, table_name, audio_field='female_audio'):
    while 1:
        rows = get_table_rows(conn, table_name, audio_field)
        if not rows:
            print '%s completed!' % table_name
            break
        for id, mp3 in rows:
            url = FILE_WEB_URLROOT + "/upload_media/tts/" + mp3
            print url
            f = urllib.urlopen(url)
            data = f.read()
            f.close()
            f = StringIO(data)
            info = MPEGInfo(f)
            duration = math.ceil(info.length)
            f.close()
            print 'duration:', duration
            assert duration > 0
            save_duration(conn, table_name, id, duration)
        time.sleep(0.2)

def get_duration(url):
    "返回音频时长"
    print url
    st = time.time()
    f = urllib.urlopen(url)
    data = f.read()
    f.close()

    f = StringIO(data)
    info = MPEGInfo(f)
    duration = math.ceil(info.length)
    f.close()
    print 'took:', time.time() - st
    return duration

def main():
    #conn = create_db_conn()
    #handle(conn, 'yy_word')
    #handle(conn, 'yy2_word')
    #handle(conn, 'yy_standard_pool_detail')
    #handle(conn, 'yy2_standard_pool_detail')
    #handle(conn, 'yy2_question', 'listen_audio')
    #conn.close()
    print get_duration('http://records.cloud.chivox.com:80/57e0ee10fbec3cc7da16a92a.mp3')

if __name__ == '__main__':
    main()
