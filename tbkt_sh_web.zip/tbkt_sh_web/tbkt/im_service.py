#coding: utf-8
"""
消息推送服务
"""
import time
import traceback
import sys; 
sys.path.insert(0, '..')
import base
sys.path.insert(0, '../getui')
from getui import sdk


class Worker:

    def __init__(self, db_alias):
        self.db_alias = db_alias
        self.c = None

    def connect(self):
        self.c = base.connect(self.db_alias)
        self.c.select_db('tbkt_web')

    def close(self):
        if self.c:
            self.c.close()
            self.c = None

    def handle(self):
        """
        返回处理的条数
        """
        expire_time = int(time.time()) - 1800
        # 处理近期的消息
        sql = """
        SELECT m.id, m.config_id, d.client_id, if(d.device_type_id>2,2,1) dtype, m.title, m.content, m.transmission_content FROM gt_message m
        inner join gt_device d on d.user_id=m.user_id
        where m.push_status=0 and m.add_time>=%s
        limit 100
        """ % expire_time
        messages = self.c.fetchall_dict(sql)

        # 删除过期的消息
        sql = """
        delete from gt_message where add_time<%s
        """ % expire_time
        self.c.execute(sql)

        if not messages:
            return

        # 把内容相同的消息归类
        groups = {}  # {(config_id, title, text): [client_id]}
        for m in messages:
            k = (m.dtype, m.config_id, m.title, m.content, m.transmission_content)
            client_ids = groups.get(k, [])
            client_ids.append(m.client_id)
            groups[k] = client_ids

        # 批量发送
        for (dtype, config_id, title, text, transmission_content), client_ids in groups.items():
            sdk.sendmany(config_id, client_ids, title, text, dtype, transmission_content, "http://stu.m.tbkt.cn/static/notice/logo.png")

        # 修改发送状态
        message_ids = [m.id for m in messages]
        #print 'groups:', groups
        nowt = int(time.time())
        self.c.gt_message.filter(id__in=message_ids).update(push_status=1, add_time=nowt, success_time=nowt)

        return messages

    def start(self):
        while 1:
            try:
                self.connect()
                messages = self.handle() or []
                print 'handle:', len(messages)
                if not messages:
                    time.sleep(5.0)
            except:
                print traceback.format_exc()
                time.sleep(10.0)
            finally:
                self.close()


if __name__ == '__main__':
    worker = Worker('')
    worker.start()

elif __name__ == '__builtin__':
    worker = Worker('')
    application = base.twisted_run(worker.start, app_name='im_service')
