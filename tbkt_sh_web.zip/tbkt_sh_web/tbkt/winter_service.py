# coding: utf-8
import sys, os
import MySQLdb
import datetime
import time

# 设置工作目录
sys_base_path = os.path.abspath(__file__)
print os.path.normpath(os.path.join(sys_base_path, '../..'))
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))

from twisted.internet import reactor
from twisted.application import service

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')

from config import *

APP_ID = 22

def get_conn1():
    """
    建立连接
    :return:
    """
    conn = MySQLdb.connect(host='122.114.40.76',
                           db='tbkt',
                           user='renwanxing',
                           passwd='renwanxing60279052',
                           charset="utf8")
    return conn

def get_conn():
    """
    建立连接
    :return:
    """
    return get_mysql_conn()
    # conn = MySQLdb.connect(host='192.168.0.130',
    #                        db='tbkt',
    #                        user='dba_user',
    #                        passwd='tbkt123456',
    #                        charset="utf8")
    # return conn

class Worker:
    def __init__(self, conn):
        self.conn = conn
        day = datetime.date.today() - datetime.timedelta(days=1)
        self.begin_time = datetime.datetime(day.year, day.month, day.day, 0, 0, 0)
        self.end_time = datetime.datetime(day.year, day.month, day.day, 23, 59, 59)
        self.begin_tmp = int(time.mktime(self.begin_time.timetuple()))   # 昨天0点时间戳
        self.end_tmp = int(time.mktime(self.end_time.timetuple()))       # 昨天最后一刻时间戳


    def execute(self, sql, args=None):
        cur = self.conn.cursor()
        cur.execute(sql, args)
        id = cur.lastrowid
        cur.close()
        self.conn.commit()
        return id


    def fetchone(self, sql):
        cur = self.conn.cursor()
        cur.execute(sql)
        desc = cur.description
        row = cur.fetchone()
        cur.close()
        if not row:
            return {}
        row = dict(zip([col[0] for col in desc], row))
        return self.dict_to_obj(row)


    def fetchall(self, sql):
        cur = self.conn.cursor()
        cur.execute(sql)
        rows = cur.description
        d = [dict(zip([col[0] for col in rows], row)) for row in cur.fetchall()]
        cur.close()
        return self.fetchall_to_dict(d)


    def dict_to_obj(self, d):
        class _O: pass
        o = _O()
        [setattr(o, _k, d[_k]) for _k in d]
        return o


    def fetchall_to_dict(self, d):
        out = []
        for i in d:
            out.append(self.dict_to_obj(i))
        return out


    def count_to_day_stu(self):
        """
        按照班级计算当天参与活动的学生数
        :return:
        """
        sql = """
              select b.user_id,sum(t.num*50) score, r.city from
                (
                SELECT
                count(DISTINCT u.user_id) num,
                r.unit_class_id
                FROM
                (
                    SELECT user_id FROM tbkt_web.active_winter_test t  where t.add_time between %s and %s
                    UNION ALL
                    SELECT user_id FROM tbkt_web.active_winter_class_info c where c.add_time  between %s and %s
                ) u
                INNER JOIN ketang.mobile_user_bind b ON b.user_id = u.user_id
                INNER JOIN ketang.mobile_order_region r ON r.user_bind_id = b.id and r.unit_class_id >0
                GROUP BY
                r.unit_class_id
                ) t INNER JOIN ketang.mobile_order_region r on r.unit_class_id = t.unit_class_id inner join ketang.mobile_user_bind b
                on b.id = r.user_bind_id and b.type = 3 and b.subject_id in (2,9) and b.is_shield = 1 and b.user_id != 0 group by user_id;
              """ % (self.begin_tmp, self.end_tmp, self.begin_tmp, self.end_tmp)
        d = self.fetchall(sql)
        print "count_to_day_stu:%s" % len(d)
        insert_sql = """
                     INSERT INTO tbkt.score_user_detail
                    (user_id, item_no, score, cycle_num, remark, add_date, app_id) VALUES
                    """
        values = ''
        for i in d:
            app_id = 23 if i.city == '411200' else 22
            item_no = 'smx_join' if i.city == '411200' else 'hn_join'
            values += "(%s,'%s',%s, 3, '', date_sub(now(),INTERVAL 1 day), %s)," % (i.user_id, item_no, i.score, app_id)
        if d:
            self.execute(insert_sql + values[:-1])


    def count_to_tea_year(self):
        """
        计算学生当天给老师拜年次数 写入score_user_detail
        :return:
        """
        sql = """
        select s.score ,s.user_id,r.city from
        (select count(id)*100 score ,s.accept_user_id user_id  from tbkt_web.active_winter_class_info s
        where info_type = 1 and s.add_time between %s and %s 
        and s.accept_user_id !=0  group by s.accept_user_id) s
        inner join ketang.mobile_user_bind b on s.user_id = b.user_id and b.type = 3 and b.is_shield = 1
        inner join ketang.mobile_order_region r on r.user_bind_id =b.id 
        group by b.user_id
        """ % (self.begin_tmp, self.end_tmp)
        d = self.fetchall(sql)
        print "count_to_day_stu:%s" % len(d)
        insert_sql = """
                     insert into tbkt.score_user_detail
                    (user_id, item_no, score, cycle_num, remark, add_date, app_id) values
                    """
        values = ''
        for i in d:
            app_id = 23 if i.city == '411200' else 22
            item_no = 'smx_year' if i.city == '411200' else 'hn_year'
            values += "(%s,'%s',%s, 3, '', date_sub(now(),INTERVAL 1 day), %s)," % (i.user_id, item_no, i.score, app_id)
        insert_sql += values[:-1]
        if d:
            self.execute(insert_sql)


    def count_all(self):
        """
        用户积分累计 写入 score_users
        :return:
        """
        self.count_to_day_stu()
        self.count_to_tea_year()
        # 河南
        hn_sql = """
             select  s.score,s.user_id,r.city,r.unit_class_id from
                 (
                    SELECT sum(s1.score) score,s1.user_id from (
					select score,user_id,item_no,d.add_date from tbkt.score_user_detail d
                    where d.app_id = 22 and item_no in ('hn_join', 'hn_year', 'hn_send') and
                    d.add_date >= '%s' and d.add_date <= '%s'
                    GROUP BY item_no,user_id ) s1
                    GROUP by s1.user_id
                 )s
                INNER join ketang.mobile_user_bind b  on b.user_id = s.user_id and b.type = 3 and b.is_shield = 1
                inner join ketang.mobile_order_region r on r.user_bind_id =b.id and r.unit_class_id >0
                group by s.user_id;
             """ % (self.begin_time, self.end_time)
        d = self.fetchall(hn_sql)
        for i in d:
            sel = """
                  select id,score from tbkt.score_user d where app_id=22 and user_id = %s
                  """ % i.user_id
            row = self.fetchone(sel)
            if row:
                update = """update tbkt.score_user set score = %s where id = %s  """ % (row.score+i.score, row.id)
            else:
                update = """
                        insert into tbkt.score_user (user_id, score, app_id, city, unit_id)
                        values (%s, %s, %s, %s, 0)
                        """ % (i.user_id, i.score, 22, i.city)
            print i.user_id, i.score, 22, i.city
            self.execute(update)

        # 三门峡
        smx_sql = """
            select  s.score,s.user_id,r.city,r.unit_class_id from
                 (
                    SELECT sum(s1.score) score,s1.user_id from (
					select score,user_id,item_no,d.add_date from tbkt.score_user_detail d
                    where d.app_id = 23 and item_no in ('smx_join', 'smx_year', 'smx_send') and
                    d.add_date >= '%s' and d.add_date <= '%s'
                    GROUP BY item_no,user_id ) s1
                    GROUP by s1.user_id
                 )s
                INNER join ketang.mobile_user_bind b  on b.user_id = s.user_id and b.type = 3 and b.is_shield = 1
                inner join ketang.mobile_order_region r on r.user_bind_id =b.id and r.unit_class_id >0
                group by s.user_id;
             """ % (self.begin_time, self.end_time)
        smx = self.fetchall(smx_sql)
        for i in smx:
            sel = """
                  select id,score from tbkt.score_user d where app_id=23 and user_id = %s
                  """ % i.user_id
            row = self.fetchone(sel)
            if row:
                update = """update tbkt.score_user set score = %s where id = %s  """ % (row.score + i.score, row.id)
            else:
                update = """
                        insert into tbkt.score_user (user_id, score, app_id, city, unit_id)
                        values (%s, %s, %s, %s, 0)
                        """ % (i.user_id, i.score, 23, i.city)
            print i.user_id, i.score, 23, i.city
            self.execute(update)
        print "over"

    def start(self):
        lastd = None #datetime.date.today()
        while 1:
            today = datetime.date.today()
            if lastd != today:
                self.count_all()
                print 'did'
            else:
                print '.'

            lastd = today
            time.sleep(6)

    def handle(self):
        sql = """
               select score,user_id,id from tbkt.score_user where app_id = 22
               """
        rows = self.fetchall(sql)
        for obj in rows:
            sql1 = """
                       SELECT sum(s1.score) score,s1.user_id from (
                                               select score,user_id,item_no,d.add_date from tbkt.score_user_detail d
                           where d.app_id = 22 and item_no in ('hn_join', 'hn_year', 'hn_send')
                                               and user_id = %s
                           GROUP BY item_no,user_id,DATE(add_date)   ) s1
                           GROUP by s1.user_id
                   """ % obj.user_id
            rows1 = self.fetchone(sql1)
            if int(obj.score) != int(rows1.score):
                print "update_score:%s:%s" % (obj.score, rows1.score), "aaaa", obj.user_id
                update = """update tbkt.score_user set score = %s where id = %s  """ % (rows1.score, obj.id)
                self.execute(update)
        smxsql = """
                       select score,user_id,id from tbkt.score_user where app_id = 23
                       """
        smxrows = self.fetchall(smxsql)
        for i in smxrows:
            smxsql1 = """
                               SELECT sum(s1.score) score,s1.user_id from (
                                                       select score,user_id,item_no,d.add_date from tbkt.score_user_detail d
                                   where d.app_id = 23 and item_no in ('smx_join', 'smx_year', 'smx_send')
                                                       and user_id = %s
                                   GROUP BY item_no,user_id,DATE(add_date)   ) s1
                                   GROUP by s1.user_id
                           """ % i.user_id
            smxrows1 = self.fetchone(smxsql1)
            if int(i.score) != int(smxrows1.score):
                print "update_score:%s:%s" % (i.score, smxrows1.score), "aaaa", i.user_id
                update = """update tbkt.score_user set score = %s where id = %s  """ % (smxrows1.score, i.id)
                self.execute(update)


def loop():
    lastd = datetime.date.today()# - datetime.timedelta(days=1)
    while 1:
        today = datetime.date.today()
        if lastd != today:
            print 'start work.', datetime.datetime.now()
            c = get_conn()
            worker = Worker(c)
            try:
                worker.count_all()
            finally:
                c.close()
        else:
            print '.'

        lastd = today
        time.sleep(600)


def loop1():
    c = get_conn()
    worker = Worker(c)
    worker.handle()

if __name__ == "__main__":
    loop1()

elif __name__ == '__builtin__':
    print '__builtin__'
    reactor.callInThread(loop)
    application = service.Application('winter_service')
