#coding: utf-8
"""驰声录音同步(sink)到本地"""
import sys
import os
import time
import requests
import simplejson as json
import hashlib
import datetime

# 切换到base所在的目录
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, '.')
import base

UPLOAD_FILE_KEY_VALUE = 'bannei_upload'


def create_upload_key():
    now = datetime.datetime.now()
    m = hashlib.md5()
    m.update('%s%s' % (UPLOAD_FILE_KEY_VALUE, now.strftime("%Y%m%d")))
    return m.hexdigest()

class Worker:

    def __init__(self, c):
        self.c = c['tbkt_web']

    def get_jobs(self, n=10):
        return self.c.u_yy_study_detail.filter(local_audio='', remote_audio__ne='').order_by('-id')[:n]

    def readfile(self, url):
        url = url.strip()
        if not url.startswith('http'):
            url = 'http://' + url
        try:
            r = requests.get(url)
            return r.content
        except Exception, e:
            print 'READFILE ERROR)', e
            return

    def upload(self, url, data):
        try:
            fn = url.rsplit('/', 1)[1]
            files = {'file': (fn, data)}
            upload_key = create_upload_key()
            up_url = 'http://file.tbkt.cn/swf_upload/?upType=yy&upcheck=%s' % upload_key
            r = requests.post(up_url, files=files)
            text = r.text.replace("'", '"')
            results = json.loads(text)
            return results[0]['file_url']
        except Exception, e:
            print 'UPLOAD ERROR)', e

    def handle(self):
        jobs = self.get_jobs()
        for job in jobs:
            data = self.readfile(job.remote_audio)
            if not data:
                # 如果读取失败就清空远程地址
                self.c.u_yy_study_detail.filter(id=job.id).update(remote_audio='')
                continue
            fn = self.upload(job.remote_audio, data)
            if not fn:
                continue
            self.c.u_yy_study_detail.filter(id=job.id).update(local_audio=fn)
            print 'UPLOAD OK)', job.id
        return len(jobs)

    def start(self):
        while 1:
            n = self.handle()
            if n <= 0:
                print '.'
                time.sleep(10)

def main(dbname=''):
    c = base.connect(dbname)
    worker = Worker(c)
    worker.start()

if __name__ == '__main__':
    main('130')

elif __name__ == '__builtin__':
    application = base.twisted_run(main, app_name='yy_audio_sink')
