#coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import logging
import time
import random
import hashlib
import base64
import pymysql
from db import Hub
import json

LOCAL_HOST = '192.168.0.113'
# LOCAL_HOST = '116.255.220.113'
LOCAL_USER = 'duzuyong'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

HN_HOST = '192.168.0.112'
# HN_HOST = '116.255.220.112'
HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

JX_HOST = 'rm-2zeso7flj7kkik72r.mysql.rds.aliyuncs.com'
JX_USER = 'jx_tbkt_db'
JX_PASSWORD = 'fPhTisS3DvTZZgD'

db = Hub(pymysql)
# 本地新库
db.add_pool('local_user',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_user',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_ketang',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_com',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_com',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_yingyu',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_yingyu',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 河南大网老库
db.add_pool('hn_tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_tbktweb',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt_web',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_ketang',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 江西大网库
db.add_pool('jx_tbkt',
    host=JX_HOST, port=3306, user=JX_USER, passwd=JX_PASSWORD, db='jxtbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)


def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        return int(time.mktime(t))
    except:
        return 0

def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except:
        logging.info('encode_password: %s' % password)
        # print 'encode_password:', password
        return ''
    return "sha1$%s$%s" % (salt, hash)

def encode_plain_password(password):
    try:
        return base64.b64encode(password)
    except:
        return ''


class HNWorker:
    """
    河南导入类
    """
    def __init__(self):
        self.provinced = {} # {旧地市ID: 新地市ID}
        self.schoold = {} # {旧学校ID: 新学校ID}
        self.classd = {} # {旧班级ID: 新班级ID}

        self.taskd = {}
        self.yytaskdetail = {}
        self.yytestd = {}
        self.yy2testd = {}
        self.sxtestd = {}
        self.sx2testd = {}

        print 'init ok.'

    def import_yy_test(self):
        minid = 0
        psize = 2000
        # pk = 1
        while 1:
            sql = """
            SELECT id, user_id, catalog_id, nquestion, score, `status`, add_time, test_time, object_id
            FROM tbkt_web.u_yy_test 
            where id>%s
            order by id limit %s
            """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                user_id = t.user_id
                object_id = 0
                if t.object_id:
                    object_id = t.object_id               # task_id 保持不变

                details.append({
                    # "id": pk,                         # test_id 保持不变
                    "id": t.id,
                    "user_id": user_id,
                    "catalog_id": t.catalog_id,
                    "nquestion": t.nquestion,
                    "score": t.score,
                    "status": t.status,
                    "add_time": t.add_time,
                    "test_time": t.test_time,
                    "object_id": object_id})

            db.local_yingyu.yy_test.bulk_create(details, ignore=True)
            print "import yy_test", len(details)
            self.yytestd = {}
        print "yy_test over"

    def import_yy_test_detail(self):
        minid = 0
        psize = 2000
        while 1:
            task_sql = """
                select id,catalog_id,object_id,user_id from tbkt_yingyu.yy_test where id>%s limit %s
            """ % (minid, psize)
            task_list = db.local_yingyu.fetchall_dict(task_sql)
            if not task_list:
                break
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t

            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']

            sql = """
                SELECT id,test_id,question_id,ask_id,result,answer,option_id from tbkt_web.u_yy_test_detail
                where test_id in (%s) order by test_id
            """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            test_id = 0   # 测试主id
            text_list = []  # 主记录对应明细

            for obj in tlist:
                # {"answer": "B", "qid": 18132, "oid": 47030, "result": 1, "aid": 19455}
                if test_id == 0:
                    test_id = obj.test_id  # 主id
                if test_id > 0 and test_id != obj.test_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'test_id=%s to long text =%s' % (obj.test_id, len(json.dumps(text_list)))
                    else:
                        type_id = 1
                        object_id = task_dict.get(test_id).get("object_id")
                        catalog_id = task_dict.get(test_id).get("catalog_id")
                        user_id = task_dict.get(test_id).get("user_id")
                        if object_id == 0:
                            # 练习册
                            object_id = test_id
                            type_id = 2
                        detail_list.append({
                            "user_id": user_id,
                            "object_id": object_id,
                            "catalog_id": catalog_id,
                            "type": type_id,
                            "text": json.dumps(text_list),
                        })
                    test_id = obj.test_id
                    text_list = []
                detail = {"result": obj.result,
                          "qid": obj.question_id,
                          "oid": obj.option_id,
                          "aid": obj.ask_id,
                          "answer": obj.answer}
                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'test_id=%s to long text =%s' % (test_id, len(json.dumps(text_list)))
                else:
                    type_id = 1
                    object_id = task_dict.get(test_id).get("object_id")
                    catalog_id = task_dict.get(test_id).get("catalog_id")
                    user_id = task_dict.get(test_id).get("user_id")
                    if object_id == 0:
                        # 练习册
                        object_id = test_id
                        type_id = 2
                    detail_list.append({
                        "user_id": user_id,
                        "object_id": object_id,
                        "catalog_id": catalog_id,
                        "type": type_id,
                        "text": json.dumps(text_list),
                    })


            print "import yy_test_detail", minid
            db.local_yingyu.yy_test_detail.bulk_create(detail_list, ignore=True)

        print "yy_test_detail over"

    def import_yy_word_test(self):
        minid = 0
        psize = 2000
        # self.load_task_detail_id()
        while 1:
            sql = """
            SELECT id, user_id, catalog_id, type, score, `status`, test_time, object_id
            FROM tbkt_web.u_yy_word_test 
            where id>%s
            order by id limit %s
            """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                user_id = t.user_id
                # object_id = self.yytaskdetaild[t.object_id]           # task_detail_id 保持不变
                object_id = t.object_id


                details.append({
                    "user_id": user_id,
                    "catalog_id": t.catalog_id,
                    "score": t.score,
                    "type": t.type,
                    "status": t.status,
                    "test_time": t.test_time,
                    "object_id": object_id})

            print "import yy_word_test", minid
            db.local_yingyu.yy_word_test.bulk_create(details, ignore=True)
        print "u_yy_word_test over"

    def import_yy_word_test_detail(self):
        minid = 0
        psize = 2000
        while 1:
            task_sql = """
                select id,catalog_id,object_id,user_id,type from tbkt_yingyu.yy_word_test where id>%s limit %s
            """ % (minid, psize)
            task_list = db.local_yingyu.fetchall_dict(task_sql)
            if not task_list:
                break
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t

            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']

            sql = """
                SELECT id,test_id,word_id,result,score from tbkt_web.u_yy_word_test_detail
                where test_id in (%s) order by test_id
            """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            test_id = 0   # 测试主id
            text_list = []  # 主记录对应明细

            for obj in tlist:
                # {"wid": 6101, "score": 20, "result": 1}
                if test_id == 0:
                    test_id = obj.test_id  # 主id
                if test_id > 0 and test_id != obj.test_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'test_id=%s to long text =%s' % (obj.test_id, len(json.dumps(text_list)))
                    else:
                        type_id = task_dict.get(test_id).get("type")
                        object_id = task_dict.get(test_id).get("object_id")
                        catalog_id = task_dict.get(test_id).get("catalog_id")
                        user_id = task_dict.get(test_id).get("user_id")
                        if object_id > 0:
                            # 作业
                            object_id = object_id
                            if type_id == 1:
                                # 打气球
                                type_id = 3
                            elif type_id == 2:
                                # 打地鼠
                                type_id = 4
                        else:
                            object_id = test_id

                        detail_list.append({
                            "user_id": user_id,
                            "object_id": object_id,
                            "catalog_id": catalog_id,
                            "type": type_id,
                            "text": json.dumps(text_list),
                        })
                    test_id = obj.test_id
                    text_list = []
                detail = {"result": obj.result,
                          "wid": obj.word_id,
                          "score": obj.score,
                          }
                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'test_id=%s to long text =%s' % (test_id, len(json.dumps(text_list)))
                else:
                    type_id = 1
                    object_id = task_dict.get(test_id).get("object_id")
                    catalog_id = task_dict.get(test_id).get("catalog_id")
                    user_id = task_dict.get(test_id).get("user_id")
                    if object_id == 0:
                        # 练习册
                        object_id = test_id
                        type_id = 2
                    detail_list.append({
                        "user_id": user_id,
                        "object_id": object_id,
                        "catalog_id": catalog_id,
                        "type": type_id,
                        "text": json.dumps(text_list),
                    })


            print "import import_yy_word_test_detail", minid
            db.local_yingyu.yy_word_test_detail.bulk_create(detail_list, ignore=True)

        print "yy_test_detail over"

    def import_yy_study(self):
        minid = 0
        psize = 2000
        # self.load_task_detail_id()
        while 1:
            sql = """
            SELECT id, user_id, catalog_id, type, score, `status`, add_time, object_id
            FROM tbkt_web.u_yy_study 
            where id>%s
            order by id limit %s
            """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                user_id = t.user_id
                # object_id = self.yytaskdetaild[t.object_id]               # task_detail_id 保持不变
                object_id = t.object_id

                details.append({
                    "user_id": user_id,
                    "catalog_id": t.catalog_id,
                    "score": t.score,
                    "type": t.type,
                    "status": t.status,
                    "add_time": t.add_time,
                    "object_id": object_id})

            print "import yy_study", len(details)
            db.local_yingyu.yy_study.bulk_create(details, ignore=True)
        print "yy_study over"

    def import_yy_study_detail(self):
        minid = 0
        psize = 2000
        while 1:
            task_sql = """
                select id,catalog_id,object_id,user_id,type,add_time from tbkt_yingyu.yy_study where id>%s limit %s
            """ % (minid, psize)
            task_list = db.local_yingyu.fetchall_dict(task_sql)
            if not task_list:
                break
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t

            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']

            sql = """
                SELECT * from tbkt_web.u_yy_study_detail
                where study_id in (%s) order by study_id
            """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            test_id = 0   # 测试主id
            text_list = []  # 主记录对应明细

            for obj in tlist:
                # {"wid": 6101, "score": 20, "result": 1}
                if test_id == 0:
                    test_id = obj.study_id  # 主id

                if test_id > 0 and test_id != obj.study_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'study_id=%s to long text =%s' % (obj.study_id, len(json.dumps(text_list)))
                    else:
                        type_id = task_dict.get(test_id).get("type")
                        object_id = task_dict.get(test_id).get("object_id")
                        catalog_id = task_dict.get(test_id).get("catalog_id")
                        user_id = task_dict.get(test_id).get("user_id")
                        add_time = task_dict.get(test_id).get("add_time")

                        detail_list.append({
                            "user_id": user_id,
                            "object_id": object_id,
                            "catalog_id": catalog_id,
                            "type": type_id,
                            "text": json.dumps(text_list),
                            "add_time": add_time
                        })
                    test_id = obj.study_id
                    text_list = []
                detail = {"objid": obj.object_id,
                         "result": obj.result,
                         "score": obj.score,
                         "answer": obj.answer,
                         "role_id": obj.role_id,
                         "remote_audio": obj.remote_audio,
                         "local_audio": obj.local_audio}
                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'test_id=%s to long text =%s' % (test_id, len(json.dumps(text_list)))
                else:
                    type_id = 1
                    object_id = task_dict.get(test_id).get("object_id")
                    catalog_id = task_dict.get(test_id).get("catalog_id")
                    user_id = task_dict.get(test_id).get("user_id")
                    add_time = task_dict.get(test_id).get("add_time")

                    detail_list.append({
                        "user_id": user_id,
                        "object_id": object_id,
                        "catalog_id": catalog_id,
                        "type": type_id,
                        "text": json.dumps(text_list),
                        "add_time": add_time
                    })

            print "import yy_study_detail", minid
            db.local_yingyu.yy_study_detail.bulk_create(detail_list, ignore=True)

        print "yy_study_detail over"

    def import_yy2_test(self):
        minid = 0
        psize = 2000
        # pk = 1
        # self.load_yy2_test_id()

        while 1:
            sql = """
            SELECT id, user_id, catalog_id, score, `status`, add_time, object_id
            FROM tbkt.u_yy2_test 
            where id>%s
            order by id limit %s
            """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                user_id = t.user_id

                # object_id = self.taskd[t.object_id]               # task_id   保持不变
                object_id = t.object_id

                details.append({
                    # "id": pk,                                         # test_id 保持不变
                    "id": t.id,
                    "user_id": user_id,
                    "catalog_id": t.catalog_id,
                    "score": t.score,
                    "status": t.status,
                    "add_time": unix_timestamp(t.add_time),
                    "object_id": object_id})

            print "import yy2_test", len(details)
            db.local_yingyu.yy2_test.bulk_create(details, ignore=True)

        print "yy2_test over"

    def import_yy2_test_detail(self):
        minid = 0
        psize = 2000
        while 1:
            task_sql = """
                select id,catalog_id,object_id,user_id,type from tbkt_yingyu.yy2_test where id>%s limit %s
            """ % (minid, psize)
            task_list = db.local_yingyu.fetchall_dict(task_sql)
            if not task_list:
                break
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t

            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']

            sql = """
                SELECT * from tbkt.u_yy2_test_detail
                where study_id in (%s) order by study_id
            """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            test_id = 0   # 测试主id
            text_list = []  # 主记录对应明细

            for obj in tlist:
                # {"answer": "B", "qid": 18132, "oid": 47030, "result": 1, "aid": 19455}
                if test_id == 0:
                    test_id = obj.study_id  # 主id
                if test_id > 0 and test_id != obj.study_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'test_id=%s to long text =%s' % (obj.study_id, len(json.dumps(text_list)))
                    else:
                        # type_id = 1
                        object_id = task_dict.get(test_id).get("object_id")
                        catalog_id = task_dict.get(test_id).get("catalog_id")
                        user_id = task_dict.get(test_id).get("user_id")
                        type_id = task_dict.get(test_id).get("type")
                        detail_list.append({
                            "user_id": user_id,
                            "object_id": object_id,
                            "catalog_id": catalog_id,
                            "type": type_id,
                            "text": json.dumps(text_list),
                        })
                    test_id = obj.study_id
                    text_list = []
                detail = {"result": obj.result,
                          "qid": obj.object_id,
                          "oid": obj.option_id,
                          "aid": obj.ask_id,
                          "answer": obj.answer
                          }

                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'test_id=%s to long text =%s' % (test_id, len(json.dumps(text_list)))
                else:
                    object_id = task_dict.get(test_id).get("object_id")
                    catalog_id = task_dict.get(test_id).get("catalog_id")
                    user_id = task_dict.get(test_id).get("user_id")
                    type_id = task_dict.get(test_id).get("type")
                    detail_list.append({
                        "user_id": user_id,
                        "object_id": object_id,
                        "catalog_id": catalog_id,
                        "type": type_id,
                        "text": json.dumps(text_list),
                    })


            print "import yy2_test_detail", minid
            db.local_yingyu.yy2_test_detail.bulk_create(detail_list, ignore=True)

        print "yy2_test_detail over"

    def start(self):
        # 清记录
        print 'start henan worker 英语 用  2445 秒'


        # 英语单词测试记录

        db.local_yingyu.execute("truncate yy_word_test_detail")
        self.import_yy_word_test_detail()



if __name__ == '__main__':
    print datetime.datetime.now()
    hnworker = HNWorker()
    st = time.time()
    hnworker.start()
    print 'took:', time.time() - st
    print datetime.datetime.now()
