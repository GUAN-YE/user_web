#coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import time
import random
import hashlib
import base64
# import MySQLdb
from collections import defaultdict

import pymysql
from db import Hub
import json

LOCAL_HOST = '192.168.0.113'
# LOCAL_HOST = '116.255.220.112'
LOCAL_USER = 'duzuyong'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'
PORT = 3306

HN_HOST = '192.168.0.112'
# HN_HOST = '116.255.220.112'
HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

db = Hub(pymysql)
# 本地库
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=PORT, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)

# 河南大网老库
db.add_pool('hn_ziyuan',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ziyuan_new',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)


def update_weak_filed(update_table, id_field='', type_field=''):
    # update_table 需要更新的表

    minid = 0
    psize = 1000
    all_know_map = {}     # {qid: 对应知识点信息}
    all_wrong = []    # 错题qid

    while 1:
        # 已完成的测试详情记录
        test = update_table.select('id', 'text').filter(id__gt=minid)[:psize]
        if not test:
            break
        minid = test[-1].id
        test_map = {}

        # 本次批量下所有测试错误qid
        wrong = []
        for t in test:
            if len(t.text) < 2 or not is_json(t.text):
                # 格式错误 或者为空数组
                continue
            txt = json.loads(t.text)
            # 获取测试错题id
            wrong_qids = set([int(i.get('qid')) for i in txt if i and int(i.get('result')) != 1])
            test_map[t.id] = wrong_qids

            for wqid in wrong_qids:
                # 判断是否已查询过 避免重复查询
                if wqid not in all_wrong:
                    all_wrong.append(wqid)
                    wrong.append(wqid)

        # 获取对应错题id知识点信息
        q_know = get_question_knowledge(wrong)
        know_map = defaultdict(list)
        for qk in q_know:
            know_map[qk.question_id].append(qk.id)
        all_know_map.update(know_map)

        update_args = []
        for id, qids in test_map.iteritems():
            weak = []
            for qid in qids:
                knows = all_know_map.get(qid, None)
                if not knows:
                    # 说明qid没有对应知识点信息
                    continue
                for know in knows:
                    weak.append({'kid': know, 'mid': 0, 'cid': 0})
            update_args.append((json.dumps(weak), id))

        if update_args:
            sql = 'update %s' % update_table.table_name
            sql += """ set weak_knowledge=%s where id = %s"""
            # print update_args
            db.local_shuxue.execute_many(sql, update_args)
            print update_table.table_name, 'update sucess:', len(update_args), 'id', minid
    print update_table.table_name, 'update over'


def get_question_knowledge(qids):
    """
    根据qid返回知识点信息 
    """
    if not qids:
        return []
    qids = ','.join(str(i) for i in qids)
    sql = """
    select distinct k.id, a.question_id from sx2_knowledge k
    inner join sx2_relate_knowledge a on a.question_id in (%s) and a.knowledge_id = k.id and a.step_id is null
    """ % qids
    rows = db.hn_ziyuan.fetchall_dict(sql)
    return rows


def is_json(d):
    # 是否为json格式
    if not isinstance(d, (int, long)):
        try:
            json.loads(d)
        except ValueError:
            return False
        return True
    else:
        return False


if __name__ == '__main__':
    # 知识点字段更新
    # 作业
    update_weak_filed(db.local_shuxue.sx2_task_test_detail)
    # 练习册
    update_weak_filed(db.local_shuxue.sx2_test_detail)
    # 个性化
    update_weak_filed(db.local_shuxue.sx2_special_test_detail)
