#coding: utf-8
"""
更新用户密码为空的数据
"""
import datetime
import time
import random
import hashlib
import base64
# import MySQLdb
import pymysql
from db import Hub
import json


LOCAL_HOST = '192.168.7.250'
LOCAL_USER = 'dba_user'
LOCAL_PASSWORD = 'tbkt123456'

LOCAL_HOST = '192.168.0.111'

LOCAL_USER = 'duzuyong'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'



db = Hub(pymysql)
# 本地新库
db.add_pool('prod_user',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_user',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)

db.add_pool('prod_ketang',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)

def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except:
        print 'encode_password:', password
        return ''
    return "sha1$%s$%s" % (salt, hash)


def encode_plain_password(password):
    try:
        return base64.b64encode(password)
    except:
        return ''


def decode_pwd(pwd):
    # 返回明文密码
    try:
        return base64.b64decode(pwd)
    except:
        return ''


def get_none_pwd():
    # 更新没有密码的数据
    # auth_user
    # auth_profile
    default_password = '111111'  # 默认密码
    size = 100
    p = 1
    while 1:
        sql = """
        select u.id, p.password, p.id profile_id from auth_user u inner join auth_profile p 
        on u.id = p.user_id and u.password = '' limit %s, %s
        """ % ((p-1)*size, size)
        rows = db.prod_user.fetchall_dict(sql)
        if not rows:
            print 'update password finish!'
            break

        auth_user_update_args = []
        auth_profile_update_args = []

        for i in rows:
            if i.password:
                # 如果profile有密码
                # 则解析成明文密码，生成密文 update auth_user password 字段
                profile_pwd = decode_pwd(i.password)
                encode_pwd = encode_password(profile_pwd)
            else:
                # 如果为空
                # 则使用默认密码 更新 auth_user、auth_profile password字段
                profile_pwd = encode_plain_password(default_password)
                encode_pwd = encode_password(default_password)
                auth_profile_update_args.append((profile_pwd, i.profile_id))

            auth_user_update_args.append((encode_pwd, i.id))

        if auth_user_update_args:
            au = """
            update auth_user set password = %s where id = %s
            """
            db.prod_user.execute_many(au, auth_user_update_args)
            print 'update auth_user length=%s' % len(auth_user_update_args)

        if auth_profile_update_args:
            ap = """
            update auth_profile set password = %s where id = %s
            """
            db.prod_user.execute_many(ap, auth_profile_update_args)
            print 'update auth_profile length=%s' % len(auth_profile_update_args)
        p += 1
    print 'over!'


def update_mobile_subject_open_date():
    # 更新没有开通时间的数据
    now = int(time.time())
    while 1:
        detail_ids = db.prod_ketang.mobile_subject_detail_hn.\
            select('id').filter(status__in=(2, 3, 9), open_date=0).flat('id')#[:500]

        if not detail_ids:
            print 'update open_data finish!'
            break

        db.prod_ketang.mobile_subject_detail_hn.filter(id__in=detail_ids).update(open_date=now)
        print 'update success num=', len(detail_ids)
    print 'over!'


if __name__ == '__main__':
    # 更新密码
    # get_none_pwd()

    # 更新开通时间
    update_mobile_subject_open_date()
