#coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import logging
import time
import random
import hashlib
import base64
import pymysql
from db import Hub
import json

LOCAL_HOST = '192.168.0.114'
LOCAL_HOST = '116.255.220.112'
LOCAL_USER = 'duzuyong'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'


HN_HOST = '116.255.220.112'
HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

JX_HOST = 'rm-2zeso7flj7kkik72r.mysql.rds.aliyuncs.com'
JX_USER = 'jx_tbkt_db'
JX_PASSWORD = 'fPhTisS3DvTZZgD'

db = Hub(pymysql)
# 本地新库
db.add_pool('local_user',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_user',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_ketang',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_com',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_com',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_yingyu',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_yingyu',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 河南大网老库
db.add_pool('hn_tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_tbktweb',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt_web',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_ketang',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 江西大网库
db.add_pool('jx_tbkt',
    host=JX_HOST, port=3306, user=JX_USER, passwd=JX_PASSWORD, db='jxtbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)


def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        return int(time.mktime(t))
    except:
        return 0

def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except:
        logging.info('encode_password: %s' % password)
        # print 'encode_password:', password
        return ''
    return "sha1$%s$%s" % (salt, hash)

def encode_plain_password(password):
    try:
        return base64.b64encode(password)
    except:
        return ''


class HNWorker:
    """
    河南导入类
    """
    def __init__(self):
        self.provinced = {} # {旧地市ID: 新地市ID}
        self.schoold = {} # {旧学校ID: 新学校ID}
        self.classd = {} # {旧班级ID: 新班级ID}

        self.taskd = {}
        self.yytaskdetail = {}
        self.yytestd = {}
        self.yy2testd = {}
        self.sxtestd = {}
        self.sx2testd = {}

        print 'init ok.'

    def load_task_id(self):
        if not self.taskd:
            rows = db.local_shuxue.tmp_taskd[:]
            self.taskd = {r.old_id:r.new_id for r in rows} # {旧用户ID:新用户ID}

    def import_task(self):
        # minid = 0
        minid = 58649           # 2016-01-01 后的
        psize = 2000
        sx_pk = 1
        sx2_pk = 1
        yy_pk = 1
        yy2_pk = 1
        while 1:
            sql = """
            select id, subject_id, type, object_id, add_user, title, sms_content, status, UNIX_TIMESTAMP(add_time) as add_time,
            UNIX_TIMESTAMP(begin_time) as begin_time, UNIX_TIMESTAMP(end_time) as end_time, is_sendpwd
            FROM u_task 
            where id>%s
            ORDER BY id 
            LIMIT %s;
            """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            minid = tlist[-1].id
            sx_tasks, sx2_tasks, yy_tasks, yy2_tasks = [], [], [], []
            for t in tlist:
                add_user_id = t.add_user
                if t.subject_id == 21:
                    print "sx_task",t.id
                    sx_tasks.append({
                        # "id": sx_pk,
                        "id": t.id,                             # id保持不变， zsn
                        "type": t.type,
                        "object_id": t.object_id,
                        "add_user": add_user_id,
                        "title": t.title,
                        "sms_content": t.sms_content,
                        "status": t.status,
                        "add_time": t.add_time,
                        "begin_time": t.begin_time,
                        "end_time": t.end_time,
                        "is_sendpwd": t.is_sendpwd,
                    })
                    # self.taskd[t.id] = sx_pk
                    # sx_pk += 1
                if t.subject_id == 22:
                    print "sx2_task",t.id
                    sx2_tasks.append({
                        # "id": sx2_pk,
                        "id": t.id,                                 # id保持不变， zsn
                        "type": t.type,
                        "object_id": t.object_id,
                        "add_user": add_user_id,
                        "title": t.title,
                        "sms_content": t.sms_content,
                        "status": t.status,
                        "add_time": t.add_time,
                        "begin_time": t.begin_time,
                        "end_time": t.end_time,
                        "is_sendpwd": t.is_sendpwd,
                    })
                    # self.taskd[t.id] = sx2_pk
                    # sx2_pk += 1
                if t.subject_id == 91:
                    print "yy_task",t.id
                    yy_tasks.append({
                        # "id": yy_pk,
                        "id": t.id,                     # id保持不变， zsn
                        "type": t.type,
                        "object_id": t.object_id,
                        "add_user": add_user_id,
                        "title": t.title,
                        "sms_content": t.sms_content,
                        "status": t.status,
                        "add_time": t.add_time,
                        "begin_time": t.begin_time,
                        "end_time": t.end_time,
                        "is_sendpwd": t.is_sendpwd,
                    })
                    # self.taskd[t.id] = yy_pk
                    # yy_pk += 1
                if t.subject_id == 92:
                    print "yy2_task",t.id
                    yy2_tasks.append({
                        # "id": yy2_pk,
                        "id": t.id,                 # id保持不变， zsn
                        "type": t.type,
                        "object_id": t.object_id,
                        "add_user": add_user_id,
                        "title": t.title,
                        "sms_content": t.sms_content,
                        "status": t.status,
                        "add_time": t.add_time,
                        "begin_time": t.begin_time,
                        "end_time": t.end_time,
                        "is_sendpwd": t.is_sendpwd,
                    })
                    # self.taskd[t.id] = yy2_pk
                    # yy2_pk += 1
            db.local_shuxue.sx_task.bulk_create(sx_tasks, ignore=True)
            db.local_shuxue.sx2_task.bulk_create(sx2_tasks, ignore=True)
            db.local_yingyu.yy_task.bulk_create(yy_tasks, ignore=True)
            db.local_yingyu.yy2_task.bulk_create(yy2_tasks, ignore=True)
            rels = []
            for old_id, new_id in self.taskd.iteritems():
                rels.append({
                    'old_id': old_id, 'new_id': new_id
                })
            print 'task_rels:', len(rels)
            db.local_shuxue.tmp_taskd.bulk_create(rels, ignore=True)
            self.taskd = {}
        print "task over"

    def import_task_class(self):
        # minid = 0
        minid = 62070  # 2016-01-01 后的
        psize = 2000
        # self.load_classd()
        self.load_task_id()
        while 1:
            sql = """
            select tc.id, t.subject_id, tc.task_id, tc.unit_class_id, tc.type, tc.student_id,
            UNIX_TIMESTAMP(tc.add_time) as add_time
            FROM u_task_class tc 
            INNER JOIN u_task t ON t.id = tc.task_id 
            where tc.id>%s
            order by tc.id
            LIMIT %s
            """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            minid = tlist[-1].id
            sx_task_class, sx2_task_class, yy_task_class, yy2_task_class = [], [], [], []

            for t in tlist:
                stu_ids = []
                if t.student_id:
                    for d in t.student_id.split(","):
                        stu_ids.append(d)
                try:
                    # task_id = self.taskd[t.task_id]                   # zsn task_id 保持不变
                    task_id = t.task_id
                except:
                    # print "task_id not exists", t.task_id
                    logging.info("task_id not exists %s" % t.task_id)
                    continue
                try:
                    # unit_class_id = self.classd[t.unit_class_id]
                    unit_class_id = t.unit_class_id                     # zsn 班级id保持不变
                except:
                    # print "task_id not exists"
                    logging.info("unit_class_id not exists %s " % t.unit_class_id)
                    continue
                if t.subject_id == 21:
                    print "sx_task_class:", task_id
                    sx_task_class.append({
                        "task_id": task_id,
                        "unit_class_id": unit_class_id,
                        "type": t.type,
                        "student_id": ",".join(stu_ids) if stu_ids else "",
                        "add_time": t.add_time,
                    })
                if t.subject_id == 22:
                    print "sx2_task_class:", task_id
                    sx2_task_class.append({
                        "task_id": task_id,
                        "unit_class_id": unit_class_id,
                        "type": t.type,
                        "student_id": ",".join(stu_ids) if stu_ids else "",
                        "add_time": t.add_time,
                    })
                if t.subject_id == 91:
                    print "yy_task_class:",task_id
                    yy_task_class.append({
                        "task_id": task_id,
                        "unit_class_id": unit_class_id,
                        "type": t.type,
                        "student_id": ",".join(stu_ids) if stu_ids else "",
                        "add_time": t.add_time,
                    })
                if t.subject_id == 92:
                    print "yy2_task_class:",task_id
                    yy2_task_class.append({
                        "task_id": task_id,
                        "unit_class_id": unit_class_id,
                        "type": t.type,
                        "student_id": ",".join(stu_ids) if stu_ids else "",
                        "add_time": t.add_time,
                    })
            db.local_shuxue.sx_task_class.bulk_create(sx_task_class, ignore=True)
            db.local_shuxue.sx2_task_class.bulk_create(sx2_task_class, ignore=True)
            db.local_yingyu.yy_task_class.bulk_create(yy_task_class, ignore=True)
            db.local_yingyu.yy2_task_class.bulk_create(yy2_task_class, ignore=True)
        print "task_class over"

    def load_task_detail_id(self):
        if not self.taskd:
            rows = db.local_yingyu.tmp_yytaskdetaild[:]
            self.yytaskdetaild = {r.old_id:r.new_id for r in rows} # {旧用户ID:新用户ID}

    def import_yy_task_detail(self):
        # minid = 0
        minid = 481816           # 2016-01-01 后的
        psize = 2000
        pk = 1
        # self.load_task_id()
        # self.load_task_detail_id()
        while 1:
            sql = """
            select td.id, td.task_id, GROUP_CONCAT(td.catalog_id) as catalog_id,
             GROUP_CONCAT(td.text_catalog_id) as text_catalog_id,GROUP_CONCAT(td.question_id) as question_id,
              content_type FROM u_task_detail td
            INNER JOIN u_task t ON t.id= td.task_id
            WHERE t.subject_id = 91 and td.id>%s
            GROUP BY task_id, content_type 
            order by td.id
            limit %s
            """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            minid = tlist[-1].id

            details = []
            for t in tlist:
                try:
                    cids = t.catalog_id.split(',')
                    tcids = t.text_catalog_id.split(',')
                    qids = t.question_id.split(',')
                    text = []
                    for i in range(len(cids)):
                        cid = cids[i]
                        qid = qids[i]
                        tcid = tcids[i]
                        text.append({"cid": cid, "tcid": tcid, "qid": qid})
                    text = json.dumps(text)
                    try:
                        # task_id = self.taskd[t.task_id]               # task_id 保持不变
                        task_id = t.task_id
                    except:
                        # print "task not exists", task_id
                        logging.info("task not exists %s" % task_id)
                        continue
                    details.append({
                        # "id": pk,                                 # detail_id   保持不变
                        "id": t.id,
                        "task_id": task_id,
                        "text": text,
                        "content_type": t.content_type,
                    })
                    # self.yytaskdetail[t.id] = pk
                    # pk += 1
                except Exception, e:
                    # print 'id:%s---task_id:%s--content_type:%s--limit %s: 500-----%s' % (
                    # id, task_id, t.content_type, i, e)
                    logging.info('id:%s---task_id:%s--old_task_id:%s--content_type:%s--limit %s: 500-----%s' % (
                    pk, task_id, t.task_id, t.content_type, i, e))
            print "import yy_task_detail", minid
            db.local_yingyu.yy_task_detail.bulk_create(details, ignore=True)
            rels = []
            for old_id, new_id in self.yytaskdetail.iteritems():
                rels.append({
                    'old_id': old_id, 'new_id': new_id
                })
            db.local_yingyu.tmp_yytaskdetaild.bulk_create(rels, ignore=True)
            self.yytaskdetail = {}
        print "yy_task_class_detail over"

    def import_yy_task_detail_new(self):
        minid = 0
        minid = 58649  # 2016-01-01 后的
        psize = 2000
        while 1:
            sql = """
                SELECT td.id, td.task_id,td.catalog_id,td.question_id, td.text_catalog_id,
                content_type FROM u_task_detail td
                INNER JOIN (SELECT * from u_task where subject_id = 91 and id > %s and type <> 0) t ON t.id= td.task_id order by task_id, content_type  LIMIT %s
                """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            minid = tlist[-1].task_id
            # 作业id
            t_ids = []
            for d in tlist:
                if (int(d.task_id), int(d.content_type)) not in t_ids:
                    t_ids.append((int(d.task_id), int(d.content_type)))
            details = []
            for t in t_ids:
                try:
                    task_id = t[0]
                    content_type = t[1]
                except:
                    # print "task not exists",task_id
                    logging.info("task not exists %s" % task_id)
                    continue
                if content_type == 0:
                    continue
                texts = []
                qids = []
                detail_id = 0
                for i in tlist:
                    if detail_id == 0:
                        detail_id = i.id
                    if task_id == int(i.task_id) and content_type == int(i.content_type) and i.question_id not in qids:
                        detail = {"cid": i.catalog_id,
                                  "qid": i.question_id,
                                  "tcid": i.text_catalog_id}
                        texts.append(detail)
                        qids.append(i.question_id)
                if texts:
                    if len(json.dumps(texts)) > 11000:
                        logging.info("len is long======== %s %s" % (len(json.dumps(texts)), t))
                        # print "len is long========", len(json.dumps(texts)), t
                    details.append({
                        "id": detail_id,
                        "task_id": task_id,
                        "text": json.dumps(texts),
                         "content_type": content_type,
                    })
            print "import yy_task_detail ", len(details)
            db.local_yingyu.yy_task_detail.bulk_create(details, ignore=True)
        print "yy_task_class_detail over"

    def import_yy_task_progress(self):
        minid = 0
        psize = 2000
        # self.load_task_id()           # zsn
        while 1:
            sql = """
                SELECT ytp.id, ytp.user_id, ytp.task_id, ytp.`status`, ytp.update_time
                FROM tbkt_web.u_yy_task_progress ytp 
                where ytp.id>%s
                order by ytp.id
                LIMIT %s;
                """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                user_id = t.user_id
                try:
                    # task_id = self.taskd[t.task_id]           # task_id 保持不变
                    task_id = t.task_id
                except:
                    # print "task is not exists", t.task_id
                    logging.info("task is not exists %s " % t.task_id)
                    continue
                try:
                    details.append({
                        "user_id": user_id,
                        "task_id": task_id,
                        "status": t.status,
                        "update_time": t.update_time,
                    })
                except Exception, e:
                    # print e,"aaaaa"
                    logging.info(e)
                    continue
            print "import yy_task_progress", len(details)
            db.local_yingyu.yy_task_progress.bulk_create(details, ignore=True)
        print "yy_task_progress over"

    def load_yy_test_id(self):
        if not self.yytestd:
            rows = db.local_yingyu.tmp_yytestd[:]
            self.yytestd = {r.old_id: r.new_id for r in rows}  # {旧用户ID:新用户ID}

    def import_yy_test(self):
        minid = 0
        psize = 2000
        # pk = 1
        # self.load_yy_test_id()
        # self.load_task_id()
        while 1:
            sql = """
            SELECT id, user_id, catalog_id, nquestion, score, `status`, add_time, test_time, object_id
            FROM tbkt_web.u_yy_test 
            where id>%s
            order by id limit %s
            """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                try:
                    user_id = t.user_id
                except:
                    # print "user is not exists", t.user_id
                    logging.info("user is not exists %s " % t.user_id)
                    continue
                object_id = 0
                if t.object_id:
                    try:
                        # object_id = self.taskd[t.object_id]               # task_id 保持不变
                        object_id = t.object_id
                    except:
                        # print "task is not exists", t.object_id
                        logging.info("task is not exists %s" % t.object_id)
                        continue
                try:
                    details.append({
                        # "id": pk,                         # test_id 保持不变
                        "id": t.id,
                        "user_id": user_id,
                        "catalog_id": t.catalog_id,
                        "nquestion": t.nquestion,
                        "score": t.score,
                        "status": t.status,
                        "add_time": t.add_time,
                        "test_time": t.test_time,
                        "object_id": object_id})
                except Exception, e:
                    # print e
                    logging.info(e)
                    continue
                # self.yytestd[t.id] = pk
                # pk += 1
            print "import yy_test", len(details)
            db.local_yingyu.yy_test.bulk_create(details, ignore=True)
            rels = []
            for old_id, new_id in self.yytestd.iteritems():
                rels.append({
                    'old_id': old_id, 'new_id': new_id
                })
            db.local_yingyu.tmp_yytestd.bulk_create(rels, ignore=True)
            self.yytestd = {}
        print "yy_test over"

    def import_yy_test_detail(self):
        minid = 0
        psize = 2000
        self.load_yy_test_id()
        self.load_task_id()
        while 1:
            sql = """
            SELECT t.*,t1.catalog_id,t1.object_id,t1.user_id from (
                SELECT t.id, t.test_id, GROUP_CONCAT(t.question_id) question_id, GROUP_CONCAT(t.ask_id) ask_id,
                     GROUP_CONCAT(t.result) result, GROUP_CONCAT(t.answer) answer, GROUP_CONCAT(t.option_id) option_id
                    FROM tbkt_web.u_yy_test_detail t
                    where t.id>%s
                    GROUP BY t.test_id 
                    order by t.id
                    limit %s) t
                INNER join tbkt_web.u_yy_test t1 on t.test_id = t1.id
                order by t.id
            """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                try:
                    qids = t.question_id.split(',')
                    ask_ids = t.ask_id.split(',')
                    answers = t.answer.split(',')
                    results = t.result.split(',')
                    option_ids = t.option_id.split(',')
                    text = []
                    for i in range(len(qids)):
                        text.append({"qid": qids[i], "aid": ask_ids[i], "result": results[i], "answer": answers[i],
                                     "oid": option_ids[i]})
                    text = json.dumps(text)
                    if len(text) > 10000:
                        print "text is long", len(text)
                    task_id = 0
                    user_id = t.user_id
                    if not t.object_id:
                        try:
                            # test_id = self.yytestd[t.test_id]         # test_id 保持不变
                            test_id = t.id
                        except:
                            # print "test_id is not exists", t.test_id
                            logging.info("test_id is not exists %s" % t.test_id)
                            continue
                    else:
                        try:
                            # task_id = self.taskd[t.object_id]         # task_id 保持不变
                            task_id = t.object_id
                        except:
                            # print "task_id is not exists", t.object_id
                            logging.info("task_id is not exists %s" % t.object_id)
                            continue
                    d = dict(
                        catalog_id=t.catalog_id,
                        text=text,
                        object_id=task_id if task_id else test_id,
                        type=1 if task_id else 2,
                        user_id=user_id
                    )
                    details.append(d)
                except Exception, e:
                    # print e
                    logging.info(e)
                    continue
            print "import yy_test_detail", minid
            db.local_yingyu.yy_test_detail.bulk_create(details, ignore=True)
        print "yy_test_detail over"

    def import_yy_word_test(self):
        minid = 0
        psize = 2000
        # self.load_task_detail_id()
        while 1:
            sql = """
            SELECT id, user_id, catalog_id, type, score, `status`, test_time, object_id
            FROM tbkt_web.u_yy_word_test 
            where id>%s
            order by id limit %s
            """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                user_id = t.user_id
                object_id = 0
                if t.object_id:
                    try:
                        # object_id = self.yytaskdetaild[t.object_id]           # task_detail_id 保持不变
                        object_id = t.object_id
                    except:
                        # print "task_detail is not exists", t.object_id
                        logging.info("task_detail is not exists %s" % t.object_id)
                        continue
                try:
                    details.append({
                        "user_id": user_id,
                        "catalog_id": t.catalog_id,
                        "score": t.score,
                        "type": t.type,
                        "status": t.status,
                        "test_time": t.test_time,
                        "object_id": object_id})
                except Exception, e:
                    # print e
                    logging.info(e)
                    continue
            print "import yy_word_test", minid
            db.local_yingyu.yy_word_test.bulk_create(details, ignore=True)
        print "u_yy_word_test over"

    def import_yy_word_test_detail(self):
        minid = 0
        psize = 2000
        # self.load_task_detail_id()
        while 1:
            sql = """
            SELECT t.*,t1.catalog_id,t1.object_id,t1.user_id,t1.type from (
                SELECT t.id, t.test_id, GROUP_CONCAT(t.word_id) word_id,GROUP_CONCAT(t.result) result,
                GROUP_CONCAT(t.score) score FROM tbkt_web.u_yy_word_test_detail t
                  where t.id>%s
                  GROUP BY t.test_id 
                  order by t.id
                  limit %s) t
                INNER join tbkt_web.u_yy_word_test t1 on t.test_id = t1.id
                order by t.id
            """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                try:
                    wids = t.word_id.split(',')
                    scores = t.score.split(',')
                    results = t.result.split(',')
                    text = []
                    for i in range(len(wids)):
                        text.append({"wid": wids[i],  "result": results[i], "score": scores[i]})
                    text = json.dumps(text)
                    if len(text) > 9000:
                        print "text is long", len(text)
                    object_id = 0
                    user_id = t.user_id
                    if t.object_id:
                        try:
                            # object_id = self.yytaskdetaild[t.object_id]       # task_detail_id 保持不变
                            object_id = t.object_id
                        except:
                            logging.info("task_detail is not exists %s" % t.object_id)
                            # print "task_detail is not exists", t.object_id
                            continue
                    d = dict(
                        catalog_id=t.catalog_id,
                        text=text,
                        object_id=object_id,
                        user_id=user_id,
                        type=t.type
                    )
                    details.append(d)
                except Exception, e:
                    # print e
                    logging.log(e)
                    continue
            print "import yy_word_test_detail", minid
            db.local_yingyu.yy_word_test_detail.bulk_create(details, ignore=True)
        print "yy_word_test_detail over"

    def import_yy_study(self):
        minid = 0
        psize = 2000
        # self.load_task_detail_id()
        while 1:
            sql = """
            SELECT id, user_id, catalog_id, type, score, `status`, add_time, object_id
            FROM tbkt_web.u_yy_study 
            where id>%s
            order by id limit %s
            """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                user_id = t.user_id
                object_id = 0
                if t.object_id:
                    try:
                        # object_id = self.yytaskdetaild[t.object_id]               # task_detail_id 保持不变
                        object_id = t.object_id
                    except:
                        # print "task_detail is not exists", t.object_id
                        logging.info("task_detail is not exists %s" % t.object_id)
                        continue
                try:
                    details.append({
                        "user_id": user_id,
                        "catalog_id": t.catalog_id,
                        "score": t.score,
                        "type": t.type,
                        "status": t.status,
                        "add_time": t.add_time,
                        "object_id": object_id})
                except Exception, e:
                    # print e
                    logging.info(e)
                    continue
            print "import yy_study", len(details)
            db.local_yingyu.yy_study.bulk_create(details, ignore=True)
        print "yy_study over"

    def import_yy_study_detail(self):
        minid = 0
        psize = 2000
        # self.load_task_detail_id()
        while 1:
            sql = """
            SELECT t.id, t1.*,t.catalog_id,t.object_id obj_id, t.user_id,t.type,t.add_time
            from (SELECT * from tbkt_web.u_yy_study where id>%s LIMIT %s) t
            INNER join tbkt_web.u_yy_study_detail t1 on t1.study_id = t.id
            order by t.id
            """ % (minid, psize)
            # print sql
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            s_ids = []
            for s in recode:
                if s.study_id not in s_ids:
                    s_ids.append(s.study_id)
            for s in s_ids:
                try:
                    text = []
                    catalog_id, obj_id, _type, add_time = 0, 0, 0, 0
                    for t in recode:
                        if s == t.study_id:
                            try:
                                user_id = t.user_id
                            except:
                                # print "user_id is not exists", t.user_id
                                logging.info("user_id is not exists %s" % t.user_id)
                                continue
                            if t.obj_id:
                                try:
                                    # obj_id = self.yytaskdetaild[t.obj_id]                 # task_detail_id 保持不变
                                    obj_id = t.obj_id
                                except:
                                    logging.info("task_detail is not exists %s" % t.obj_id)
                                    # print "task_detail is not exists", t.obj_id
                                    continue
                            _type = t.type
                            add_time = t.add_time
                            catalog_id = t.catalog_id
                            text.append({"objid": t.object_id,
                                         "result": t.result,
                                         "score": t.score,
                                         "answer": t.answer,
                                         "role_id": t.role_id,
                                         "remote_audio": t.remote_audio,
                                         "local_audio": t.local_audio})
                    text = json.dumps(text)
                    if len(text) > 9000:
                        logging.info("text is long %s" % len(text))
                        # print "text is long", len(text)
                    d = dict(
                        catalog_id=catalog_id,
                        text=text,
                        object_id=obj_id,
                        user_id=user_id,
                        type=_type,
                        add_time=add_time
                    )
                    details.append(d)
                except Exception, e:
                    # print e
                    logging.info(e)
                    continue
            print "import yy_study_detail", minid
            db.local_yingyu.yy_study_detail.bulk_create(details, ignore=True)
        print "yy_study_detail over"

    def import_yy2_task_detail(self):
        minid = 0
        psize = 2000
        while 1:
            sql = """
            select td.id, td.task_id, GROUP_CONCAT(td.catalog_id) as catalog_id,
             GROUP_CONCAT(td.text_catalog_id) as text_catalog_id,GROUP_CONCAT(td.question_id) as question_id,
              content_type FROM u_task_detail td
            INNER JOIN u_task t ON t.id= td.task_id
            WHERE t.subject_id = 92 and td.id>%s and t.type <> 0
            GROUP BY task_id
            order by task_id
            limit %s
            """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            minid = tlist[-1].id

            details = []
            for t in tlist:
                try:
                    cids = t.catalog_id.split(',')
                    tcids = t.text_catalog_id.split(',')
                    qids = t.question_id.split(',')
                    text = []
                    for i in range(len(cids)):
                        cid = cids[i]
                        qid = qids[i]
                        tcid = tcids[i]
                        text.append({"cid": cid, "tcid": tcid, "qid": qid})
                    text = json.dumps(text)
                    try:
                        # task_id = self.taskd[t.task_id]               # task_id 保持不变
                        task_id = t.task_id
                    except:
                        # print "task not exists", task_id
                        logging.info("task not exists %s" % task_id)
                        continue
                    details.append({
                        # "id": pk,                                 # detail_id   保持不变
                        "id": t.id,
                        "task_id": task_id,
                        "text": text,
                        "content_type": t.content_type,
                    })
                    # self.yytaskdetail[t.id] = pk
                    # pk += 1
                except Exception, e:
                    # print 'id:%s---task_id:%s--content_type:%s--limit %s: 500-----%s' % (
                    # id, task_id, t.content_type, i, e)
                    logging.info('id:%s---task_id:%s--old_task_id:%s--content_type:%s--limit %s: 500-----%s' % (
                    t.id, task_id, t.task_id, t.content_type, i, e))
            print "import yy2_task_detail", minid
            db.local_yingyu.yy2_task_detail.bulk_create(details, ignore=True)
            # rels = []
            # for old_id, new_id in self.yytaskdetail.iteritems():
            #     rels.append({
            #         'old_id': old_id, 'new_id': new_id
            #     })
            # db.local_yingyu.tmp_yytaskdetaild.bulk_create(rels, ignore=True)
            # self.yytaskdetail = {}
        print "yy2_task_class_detail over"

    def load_yy2_test_id(self):
        if not self.yytestd:
            rows = db.local_yingyu.tmp_yy2testd[:]
            self.yy2testd = {r.old_id: r.new_id for r in rows}  # {旧用户ID:新用户ID}

    def import_yy2_test(self):
        minid = 0
        psize = 2000
        # pk = 1
        # self.load_yy2_test_id()
        # self.load_task_id()

        while 1:
            sql = """
            SELECT id, user_id, catalog_id, score, `status`, add_time, object_id
            FROM tbkt.u_yy2_test 
            where id>%s
            order by id limit %s
            """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                user_id = t.user_id
                object_id = 0
                if t.object_id:
                    try:
                        # object_id = self.taskd[t.object_id]               # task_id   保持不变
                        object_id = t.object_id
                    except:
                        # print "task is not exists", t.object_id
                        logging.info("task is not exists %s" % t.object_id)
                        continue
                try:
                    details.append({
                        # "id": pk,                                         # test_id 保持不变
                        "id": t.id,
                        "user_id": user_id,
                        "catalog_id": t.catalog_id,
                        "score": t.score,
                        "status": t.status,
                        "add_time": unix_timestamp(t.add_time),
                        "object_id": object_id})
                except Exception, e:
                    # print e
                    logging.info(e)
                    continue
                # self.yy2testd[t.id] = pk
                # pk += 1
            print "import yy2_test", len(details)
            db.local_yingyu.yy2_test.bulk_create(details, ignore=True)
            rels = []
            for old_id, new_id in self.yy2testd.iteritems():
                rels.append({
                    'old_id': old_id, 'new_id': new_id
                })
            db.local_yingyu.tmp_yy2testd.bulk_create(rels, ignore=True)
            self.yy2testd = {}
        print "yy2_test over"

    def import_yy2_test_detail(self):
        minid = 0
        psize = 2000
        self.load_yy2_test_id()
        self.load_task_id()
        while 1:
            sql = """
            SELECT t.*,t1.catalog_id,t1.object_id,t1.user_id from (
                SELECT t.id, t.study_id, GROUP_CONCAT(t.object_id) question_id, GROUP_CONCAT(t.question_ask_id) ask_id,
                                 GROUP_CONCAT(t.result) result, GROUP_CONCAT(t.answer) answer, GROUP_CONCAT(t.option_id) option_id
                                 FROM tbkt.u_yy2_test_detail t
                                GROUP BY t.study_id limit %s, %s) t
                INNER join tbkt.u_yy2_test t1 on t.study_id = t1.id
            """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            details = []
            for t in recode:
                try:
                    qids = t.question_id.split(',')
                    ask_ids = t.ask_id.split(',')
                    answers = t.answer.split(',')
                    results = t.result.split(',')
                    option_ids = t.option_id.split(',')
                    text = []
                    for i in range(len(qids)):
                        text.append({"qid": qids[i], "aid": ask_ids[i], "result": results[i], "answer": answers[i],
                                     "oid": option_ids[i]})
                    text = json.dumps(text)
                    if len(text) > 13000:
                        print "text is long", len(text)
                    task_id = 0
                    try:
                        user_id = t.user_id
                    except:
                        logging.info("user_id is not exists %s" % t.user_id)
                        # print "user_id is not exists", t.user_id
                        continue
                    if not t.object_id:
                        try:
                            # test_id = self.yy2testd[t.study_id]               # test_id 保持不变
                            test_id = t.study_id
                        except:
                            # logging.info("test_id is not exists %s" % t.test_id)
                            # print "test_id is not exists", t.test_id
                            continue
                    else:
                        try:
                            # task_id = self.taskd[t.object_id]             # task_id 保持不变
                            task_id = t.object_id
                        except:
                            logging.info("task_id is not exists %s" % t.object_id)
                            # print "task_id is not exists", t.object_id
                            continue
                    d = dict(
                        catalog_id=t.catalog_id,
                        text=text,
                        object_id=task_id if task_id else test_id,
                        type=1 if task_id else 2,
                        user_id=user_id
                    )
                    details.append(d)
                except Exception, e:
                    logging.info(e)
                    # print e
                    continue
            print "import yy2_test_detail", minid
            db.local_yingyu.yy2_test_detail.bulk_create(details, ignore=True)
            minid = minid + psize
        print "yy2_test_detail over"

    def import_sx_task_detail(self):
        minid = 0
        psize = 2000
        self.load_task_id()
        while 1:
            sql = """
                SELECT td.task_id,td.catalog_id,td.question_id, td.text_catalog_id,
                UNIX_TIMESTAMP(t.add_time) as add_time FROM u_task_detail td
                INNER JOIN (SELECT * from u_task where subject_id = 21 and id > %s and type <> 0 LIMIT %s) t ON t.id= td.task_id order by task_id
                """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            # 作业id
            t_ids = []
            for d in tlist:
                if int(d.task_id) not in t_ids:
                    t_ids.append(int(d.task_id))
            details = []
            for t in t_ids:
                try:
                    # task_id = self.taskd[t]               # task_id 保持不变
                    task_id = t
                except:
                    # print "task not exists",task_id
                    logging.info("task not exists %s" % task_id)
                    continue
                texts = []
                qids = []
                add_time = 0
                for i in tlist:
                    if int(t) == int(i.task_id) and i.question_id not in qids:
                        detail = {"cid": i.catalog_id,
                                  "qid": i.question_id,
                                  "tcid": i.text_catalog_id}
                        texts.append(detail)
                        add_time = i.add_time
                        qids.append(i.question_id)
                if texts:
                    if len(json.dumps(texts)) > 11000:
                        logging.info("len is long======== %s %s" % (len(json.dumps(texts)), t))
                        # print "len is long========", len(json.dumps(texts)), t
                    details.append({
                        "task_id": task_id,
                        "text": json.dumps(texts),
                        "add_time": add_time,
                    })
            print "import sx task detail ", len(details)
            db.local_shuxue.sx_task_content.bulk_create(details, ignore=True)
            minid = minid + psize
        print "import_sx_task_class_detail over"

    def import_sx2_task_detail(self):
        minid = 0
        psize = 2000
        self.load_task_id()
        while 1:
            sql = """
                SELECT td.task_id,td.catalog_id,td.question_id, td.text_catalog_id,
                UNIX_TIMESTAMP(t.add_time) as add_time FROM u_task_detail td
                INNER JOIN (SELECT * from u_task where subject_id = 22 and id > %s and type <> 0 LIMIT %s) t ON t.id= td.task_id order by task_id
                """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            minid = tlist[-1].task_id + 1
            # 作业id
            t_ids = []
            for d in tlist:
                if int(d.task_id) not in t_ids:
                    t_ids.append(int(d.task_id))
            details = []
            for t in t_ids:
                try:
                    # task_id = self.taskd[t]                   # task_id 保持不变
                    task_id = t
                except:
                    logging.info("task not exists %s" % t)
                    # print "task not exists", t
                    continue
                texts = []
                qids = []
                add_time = 0
                for i in tlist:
                    if int(t) == int(i.task_id) and i.question_id not in qids:
                        detail = {"cid": i.catalog_id,
                                  "qid": i.question_id,
                                  "tcid": i.text_catalog_id}
                        texts.append(detail)
                        add_time = i.add_time
                        qids.append(i.question_id)
                if texts:
                    if len(json.dumps(texts)) > 11000:
                        logging.info("len is long======== %s %s" % (len(json.dumps(texts)), t))
                        # print "len is long========", len(json.dumps(texts)), t
                    details.append({
                        "task_id": task_id,
                        "text": json.dumps(texts),
                        "add_time": add_time,
                    })
            print "import task2 detail ", len(details)
            db.local_shuxue.sx2_task_content.bulk_create(details, ignore=True)
        print "import_sx2_task_class_detail over"

    def load_sx_test_id(self):
        if not self.sxtestd:
            rows = db.local_shuxue.tmp_sxtestd[:]
            self.sxtestd = {r.old_id: r.new_id for r in rows}  # {旧用户ID:新用户ID}

    def import_sx_test(self):
        minid = 1
        psize = 1000
        self.load_task_id()
        self.load_sx_test_id()
        while 1:
            sql = """
                SELECT id,user_id,object_id,type,subject_id,title,score,`status`,
                UNIX_TIMESTAMP(test_time) test_time,UNIX_TIMESTAMP(add_time) add_time,wrong_status,
                agent from tbkt.u_sx_test where  id > %s limit %s;
                """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            task_details, test_details, special_details, wrong_details = [], [], [], []
            for t in tlist:
                # 作业测试记录
                try:
                    user_id = t.user_id
                except:
                    logging.info("user_id not exists %s" % t.user_id)
                    # print "user_id not exists", t.user_id
                    continue
                if t.type == 5:
                    try:
                        # task_id = self.taskd[t.object_id]         # task_id 保持不变
                        task_id = t.object_id
                    except:
                        logging.info("task not exists %s" % task_id)
                        # print "task not exists",task_id
                        continue
                    task_details.append({
                        # "id": self.sx_task_test,              # test_id 保持不变
                        "id": t.id,
                        "task_id": task_id,
                        "user_id": user_id,
                        "add_time": t.add_time,
                        "test_time": t.test_time,
                        "title": t.title,
                        "score": int(t.score) if int(t.score) > 0 else 0,
                        "status": t.status,
                        "wrong_status": t.wrong_status,
                        "agent": t.agent,
                    })
                    # self.sxtestd[t.id] = self.sx_task_test
                    # self.sx_task_test += 1
                if t.type in (1, 2):
                    test_details.append({
                        # "id": self.sx_test,                       # test_id 保持不变
                        "id": t.id,
                        "paper_id": t.object_id,
                        "user_id": user_id,
                        "add_time": t.add_time,
                        "test_time": t.test_time,
                        "title": t.title,
                        "score": int(t.score) if int(t.score) > 0 else 0,
                        "status": t.status,
                        "agent": t.agent,
                    })
                    # self.sxtestd[t.id] = self.sx_test
                    # self.sx_test += 1
                if t.type == 4:
                    wrong_details.append({
                        "user_id": user_id,
                        "catalog_id": t.object_id,
                        "add_time": t.add_time,
                        "test_time": t.test_time,
                        "title": t.title,
                        "score": int(t.score) if int(t.score) > 0 else 0,
                        "status": t.status,
                        "agent": t.agent,
                    })
                if t.type == 3:
                    try:
                        # 取作业id或试卷id
                        test = db.hn_tbkt.u_sx_test.filter(id=t.object_id).first()
                        if test.type == 5:
                            # object_id = self.taskd[test.object_id]                # task_id 保持不变
                            object_id = test.object_id
                        else:
                            object_id = test.object_id
                    except:
                        logging.info("object_id not exists %s" % t.object_id)
                        # print "object_id not exists", t.object_id
                        continue
                    special_details.append({
                        "user_id": user_id,
                        "object_id": object_id,
                        "object_type": t.type,
                        "title": t.title,
                        "score": int(t.score) if int(t.score) > 0 else 0,
                        "status": t.status,
                        "agent": t.agent,
                        "add_time": t.add_time,
                        "test_time": t.test_time,
                    })
                minid = t.id
            if len(task_details) > 0:
                print "import sx_task_test ", len(task_details)
                db.local_shuxue.sx_task_test.bulk_create(task_details, ignore=True)
            if len(test_details) > 0:
                print "import sx_test ", len(test_details)
                db.local_shuxue.sx_test.bulk_create(test_details, ignore=True)
            if len(special_details) > 0:
                print "import sx_special_test ", len(special_details)
                db.local_shuxue.sx_special_test.bulk_create(special_details, ignore=True)
            if len(wrong_details) > 0:
                print "import sx_wrong_title_set_test ", len(wrong_details)
                db.local_shuxue.sx_wrong_title_set_test.bulk_create(wrong_details, ignore=True)
            print minid
            rels = []
            for old_id, new_id in self.sxtestd.iteritems():
                rels.append({
                    'old_id': old_id, 'new_id': new_id
                })
            db.local_shuxue.tmp_sxtestd.bulk_create(rels, ignore=True)
            self.sxtestd = {}
        print "sx_test over"

    def import_sx_test_detail(self):
        minid = 0
        psize = 2000
        self.load_task_id()
        self.load_sx_test_id()
        while 1:
            sql = """
                    SELECT t1.object_id, t1.type, t1.user_id,t.* from tbkt.u_sx_test t1
                    inner join (
                    SELECT t.test_study_id,GROUP_CONCAT(t.question_id) question_id,
                    GROUP_CONCAT(t.question_ask_id) question_ask_id,GROUP_CONCAT(t.answer) answer,
                    GROUP_CONCAT(t.option_id) option_id,GROUP_CONCAT(t.result) result,UNIX_TIMESTAMP(t.add_time)
                    from tbkt.u_sx_test_detail t
                    GROUP BY t.test_study_id LIMIT %s,%s) t on t.test_study_id = t1.id;
                   """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            task_details, test_details, special_details, wrong_details = [], [], [], []
            for t in tlist:
                # 作业测试记录
                try:
                    user_id = t.user_id
                except:
                    logging.log("user_id not exists %s" % t.user_id)
                    # print "user_id not exists", t.user_id
                    continue
                qids = t.question_id.split(',')
                ask_ids = t.ask_id.split(',')
                answers = t.answer.split(',')
                results = t.result.split(',')
                option_ids = t.option_id.split(',')
                text = []
                for i in range(len(qids)):
                    text.append({"qid": qids[i], "aid": ask_ids[i], "result": results[i], "answer": answers[i],
                                 "oid": option_ids[i]})
                text = json.dumps(text)

                if t.type == 5:
                    try:
                        # task_id = self.taskd[t.object_id]             # task_id 保持不变
                        task_id = t.object_id
                    except:
                        logging.info("task not exists %s" % task_id)
                        # print "task not exists", task_id
                        continue
                    task_details.append({
                        "task_id": task_id,
                        "user_id": user_id,
                        "add_time": t.add_time,
                        "text": text,
                    })
                if t.type in (1, 2):
                    test_details.append({
                        "paper_id": t.object_id,
                        "user_id": user_id,
                        "type": t.type,
                        "add_time": t.add_time,
                        "text": text,
                    })
                if t.type == 4:
                    wrong_details.append({
                        "user_id": user_id,
                        "catalog_id": t.object_id,
                        "add_time": t.add_time,
                        "text": text,
                    })
                if t.type == 3:
                    try:
                        # 取作业id或试卷id
                        test = db.hn_tbkt.u_sx_test.filter(id=t.object_id).first()
                        if test.type == 5:
                            # object_id = self.taskd[test.object_id]      # task_id 保持不变
                            object_id = test.object_id
                        else:
                            object_id = test.object_id
                    except:
                        logging.log("object_id not exists %s" % t.object_id)
                        # print "object_id not exists", t.object_id
                        continue
                    special_details.append({
                        "user_id": user_id,
                        "object_id": object_id,
                        "object_type": t.object_type,
                        "text": text,
                        "add_time": t.add_time,
                    })
            print "import sx_task_test_detail ", len(task_details)
            db.local_shuxue.sx_task_test_detail.bulk_create(task_details, ignore=True)
            print "import sx_test_detail ", len(test_details)
            db.local_shuxue.sx_test_detail.bulk_create(test_details, ignore=True)
            print "import sx_special_test_detail ", len(special_details)
            db.local_shuxue.sx_special_test_detail.bulk_create(special_details, ignore=True)
            print "import sx_wrong_title_set_test_detail ", len(wrong_details)
            db.local_shuxue.sx_wrong_title_set_test_detail.bulk_create(wrong_details, ignore=True)
            minid = minid + psize
            print minid
        print "sx_test over"

    def import_sx_wrong_set(self):
        self.load_task_id()
        self.load_sx_test_id()
        sx_wrong_title_set_dict = db.local_shuxue.sx_wrong_title_set_dict.last()
        sx_wrong_title_set_dict_id = sx_wrong_title_set_dict.id if sx_wrong_title_set_dict else 1
        sql1 = """
            SELECT DISTINCT user_id from tbkt.u_sx_wrong_title_set
            """
        users = db.hn_tbkt.fetchall_dict(sql1)
        for user in users:
            sql = """
                    SELECT id,user_id,catalog_id,test_id,question_id,from_type,UNIX_TIMESTAMP(add_time) add_time
                    from tbkt.u_sx_wrong_title_set
                     where user_id= %s group by catalog_id;
                   """ % user.user_id
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            wrong_details = []
            catalog_ids = []
            catalog_ids = [d.catalog_id for d in tlist if d.catalog_id not in catalog_ids]
            from_types, from_details = [], []
            for c in catalog_ids:
                text = []
                for t in tlist:
                    if t.catalog_id == c:
                        try:
                            user_id = t.user_id
                        except:
                            logging.info("user_id not exists %s" % t.user_id)
                            # print "user_id not exists", t.user_id
                            continue
                        if t.from_type not in from_types:
                            sx_wrong_title_set_dict_id += 1
                            from_details.append({
                                "id": sx_wrong_title_set_dict_id,
                                "user_id": user_id,
                                "catalog_id": t.catalog_id,
                                "name": t.from_type,
                                "add_time": t.add_time
                            })
                            from_types.append(t.from_type)
                        text.append({"qid": t.question_id, "ftype": sx_wrong_title_set_dict_id})
                text = json.dumps(text)
                if len(text) > 9000:
                    # print "> 9000", len(text)
                    # print text
                    # print user.user_id
                    logging.log("> 9000 user %s len %s" % (user.user_id, len(text)))
                    #time.sleep(1000)
                wrong_details.append({
                    "user_id": user_id,
                    "catalog_id": c,
                    "text": text,
                })

            print "import sx_wrong_title_set_dict ", len(from_details)
            db.local_shuxue.sx_wrong_title_set_dict.bulk_create(from_details, ignore=True)
            print "import sx_wrong_title_set ", len(wrong_details)
            db.local_shuxue.sx_wrong_title_set.bulk_create(wrong_details, ignore=True)
        print "sx_wrong_title_set over"

    def load_sx2_test_id(self):
        if not self.sx2testd:
            rows = db.local_shuxue.tmp_sx2testd[:]
            self.sx2testd = {r.old_id: r.new_id for r in rows}  # {旧用户ID:新用户ID}

    def import_sx2_test(self):
        minid = 0
        psize = 2000
        self.load_task_id()
        self.load_sx2_test_id()
        while 1:
            sql = """
                SELECT id,user_id,object_id,type,subject_id,title,score,`status`,
                UNIX_TIMESTAMP(test_time) test_time,UNIX_TIMESTAMP(add_time) add_time,wrong_status
                from tbkt.u_sx2_test where id > %s limit %s
                """ % (minid,psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            task_details, test_details, special_details,wrong_details = [], [], [], []
            for t in tlist:
                # 作业测试记录
                try:
                    user_id = t.user_id
                except:
                    # print "user_id not exists", t.user_id
                    logging.log("user_id not exists %s" % t.user_id)
                    continue
                if t.type == 5:
                    try:
                        # task_id = self.taskd[t.object_id]         # task_id 保持不变
                        task_id = t.object_id
                    except:
                        # print "task not exists",task_id
                        logging.log("task not exists %s" % task_id)
                        continue
                    task_details.append({
                        # "id": self.sx2_task_test,             # test_id 保持不变
                        "id": t.id,
                        "task_id": task_id,
                        "user_id": user_id,
                        "add_time": t.add_time,
                        "test_time": t.test_time,
                        "title": t.title,
                        "score": t.score,
                        "status": t.status,
                        "wrong_status": t.wrong_status,
                        "agent": 1,
                    })
                    # self.sx2testd[t.id] = self.sx2_task_test
                    # self.sx2_task_test += 1
                if t.type in (1, 2):
                    test_details.append({
                        # "id": self.sx2_test,              # test_id 保持不变
                        "id": t.id,
                        "paper_id": t.object_id,
                        "user_id": user_id,
                        "add_time": t.add_time,
                        "test_time": t.test_time,
                        "title": t.title,
                        "score": t.score,
                        "status": t.status,
                        "agent": t.agent,
                    })
                    # self.sx2testd[t.id] = self.sx2_test
                    # self.sx2_test += 1
                if t.type == 4:
                    wrong_details.append({
                        "user_id": user_id,
                        "catalog_id": t.object_id,
                        "add_time": t.add_time,
                        "test_time": t.test_time,
                        "title": t.title,
                        "score": t.score,
                        "status": t.status,
                        "agent": t.agent,
                    })
                if t.type == 3:
                    try:
                        # 取作业id或试卷id
                        test = db.hn_tbkt.u_sx2_test.filter(id=t.object_id).first()
                        if test.type == 5:
                            # object_id = self.taskd[test.object_id]            # task_id  保持不变
                            object_id = test.object_id
                        else:
                            object_id = test.object_id
                    except:
                        logging.log("object_id not exists %s" % t.object_id)
                        # print "object_id not exists", t.object_id
                        continue
                    special_details.append({
                        "user_id": user_id,
                        "object_id": object_id,
                        "object_type": t.type,
                        "title": t.title,
                        "score": t.score,
                        "status": t.status,
                        "agent": t.agent,
                        "add_time": t.add_time,
                        "test_time": t.test_time,
                    })
                minid = t.id
            if len(task_details) > 0:
                print "import sx2_task_test ", len(task_details)
                db.local_shuxue.sx2_task_test.bulk_create(task_details, ignore=True)
            if len(test_details) > 0:
                print "import sx2_test ", len(test_details)
                db.local_shuxue.sx2_test.bulk_create(test_details, ignore=True)
            if len(special_details) > 0:
                print "import sx2_special_test ", len(special_details)
                db.local_shuxue.sx2_special_test.bulk_create(special_details, ignore=True)
            if len(wrong_details) > 0:
                print "import sx2_wrong_title_set_test ", len(wrong_details)
                db.local_shuxue.sx2_wrong_title_set_test.bulk_create(wrong_details, ignore=True)
            print minid
            rels = []
            for old_id, new_id in self.sx2testd.iteritems():
                rels.append({
                    'old_id': old_id, 'new_id': new_id
                })
            db.local_shuxue.tmp_sx2testd.bulk_create(rels, ignore=True)
            self.sx2testd = {}
        print "sx2_test over"

    def import_sx2_test_detail(self):
        minid = 0
        psize = 2000
        self.load_task_id()
        self.load_sx2_test_id()
        while 1:
            sql = """
                    SELECT t1.object_id, t1.type, t1.user_id,t.* from tbkt.u_sx2_test t1
                    inner join (
                    SELECT t.test_study_id,GROUP_CONCAT(t.question_id) question_id,
                    GROUP_CONCAT(t.question_ask_id) question_ask_id,GROUP_CONCAT(t.answer) answer,
                    GROUP_CONCAT(t.option_id) option_id,GROUP_CONCAT(t.result) result,UNIX_TIMESTAMP(t.add_time)
                    from tbkt.u_sx2_test_detail t
                    GROUP BY t.test_study_id LIMIT %s,%s) t on t.test_study_id = t1.id;
                   """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            task_details, test_details, special_details, wrong_details = [], [], [], []
            for t in tlist:
                # 作业测试记录
                try:
                    user_id = t.user_id
                except:
                    logging.info("user_id not exists %s " % t.user_id)
                    # print "user_id not exists", t.user_id
                    continue
                qids = t.question_id.split(',')
                ask_ids = t.ask_id.split(',')
                answers = t.answer.split(',')
                results = t.result.split(',')
                option_ids = t.option_id.split(',')
                text = []
                for i in range(len(qids)):
                    text.append({"qid": qids[i], "aid": ask_ids[i], "result": results[i], "answer": answers[i],
                                 "oid": option_ids[i]})
                text = json.dumps(text)

                if t.type == 5:
                    try:
                        # task_id = self.taskd[t.object_id]             # task_id  保持不变
                        task_id = t.object_id
                    except:
                        logging.info("task not exists %s" % task_id)
                        # print "task not exists", task_id
                        continue
                    task_details.append({
                        "task_id": task_id,
                        "user_id": user_id,
                        "add_time": t.add_time,
                        "text": text,
                    })
                if t.type in (1, 2):
                    test_details.append({
                        "paper_id": t.object_id,
                        "user_id": user_id,
                        "type": t.type,
                        "add_time": t.add_time,
                        "text": text,
                    })
                if t.type == 4:
                    wrong_details.append({
                        "user_id": user_id,
                        "catalog_id": t.object_id,
                        "add_time": t.add_time,
                        "text": text,
                    })
                if t.type == 3:
                    try:
                        # 取作业id或试卷id
                        test = db.hn_tbkt.u_sx2_test.filter(id=t.object_id).first()
                        if test.type == 5:
                            # object_id = self.taskd[test.object_id]            # task_id  保持不变
                            object_id = test.object_id
                        else:
                            object_id = test.object_id
                    except:
                        logging.info("object_id not exists %s" % t.object_id)
                        # print "object_id not exists", t.object_id
                        continue
                    special_details.append({
                        "user_id": user_id,
                        "object_id": object_id,
                        "object_type": t.object_type,
                        "text": text,
                        "add_time": t.add_time,
                    })
            print "import sx2_task_test_detail ", len(task_details)
            db.local_shuxue.sx2_task_test_detail.bulk_create(task_details, ignore=True)
            print "import sx2_test_detail ", len(test_details)
            db.local_shuxue.sx2_test_detail.bulk_create(test_details, ignore=True)
            print "import sx2_special_test_detail ", len(special_details)
            db.local_shuxue.sx2_special_test_detail.bulk_create(special_details, ignore=True)
            print "import sx2_wrong_title_set_test_detail ", len(wrong_details)
            db.local_shuxue.sx2_wrong_title_set_test_detail.bulk_create(wrong_details, ignore=True)
            minid = minid + psize
            print minid
        print "sx2_test over"


    def import_table(self, localtable, remotetable, converter={}, callback=None):
        """
        :param localtable: 目标db表(QuerySet)
        :param remotetable: 来源db表(QuerySet)
        :param converter: {'字段名':转换类型('user_id'转为新用户ID, 'unixtime'转为时间戳, 'ignore':忽略该字段, ...)}
        :param callback: 过滤器函数
        """
        minid = 0
        psize = 2000
        while 1:
            rows = remotetable.filter(id__gt=minid).order_by('id')[:psize]
            if not rows:
                break
            minid = rows[-1].id
            details = []
            for r in rows:
                if callback and callable(callback):
                    r = callback(r)
                for fieldname, type in converter.iteritems():
                    if type == 'user_id_strict':
                        pass
                    elif type == 'user_id':
                        pass
                    elif type == 'unixtime':
                        r[fieldname] = unix_timestamp(r[fieldname])
                    elif type == 'ignore':
                        r.pop(fieldname, None)
                    elif type == 'sxtest_id':
                        self.load_sx_test_id()
                        test_id = self.sxtestd.get(r[fieldname], 0)
                        if not test_id:
                            continue
                        r[fieldname] = self.sxtestd.get(r[fieldname], 0)
                    elif type == 'sx2test_id':
                        self.load_sx2_test_id()
                        test_id = self.sx2testd.get(r[fieldname], 0)
                        if not test_id:
                            continue
                        r[fieldname] = self.sx2testd.get(r[fieldname], 0)
                details.append(r)
            localtable.bulk_create(details, ignore=True)
            print "import table %s: %s %s" % (localtable.table_name, minid, len(details))
        print "import table %s over" % localtable.table_name

    def start(self):
        # 清记录
        print 'start henan worker'

        # # 导作业表
        # db.local_shuxue.execute("truncate tmp_taskd")
        # db.local_shuxue.execute("truncate sx_task")
        # db.local_shuxue.execute("truncate sx2_task")
        # db.local_yingyu.execute("truncate yy_task")
        # db.local_yingyu.execute("truncate yy2_task")
        # self.import_task()
        # #
        # # # 导作业班级表
        # db.local_shuxue.execute("truncate sx_task_class")
        # db.local_shuxue.execute("truncate sx2_task_class")
        # db.local_yingyu.execute("truncate yy_task_class")
        # db.local_yingyu.execute("truncate yy2_task_class")
        # self.import_task_class()
        # #
        # # # # 英语作业明细
        # db.local_yingyu.execute("truncate tmp_yytaskdetaild")
        # db.local_yingyu.execute("truncate yy_task_detail")
        # self.import_yy_task_detail_new()
        #
        # # # # 英语作业进度
        # db.local_yingyu.execute("truncate yy_task_progress")
        # self.import_yy_task_progress()
        #
        # # 英语测试记录
        # db.local_yingyu.execute("truncate yy_test")
        # # db.local_yingyu.execute("truncate tmp_yytestd")
        # self.import_yy_test()
        #
        # # 英语测试明细
        # db.local_yingyu.execute("truncate yy_test_detail")
        # self.import_yy_test_detail()
        #
        # # 英语单词测试记录
        # db.local_yingyu.execute("truncate yy_word_test")
        # self.import_yy_word_test()
        # db.local_yingyu.execute("truncate yy_word_test_detail")
        # self.import_yy_word_test_detail()
        #
        # # 英语学习记录
        # db.local_yingyu.execute("truncate yy_study")
        # self.import_yy_study()
        # db.local_yingyu.execute("truncate yy_study_detail")
        # self.import_yy_study_detail()
        #

        # 初中英语作业详细表
        # db.local_yingyu.execute("truncate yy2_task_detail")
        # self.import_yy2_task_detail()


        # # 初中英语测试记录
        # db.local_yingyu.execute("truncate yy2_test")
        # db.local_yingyu.execute("truncate tmp_yy2testd")
        # self.import_yy2_test()
        # db.local_yingyu.execute("truncate yy2_test_detail")
        # self.import_yy2_test_detail()

        # # 数学作业明细
        # db.local_shuxue.execute("truncate sx_task_content")
        # self.import_sx_task_detail()
        # db.local_shuxue.execute("truncate sx2_task_content")
        self.import_sx2_task_detail()

        # # 数学测试记录
        # db.local_shuxue.execute("truncate tmp_sxtestd")
        # db.local_shuxue.execute("truncate sx_task_test")
        # db.local_shuxue.execute("truncate sx_test")
        # db.local_shuxue.execute("truncate sx_special_test")
        # db.local_shuxue.execute("truncate sx_wrong_title_set_test")
        # self.import_sx_test()

        # # 数学测试明细
        # db.local_shuxue.execute("truncate sx_task_test_detail")
        # db.local_shuxue.execute("truncate sx_test_detail")
        # db.local_shuxue.execute("truncate sx_special_test_detail")
        # db.local_shuxue.execute("truncate sx_wrong_title_set_test_detail")
        # self.import_sx_test_detail()

        # # 初中数学测试记录
        # db.local_shuxue.execute("truncate tmp_sx2testd")
        # db.local_shuxue.execute("truncate sx2_task_test")
        # db.local_shuxue.execute("truncate sx2_test")
        # db.local_shuxue.execute("truncate sx2_special_test")
        # db.local_shuxue.execute("truncate sx2_wrong_title_set_test")
        # self.import_sx2_test()

        # # 初中数学测试明细
        # db.local_shuxue.execute("truncate sx2_task_test_detail")
        # db.local_shuxue.execute("truncate sx2_test_detail")
        # db.local_shuxue.execute("truncate sx2_special_test_detail")
        # db.local_shuxue.execute("truncate sx2_wrong_title_set_test_detail")
        self.import_sx2_test_detail()

        # # 导错题集
        # db.local_shuxue.execute("truncate sx_wrong_title_set")
        # db.local_shuxue.execute("truncate sx_wrong_title_set_dict")
        # self.import_sx_wrong_set()

        # 用户试卷表
        # db.local_shuxue.execute("truncate sx_paper")
        # self.import_table(db.local_shuxue.sx_paper, db.hn_tbktweb.sx_paper, {'add_user':'user_id', 'add_time':'unixtime'})
        # db.local_shuxue.execute("truncate sx_paper_detail")
        # self.import_table(db.local_shuxue.sx_paper_detail, db.hn_tbktweb.sx_paper_detail, {'add_user':'user_id', 'add_time':'unixtime'})
        # db.local_shuxue.execute("truncate sx_paper_question_number")
        # self.import_table(db.local_shuxue.sx_paper_question_number, db.hn_tbktweb.sx_paper_question_number, {'add_user':'user_id', 'add_time':'unixtime'})
        # db.local_shuxue.execute("truncate sx_paper_relate")
        # self.import_table(db.local_shuxue.sx_paper_relate, db.hn_tbktweb.sx_paper_relate, {'add_user':'user_id', 'add_time':'unixtime'})
        # db.local_shuxue.execute("truncate sx_paper_type")
        # self.import_table(db.local_shuxue.sx_paper_type, db.hn_tbktweb.sx_paper_type, {'add_user':'user_id', 'add_time':'unixtime'})

        # db.local_shuxue.execute("truncate sx2_paper")
        # self.import_table(db.local_shuxue.sx2_paper, db.hn_tbktweb.sx2_paper, {'add_user':'user_id', 'add_time':'unixtime'})
        # db.local_shuxue.execute("truncate sx2_paper_detail")
        # self.import_table(db.local_shuxue.sx2_paper_detail, db.hn_tbktweb.sx2_paper_detail, {'add_user':'user_id', 'add_time':'unixtime'})
        # db.local_shuxue.execute("truncate sx2_paper_question_number")
        # self.import_table(db.local_shuxue.sx2_paper_question_number, db.hn_tbktweb.sx2_paper_question_number, {'add_user':'user_id', 'add_time':'unixtime'})
        # db.local_shuxue.execute("truncate sx2_paper_relate")
        # self.import_table(db.local_shuxue.sx2_paper_relate, db.hn_tbktweb.sx2_paper_relate, {'add_user':'user_id', 'add_time':'unixtime'})
        # db.local_shuxue.execute("truncate sx2_paper_type")
        # self.import_table(db.local_shuxue.sx2_paper_type, db.hn_tbktweb.sx2_paper_type, {'add_user':'user_id', 'add_time':'unixtime'})

def log_config():
    """配置log输出"""
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s %(filename)s[line:%(lineno)d] %(funcName)s %(message)s',
                        datefmt='%a,%d %b %Y %H:%M:%S',
                        filename='import_data_hn_test.log',
                        filemode='w+')

    logging.info('import_data_hn_test begin log info')

if __name__ == '__main__':
    log_config()
    hnworker = HNWorker()
    st = time.time()
    hnworker.start()
    print 'took:', time.time()-st