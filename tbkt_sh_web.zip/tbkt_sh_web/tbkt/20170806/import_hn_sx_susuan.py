# coding: utf-8


LOCAL_HOST = '192.168.0.76'
# LOCAL_HOST = '116.255.220.112'
LOCAL_USER = 'duzuyong'
LOCAL_USER = 'bannei'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'
LOCAL_PASSWORD = 'bannei60279052'


# HN_HOST = '192.168.7.250'
HN_HOST = '116.255.220.112'
HN_HOST = '192.168.0.112'

HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

import time
import pymysql
from db import Hub


db = Hub(pymysql)
# 本地新库
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)

# 河南大网老库
db.add_pool('hn_tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_tbktweb',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt_web',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)


def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        return int(time.mktime(t))
    except:
        return 0


def import_table(localtable, remotetable, converter={}, callback=None):
    """
    :param localtable: 目标db表(QuerySet)
    :param remotetable: 来源db表(QuerySet)
    :param converter: {'字段名':转换类型('user_id'转为新用户ID, 'unixtime'转为时间戳, 'ignore':忽略该字段, ...)}
    :param callback: 过滤器函数
    """
    minid = 0
    psize = 2000
    while 1:
        rows = remotetable.filter(id__gt=minid)[:psize]
        if not rows:
            break
        minid = rows[-1].id
        details = []
        for r in rows:
            if callback and callable(callback):
                r = callback(r)
            for fieldname, type in converter.iteritems():
                if type == 'user_id_strict':
                    pass
                elif type == 'user_id':
                    pass
                elif type == 'unixtime':
                    r[fieldname] = unix_timestamp(r[fieldname])
                elif type == 'ignore':
                    r.pop(fieldname, None)
            if r.has_key('update_date') and not r.update_date:
                r.update_date = 0
            details.append(r)
        localtable.bulk_create(details, ignore=True)
        print "import table %s: %s %s" % (localtable.table_name, minid, len(details))
    print "import table %s over" % localtable.table_name


if __name__ == '__main__':
    star = time.time()
    db.local_shuxue.execute("truncate susuan_first")
    import_table(localtable=db.local_shuxue.susuan_first, remotetable=db.hn_tbktweb.susuan_first)

    db.local_shuxue.execute("truncate susuan_test")
    import_table(localtable=db.local_shuxue.susuan_test, remotetable=db.hn_tbktweb.susuan_test)

    db.local_shuxue.execute("truncate susuan_question")
    import_table(localtable=db.local_shuxue.susuan_question, remotetable=db.hn_tbkt.a_susuan_question)

    end = time.time()
    print end - star  # 75s