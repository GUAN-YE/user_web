#coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import logging
import time
import random
import hashlib
import base64
import pymysql
from db import Hub
import json

LOCAL_HOST = '192.168.0.113'
# LOCAL_HOST = '116.255.220.114'
LOCAL_USER = 'duzuyong'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

HN_HOST = '192.168.0.112'
# HN_HOST = '116.255.220.112'
HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

JX_HOST = 'rm-2zeso7flj7kkik72r.mysql.rds.aliyuncs.com'
JX_USER = 'jx_tbkt_db'
JX_PASSWORD = 'fPhTisS3DvTZZgD'

db = Hub(pymysql)
# 本地新库
db.add_pool('local_user',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_user',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_ketang',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_com',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_com',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_yingyu',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_yingyu',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 河南大网老库
db.add_pool('hn_tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_tbktweb',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt_web',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_ketang',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 江西大网库
db.add_pool('jx_tbkt',
    host=JX_HOST, port=3306, user=JX_USER, passwd=JX_PASSWORD, db='jxtbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)


def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        return int(time.mktime(t))
    except:
        return 0

def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except:
        logging.info('encode_password: %s' % password)
        # print 'encode_password:', password
        return ''
    return "sha1$%s$%s" % (salt, hash)

def encode_plain_password(password):
    try:
        return base64.b64encode(password)
    except:
        return ''


class HNWorker:
    """
    河南导入类
    """
    def __init__(self):
        self.provinced = {} # {旧地市ID: 新地市ID}
        self.schoold = {} # {旧学校ID: 新学校ID}
        self.classd = {} # {旧班级ID: 新班级ID}

        self.taskd = {}
        self.yytaskdetail = {}
        self.yytestd = {}
        self.yy2testd = {}
        self.sxtestd = {}
        self.sx2testd = {}

        print 'init ok.'

    def import_sx2_test(self):
        minid = 0
        psize = 2000
        while 1:
            sql = """
                SELECT id,user_id,object_id,type,subject_id,title,score,`status`,
                UNIX_TIMESTAMP(test_time) test_time,UNIX_TIMESTAMP(add_time) add_time,wrong_status
                from tbkt.u_sx2_test where id > %s limit %s
                """ % (minid,psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            task_details, test_details, special_details,wrong_details = [], [], [], []
            for t in tlist:
                # 作业测试记录
                user_id = t.user_id
                if t.type == 5:
                    task_id = t.object_id
                    task_details.append({
                        # "id": self.sx2_task_test,             # test_id 保持不变
                        "id": t.id,
                        "task_id": task_id,
                        "user_id": user_id,
                        "add_time": t.add_time,
                        "test_time": t.test_time,
                        "title": t.title,
                        "score": t.score,
                        "status": t.status,
                        "wrong_status": t.wrong_status,
                        "agent": 1,
                    })
                    # self.sx2testd[t.id] = self.sx2_task_test
                    # self.sx2_task_test += 1
                if t.type in (1, 2):
                    test_details.append({
                        # "id": self.sx2_test,              # test_id 保持不变
                        "id": t.id,
                        "paper_id": t.object_id,
                        "type": t.type,
                        "user_id": user_id,
                        "add_time": t.add_time,
                        "test_time": t.test_time,
                        "title": t.title,
                        "score": t.score,
                        "status": t.status,
                        "agent": t.agent or 0,
                    })
                    # self.sx2testd[t.id] = self.sx2_test
                    # self.sx2_test += 1
                if t.type == 4:
                    wrong_details.append({
                        "id": t.id,
                        "user_id": user_id,
                        "catalog_id": t.object_id,
                        "add_time": t.add_time,
                        "test_time": t.test_time,
                        "title": t.title,
                        "score": t.score,
                        "status": t.status,
                        "agent": t.agent or 0,
                    })
                if t.type == 3:
                    # 取作业id或试卷id
                    test = db.hn_tbkt.u_sx2_test.filter(id=t.object_id).first()
                    object_id = test.object_id
                    object_type = 5  # 作业
                    if test.type in (1, 2):
                        object_type = test.type

                    special_details.append({
                        "id": t.id,
                        "user_id": user_id,
                        "object_id": object_id,
                        "object_type": object_type,
                        "title": t.title,
                        "score": t.score,
                        "status": t.status,
                        "agent": t.agent or 0,
                        "add_time": t.add_time,
                        "test_time": t.test_time,
                    })
                minid = t.id
            if len(task_details) > 0:
                print "import sx2_task_test ", len(task_details)
                db.local_shuxue.sx2_task_test.bulk_create(task_details, ignore=True)
            if len(test_details) > 0:
                print "import sx2_test ", len(test_details)
                db.local_shuxue.sx2_test.bulk_create(test_details, ignore=True)
            if len(special_details) > 0:
                print "import sx2_special_test ", len(special_details)
                db.local_shuxue.sx2_special_test.bulk_create(special_details, ignore=True)
            if len(wrong_details) > 0:
                print "import sx2_wrong_title_set_test ", len(wrong_details)
                db.local_shuxue.sx2_wrong_title_set_test.bulk_create(wrong_details, ignore=True)
            print 'sx2_test  ', minid

        print "sx2_test over"


    def start(self):
        # 清记录 用时  320 秒
        print 'start henan worker'

        # # # 初中数学测试记录
        db.local_shuxue.execute("truncate sx2_task_test")
        db.local_shuxue.execute("truncate sx2_test")
        db.local_shuxue.execute("truncate sx2_special_test")
        db.local_shuxue.execute("truncate sx2_wrong_title_set_test")
        self.import_sx2_test()


if __name__ == '__main__':
    print datetime.datetime.now()
    hnworker = HNWorker()
    st = time.time()
    hnworker.start()
    print 'took:', time.time() - st
    print datetime.datetime.now()
