#coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import logging
import time
import random
import hashlib
import base64
import pymysql
from db import Hub
import json

LOCAL_HOST = '192.168.0.113'
# LOCAL_HOST = '116.255.220.112'
LOCAL_USER = 'duzuyong'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'


HN_HOST = '192.168.0.112'
# HN_HOST = '116.255.220.112'
HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

JX_HOST = 'rm-2zeso7flj7kkik72r.mysql.rds.aliyuncs.com'
JX_USER = 'jx_tbkt_db'
JX_PASSWORD = 'fPhTisS3DvTZZgD'

db = Hub(pymysql)
# 本地新库
db.add_pool('local_user',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_user',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_ketang',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_com',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_com',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_yingyu',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_yingyu',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 河南大网老库
db.add_pool('hn_tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_tbktweb',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt_web',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_ketang',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 江西大网库
db.add_pool('jx_tbkt',
    host=JX_HOST, port=3306, user=JX_USER, passwd=JX_PASSWORD, db='jxtbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)


def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        return int(time.mktime(t))
    except:
        return 0

def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except:
        logging.info('encode_password: %s' % password)
        # print 'encode_password:', password
        return ''
    return "sha1$%s$%s" % (salt, hash)

def encode_plain_password(password):
    try:
        return base64.b64encode(password)
    except:
        return ''


class HNWorker:
    """
    河南导入类
    """
    def __init__(self):
        self.provinced = {} # {旧地市ID: 新地市ID}
        self.schoold = {} # {旧学校ID: 新学校ID}
        self.classd = {} # {旧班级ID: 新班级ID}

        self.taskd = {}
        self.yytaskdetail = {}
        self.yytestd = {}
        self.yy2testd = {}
        self.sxtestd = {}
        self.sx2testd = {}

        print 'init ok.'

    def import_task(self):
        # minid = 0
        minid = 0  # 58648           # 2016-01-01 后的
        psize = 2000
        sx_pk = 1
        sx2_pk = 1
        yy_pk = 1
        yy2_pk = 1
        while 1:
            sql = """
            select id, subject_id, type, object_id, add_user, title, sms_content, status, UNIX_TIMESTAMP(add_time) as add_time,
            UNIX_TIMESTAMP(begin_time) as begin_time, UNIX_TIMESTAMP(end_time) as end_time, is_sendpwd
            FROM u_task 
            where id>%s
            ORDER BY id 
            LIMIT %s;
            """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            minid = tlist[-1].id
            sx_tasks, sx2_tasks, yy_tasks, yy2_tasks = [], [], [], []
            for t in tlist:
                add_user_id = t.add_user
                if t.subject_id == 21:
                    if t.type == 14:            # 数学活动试卷不要
                        continue
                    print "sx_task",t.id
                    sx_tasks.append({
                        "id": t.id,                             # id保持不变， zsn
                        "type": t.type,
                        "object_id": t.object_id,
                        "add_user": add_user_id,
                        "title": t.title,
                        "sms_content": t.sms_content,
                        "status": t.status,
                        "add_time": t.add_time,
                        "begin_time": t.begin_time,
                        "end_time": t.end_time,
                        "is_sendpwd": t.is_sendpwd,
                    })

                if t.subject_id == 22:
                    print "sx2_task", t.id
                    if t.type == 14:            # 数学活动试卷不要
                        continue
                    sx2_tasks.append({
                        # "id": sx2_pk,
                        "id": t.id,                                 # id保持不变， zsn
                        "type": t.type,
                        "object_id": t.object_id,
                        "add_user": add_user_id,
                        "title": t.title,
                        "sms_content": t.sms_content,
                        "status": t.status,
                        "add_time": t.add_time,
                        "begin_time": t.begin_time,
                        "end_time": t.end_time,
                        "is_sendpwd": t.is_sendpwd,
                    })
                    # self.taskd[t.id] = sx2_pk
                    # sx2_pk += 1
                if t.subject_id == 91:
                    print "yy_task",t.id
                    yy_tasks.append({
                        # "id": yy_pk,
                        "id": t.id,                     # id保持不变， zsn
                        "type": t.type,
                        "object_id": t.object_id,
                        "add_user": add_user_id,
                        "title": t.title,
                        "sms_content": t.sms_content,
                        "status": t.status,
                        "add_time": t.add_time,
                        "begin_time": t.begin_time,
                        "end_time": t.end_time,
                        "is_sendpwd": t.is_sendpwd,
                    })
                    # self.taskd[t.id] = yy_pk
                    # yy_pk += 1
                if t.subject_id == 92:
                    print "yy2_task",t.id
                    yy2_tasks.append({
                        # "id": yy2_pk,
                        "id": t.id,                 # id保持不变， zsn
                        "type": t.type,
                        "object_id": t.object_id,
                        "add_user": add_user_id,
                        "title": t.title,
                        "sms_content": t.sms_content,
                        "status": t.status,
                        "add_time": t.add_time,
                        "begin_time": t.begin_time,
                        "end_time": t.end_time,
                        "is_sendpwd": t.is_sendpwd,
                    })
                    # self.taskd[t.id] = yy2_pk
                    # yy2_pk += 1
            db.local_shuxue.sx_task.bulk_create(sx_tasks, ignore=True)
            db.local_shuxue.sx2_task.bulk_create(sx2_tasks, ignore=True)
            db.local_yingyu.yy_task.bulk_create(yy_tasks, ignore=True)
            db.local_yingyu.yy2_task.bulk_create(yy2_tasks, ignore=True)
            rels = []
            for old_id, new_id in self.taskd.iteritems():
                rels.append({
                    'old_id': old_id, 'new_id': new_id
                })
            print 'task_rels:', len(rels)
            self.taskd = {}
            # break
        print "task over"

    def import_task_class(self):
        # minid = 0
        minid = 0  # 62069  # 2016-01-01 后的
        psize = 2000
        # self.load_classd()
        while 1:
            sql = """
            select tc.id, t.subject_id, tc.task_id, tc.unit_class_id, tc.type, tc.student_id,
            UNIX_TIMESTAMP(tc.add_time) as add_time
            FROM u_task_class tc 
            INNER JOIN u_task t ON t.id = tc.task_id 
            where tc.id>%s
            order by tc.id
            LIMIT %s
            """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            minid = tlist[-1].id
            sx_task_class, sx2_task_class, yy_task_class, yy2_task_class = [], [], [], []

            for t in tlist:
                stu_ids = []
                if t.student_id:
                    for d in t.student_id.split(","):
                        stu_ids.append(d)
                task_id = t.task_id
                unit_class_id = t.unit_class_id                     # zsn 班级id保持不变

                if t.subject_id == 21:
                    print "sx_task_class:", task_id
                    sx_task_class.append({
                        "task_id": task_id,
                        "unit_class_id": unit_class_id,
                        "type": t.type,
                        "student_id": ",".join(stu_ids) if stu_ids else "",
                        "add_time": t.add_time,
                    })
                if t.subject_id == 22:
                    print "sx2_task_class:", task_id
                    sx2_task_class.append({
                        "task_id": task_id,
                        "unit_class_id": unit_class_id,
                        "type": t.type,
                        "student_id": ",".join(stu_ids) if stu_ids else "",
                        "add_time": t.add_time,
                    })
                if t.subject_id == 91:
                    print "yy_task_class:",task_id
                    yy_task_class.append({
                        "task_id": task_id,
                        "unit_class_id": unit_class_id,
                        "type": t.type,
                        "student_id": ",".join(stu_ids) if stu_ids else "",
                        "add_time": t.add_time,
                    })
                if t.subject_id == 92:
                    print "yy2_task_class:",task_id
                    yy2_task_class.append({
                        "task_id": task_id,
                        "unit_class_id": unit_class_id,
                        "type": t.type,
                        "student_id": ",".join(stu_ids) if stu_ids else "",
                        "add_time": t.add_time,
                    })
            db.local_shuxue.sx_task_class.bulk_create(sx_task_class, ignore=True)
            db.local_shuxue.sx2_task_class.bulk_create(sx2_task_class, ignore=True)
            db.local_yingyu.yy_task_class.bulk_create(yy_task_class, ignore=True)
            db.local_yingyu.yy2_task_class.bulk_create(yy2_task_class, ignore=True)
            # break
        print "task_class over"

    def load_task_detail_id(self):
        if not self.taskd:
            rows = db.local_yingyu.tmp_yytaskdetaild[:]
            self.yytaskdetaild = {r.old_id:r.new_id for r in rows} # {旧用户ID:新用户ID}

    def import_yy2_task_detail(self):
        minid = 0   # 58649  # 2016-01-01 后的
        psize = 2000
        while 1:
            task_sql = """
                select id from tbkt_yingyu.yy2_task where id>%s limit %s
            """ % (minid, psize)
            task_list = db.local_yingyu.fetchall_dict(task_sql)
            if not task_list:
                break
            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']
            sql = """
                SELECT td.id, td.task_id,td.catalog_id,td.question_id, td.text_catalog_id,
                content_type FROM tbkt.u_task_detail td where task_id in (%s)
                """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            # 作业id
            detail_list = []
            task_id = 0
            content_type = 0
            text_list = []  # 主记录对应明细
            for obj in tlist:
                if task_id == 0:
                    task_id = obj.task_id  # 作业主id
                    content_type = obj.content_type
                if task_id > 0 and task_id != obj.task_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'yy2_task_detailtask_id=%s to long text =%s' % (obj.task_id, len(json.dumps(text_list)))
                    else:
                        detail_list.append({
                            "task_id": task_id,
                            "text": json.dumps(text_list),
                             "content_type": content_type,
                        })
                    task_id = obj.task_id
                    content_type = obj.content_type
                    text_list = []
                detail = {"cid": obj.catalog_id,
                          "qid": obj.question_id,
                          "tcid": obj.text_catalog_id}
                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'task_id=%s to long text =%s' % (task_id, len(json.dumps(text_list)))
                else:
                    detail_list.append({
                            "task_id": task_id,
                            "text": json.dumps(text_list),
                             "content_type": content_type,
                        })

            print "import yy_task_detail ", len(detail_list)
            db.local_yingyu.yy2_task_detail.bulk_create(detail_list, ignore=True)
        print "yy_task_class_detail over"

    def import_yy_task_detail_new(self):
        minid = 0   # 58649  # 2016-01-01 后的
        psize = 2000
        while 1:
            task_sql = """
                select id from tbkt_yingyu.yy_task where id>%s limit %s
            """ % (minid, psize)
            task_list = db.local_yingyu.fetchall_dict(task_sql)
            if not task_list:
                break
            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']
            sql = """
                SELECT td.id, td.task_id,td.catalog_id,td.question_id, td.text_catalog_id,
                content_type FROM tbkt.u_task_detail td where task_id in (%s) order by task_id,content_type
                """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            # 作业id
            detail_list = []
            task_id = 0
            content_type = 0
            text_list = []  # 主记录对应明细
            for obj in tlist:
                if task_id == 0:
                    task_id = obj.task_id  # 作业主id
                    content_type = obj.content_type
                if task_id > 0 and [task_id, content_type] != [obj.task_id, obj.content_type]:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'yy_task_detailtask_id=%s to long text =%s' % (obj.task_id, len(json.dumps(text_list)))
                    else:
                        detail_list.append({
                            "task_id": task_id,
                            "text": json.dumps(text_list),
                            "content_type": content_type,
                        })
                    task_id = obj.task_id
                    content_type = obj.content_type
                    text_list = []
                detail = {"cid": obj.catalog_id,
                          "qid": obj.question_id,
                          "tcid": obj.text_catalog_id}
                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'task_id=%s to long text =%s' % (task_id, len(json.dumps(text_list)))
                else:
                    detail_list.append({
                            "task_id": task_id,
                            "text": json.dumps(text_list),
                             "content_type": content_type,
                        })

            print "import yy_task_detail ", len(detail_list)
            db.local_yingyu.yy_task_detail.bulk_create(detail_list, ignore=True)
        print "yy_task_class_detail over"

    def import_yy_task_progress(self):
        minid = 0
        psize = 2000
        while 1:
            sql = """
                SELECT ytp.id, ytp.user_id, ytp.task_id, ytp.`status`, ytp.update_time
                FROM tbkt_web.u_yy_task_progress ytp
                where ytp.id>%s
                order by ytp.id
                LIMIT %s;
                """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id
            details = []
            for t in recode:
                user_id = t.user_id
                task_id = t.task_id
                details.append({
                    "user_id": user_id,
                    "task_id": task_id,
                    "status": t.status,
                    "update_time": t.update_time,
                })
            print "import yy_task_progress", len(details)
            db.local_yingyu.yy_task_progress.bulk_create(details, ignore=True)
        print "yy_task_progress over"

    def import_yy_word_test_detail(self):
        minid = 0
        psize = 2000
        # self.load_task_detail_id()
        while 1:
            sql = """
            SELECT t.*,t1.catalog_id,t1.object_id,t1.user_id,t1.type from (
                SELECT t.id, t.test_id, GROUP_CONCAT(t.word_id) word_id,GROUP_CONCAT(t.result) result,
                GROUP_CONCAT(t.score) score FROM tbkt_web.u_yy_word_test_detail t
                  where t.id>%s
                  GROUP BY t.test_id
                  order by t.id
                  limit %s) t
                INNER join tbkt_web.u_yy_word_test t1 on t.test_id = t1.id
                order by t.id
            """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                try:
                    wids = t.word_id.split(',')
                    scores = t.score.split(',')
                    results = t.result.split(',')
                    text = []
                    for i in range(len(wids)):
                        text.append({"wid": wids[i],  "result": results[i], "score": scores[i]})
                    text = json.dumps(text)
                    if len(text) > 9000:
                        print "yy_word_detailtext is long", len(text)
                    object_id = 0
                    user_id = t.user_id
                    if t.object_id:
                        try:
                            # object_id = self.yytaskdetaild[t.object_id]       # task_detail_id 保持不变
                            object_id = t.object_id
                        except:
                            logging.info("task_detail is not exists %s" % t.object_id)
                            # print "task_detail is not exists", t.object_id
                            continue
                    d = dict(
                        catalog_id=t.catalog_id,
                        text=text,
                        object_id=object_id,
                        user_id=user_id,
                        type=t.type
                    )
                    details.append(d)
                except Exception, e:
                    # print e
                    logging.log(e)
                    continue
            print "import yy_word_test_detail", minid
            db.local_yingyu.yy_word_test_detail.bulk_create(details, ignore=True)
        print "yy_word_test_detail over"

    def import_sx_task_detail(self):
        minid = 0   # 58649  # 2016-01-01 后的
        psize = 2000
        while 1:
            task_sql = """
                select id,add_time from tbkt_shuxue.sx_task where id>%s limit %s
            """ % (minid, psize)
            task_list = db.local_shuxue.fetchall_dict(task_sql)
            if not task_list:
                break
            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t
            # task_id_list = ['8491','8564']
            sql = """
                SELECT td.id, td.task_id,td.catalog_id,td.question_id, td.text_catalog_id
                 FROM tbkt.u_task_detail td where task_id in (%s)
                """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            # 作业id
            detail_list = []
            task_id = 0
            content_type = 0
            text_list = []  # 主记录对应明细
            for obj in tlist:
                if task_id == 0:
                    task_id = obj.task_id  # 作业主id
                    content_type = obj.content_type
                if task_id > 0 and task_id != obj.task_id:
                    if len(json.dumps(text_list)) >= 7000:
                        print 'sx_task_id=%s to long text =%s' % (obj.task_id,len(json.dumps(text_list)))
                    else:
                        add_time = task_dict.get(task_id).get("add_time")
                        detail_list.append({
                            "task_id": task_id,
                            "add_time": add_time,
                            "text": json.dumps(text_list),
                        })
                    task_id = obj.task_id
                    content_type = obj.content_type
                    text_list = []

                detail = {"cid": obj.catalog_id,
                          "qid": obj.question_id,
                          "tcid": obj.text_catalog_id}

                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 7000:
                    print 'sx_task_id=%s to long text =%s' % (task_id,len(json.dumps(text_list)))
                else:
                    add_time = task_dict.get(task_id).get("add_time")
                    detail_list.append({
                            "task_id": task_id,
                            "add_time": add_time,
                            "text": json.dumps(text_list),
                        })

            print "import sx_task_detail ", len(detail_list)
            db.local_shuxue.sx_task_content.bulk_create(detail_list, ignore=True)
        print "sx_task_class_detail over"

    def import_sx2_task_detail(self):
        minid = 0   # 58649  # 2016-01-01 后的
        psize = 2000
        while 1:
            task_sql = """
                select id,add_time from tbkt_shuxue.sx2_task where id>%s limit %s
            """ % (minid, psize)
            task_list = db.local_shuxue.fetchall_dict(task_sql)
            if not task_list:
                break
            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t
            # task_id_list = ['8491','8564']
            sql = """
                SELECT td.id, td.task_id,td.catalog_id,td.question_id, td.text_catalog_id
                 FROM tbkt.u_task_detail td where task_id in (%s)
                """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            # 作业id
            detail_list = []
            task_id = 0
            content_type = 0
            text_list = []  # 主记录对应明细
            for obj in tlist:
                if task_id == 0:
                    task_id = obj.task_id  # 作业主id
                    content_type = obj.content_type
                if task_id > 0 and task_id != obj.task_id:
                    if len(json.dumps(text_list)) >= 7000:
                        print 'sx2_task_id=%s to long text =%s' % (obj.task_id, len(json.dumps(text_list)))
                    else:
                        add_time = task_dict.get(task_id).get("add_time")
                        detail_list.append({
                            "task_id": task_id,
                            "add_time": add_time,
                            "text": json.dumps(text_list),
                        })
                    task_id = obj.task_id
                    content_type = obj.content_type
                    text_list = []
                detail = {"cid": obj.catalog_id,
                          "qid": obj.question_id,
                          "tcid": obj.text_catalog_id}
                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 7000:
                    print 'task_id=%s to long text =%s' % (task_id,len(json.dumps(text_list)))
                else:
                    add_time = task_dict.get(task_id).get("add_time")
                    detail_list.append({
                            "task_id": task_id,
                            "add_time": add_time,
                            "text": json.dumps(text_list),
                        })

            print "import sx2_task_detail ", len(detail_list)
            db.local_shuxue.sx2_task_content.bulk_create(detail_list, ignore=True)
        print "sx2_task_class_detail over"

    def import_table(self, localtable, remotetable, converter={}, callback=None):
        """
        :param localtable: 目标db表(QuerySet)
        :param remotetable: 来源db表(QuerySet)
        :param converter: {'字段名':转换类型('user_id'转为新用户ID, 'unixtime'转为时间戳, 'ignore':忽略该字段, ...)}
        :param callback: 过滤器函数
        """
        minid = 0
        psize = 2000
        while 1:
            rows = remotetable.filter(id__gt=minid).order_by('id')[:psize]
            if not rows:
                break
            minid = rows[-1].id
            details = []
            for r in rows:
                if callback and callable(callback):
                    r = callback(r)
                for fieldname, type in converter.iteritems():
                    if type == 'user_id_strict':
                        pass
                    elif type == 'user_id':
                        pass
                    elif type == 'unixtime':
                        r[fieldname] = unix_timestamp(r[fieldname])
                    elif type == 'ignore':
                        r.pop(fieldname, None)
                    elif type == 'sxtest_id':
                        self.load_sx_test_id()
                        test_id = self.sxtestd.get(r[fieldname], 0)
                        if not test_id:
                            continue
                        r[fieldname] = self.sxtestd.get(r[fieldname], 0)
                    elif type == 'sx2test_id':
                        self.load_sx2_test_id()
                        test_id = self.sx2testd.get(r[fieldname], 0)
                        if not test_id:
                            continue
                        r[fieldname] = self.sx2testd.get(r[fieldname], 0)
                details.append(r)
            localtable.bulk_create(details, ignore=True)
            print "import table %s: %s %s" % (localtable.table_name, minid, len(details))
        print "import table %s over" % localtable.table_name

    def start(self):
        # 清记录 用时 1642 秒
        print 'start henan worker'

        # # 导作业表
        db.local_shuxue.execute("truncate sx_task")
        db.local_shuxue.execute("truncate sx2_task")
        db.local_yingyu.execute("truncate yy_task")
        db.local_yingyu.execute("truncate yy2_task")
        self.import_task()
        # #
        # # # 导作业班级表
        db.local_shuxue.execute("truncate sx_task_class")
        db.local_shuxue.execute("truncate sx2_task_class")
        db.local_yingyu.execute("truncate yy_task_class")
        db.local_yingyu.execute("truncate yy2_task_class")
        self.import_task_class()

        # import_yy2_task_detail
        # # # 初中英语作业明细
        db.local_yingyu.execute("truncate yy2_task_detail")
        self.import_yy2_task_detail()

        # # 英语作业明细
        db.local_yingyu.execute("truncate yy_task_detail")
        self.import_yy_task_detail_new()

        # # # # 英语作业进度
        db.local_yingyu.execute("truncate yy_task_progress")
        self.import_yy_task_progress()


        # # 数学作业明细
        db.local_shuxue.execute("truncate sx_task_content")
        self.import_sx_task_detail()
        db.local_shuxue.execute("truncate sx2_task_content")
        self.import_sx2_task_detail()

if __name__ == '__main__':

    print datetime.datetime.now()
    hnworker = HNWorker()
    st = time.time()
    hnworker.start()
    print 'took:', time.time() - st
    print datetime.datetime.now()
