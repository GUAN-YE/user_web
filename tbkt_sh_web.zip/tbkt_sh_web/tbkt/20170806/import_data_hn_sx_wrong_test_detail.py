#coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import logging
import time
import random
import hashlib
import base64
import pymysql
from db import Hub
import json

LOCAL_HOST = '192.168.0.113'
# LOCAL_HOST = '116.255.220.114'
LOCAL_USER = 'duzuyong'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

HN_HOST = '192.168.0.112'
# HN_HOST = '116.255.220.112'
HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

JX_HOST = 'rm-2zeso7flj7kkik72r.mysql.rds.aliyuncs.com'
JX_USER = 'jx_tbkt_db'
JX_PASSWORD = 'fPhTisS3DvTZZgD'

db = Hub(pymysql)
# 本地新库
db.add_pool('local_user',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_user',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_ketang',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_com',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_com',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_yingyu',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_yingyu',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 河南大网老库
db.add_pool('hn_tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_tbktweb',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt_web',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_ketang',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 江西大网库
db.add_pool('jx_tbkt',
    host=JX_HOST, port=3306, user=JX_USER, passwd=JX_PASSWORD, db='jxtbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)


def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        return int(time.mktime(t))
    except:
        return 0

def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except:
        logging.info('encode_password: %s' % password)
        # print 'encode_password:', password
        return ''
    return "sha1$%s$%s" % (salt, hash)

def encode_plain_password(password):
    try:
        return base64.b64encode(password)
    except:
        return ''


class HNWorker:
    """
    河南导入类
    """
    def __init__(self):
        self.provinced = {} # {旧地市ID: 新地市ID}
        self.schoold = {} # {旧学校ID: 新学校ID}
        self.classd = {} # {旧班级ID: 新班级ID}

        self.taskd = {}
        self.yytaskdetail = {}
        self.yytestd = {}
        self.yy2testd = {}
        self.sxtestd = {}
        self.sxtestd = {}

        print 'init ok.'

    def import_sx_test_detail(self):
        minid = 0
        minid = db.local_shuxue.sx_test.filter(id__gt=0).order_by('-id')[0].id + 1
        psize = 2000
        while 1:
            task_sql = """
                select id,paper_id,type,user_id,add_time from tbkt_shuxue.sx_test where  id<%s order by id desc limit %s
            """ % (minid, psize)
            task_list = db.local_shuxue.fetchall_dict(task_sql)
            if not task_list:
                break
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t

            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']

            sql = """
                SELECT * from tbkt.u_sx_test_detail
                where test_study_id in (%s) order by test_study_id
            """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            test_id = 0   # 测试主id
            text_list = []  # 主记录对应明细
            for obj in tlist:
                # {"answer": "B", "aid": 14192, "oid": 0, "result": 0, "qid": 24768}
                # {"kid": 40, "mid": 0, "cid": 8825}
                if test_id == 0:
                    test_id = obj.test_study_id  # 主id
                if test_id > 0 and test_id != obj.test_study_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'test_id=%s to long text =%s' % (obj.test_study_id, len(json.dumps(text_list)))
                    else:
                        paper_id = task_dict.get(test_id).get("paper_id")
                        user_id = task_dict.get(test_id).get("user_id")
                        type_id = task_dict.get(test_id).get("type")
                        add_time = task_dict.get(test_id).get("add_time")

                        detail_list.append({
                            "id": task_dict.get(test_id).get("id"),
                            "user_id": user_id,
                            "paper_id": paper_id,
                            "type": type_id,
                            "text": json.dumps(text_list),
                            "add_time": add_time,
                            "weak_knowledge":""
                        })
                    test_id = obj.test_study_id
                    text_list = []
                detail = {"result": obj.result,
                          "qid": obj.question_id,
                          "oid": obj.option_id,
                          "aid": obj.question_ask_id or 0,
                          "answer": obj.answer}

                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'test_id=%s to long text =%s' % (test_id, len(json.dumps(text_list)))
                else:
                    paper_id = task_dict.get(test_id).get("paper_id")
                    user_id = task_dict.get(test_id).get("user_id")
                    type_id = task_dict.get(test_id).get("type")
                    add_time = task_dict.get(test_id).get("add_time")

                    detail_list.append({
                        "id": task_dict.get(test_id).get("id"),
                        "user_id": user_id,
                        "paper_id": paper_id,
                        "type": type_id,
                        "text": json.dumps(text_list),
                        "add_time": add_time,
                        "weak_knowledge":""
                    })

            print "import sx_test_detail", minid, len(detail_list)
            db.local_shuxue.sx_test_detail.bulk_create(detail_list, ignore=True)

        print "sx_test_detail over"


    def import_sx_task_test_detail(self):
        minid = 0
        minid = db.local_shuxue.sx_task_test.filter(id__gt=0).order_by('-id')[0].id + 1
        psize = 2000
        while 1:
            task_sql = """
                select id,task_id,user_id,add_time from tbkt_shuxue.sx_task_test where  id<%s order by id desc limit %s
            """ % (minid, psize)
            task_list = db.local_shuxue.fetchall_dict(task_sql)
            if not task_list:
                break
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t

            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']

            sql = """
                SELECT * from tbkt.u_sx_test_detail
                where test_study_id in (%s) order by test_study_id
            """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            test_id = 0   # 测试主id
            text_list = []  # 主记录对应明细

            for obj in tlist:
                # {"answer": "B", "aid": 14192, "oid": 0, "result": 0, "qid": 24768}
                # {"kid": 40, "mid": 0, "cid": 8825}
                if test_id == 0:
                    test_id = obj.test_study_id  # 主id
                if test_id > 0 and test_id != obj.test_study_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'test_id=%s to long text =%s' % (obj.test_study_id, len(json.dumps(text_list)))
                    else:
                        task_id = task_dict.get(test_id).get("task_id")
                        user_id = task_dict.get(test_id).get("user_id")
                        add_time = task_dict.get(test_id).get("add_time")

                        detail_list.append({
                            "id": task_dict.get(test_id).get("id"),
                            "user_id": user_id,
                            "task_id": task_id,
                            "text": json.dumps(text_list),
                            "add_time": add_time,
                            "weak_knowledge":""
                        })
                    test_id = obj.test_study_id
                    text_list = []
                detail = {"result": obj.result,
                          "qid": obj.question_id,
                          "oid": obj.option_id,
                          "aid": obj.question_ask_id or 0,
                          "answer": obj.answer}

                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'test_id=%s to long text =%s' % (test_id, len(json.dumps(text_list)))
                else:
                    task_id = task_dict.get(test_id).get("task_id")
                    user_id = task_dict.get(test_id).get("user_id")
                    add_time = task_dict.get(test_id).get("add_time")

                    detail_list.append({
                        "id": task_dict.get(test_id).get("id"),
                        "user_id": user_id,
                        "task_id": task_id,
                        "text": json.dumps(text_list),
                        "add_time": add_time,
                        "weak_knowledge":""
                    })

            print "import sx_task_test_detail", minid
            db.local_shuxue.sx_task_test_detail.bulk_create(detail_list, ignore=True)

        print "sx_task_test_detail over"

    def import_sx_special_test_detail(self):
        minid = 0
        minid = db.local_shuxue.sx_special_test.filter(id__gt=0).order_by('-id')[0].id + 1
        psize = 2000
        while 1:
            task_sql = """
                select id,object_id, object_type,user_id,add_time from tbkt_shuxue.sx_special_test where  id<%s order by id desc limit %s
            """ % (minid, psize)
            task_list = db.local_shuxue.fetchall_dict(task_sql)
            if not task_list:
                break
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t

            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']

            sql = """
                SELECT * from tbkt.u_sx_test_detail
                where test_study_id in (%s) order by test_study_id
            """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            test_id = 0   # 测试主id
            text_list = []  # 主记录对应明细

            for obj in tlist:
                # {"answer": "B", "aid": 14192, "oid": 0, "result": 0, "qid": 24768}
                # {"kid": 40, "mid": 0, "cid": 8825}
                if test_id == 0:
                    test_id = obj.test_study_id  # 主id
                if test_id > 0 and test_id != obj.test_study_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'test_id=%s to long text =%s' % (obj.test_study_id, len(json.dumps(text_list)))
                    else:
                        object_type = task_dict.get(test_id).get("object_type")
                        user_id = task_dict.get(test_id).get("user_id")
                        object_id = task_dict.get(test_id).get("object_id")
                        add_time = task_dict.get(test_id).get("add_time")

                        detail_list.append({
                            "id": task_dict.get(test_id).get("id"),
                            "user_id": user_id,
                            "object_id": object_id,
                            "object_type": object_type,
                            "text": json.dumps(text_list),
                            "add_time": add_time,
                            "weak_knowledge":""
                        })
                    test_id = obj.test_study_id
                    text_list = []
                detail = {"result": obj.result,
                          "qid": obj.question_id,
                          "oid": obj.option_id,
                          "aid": obj.question_ask_id or 0,
                          "answer": obj.answer}

                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'test_id=%s to long text =%s' % (test_id, len(json.dumps(text_list)))
                else:
                    object_type = task_dict.get(test_id).get("object_type")
                    user_id = task_dict.get(test_id).get("user_id")
                    object_id = task_dict.get(test_id).get("object_id")
                    add_time = task_dict.get(test_id).get("add_time")

                    detail_list.append({
                        "id": task_dict.get(test_id).get("id"),
                        "user_id": user_id,
                        "object_id": object_id,
                        "object_type": object_type,
                        "text": json.dumps(text_list),
                        "add_time": add_time,
                        "weak_knowledge":""
                    })

            print "import sx_special_test_detail", minid
            db.local_shuxue.sx_special_test_detail.bulk_create(detail_list, ignore=True)

        print "sx_special_test_detail over"

    def import_sx_wrong_title_set(self):
        minid = 0
        minid = db.local_shuxue.sx_wrong_title_set_test.filter(id__gt=0).order_by('-id')[0].id + 1
        psize = 2000
        while 1:
            task_sql = """
                   select id,user_id,catalog_id,agent,add_time
                   from tbkt_shuxue.sx_wrong_title_set_test where  id<%s order by id desc limit %s
               """ % (minid, psize)
            task_list = db.local_shuxue.fetchall_dict(task_sql)
            if not task_list:
                break
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t

            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']

            sql = """
                   SELECT * from tbkt.u_sx_test_detail
                   where test_study_id in (%s) order by test_study_id
               """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            test_id = 0  # 测试主id
            text_list = []  # 主记录对应明细
            for obj in tlist:
                # {"answer": "B", "aid": 14192, "oid": 0, "result": 0, "qid": 24768}
                # {"kid": 40, "mid": 0, "cid": 8825}
                if test_id == 0:
                    test_id = obj.test_study_id  # 主id
                if test_id > 0 and test_id != obj.test_study_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'test_id=%s to long text =%s' % (obj.test_study_id, len(json.dumps(text_list)))
                    else:
                        user_id = task_dict.get(test_id).get("user_id")
                        catalog_id = task_dict.get(test_id).get("catalog_id")
                        add_time = task_dict.get(test_id).get("add_time")
                        detail_list.append({
                            "id": task_dict.get(test_id).get("id"),
                            "user_id": user_id,
                            "catalog_id": catalog_id,
                            "text": json.dumps(text_list),
                            "add_time": add_time
                        })
                    test_id = obj.test_study_id
                    text_list = []
                detail = {"result": obj.result,
                          "qid": obj.question_id,
                          "oid": obj.option_id,
                          "aid": obj.question_ask_id or 0,
                          "answer": obj.answer}

                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'test_id=%s to long text =%s' % (test_id, len(json.dumps(text_list)))
                else:
                    user_id = task_dict.get(test_id).get("user_id")
                    catalog_id = task_dict.get(test_id).get("catalog_id")
                    add_time = task_dict.get(test_id).get("add_time")
                    detail_list.append({
                        "id": task_dict.get(test_id).get("id"),
                        "user_id": user_id,
                        "catalog_id": catalog_id,
                        "text": json.dumps(text_list),
                        "add_time": add_time
                    })
            print "import sx_wrong_title_set_detail", minid, len(detail_list)
            db.local_shuxue.sx_wrong_title_set_test_detail.bulk_create(detail_list, ignore=True)

        print "sx_wrong_title_set_test_detail over"

    def start(self):
        # 清记录 用时
        print 'start sx_wrong_title_set_detail henan worker'

        # # 初中数学测试明细
        db.local_shuxue.execute("truncate sx_wrong_title_set_test_detail")

        # 导入初中数学错题集
        self.import_sx_wrong_title_set()

if __name__ == '__main__':
    print datetime.datetime.now()
    hnworker = HNWorker()
    st = time.time()
    hnworker.start()
    print 'took:', time.time() - st
    print datetime.datetime.now()
