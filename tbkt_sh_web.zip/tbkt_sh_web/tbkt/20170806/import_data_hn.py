#coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import time
import random
import hashlib
import base64
# import MySQLdb
import pymysql
from db import Hub
import json



LOCAL_HOST = '192.168.0.113'
# LOCAL_HOST = '116.255.220.114'

LOCAL_USER = 'duzuyong'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'


HN_HOST = '192.168.0.112'
# HN_HOST = '116.255.220.112'
HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

JX_HOST = 'rm-2zeso7flj7kkik72r.mysql.rds.aliyuncs.com'
JX_USER = 'jx_tbkt_db'
JX_PASSWORD = 'fPhTisS3DvTZZgD'

db = Hub(pymysql)
# 本地新库
db.add_pool('local_user',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_user',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_ketang',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_com',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_com',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_yingyu',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_yingyu',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 河南大网老库
db.add_pool('hn_tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_tbktweb',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt_web',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_ketang',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 江西大网库
db.add_pool('jx_tbkt',
    host=JX_HOST, port=3306, user=JX_USER, passwd=JX_PASSWORD, db='jxtbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)


def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        now = int(time.mktime(t))
        if now < 0:
            now = 0
        return now
    except:
        return 0


def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except:
        print 'encode_password: error'
        return ''
    return "sha1$%s$%s" % (salt, hash)

def encode_plain_password(password):
    try:
        return base64.b64encode(password)
    except:
        return ''


class HNWorker:
    """
    河南导入类
    """
    def __init__(self):
        self.provinced = {} # {旧地市ID: 新地市ID}
        self.schoold = {} # {旧学校ID: 新学校ID}
        self.classd = {} # {旧班级ID: 新班级ID}

        print 'init ok.'

    def import_province(self):
        """导省市县"""
        provinces = db.hn_tbkt.common_provincecity[:]
        rows = []
        for p in provinces:
            rows.append({
                'id': p.id,
                'cityId': p.cityId,
                'name': p.name,
                'fatherId': p.fatherId,
                'parentId': p.parentId,
                'levelId': p.levelId,
                'path': p.path,
            })
            if len(rows) >= 2000:
                db.local_com.common_provincecity.bulk_create(rows)
                rows = []
        if rows:
            db.local_com.common_provincecity.bulk_create(rows)

    def import_school(self):
        """导学校"""
        minid = 0       # 老表分页ID
        psize = 2000    # 每页多少条
        while 1:
            schools = db.hn_tbkt.school.filter(id__gt=minid)[:psize]
            if not schools:
                break
            minid = schools[-1].id
            rows = []
            for s in schools:
                rows.append({
                    'id': s.id,
                    'county': s.county.strip(),
                    'name': s.name,
                    'learn_length': s.learn_length,
                    'type': s.type,
                    'address': s.address or '',
                    'fix_tel': s.fix_tel or '',
                    'user_id': s.user_id or 0,
                    'add_date': unix_timestamp(s.add_date),
                    'link_man': s.link_man or '',
                    'notes': s.notes or '',
                    'status': s.status,
                    'view_count': s.view_count or 0,
                    'contact_mode': s.contact_mode or 0,
                    'contact_object': s.contact_object or '',
                    'handle_result': s.handle_result or '',
                    'image_url': s.image_url or '',
                    'ecid': s.ecid or '',
                })
            db.local_com.school.bulk_create(rows)

    def import_class(self):
        """班级信息表"""
        minid = 0       # 老表分页ID
        psize = 2000    # 每页多少条
        while 1:
            units = db.hn_tbkt.school_unit_class.filter(id__gt=minid)[:psize]
            if not units:
                break
            minid = units[-1].id

            rows = []
            for u in units:
                rows.append({
                    'id': u.id,
                    'school_id': u.school_id,
                    'unit_type': u.unit_type,
                    'unit_name': u.unit_name,
                    'learn_length': u.learn_length,
                    'type': u.type,
                    'grade_id': u.grade_id,
                    'class_id': u.class_id,
                    'parent_id': u.parent_id,
                    'level_id': u.level_id,
                    'is_leaf': u.is_leaf,
                    'path': u.path,
                    'is_update': u.is_update,
                    'max_class': u.max_class,
                    'add_time': unix_timestamp(u.add_time),
                    'sms_num': u.sms_num,
                    'real_num': u.real_num,
                    'upgrade_date': u.upgrade_date,
                })
            db.local_com.school_unit_class.bulk_create(rows)
        print 'class over', len(self.classd)

    def import_user1(self):
        """导入auth_user用户, 保证user_id不变"""
        minid = 0
        print 'import user1', minid, datetime.datetime.now()
        psize = 2000
        while 1:
            sql = """
            select u.id, u.last_login, u.date_joined, u.status, u.grade_id, u.portrait, u.username
            from tbkt.auth_user u
            where u.id>%s
            order by u.id
            limit %s
            """ % (minid, psize)
            users = db.hn_ketang.fetchall_dict(sql)
            if not users:
                break
            # 获取用户id
            user_id_list = ['%s' % obj.id for obj in users]

            sql = """
            select b.user_id, b.phone_number phone, b.password plain_password,
                b.type, b.user_name real_name, b.subject_id sid, b.sex
            from ketang.mobile_user_bind b
            where b.user_id >0 and b.user_id in (%s)
            """ % ",".join(user_id_list)
            user_bind_list = db.hn_ketang.fetchall_dict(sql)

            user_bind_dict = {}  # 用户对应bind信息
            for obj in user_bind_list:
                user_bind_dict[obj.user_id] = obj

            minid = users[-1].id

            rows = []
            profile_rows = []
            for u in users:
                bind = user_bind_dict.get(u.id)
                if not bind:
                    continue
                plain_password = bind.plain_password or "111111"
                # if not u.password:
                u.password = encode_password(bind.plain_password)
                rows.append({
                    'id': u.id,
                    'username': u.username.strip(),
                    'password': u.password,
                    'type': bind.type,
                    'real_name': bind.real_name,
                    'last_login': unix_timestamp(u.last_login),
                    'date_joined': unix_timestamp(u.date_joined),
                    'status': u.status or 0,
                    'phone': bind.phone.strip(),
                    'platform_id': 1,
                    'grade_id': u.grade_id or 0,
                    'sid': bind.sid or 0,
                    'dept_id': 1,
                })
                profile_rows.append({
                    'user_id': u.id,
                    'nickname': '',
                    'portrait': u.portrait or '',
                    'sex': bind.sex,
                    'password': encode_plain_password(bind.plain_password),
                })
            db.local_user.auth_user.bulk_create(rows, ignore=True)
            db.local_user.auth_profile.bulk_create(profile_rows, ignore=True)

            print 'importing user1', u.id
        print 'import user1', minid, datetime.datetime.now()

    def import_user2(self):
        """导入bind里关联不到auth_user的用户"""
        minid = 0
        print 'import user2', minid, datetime.datetime.now()
        psize = 2000
        row = db.local_user.auth_user.last()
        pk = row.id+1 if row else 1
        print 'import user2: pk=', pk
        while 1:
            sql = """
            select b.id bind_id, b.phone_number phone, b.username, b.password plain_password,
                b.type, b.user_name real_name,b.subject_id sid, b.sex,b.add_date
            from mobile_user_bind b
            where b.user_id=0 and b.id>%s
            limit %s
            """ % (minid, psize)
            users = db.hn_ketang.fetchall_dict(sql)
            if not users:
                break
            minid = users[-1].bind_id

            rows = []
            profile_rows = []
            for u in users:
                plain_password = u.plain_password or "111111"
                # if not u.password:
                u.password = encode_password(u.plain_password)
                rows.append({
                    'id': pk,
                    'username': u.username.strip(),
                    'password': u.password,
                    'type': u.type,
                    'real_name': u.real_name.strip(),
                    'last_login': 0,
                    'date_joined': unix_timestamp(u.add_date),
                    'status': 0,
                    'phone': u.phone.strip(),
                    'platform_id': 1,
                    'grade_id': u.grade_id or 0,
                    'sid': u.sid or 0,
                    'dept_id': 1,
                })
                profile_rows.append({
                    'user_id': pk,
                    'nickname': '',
                    'portrait': '',
                    'sex': u.sex,
                    'password': encode_plain_password(u.plain_password),
                })
                pk += 1
            db.local_user.auth_user.bulk_create(rows, ignore=True)
            db.local_user.auth_profile.bulk_create(profile_rows, ignore=True)

            print 'importing user2 pk=%s,minid=%s' % (pk, minid)
        print 'import user2', minid, datetime.datetime.now()

    def import_order_region(self):
        """导入用户班级关系"""
        minid = 0
        psize = 2000
        print 'import order_region', minid, datetime.datetime.now()
        while 1:
            sql = """
            select r.*
            from ketang.mobile_order_region r where r.id>%s order by r.id limit %s
            """ % (minid, psize)
            print sql
            regions = db.hn_ketang.fetchall_dict(sql)
            if not regions:
                print 'not find regions'
                break
            minid = regions[-1].id

            bind_id_list = ['%s' % obj.user_bind_id for obj in regions if obj.user_bind_id]

            sql = """
            select b.username,b.id as bind_id
            from ketang.mobile_user_bind b
            where b.id>0 and b.id in (%s)
            order by b.id
            """ % ",".join(bind_id_list)
            # print sql
            bind_users = db.hn_ketang.fetchall_dict(sql)

            # bind_id与username关系
            bind_user_dict = {}
            for obj in bind_users:
                bind_user_dict[obj.bind_id] = obj
            # print bind_user_dict
            username_list = [r.username for r in bind_users]
            users = db.local_user.auth_user.filter(username__in=username_list).select('id', 'username', 'type')[:]
            # user_id与username关系
            username_user_id_dict = {u.username:u for u in users}

            rows = []
            for r in regions:
                # print 'r.user_bind_id',r.user_bind_id
                bind = bind_user_dict.get(r.user_bind_id)
                # print 'bind',bind
                if not bind:
                    continue
                user = username_user_id_dict.get(bind.username)
                # print 'user_id',user_id
                if not user:
                    continue
                rows.append({
                    'id': r.id,
                    'province': r.province,
                    'city': r.city,
                    'county': r.county,
                    'school_id': r.school_id,
                    'school_name': r.school_name,
                    'school_type': r.school_type,
                    'unit_class_id': r.unit_class_id,
                    'is_update': r.is_update,
                    'add_date': unix_timestamp(r.add_date),
                    'del_state': 0,
                    'user_type': user.type,
                    'user_id': user.id,
                    'province_id': r.province_id,
                    'city_id': r.city_id,
                    'county_id': r.county_id,
                })
            if rows:
                db.local_ketang.mobile_order_region.bulk_create(rows, ignore=True)
            print 'minid=%s, psize=%s' % (minid, psize)
        print 'order_region over.'
        print 'import order_region', minid, datetime.datetime.now()


    def get_phoned(self, phones):
        """
        获取电话相关用户ID
        :return: {phone: [用户ID]}
        """
        if not phones:
            return {}
        users = db.local_user.auth_user.filter(phone__in=phones).select('id', 'phone', 'type')[:]
        groups = {}
        for u in users:
            rows = groups.get(u.phone) or []
            rows.append(u)
            groups[u.phone] = rows
        return groups

    def import_mobile_subject(self):
        """导入学科开通记录"""
        minid = 0
        psize = 2000
        print 'import mobile_subject', minid, datetime.datetime.now()
        while 1:
            sql = """
            select m.id, m.code, m.open_date, m.phone_number, m.status, m.add_date
            from mobile_subject m
            where status in (2,9) and m.id>%s
            order by m.id
            limit %s
            """ % (minid, psize)
            mslist = db.hn_ketang.fetchall_dict(sql)
            if not mslist:
                break
            minid = mslist[-1].id

            # 过滤掉多余学科代码
            mslist = [m for m in mslist if m.code in ('A', 'B', 'C', 'D', 'E', 'J', 'K', 'L', 'M', 'N')]
            if not mslist:
                print 'reject invalid code.'
                continue

            phones = [m.phone_number for m in mslist]
            phoned = self.get_phoned(phones)
            # print 'phoned:', len(phoned)

            rows = []
            for m in mslist:
                user_ids = phoned.get(m.phone_number) or []
                # print 'phone user_ids:', user_ids
                sid = {'A':2, 'B':3, 'C':4, 'D':9, 'E':5,'J':2, 'K':3, 'L':4, 'M':9, 'N':5}[m.code]
                for user_obj in user_ids:
                    user_id = user_obj['id']
                    if user_obj['type'] == 1 and m.code in ('A', 'B', 'C', 'D', 'E'):
                        rows.append({
                            'user_id': user_id,
                            'phone_number': m.phone_number,
                            'subject_id': sid,
                            'open_date': unix_timestamp(m.open_date),
                            'cancel_date': 0,
                            'pay_type': 2,
                            'platform_id': 1,
                            'add_date': unix_timestamp(m.add_date),
                        })
                    elif user_obj['type'] == 3 and m.code in ('J', 'K', 'L', 'M', 'N'):
                        rows.append({
                            'user_id': user_id,
                            'phone_number': m.phone_number,
                            'subject_id': sid,
                            'open_date': unix_timestamp(m.open_date),
                            'cancel_date': 0,
                            'pay_type': 2,
                            'platform_id': 1,
                            'add_date': unix_timestamp(m.add_date),
                        })
            if rows:
                db.local_ketang.mobile_subject.bulk_create(rows, ignore=True)
            print 'importing subject:', minid
            # break
        print 'subject over.'
        print 'import mobile_subject', minid, datetime.datetime.now()

    def update_dept_id(self):
        """更新学生用户dept_id, 1是小学 2是初中, 如果没班级默认1"""
        minid = 0
        psize = 2000
        print 'import update_dept', minid, datetime.datetime.now()
        while 1:
            users = db.local_user.auth_user.select('id', 'type').filter(id__gt=minid)[:psize]
            if not users:
                break
            minid = users[-1].id

            user_ids = [u.id for u in users]
            if not user_ids:
                continue

            # 批量查用户班级类型
            regions = db.local_ketang.mobile_order_region.filter(user_id__in=user_ids).select('unit_class_id', 'user_id')[:]
            if not regions:
                continue
            unit_ids = [r.unit_class_id for r in regions]
            units = db.local_com.school_unit_class.filter(id__in=unit_ids, type__in=(1, 2)).select('id', 'type')[:]

            units_map = {i.id: i.type for i in units}

            args = []
            for i in regions:
                type = units_map.get(i.unit_class_id, 1)
                args.append((type, i.user_id))

            sql = """
            update auth_user set dept_id = %s where id = %s
            """
            if args:
                db.local_user.execute_many(sql, args)
                print 'update auth_user dept_id:', len(args)
            break
        print 'update dept_id over.'
        print 'import update_dept', minid, datetime.datetime.now()

    def start(self):
        # 清记录 用时 10741 秒
        print 'start henan worker '

        # # 导入省市班级
        print 'start common_provincecity', datetime.datetime.now()
        db.local_com.execute("truncate common_provincecity")
        self.import_province()
        print 'start school', datetime.datetime.now()
        db.local_com.execute("truncate school")
        self.import_school()
        print 'start school_unit_class', datetime.datetime.now()
        db.local_com.execute("truncate school_unit_class")
        self.import_class()
        print 'end school_unit_class', datetime.datetime.now()

        # 导用户
        db.local_user.execute("truncate auth_user")
        db.local_user.execute("truncate auth_profile")
        print 'start import_user1', datetime.datetime.now()
        self.import_user1()
        print 'start import_user2', datetime.datetime.now()
        self.import_user2()
        print 'end import_user2', datetime.datetime.now()
        # 导入用户班级
        db.local_ketang.execute("truncate mobile_order_region")
        self.import_order_region()
        self.update_dept_id()  # 更新auth_user.dept_id
        #
        # 导入学科开通
        db.local_ketang.execute("truncate mobile_subject")
        self.import_mobile_subject()


if __name__ == '__main__':

    print datetime.datetime.now()
    hnworker = HNWorker()
    st = time.time()
    hnworker.start()
    print 'use time:', time.time() - st
    print datetime.datetime.now()
