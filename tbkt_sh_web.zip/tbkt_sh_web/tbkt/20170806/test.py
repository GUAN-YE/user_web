#coding=utf-8

"""
@varsion: ??
@author: 张帅男
@file: import_data_hn_yy2_book_message.py
@time: 2017/8/9 15:48

tbkt_com.message  消息表  从tbkt.u_task
tbkt_com.message_class    从tbkt.u_task_class
tbkt_com.user_book        从tbkt.u_user_book
tbkt_yingyu.yy2_wrong_title_set  从tbkt.u_yy2_wrong_title_set
"""

import datetime
import logging
import time
import random
import hashlib
import base64
import pymysql
from db import Hub
import json


LOCAL_HOST = '192.168.7.250'
LOCAL_USER = 'dba_user'
LOCAL_PASSWORD = 'tbkt123456'


# HN_HOST = '192.168.0.112'
HN_HOST = '116.255.220.112'
HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

JX_HOST = 'rm-2zeso7flj7kkik72r.mysql.rds.aliyuncs.com'
JX_USER = 'jx_tbkt_db'
JX_PASSWORD = 'fPhTisS3DvTZZgD'

db = Hub(pymysql)
# 本地新库
db.add_pool('local_user',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_user',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_ketang',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_com',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_com',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_yingyu',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_yingyu',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 河南大网老库
db.add_pool('hn_tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_tbktweb',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt_web',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_ketang',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 江西大网库
db.add_pool('jx_tbkt',
    host=JX_HOST, port=3306, user=JX_USER, passwd=JX_PASSWORD, db='jxtbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)

def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        return int(time.mktime(t))
    except:
        return 0

def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except:
        logging.info('encode_password: %s' % password)
        # print 'encode_password:', password
        return ''
    return "sha1$%s$%s" % (salt, hash)

def encode_plain_password(password):
    try:
        return base64.b64encode(password)
    except:
        return ''


class HNWorker:
    """
    河南导入类
    """
    def __init__(self):
        self.provinced = {} # {旧地市ID: 新地市ID}
        self.schoold = {} # {旧学校ID: 新学校ID}
        self.classd = {} # {旧班级ID: 新班级ID}

        self.taskd = {}
        self.yytaskdetail = {}
        self.yytestd = {}
        self.yy2testd = {}
        self.sxtestd = {}
        self.sx2testd = {}

        print 'init ok.'

    def import_yy2_wrong_title_test(self):
        minid = 0
        psize = 2000
        while 1:
            sql = """
                SELECT id, user_id, catalog_id, question_id, UNIX_TIMESTAMP(add_time) add_time
                FROM u_yy2_wrong_title_set WHERE  id > %s ORDER BY id  LIMIT %s  ;
                 """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            detail_list = []
            for r in recode:
                detail_list.append({
                    "id": r.id,
                    "user_id": r.user_id,
                    "catalog_id": r.catalog_id,
                    "question_id": r.question_id,
                    "add_time": r.add_time
                })
            db.local_yingyu.yy2_wrong_title_set.bulk_create(detail_list, ignore=True)
            print "import yy2_wrong_title_set", len(detail_list)

    def import_user_book(self):
        minid = 0
        psize = 2000
        while 1:
            sql = """
                SELECT id, book_id, subject_id, user_id, UNIX_TIMESTAMP(add_time) add_time,
                 is_work_book FROM u_user_book WHERE id > %s ORDER BY id LIMIT %s;
                """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            detail_list = []
            for r in recode:
                detail_list.append({
                    "id": r.id,
                    "user_id": r.user_id,
                    "book_id": r.book_id,
                    "subject_id": r.subject_id,
                    "add_time": r.add_time,
                    "is_work_book": r.is_work_book,
                })
            db.local_com.user_book.bulk_create(detail_list, ignore=True)
            print "import user_book", len(detail_list)

    def import_message(self):
        minid = 0
        psize = 2000
        while 1:
            sql = """
                SELECT id, type, object_id, subject_id, add_user, title, sms_content,
                `status`, UNIX_TIMESTAMP(add_time) add_time, UNIX_TIMESTAMP(end_time) end_time
                 FROM u_task WHERE id > %s ORDER BY id limit %s;
                """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            type_id = 0
            task_id = 0
            detail_list = []
            for r in recode:
                if r.type == 0:     # 通知
                    type_id = 1
                    task_id = r.id
                elif r.type == 1:   # 作业
                    type_id = 2
                    task_id = r.id
                elif r.type == 2 and r.subject_id in (21, 22):  # 数学试卷
                    type_id = 7
                    task_id = r.id
                elif r.type == 3:           # 资源
                    type_id = 3
                    task_id = r.object_id
                else:
                    continue
                detail_list.append({
                    "type": type_id,
                    "subject_id": r.subject_id,
                    "object_id": task_id,
                    "add_user": r.add_user,
                    "title": r.title,
                    "content": r.sms_content,
                    "status": r.status,
                    "add_time": r.add_time,
                    "end_time": r.end_time
                })
            db.local_com.message.bulk_create(detail_list, ignore=True)
            print "import message", len(detail_list)

    def import_message_class(self):
        minid = 0
        psize = 2000

        while 1:
            sql = """
                SELECT id, object_id FROM message WHERE id > %s ORDER BY id LIMIT %s
                """ % (minid, psize)
            message = db.local_com.fetchall_dict(sql)
            if not message:
                break
            minid = message[-1].id

            message_dict = {}
            message_task_list = []
            for m in message:
                message_dict[m.object_id] = m.id
                message_task_list.append(m.object_id)

            sql = """SELECT task_id, unit_class_id, student_id
                  FROM u_task_class WHERE task_id in (%s);
                """ % ",".join(str(obj) for obj in message_task_list)
            task_class_list = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            for r in task_class_list:
                mess_id = message_dict.get(r.task_id)
                detail_list.append({
                    "message_id": mess_id,
                    "unit_class_id": r.unit_class_id,
                    "student_ids": r.student_id
                })
            db.local_com.message_class.bulk_create(detail_list, ignore=True)
            print "import message_class", len(detail_list)

    def import_table(self, localtable, remotetable, converter={}, callback=None):
        """
        :param localtable: 目标db表(QuerySet)
        :param remotetable: 来源db表(QuerySet)
        :param converter: {'字段名':转换类型('user_id'转为新用户ID, 'unixtime'转为时间戳, 'ignore':忽略该字段, ...)}
        :param callback: 过滤器函数
        """
        minid = 0
        psize = 2000
        while 1:
            rows = remotetable.filter(id__gt=minid)[:psize]
            if not rows:
                break
            minid = rows[-1].id
            details = []
            for r in rows:
                if callback and callable(callback):
                    r = callback(r)
                for fieldname, type in converter.iteritems():
                    if type == 'user_id_strict':
                        pass
                    elif type == 'user_id':
                        pass
                    elif type == 'unixtime':
                        r[fieldname] = unix_timestamp(r[fieldname])
                    elif type == 'ignore':
                        r.pop(fieldname, None)
                if r.has_key('update_date') and not r.update_date:
                    r.update_date = 0
                details.append(r)
            localtable.bulk_create(details, ignore=True)
            print "import table %s: %s %s" % (localtable.table_name, minid, len(details))
        print "import table %s over" % localtable.table_name

    def import_task(self):
        minid = 0  # 58648           # 2016-01-01 后的
        psize = 2000
        tmp = 0
        while 1:
            tmp += 1
            if tmp > 10:
                break
            sql = """
            select id, subject_id, type, object_id, add_user, title, sms_content, status, UNIX_TIMESTAMP(add_time) as add_time,
            UNIX_TIMESTAMP(begin_time) as begin_time, UNIX_TIMESTAMP(end_time) as end_time, is_sendpwd
            FROM u_task
            where id>%s
            ORDER BY id
            LIMIT %s;
            """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            minid = tlist[-1].id
            sx_tasks, sx2_tasks, yy_tasks, yy2_tasks = [], [], [], []
            for t in tlist:
                add_user_id = t.add_user
                if t.subject_id == 91:
                    print "yy_task",t.id
                    yy_tasks.append({
                        # "id": yy_pk,
                        "id": t.id,                     # id保持不变， zsn
                        "type": t.type,
                        "object_id": t.object_id,
                        "add_user": add_user_id,
                        "title": t.title,
                        "sms_content": t.sms_content,
                        "status": t.status,
                        "add_time": t.add_time,
                        "begin_time": t.begin_time,
                        "end_time": t.end_time,
                        "is_sendpwd": t.is_sendpwd,
                    })
                    # self.taskd[t.id] = yy_pk
                    # yy_pk += 1
                if t.subject_id == 92:
                    print "yy2_task",t.id
                    yy2_tasks.append({
                        # "id": yy2_pk,
                        "id": t.id,                 # id保持不变， zsn
                        "type": t.type,
                        "object_id": t.object_id,
                        "add_user": add_user_id,
                        "title": t.title,
                        "sms_content": t.sms_content,
                        "status": t.status,
                        "add_time": t.add_time,
                        "begin_time": t.begin_time,
                        "end_time": t.end_time,
                        "is_sendpwd": t.is_sendpwd,
                    })
                    # self.taskd[t.id] = yy2_pk
                    # yy2_pk += 1
            db.local_yingyu.yy_task.bulk_create(yy_tasks, ignore=True)
            db.local_yingyu.yy2_task.bulk_create(yy2_tasks, ignore=True)
            rels = []
            for old_id, new_id in self.taskd.iteritems():
                rels.append({
                    'old_id': old_id, 'new_id': new_id
                })
            print 'task_rels:', len(rels)
            self.taskd = {}
            # break
        print "task over"

    def import_task_class(self):
        minid = 0  # 62069  # 2016-01-01 后的
        psize = 2000
        tmp = 0
        while 1:
            sql = """
            select tc.id, t.subject_id, tc.task_id, tc.unit_class_id, tc.type, tc.student_id,
            UNIX_TIMESTAMP(tc.add_time) as add_time
            FROM u_task_class tc
            INNER JOIN u_task t ON t.id = tc.task_id
            where tc.id>%s  AND  tc.task_id < 28457
            order by tc.id
            LIMIT %s
            """ % (minid, psize)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            minid = tlist[-1].id
            tmp = tlist[-1].task_id
            if tmp > 28456:
                break
            sx_task_class, sx2_task_class, yy_task_class, yy2_task_class = [], [], [], []

            for t in tlist:
                stu_ids = []
                if t.student_id:
                    for d in t.student_id.split(","):
                        stu_ids.append(d)
                task_id = t.task_id
                unit_class_id = t.unit_class_id                     # zsn 班级id保持不变

                if t.subject_id == 91:
                    print "yy_task_class:",task_id
                    yy_task_class.append({
                        "task_id": task_id,
                        "unit_class_id": unit_class_id,
                        "type": t.type,
                        "student_id": ",".join(stu_ids) if stu_ids else "",
                        "add_time": t.add_time,
                    })
                if t.subject_id == 92:
                    print "yy2_task_class:",task_id
                    yy2_task_class.append({
                        "task_id": task_id,
                        "unit_class_id": unit_class_id,
                        "type": t.type,
                        "student_id": ",".join(stu_ids) if stu_ids else "",
                        "add_time": t.add_time,
                    })

            db.local_yingyu.yy_task_class.bulk_create(yy_task_class, ignore=True)
            db.local_yingyu.yy2_task_class.bulk_create(yy2_task_class, ignore=True)
            # break
        print "task_class over"

    def import_yy2_task_detail(self):
        minid = 0   # 58649  # 2016-01-01 后的
        psize = 2000
        while 1:
            task_sql = """
                select id from tbkt_yingyu.yy2_task where id>%s limit %s
            """ % (minid, psize)
            task_list = db.local_yingyu.fetchall_dict(task_sql)
            if not task_list:
                break
            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']
            sql = """
                SELECT td.id, td.task_id,td.catalog_id,td.question_id, td.text_catalog_id,
                content_type FROM tbkt.u_task_detail td where task_id in (%s)
                """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            # 作业id
            detail_list = []
            task_id = 0
            content_type = 0
            text_list = []  # 主记录对应明细
            for obj in tlist:
                if task_id == 0:
                    task_id = obj.task_id  # 作业主id
                    content_type = obj.content_type
                if task_id > 0 and task_id != obj.task_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'task_id=%s to long text =%s' % (obj.task_id, len(json.dumps(text_list)))
                    else:
                        detail_list.append({
                            "task_id": task_id,
                            "text": json.dumps(text_list),
                             "content_type": content_type,
                        })
                    task_id = obj.task_id
                    content_type = obj.content_type
                    text_list = []
                detail = {"cid": obj.catalog_id,
                          "qid": obj.question_id,
                          "tcid": obj.text_catalog_id}
                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'task_id=%s to long text =%s' % (task_id, len(json.dumps(text_list)))
                else:
                    detail_list.append({
                            "task_id": task_id,
                            "text": json.dumps(text_list),
                             "content_type": content_type,
                        })

            print "import yy_task_detail ", len(detail_list)
            db.local_yingyu.yy2_task_detail.bulk_create(detail_list, ignore=True)
        print "yy_task_class_detail over"

    def import_yy_task_detail_new(self):
        minid = 0   # 58649  # 2016-01-01 后的
        psize = 2000
        while 1:
            task_sql = """
                select id from tbkt_yingyu.yy_task where id>%s limit %s
            """ % (minid, psize)
            task_list = db.local_yingyu.fetchall_dict(task_sql)
            if not task_list:
                break
            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']
            sql = """
                SELECT td.id, td.task_id,td.catalog_id,td.question_id, td.text_catalog_id,
                content_type FROM tbkt.u_task_detail td where task_id in (%s) order by task_id,content_type
                """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)
            # 作业id
            detail_list = []
            task_id = 0
            content_type = 0
            text_list = []  # 主记录对应明细
            for obj in tlist:
                if task_id == 0:
                    task_id = obj.task_id  # 作业主id
                    content_type = obj.content_type
                if task_id > 0 and [task_id, content_type] != [obj.task_id, obj.content_type]:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'task_id=%s to long text =%s' % (obj.task_id, len(json.dumps(text_list)))
                    else:
                        detail_list.append({
                            "task_id": task_id,
                            "text": json.dumps(text_list),
                            "content_type": content_type,
                        })
                    task_id = obj.task_id
                    content_type = obj.content_type
                    text_list = []
                detail = {"cid": obj.catalog_id,
                          "qid": obj.question_id,
                          "tcid": obj.text_catalog_id}
                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'task_id=%s to long text =%s' % (task_id, len(json.dumps(text_list)))
                else:
                    detail_list.append({
                            "task_id": task_id,
                            "text": json.dumps(text_list),
                             "content_type": content_type,
                        })

            print "import yy_task_detail ", len(detail_list)
            db.local_yingyu.yy_task_detail.bulk_create(detail_list, ignore=True)
            break
        print "yy_task_class_detail over"

    def import_yy_task_progress(self):
        minid = 0
        psize = 2000
        while 1:
            sql = """
                SELECT ytp.id, ytp.user_id, ytp.task_id, ytp.`status`, ytp.update_time
                FROM tbkt_web.u_yy_task_progress ytp
                where ytp.id>%s
                order by ytp.id
                LIMIT %s;
                """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id
            details = []
            for t in recode:
                user_id = t.user_id
                task_id = t.task_id
                details.append({
                    "user_id": user_id,
                    "task_id": task_id,
                    "status": t.status,
                    "update_time": t.update_time,
                })
            print "import yy_task_progress", len(details)
            db.local_yingyu.yy_task_progress.bulk_create(details, ignore=True)
        print "yy_task_progress over"

    def import_yy_test(self):
        minid = 0
        psize = 2000
        # pk = 1
        while 1:
            sql = """
              SELECT id, user_id, catalog_id, nquestion, score, `status`, add_time, test_time, object_id
              FROM tbkt_web.u_yy_test
              where id>%s
              order by id limit %s
              """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                user_id = t.user_id
                object_id = 0
                if t.object_id:
                    object_id = t.object_id  # task_id 保持不变

                details.append({
                    # "id": pk,                         # test_id 保持不变
                    "id": t.id,
                    "user_id": user_id,
                    "catalog_id": t.catalog_id,
                    "nquestion": t.nquestion,
                    "score": t.score,
                    "status": t.status,
                    "add_time": t.add_time,
                    "test_time": t.test_time,
                    "object_id": object_id})

            db.local_yingyu.yy_test.bulk_create(details, ignore=True)
            print "import yy_test", len(details)
            self.yytestd = {}
        print "yy_test over"

    def import_yy_test_detail(self):
        minid = 0
        psize = 2000
        while 1:
            task_sql = """
                  select id,catalog_id,object_id,user_id from tbkt_yingyu.yy_test where id>%s limit %s
              """ % (minid, psize)
            task_list = db.local_yingyu.fetchall_dict(task_sql)
            if not task_list:
                break
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t

            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']

            sql = """
                  SELECT id,test_id,question_id,ask_id,result,answer,option_id from tbkt_web.u_yy_test_detail
                  where test_id in (%s) order by test_id
              """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            test_id = 0  # 测试主id
            text_list = []  # 主记录对应明细

            for obj in tlist:
                # {"answer": "B", "qid": 18132, "oid": 47030, "result": 1, "aid": 19455}
                if test_id == 0:
                    test_id = obj.test_id  # 主id
                if test_id > 0 and test_id != obj.test_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'test_id=%s to long text =%s' % (obj.test_id, len(json.dumps(text_list)))
                    else:
                        type_id = 1
                        object_id = task_dict.get(test_id).get("object_id")
                        catalog_id = task_dict.get(test_id).get("catalog_id")
                        user_id = task_dict.get(test_id).get("user_id")
                        if object_id == 0:
                            # 练习册
                            object_id = test_id
                            type_id = 2
                        detail_list.append({
                            "user_id": user_id,
                            "object_id": object_id,
                            "catalog_id": catalog_id,
                            "type": type_id,
                            "text": json.dumps(text_list),
                        })
                    test_id = obj.test_id
                    text_list = []
                detail = {"result": obj.result,
                          "qid": obj.question_id,
                          "oid": obj.option_id,
                          "aid": obj.ask_id,
                          "answer": obj.answer}
                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'test_id=%s to long text =%s' % (test_id, len(json.dumps(text_list)))
                else:
                    type_id = 1
                    object_id = task_dict.get(test_id).get("object_id")
                    catalog_id = task_dict.get(test_id).get("catalog_id")
                    user_id = task_dict.get(test_id).get("user_id")
                    if object_id == 0:
                        # 练习册
                        object_id = test_id
                        type_id = 2
                    detail_list.append({
                        "user_id": user_id,
                        "object_id": object_id,
                        "catalog_id": catalog_id,
                        "type": type_id,
                        "text": json.dumps(text_list),
                    })

            print "import yy_test_detail", minid
            db.local_yingyu.yy_test_detail.bulk_create(detail_list, ignore=True)

        print "yy_test_detail over"

    def import_yy_word_test(self):
        minid = 0
        psize = 2000
        # self.load_task_detail_id()
        while 1:
            sql = """
              SELECT id, user_id, catalog_id, type, score, `status`, test_time, object_id
              FROM tbkt_web.u_yy_word_test
              where id>%s
              order by id limit %s
              """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id
            object_id_list = ['%s' % obj.object_id for obj in recode]
            sql = "select id, task_id,catalog_id from tbkt.u_task_detail where id in (%s)" % ",".join(object_id_list)
            u_task_details = db.hn_tbkt.fetchall_dict(sql)
            u_task_detail_dict = {}  # 原作业明细
            for obj in u_task_details:
                u_task_detail_dict[obj.id] = obj
            details = []
            for t in recode:
                user_id = t.user_id
                object_id = t.object_id
                if u_task_detail_dict.get(object_id):
                    #  作业
                    task_id = u_task_detail_dict.get(object_id).get('task_id')
                    catalog_id = u_task_detail_dict.get(object_id).get('catalog_id')
                else:
                    # 练习
                    task_id = 0
                    catalog_id = t.catalog_id
                details.append({
                    "id": t.id,
                    "user_id": user_id,
                    "catalog_id": catalog_id,
                    "score": t.score,
                    "type": t.type,
                    "status": t.status,
                    "test_time": t.test_time,
                    "object_id": task_id})

            print "import yy_word_test", minid
            db.local_yingyu.yy_word_test.bulk_create(details, ignore=True)
        print "u_yy_word_test over"

    def import_yy_word_test_detail(self):
        minid = 0
        psize = 2000
        while 1:
            task_sql = """
                  select id,catalog_id,object_id,user_id,type from tbkt_yingyu.yy_word_test where id>%s limit %s
              """ % (minid, psize)
            task_list = db.local_yingyu.fetchall_dict(task_sql)
            if not task_list:
                break
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t

            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']

            sql = """
                  SELECT id,test_id,word_id,result,score from tbkt_web.u_yy_word_test_detail
                  where test_id in (%s) order by test_id
              """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            test_id = 0  # 测试主id
            text_list = []  # 主记录对应明细

            for obj in tlist:
                # {"wid": 6101, "score": 20, "result": 1}
                if test_id == 0:
                    test_id = obj.test_id  # 主id
                if test_id > 0 and test_id != obj.test_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'test_id=%s to long text =%s' % (obj.test_id, len(json.dumps(text_list)))
                    else:
                        type_id = task_dict.get(test_id).get("type")
                        object_id = task_dict.get(test_id).get("object_id")
                        catalog_id = task_dict.get(test_id).get("catalog_id")
                        user_id = task_dict.get(test_id).get("user_id")
                        if object_id > 0:
                            # 作业
                            object_id = test_id
                            if type_id == 1:
                                # 打气球
                                type_id = 3
                            elif type_id == 2:
                                # 打地鼠
                                type_id = 4
                        else:
                            object_id = test_id

                        detail_list.append({
                            "user_id": user_id,
                            "object_id": object_id,
                            "catalog_id": catalog_id,
                            "type": type_id,
                            "text": json.dumps(text_list),
                        })
                    test_id = obj.test_id
                    text_list = []
                detail = {"result": obj.result,
                          "wid": obj.word_id,
                          "score": obj.score,
                          }
                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'test_id=%s to long text =%s' % (test_id, len(json.dumps(text_list)))
                else:
                    type_id = 1
                    object_id = task_dict.get(test_id).get("object_id")
                    catalog_id = task_dict.get(test_id).get("catalog_id")
                    user_id = task_dict.get(test_id).get("user_id")
                    if object_id == 0:
                        # 练习册
                        object_id = test_id
                        type_id = 2
                    detail_list.append({
                        "user_id": user_id,
                        "object_id": object_id,
                        "catalog_id": catalog_id,
                        "type": type_id,
                        "text": json.dumps(text_list),
                    })

            print "import yy_test_detail", minid
            db.local_yingyu.yy_word_test_detail.bulk_create(detail_list, ignore=True)

        print "yy_test_detail over"

    def import_yy_study(self):
        minid = 0
        psize = 2000
        # self.load_task_detail_id()
        while 1:
            sql = """
              SELECT id, user_id, catalog_id, type, score, `status`, add_time, object_id
              FROM tbkt_web.u_yy_study
              where id>%s
              order by id limit %s
              """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id
            object_id_list = ['%s' % obj.object_id for obj in recode]
            sql = "select id, task_id,catalog_id from tbkt.u_task_detail where id in (%s)" % ",".join(object_id_list)
            u_task_details = db.hn_tbkt.fetchall_dict(sql)
            u_task_detail_dict = {}  # 原作业明细
            for obj in u_task_details:
                u_task_detail_dict[obj.id] = obj

            details = []
            for t in recode:
                user_id = t.user_id
                # object_id = self.yytaskdetaild[t.object_id]               # task_detail_id 保持不变
                object_id = t.object_id
                if u_task_detail_dict.get(object_id):
                    #  作业
                    task_id = u_task_detail_dict.get(object_id).get('task_id')
                    catalog_id = u_task_detail_dict.get(object_id).get('catalog_id')
                else:
                    # 练习
                    task_id = 0
                    catalog_id = t.catalog_id

                details.append({
                    "id": t.id,
                    "user_id": user_id,
                    "catalog_id": catalog_id,
                    "score": t.score,
                    "type": t.type,
                    "status": t.status,
                    "add_time": t.add_time,
                    "object_id": task_id})

            print "import yy_study", len(details)
            db.local_yingyu.yy_study.bulk_create(details, ignore=True)

        print "yy_study over"

    def import_yy_study_detail(self):
        minid = 0
        psize = 2000
        while 1:
            task_sql = """
                  select id,catalog_id,object_id,user_id,type,add_time from tbkt_yingyu.yy_study where id>%s limit %s
              """ % (minid, psize)
            task_list = db.local_yingyu.fetchall_dict(task_sql)
            if not task_list:
                break
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t

            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']

            sql = """
                  SELECT * from tbkt_web.u_yy_study_detail
                  where study_id in (%s) order by study_id
              """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            test_id = 0  # 测试主id
            text_list = []  # 主记录对应明细

            for obj in tlist:
                # {"wid": 6101, "score": 20, "result": 1}
                if test_id == 0:
                    test_id = obj.study_id  # 主id
                if test_id > 0 and test_id != obj.study_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'study_id=%s to long text =%s' % (obj.study_id, len(json.dumps(text_list)))
                    else:
                        type_id = task_dict.get(test_id).get("type")
                        object_id = task_dict.get(test_id).get("object_id")
                        catalog_id = task_dict.get(test_id).get("catalog_id")
                        user_id = task_dict.get(test_id).get("user_id")
                        add_time = task_dict.get(test_id).get("add_time")

                        is_change = 0 if text_list[0]['local_audio'] == '' and text_list[0]['remote_audio'] != '' else 1
                        detail_list.append({
                            "user_id": user_id,
                            "object_id": object_id,
                            "catalog_id": catalog_id,
                            "type": type_id,
                            "text": json.dumps(text_list),
                            "add_time": add_time,
                            "is_change": is_change
                        })
                    test_id = obj.study_id
                    text_list = []
                detail = {"objid": obj.object_id,
                          "result": obj.result,
                          "score": obj.score,
                          "answer": obj.answer,
                          "role_id": obj.role_id,
                          "remote_audio": obj.remote_audio,
                          "local_audio": obj.local_audio}
                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'test_id=%s to long text =%s' % (test_id, len(json.dumps(text_list)))
                else:
                    type_id = 1
                    object_id = task_dict.get(test_id).get("object_id")
                    catalog_id = task_dict.get(test_id).get("catalog_id")
                    user_id = task_dict.get(test_id).get("user_id")
                    add_time = task_dict.get(test_id).get("add_time")

                    is_change = 0 if text_list[0]['local_audio'] == '' and text_list[0]['remote_audio'] != '' else 1
                    detail_list.append({
                        "user_id": user_id,
                        "object_id": object_id,
                        "catalog_id": catalog_id,
                        "type": type_id,
                        "text": json.dumps(text_list),
                        "add_time": add_time,
                        "is_change": is_change
                    })

            print "import yy_study_detail", minid
            db.local_yingyu.yy_study_detail.bulk_create(detail_list, ignore=True)

        print "yy_study_detail over"

    def import_yy2_test(self):
        minid = 0
        psize = 2000
        # pk = 1
        # self.load_yy2_test_id()

        while 1:
            sql = """
              SELECT id, user_id, catalog_id, score, `status`, add_time, object_id,type
              FROM tbkt.u_yy2_test
              where id>%s
              order by id limit %s
              """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            details = []
            for t in recode:
                user_id = t.user_id

                # object_id = self.taskd[t.object_id]               # task_id   保持不变
                object_id = t.object_id

                details.append({
                    # "id": pk,                                         # test_id 保持不变
                    "id": t.id,
                    "type": t.type,
                    "user_id": user_id,
                    "catalog_id": t.catalog_id,
                    "score": t.score,
                    "status": t.status,
                    "add_time": unix_timestamp(t.add_time),
                    "object_id": object_id})

            print "import yy2_test", len(details)
            db.local_yingyu.yy2_test.bulk_create(details, ignore=True)

        print "yy2_test over"

    def import_yy2_test_detail(self):
        minid = 0
        psize = 2000
        while 1:
            task_sql = """
                  select id,catalog_id,object_id,user_id,type from tbkt_yingyu.yy2_test where id>%s limit %s
              """ % (minid, psize)
            task_list = db.local_yingyu.fetchall_dict(task_sql)
            if not task_list:
                break
            task_dict = {}
            for t in task_list:
                task_dict[t.id] = t

            minid = task_list[-1].id
            task_id_list = ["%s" % obj.id for obj in task_list]
            # task_id_list = ['8491','8564']

            sql = """
                  SELECT * from tbkt.u_yy2_test_detail
                  where study_id in (%s) order by study_id
              """ % ",".join(task_id_list)
            tlist = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            test_id = 0  # 测试主id
            text_list = []  # 主记录对应明细

            for obj in tlist:
                # {"answer": "B", "qid": 18132, "oid": 47030, "result": 1, "aid": 19455}
                if test_id == 0:
                    test_id = obj.study_id  # 主id
                if test_id > 0 and test_id != obj.study_id:
                    if len(json.dumps(text_list)) >= 9000:
                        print 'test_id=%s to long text =%s' % (obj.study_id, len(json.dumps(text_list)))
                    else:
                        # type_id = 1
                        object_id = task_dict.get(test_id).get("object_id")
                        catalog_id = task_dict.get(test_id).get("catalog_id")
                        user_id = task_dict.get(test_id).get("user_id")
                        type_id = task_dict.get(test_id).get("type")
                        detail_list.append({
                            "user_id": user_id,
                            "object_id": object_id,
                            "catalog_id": catalog_id,
                            "type": type_id,
                            "text": json.dumps(text_list),
                        })
                    test_id = obj.study_id
                    text_list = []
                detail = {"result": obj.result,
                          "qid": obj.object_id,
                          "oid": obj.option_id,
                          "aid": obj.question_ask_id,
                          "answer": obj.answer
                          }

                text_list.append(detail)
            if text_list:
                # 最后一个主记录明细
                if len(json.dumps(text_list)) >= 9000:
                    print 'test_id=%s to long text =%s' % (test_id, len(json.dumps(text_list)))
                else:
                    object_id = task_dict.get(test_id).get("object_id")
                    catalog_id = task_dict.get(test_id).get("catalog_id")
                    user_id = task_dict.get(test_id).get("user_id")
                    type_id = task_dict.get(test_id).get("type")
                    detail_list.append({
                        "user_id": user_id,
                        "object_id": object_id,
                        "catalog_id": catalog_id,
                        "type": type_id,
                        "text": json.dumps(text_list),
                    })

            print "import yy2_test_detail", minid
            db.local_yingyu.yy2_test_detail.bulk_create(detail_list, ignore=True)

        print "yy2_test_detail over"

    def start(self):
        # 清记录
        print ' 7449 s'

        # # 初中英语错题集
        # db.local_yingyu.execute("truncate yy2_wrong_title_set")
        # self.import_yy2_wrong_title_test()
        #
        # # 用户教材记录
        # db.local_com.execute("truncate user_book")
        # self.import_user_book()

        # 作业记录 和 作业班级记录
        # db.local_com.execute("truncate message")
        # self.import_message()
        # db.local_com.execute("truncate message_class")
        # self.import_message_class()

        # score_user 表数据
        # db.local_com.execute("truncate score_user")
        # def f_score_user(r):
        #     r['unit_id'] = r['unit_id']
        #     r.pop('unit_id', None)
        #     return r
        # self.import_table(db.local_com.score_user, db.hn_tbkt.score_user, {'user_id': 'user_id', 'city': 'city'})

        # 英语作业表
        # db.local_yingyu.execute("truncate yy_task")
        # db.local_yingyu.execute("truncate yy2_task")
        # self.import_task()

        # 班级作业表
        # db.local_yingyu.execute("truncate yy_task_class")
        # db.local_yingyu.execute("truncate yy2_task_class")
        # self.import_task_class()
        #
        # # # # 初中英语作业明细
        # db.local_yingyu.execute("truncate yy2_task_detail")
        # self.import_yy2_task_detail()
        #
        # # # 英语作业明细
        # db.local_yingyu.execute("truncate yy_task_detail")
        # self.import_yy_task_detail_new()
        #
        #
        # # # 小学英语测试记录
        # db.local_yingyu.execute("truncate yy_test")
        # self.import_yy_test()
        # #
        # # # 小学英语测试明细
        # db.local_yingyu.execute("truncate yy_test_detail")
        # self.import_yy_test_detail()
        #
        # # 英语单词测试记录
        # db.local_yingyu.execute("truncate yy_word_test")
        # self.import_yy_word_test()
        # db.local_yingyu.execute("truncate yy_word_test_detail")
        # self.import_yy_word_test_detail()
        #
        # # 英语学习记录
        db.local_yingyu.execute("truncate yy_study")
        self.import_yy_study()
        db.local_yingyu.execute("truncate yy_study_detail")
        self.import_yy_study_detail()
        # #
        # # 初中英语测试记录
        # db.local_yingyu.execute("truncate yy2_test")
        # self.import_yy2_test()
        # db.local_yingyu.execute("truncate yy2_test_detail")
        # self.import_yy2_test_detail()





if __name__ == '__main__':
    print datetime.datetime.now()
    hnworker = HNWorker()
    st = time.time()
    hnworker.start()
    print 'took:', time.time() - st
    print datetime.datetime.now()