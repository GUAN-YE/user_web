# coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import time
import random
import hashlib
import base64
# import MySQLdb
import pymysql
from db import Hub
import json

# LOCAL_HOST = '192.168.0.113'
# # LOCAL_HOST = '116.255.220.114'
#
# LOCAL_USER = 'duzuyong'
# LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'


LOCAL_HOST = 'rm-2ze8fpa1oek84h9gko.mysql.rds.aliyuncs.com'
LOCAL_USER = 'renwanxing'
LOCAL_PASSWORD = 'wanxing@TbkT!rds2017'

# HN_HOST = '192.168.0.112'
# # HN_HOST = '116.255.220.112'
# HN_USER = 'duzuyong'
# HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

JX_HOST = 'rm-2zeso7flj7kkik72ro.mysql.rds.aliyuncs.com'
JX_USER = 'renwangxing'
JX_PASSWORD = 'fPhTisS3DvTZZgD'

db = Hub(pymysql)
# 本地新库
db.add_pool('local_user',
            host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_user',
            charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
            )
db.add_pool('local_ketang',
            host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
            charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
            )
db.add_pool('local_com',
            host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_com',
            charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
            )
db.add_pool('local_shuxue',
            host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
            charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
            )
db.add_pool('local_yingyu',
            host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_yingyu',
            charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
            )
db.add_pool('local_web',
            host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_web',
            charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
            )

# 江西大网库
db.add_pool('jx_tbkt',
            host=JX_HOST, port=3306, user=JX_USER, passwd=JX_PASSWORD, db='jxtbkt',
            charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
            )


def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        now = int(time.mktime(t))
        if now < 0:
            now = 0
        return now
    except:
        return 0


def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except:
        print 'encode_password:', password
        return ''
    return "sha1$%s$%s" % (salt, hash)


def encode_plain_password(password):
    try:
        return base64.b64encode(password)
    except:
        return ''


class JXWorker:
    """
    江西导入类
    """

    def __init__(self):
        print 'init ok.'

    def import_user(self):
        last = db.local_user.auth_user.filter().last()
        last_id = last.id
        details = []
        profile_rows = []
        third_rows = []
        sql = """
            select u.username, u.password, u.type, u.nick_name,u.real_name,u.phone,u.subject_id,UNIX_TIMESTAMP(u.last_login) last_login,
            UNIX_TIMESTAMP(u.date_joined) date_joined, u.is_active status,t.third_uid,t.third_abb,b.password  plain_password
            from auth_user u join score_user s on s.user_id = u.id and s.app_id  =3
            left join third_user t on t.user_id=u.id
            left join mobile_user_bind b on b.username=u.phone"""
        rows = db.jx_tbkt.fetchall_dict(sql)
        sql = """select u.username, u.password, u.type, u.nick_name,u.real_name,u.phone,u.subject_id,UNIX_TIMESTAMP(u.last_login) last_login,
            UNIX_TIMESTAMP(u.date_joined) date_joined, u.is_active status,t.third_uid,t.third_abb,b.password  plain_password
            from auth_user u join active_award s on s.user_id = u.id
            left join third_user t on t.user_id=u.id
            left join mobile_user_bind b on b.username=u.phone """
        rows2 = db.jx_tbkt.fetchall_dict(sql)
        for i in rows2:
            if i not in rows:
                rows.append(i)
        for r in rows:
            last_id += 1
            r.id = last_id
            r.platform_id = 2
            r.sid = int(str(r.subject_id)[0]) if r.subject_id else 0
            r.third_uid = str(r.third_uid) + '_' + str(r.third_abb) if r.third_uid and r.third_abb else ''
            profile_rows.append({
                'user_id': r.id,
                'nickname': r.nick_name,
                'portrait': '',
                'password': encode_plain_password(r.plain_password)
            })
            third_rows.append({
                'user_id': r.id,
                'third_id': r.third_uid,
                'platform_id': 2
            })
            del r.nick_name, r.third_uid, r.plain_password, r.subject_id, r.third_abb
            details.append(r)
        db.local_user.auth_user.bulk_create(details, ignore=True)
        db.local_user.auth_profile.bulk_create(profile_rows, ignore=True)
        db.local_user.third_user.bulk_create(third_rows, ignore=True)

    def import_score(self):
        sql = """select s.*,t.third_uid,t.third_abb from score_user s join third_user t on t.user_id=s.user_id where s.app_id=3"""
        rows = db.jx_tbkt.fetchall_dict(sql)

        user_ids = db.local_user.third_user.filter(platform_id=2).select('user_id', 'third_id')[:]

        third_uid_dict = {str(u.third_id): u.user_id for u in user_ids}
        score_user = []
        for r in rows:
            r.third_uid = str(r.third_uid) + '_' + str(r.third_abb) if r.third_uid and r.third_abb else ''
            user_id = third_uid_dict.get(r.third_uid, 0)
            if user_id:
                r.user_id = user_id
                r.app_id = 7
                del r.third_uid, r.id, r.third_abb
                score_user.append(r)
        db.local_com.score_user.bulk_create(score_user, ignore=True)

        sql = """select s.*,t.third_uid,t.third_abb from score_user_detail s join third_user t on t.user_id=s.user_id where s.app_id=3"""
        rows = db.jx_tbkt.fetchall_dict(sql)
        detail = []
        for r in rows:
            r.third_uid = str(r.third_uid) + '_' + str(r.third_abb) if r.third_uid and r.third_abb else ''
            user_id = third_uid_dict.get(r.third_uid, 0)
            if user_id:
                r.add_date = unix_timestamp(r.add_date)
                r.user_id = user_id
                r.app_id = 7
                del r.third_uid, r.id, r.third_abb
                detail.append(r)
        db.local_com.score_user_detail.bulk_create(detail, ignore=True)

        sql = """insert into score_app  values (7,'教师礼品商城(金豆)','教师礼品商城(金豆)')"""
        db.local_com.execute(sql)
        # sql = """select s.*,t.third_uid,t.third_abb  from active_award s join third_user t on t.user_id=s.user_id """
        # rows = db.jx_tbkt.fetchall_dict(sql)
        # detail = []
        # for r in rows:
        #     r.third_uid = str(r.third_uid) + '_' + str(r.third_abb) if r.third_uid and r.third_abb else ''
        #     user_id = third_uid_dict.get(r.third_uid, 0)
        #     if user_id:
        #         r.user_id = user_id
        #         del r.third_uid, r.id, r.third_abb
        #         detail.append(r)
        # db.local_web.active_award_jx.bulk_create(detail, ignore=True)

    def start(self):
        print 'start  worker'
        self.import_user()
        self.import_score()


if __name__ == '__main__':
    print datetime.datetime.now()
    jxworker = JXWorker()
    st = time.time()
    jxworker.start()
    print 'use time:', time.time() - st
    print datetime.datetime.now()
