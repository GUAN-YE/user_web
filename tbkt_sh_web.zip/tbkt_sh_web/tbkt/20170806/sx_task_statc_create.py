#coding: utf-8
"""
"""
import datetime
import time
import random
import hashlib
import base64
# import MySQLdb
from collections import defaultdict

import pymysql
from db import Hub
import json

LOCAL_HOST = '116.255.220.112'
LOCAL_HOST = '192.168.0.76'

LOCAL_USER = 'duzuyong'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'
PORT = 3306

HN_HOST = '116.255.220.112'
HN_HOST = '192.168.0.112'
HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

db = Hub(pymysql)
# 本地库
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=PORT, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)

# 河南大网老库
db.add_pool('hn_ziyuan',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ziyuan_new',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_shuxue',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)


def create_static():
    # 根据作业详情创建作业统计表
    minid = 0
    psize = 50
    all_qids = []      # 作业全部的qid已去重
    all_ask_map = {}   # {qid:[ask_id]}
    all_know_map = {}  # {qid:knowledge}
    while 1:

        q_stat = []    # 试题统计插入数据
        k_stat = []    # 知识点统计插入数据
        con_map = {}   # {task_id: [qid]}
        # 作业详情记录
        content = db.local_shuxue.sx_task_content.select('task_id', 'text', 'id').filter(id__gt=minid)[:psize]
        if not content:
            break
        minid = content[-1].id
        print minid
        qid_list = []
        for con in content:
            if len(con.text) < 2 or not is_json(con.text):
                # 数据错误 text字段为空
                continue
            txt = json.loads(con.text)
            qids = [t.get('qid') for t in txt if t]
            con_map[con.task_id] = qids
            for i in qids:
                if i not in all_qids:
                    qid_list.append(i)
                    all_qids.append(i)

        ask_ids = db.hn_ziyuan.sx_question_ask.select('id ask_id', 'question_id').filter(question_id__in=qid_list)[:]
        ask_map = defaultdict(list)
        for i in ask_ids:
            ask_map[i.question_id].append(i.ask_id)
        all_ask_map.update(ask_map)

        know = get_question_knowledge(qid_list)
        know_map = defaultdict(list)
        for i in know:
            know_map[i.question_id].append(i)
        all_know_map.update(know_map)

        for task_id, qids in con_map.iteritems():
            for qid in qids:
                knows = all_know_map.get(qid, [])
                for know in knows:
                    # 知识点更新
                    k_args = {'task_id': task_id,
                              'knowledge_id': know.id,
                              'knowledge_name': know.name,
                              'finish_student': '',
                              'wrong_student': '',
                              'add_time': 0}
                    if k_args not in k_stat:
                        k_stat.append(k_args)

                asks = all_ask_map.get(qid, [])
                for aid in asks:
                    # 题目更新
                    q_args = {'task_id': task_id,
                              'ask_id': aid,
                              'finish_student': '',
                              'wrong_student': '',
                              'add_time': 0}
                    if q_args not in q_stat:
                        q_stat.append(q_args)
        if q_stat:
            db.local_shuxue.sx_task_qstat.bulk_create(q_stat, ignore=True)
            print 'insert success qstat', len(q_stat)
        if k_stat:
            db.local_shuxue.sx_task_kstat.bulk_create(k_stat, ignore=True)
            print 'insert success kstat', len(k_stat)

    print 'update task finish'


def get_question_knowledge(qids):
    """
    根据qid返回知识点信息 
    """
    if not qids:
        return []
    qids = ','.join(str(i) for i in qids)
    sql = """
    select distinct k.id,if(k.name!='',k.name,r.name) name, a.question_id from sx_knowledge k
    inner join sx_ask_relate_knowledge a on a.question_id in (%s) and a.knowledge_id = k.id and k.status = 1
    inner join sx_text_book_catalog_relate_knowledge r on r.knowledge_id = k.id;
    """ % qids
    rows = db.hn_ziyuan.fetchall_dict(sql)
    return rows


def is_json(d):
    # 是否为json格式
    if not isinstance(d, (int, long)):
        try:
            json.loads(d)
        except ValueError:
            return False
        return True
    else:
        return False


def join(o):
    if isinstance(o, (list, tuple)):
        return ','.join(str(i) for i in o)
    return str(o)


if __name__ == '__main__':
    """
    创建 sx_task_qstat, sx_task_kstat
    """
    db.local_shuxue.execute("truncate sx_task_qstat")
    db.local_shuxue.execute("truncate sx_task_kstat")
    create_static()
