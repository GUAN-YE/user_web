#coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import time
import random
import hashlib
import base64
# import MySQLdb
import pymysql
from db import Hub
import json



LOCAL_HOST = '192.168.0.113'
# LOCAL_HOST = '116.255.220.112'
LOCAL_USER = 'duzuyong'
# LOCAL_USER = 'dba_user'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'
# LOCAL_PASSWORD = 'tbkt123456'


HN_HOST = '192.168.0.112'
# HN_HOST = '116.255.220.112'
HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

JX_HOST = 'rm-2zeso7flj7kkik72r.mysql.rds.aliyuncs.com'
JX_USER = 'jx_tbkt_db'
JX_PASSWORD = 'fPhTisS3DvTZZgD'

db = Hub(pymysql)
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 河南大网老库
db.add_pool('hn_tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)



def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        now = int(time.mktime(t))
        if now < 0:
            now = 0
        return now
    except:
        return 0


def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except:
        print 'encode_password:', password
        return ''
    return "sha1$%s$%s" % (salt, hash)

def encode_plain_password(password):
    try:
        return base64.b64encode(password)
    except:
        return ''


class HNWorker:
    """
    河南导入类
    """
    def __init__(self):
        print 'init ok.'

    def import_table(self, localtable, remotetable, converter={}, callback=None):
        """
        :param localtable: 目标db表(QuerySet)
        :param remotetable: 来源db表(QuerySet)
        :param converter: {'字段名':转换类型('user_id'转为新用户ID, 'unixtime'转为时间戳, 'ignore':忽略该字段, ...)}
        :param callback: 过滤器函数
        """
        minid = 0
        psize = 2000
        while 1:
            rows = remotetable.filter(id__gt=minid)[:psize]
            if not rows:
                break
            minid = rows[-1].id
            details = []
            for r in rows:
                if callback and callable(callback):
                    r = callback(r)
                for fieldname, type in converter.iteritems():
                    if type == 'user_id_strict':
                        pass
                    elif type == 'user_id':
                        pass
                    elif type == 'unixtime':
                        r[fieldname] = unix_timestamp(r[fieldname])
                    elif type == 'ignore':
                        r.pop(fieldname, None)
                if r.has_key('update_date') and not r.update_date:
                    r.update_date = 0
                details.append(r)
            localtable.bulk_create(details, ignore=True)
            print "import table %s: %s %s" % (localtable.table_name, minid, len(details))
        print "import table %s over" % localtable.table_name

    def start(self):
        # 清记录 用时1081 秒
        print 'start henan worker'
        # 奥数
        db.local_shuxue.execute("truncate think_test")
        self.import_table(db.local_shuxue.think_test, db.hn_tbkt.think_test)

        db.local_shuxue.execute("truncate think_test_detail")
        self.import_table(db.local_shuxue.think_test_detail, db.hn_tbkt.think_test_detail)

        db.local_shuxue.execute("truncate think_user_book")
        self.import_table(db.local_shuxue.think_user_book, db.hn_tbkt.think_user_book)

if __name__ == '__main__':

    print datetime.datetime.now()
    hnworker = HNWorker()
    st = time.time()
    hnworker.start()
    print 'use time:', time.time() - st
    print datetime.datetime.now()
