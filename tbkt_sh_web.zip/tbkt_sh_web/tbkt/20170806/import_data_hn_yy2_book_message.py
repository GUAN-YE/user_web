#coding=utf-8

"""
@varsion: ??
@author: 张帅男
@file: import_data_hn_yy2_book_message.py
@time: 2017/8/9 15:48

tbkt_com.message  消息表  从tbkt.u_task
tbkt_com.message_class    从tbkt.u_task_class
tbkt_com.user_book        从tbkt.u_user_book
tbkt_yingyu.yy2_wrong_title_set  从tbkt.u_yy2_wrong_title_set
"""

import datetime
import logging
import time
import random
import hashlib
import base64
import pymysql
from db import Hub
import json


LOCAL_HOST = '192.168.0.113'
# LOCAL_HOST = '116.255.220.112'
LOCAL_USER = 'duzuyong'
LOCAL_USER = 'bannei'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'
LOCAL_PASSWORD = 'bannei60279052'


# HN_HOST = '192.168.7.250'
HN_HOST = '116.255.220.112'
HN_HOST = '192.168.0.112'

HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

JX_HOST = 'rm-2zeso7flj7kkik72r.mysql.rds.aliyuncs.com'
JX_USER = 'jx_tbkt_db'
JX_PASSWORD = 'fPhTisS3DvTZZgD'


db = Hub(pymysql)
# 本地新库
db.add_pool('local_user',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_user',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_ketang',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_com',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_com',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_yingyu',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_yingyu',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 河南大网老库
db.add_pool('hn_tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_tbktweb',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt_web',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_ketang',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 江西大网库
db.add_pool('jx_tbkt',
    host=JX_HOST, port=3306, user=JX_USER, passwd=JX_PASSWORD, db='jxtbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)

def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        return int(time.mktime(t))
    except:
        return 0

def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except:
        logging.info('encode_password: %s' % password)
        # print 'encode_password:', password
        return ''
    return "sha1$%s$%s" % (salt, hash)

def encode_plain_password(password):
    try:
        return base64.b64encode(password)
    except:
        return ''


class HNWorker:
    """
    河南导入类
    """
    def __init__(self):
        self.provinced = {} # {旧地市ID: 新地市ID}
        self.schoold = {} # {旧学校ID: 新学校ID}
        self.classd = {} # {旧班级ID: 新班级ID}

        self.taskd = {}
        self.yytaskdetail = {}
        self.yytestd = {}
        self.yy2testd = {}
        self.sxtestd = {}
        self.sx2testd = {}

        print 'init ok.'

    def import_yy2_wrong_title_test(self):
        minid = 0
        psize = 2000
        while 1:
            sql = """
                SELECT id, user_id, catalog_id, question_id, UNIX_TIMESTAMP(add_time) add_time
                FROM u_yy2_wrong_title_set WHERE  id > %s ORDER BY id  LIMIT %s  ;
                 """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            detail_list = []
            for r in recode:
                detail_list.append({
                    "id": r.id,
                    "user_id": r.user_id,
                    "catalog_id": r.catalog_id,
                    "question_id": r.question_id,
                    "add_time": r.add_time
                })
            db.local_yingyu.yy2_wrong_title_set.bulk_create(detail_list, ignore=True)
            print "import yy2_wrong_title_set", len(detail_list)

    def import_user_book(self):
        minid = 0
        psize = 2000
        while 1:
            sql = """
                SELECT id, book_id, subject_id, user_id, UNIX_TIMESTAMP(add_time) add_time,
                 is_work_book FROM u_user_book WHERE id > %s ORDER BY id LIMIT %s;
                """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            detail_list = []
            for r in recode:
                detail_list.append({
                    "id": r.id,
                    "user_id": r.user_id,
                    "book_id": r.book_id,
                    "subject_id": r.subject_id,
                    "add_time": r.add_time,
                    "is_work_book": r.is_work_book,
                })
            db.local_com.user_book.bulk_create(detail_list, ignore=True)
            print "import user_book", len(detail_list)

    def import_message(self):
        minid = 0
        psize = 2000
        while 1:
            sql = """
                SELECT id, type, object_id, subject_id, add_user, title, sms_content,
                `status`, UNIX_TIMESTAMP(begin_time) begin_time, UNIX_TIMESTAMP(end_time) end_time,
                UNIX_TIMESTAMP(add_time) add_time
                 FROM u_task WHERE id > %s ORDER BY id limit %s;
                """ % (minid, psize)
            recode = db.hn_tbkt.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id

            type_id = 0
            task_id = 0
            detail_list = []
            for r in recode:
                if r.type == 0:     # 通知
                    type_id = 1
                    task_id = r.id
                elif r.type == 1:   # 作业
                    type_id = 2
                    task_id = r.id
                elif r.type == 2 and r.subject_id in (21, 22):  # 数学试卷
                    type_id = 7
                    task_id = r.id
                elif r.type == 3:           # 资源
                    type_id = 3
                    task_id = r.object_id
                else:
                    continue
                detail_list.append({
                    "type": type_id,
                    "subject_id": r.subject_id,
                    "object_id": task_id,
                    "add_user": r.add_user,
                    "title": r.title,
                    "content": r.sms_content,
                    "status": 1,
                    "add_time": r.add_time,
                    "begin_time": r.begin_time,
                    "end_time": r.end_time
                })
            db.local_com.message.bulk_create(detail_list, ignore=True)
            print "import message", len(detail_list)

    def import_message_class(self):
        minid = 0
        psize = 2000

        while 1:
            sql = """
                SELECT id, object_id FROM message WHERE id > %s ORDER BY id LIMIT %s
                """ % (minid, psize)
            message = db.local_com.fetchall_dict(sql)
            if not message:
                break
            minid = message[-1].id

            message_dict = {}
            message_task_list = []
            for m in message:
                message_dict[m.object_id] = m.id
                message_task_list.append(m.object_id)

            sql = """SELECT task_id, unit_class_id, student_id
                  FROM u_task_class WHERE task_id in (%s);
                """ % ",".join(str(obj) for obj in message_task_list)
            task_class_list = db.hn_tbkt.fetchall_dict(sql)

            detail_list = []
            for r in task_class_list:
                mess_id = message_dict.get(r.task_id)
                detail_list.append({
                    "message_id": mess_id,
                    "unit_class_id": r.unit_class_id,
                    "student_ids": r.student_id
                })
            db.local_com.message_class.bulk_create(detail_list, ignore=True)
            print "import message_class", len(detail_list)

    def start(self):
        # 清记录
        print ' 893 s'

        # 初中英语错题集
        db.local_yingyu.execute("truncate yy2_wrong_title_set")
        self.import_yy2_wrong_title_test()

        # 用户教材记录
        db.local_com.execute("truncate user_book")
        self.import_user_book()

        # 作业记录 和 作业班级记录
        db.local_com.execute("truncate message")
        self.import_message()
        db.local_com.execute("truncate message_class")
        self.import_message_class()

if __name__ == '__main__':
    print datetime.datetime.now()
    hnworker = HNWorker()
    st = time.time()
    hnworker.start()
    print 'took:', time.time() - st
    print datetime.datetime.now()