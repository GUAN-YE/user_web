#coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import time
import pymysql
from db import Hub



LOCAL_HOST = '192.168.0.113'
# LOCAL_HOST = '192.168.7.250'

# LOCAL_HOST = '116.255.220.112'
LOCAL_USER = 'duzuyong'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'


HN_HOST = '192.168.0.112'
# HN_HOST = '116.255.220.112'
HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

JX_HOST = 'rm-2zeso7flj7kkik72r.mysql.rds.aliyuncs.com'
JX_USER = 'jx_tbkt_db'
JX_PASSWORD = 'fPhTisS3DvTZZgD'

db = Hub(pymysql)
db.add_pool('local_ketang',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 河南大网老库
db.add_pool('hn_ketang',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)



def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        now = int(time.mktime(t))
        if now < 0:
            now = 0
        return now
    except:
        return 0



class HNWorker:
    """
    河南导入类
    """
    def __init__(self):
        print 'init ok.'

    def import_mobile_subject_detail(self):
        """"""
        minid = 0
        psize = 2000
        while 1:
            sql = """
                SELECT id,phone_number,code,UNIX_TIMESTAMP(add_date) add_date,
                 UNIX_TIMESTAMP(open_date) open_date, UNIX_TIMESTAMP(cancel_date) cancel_date,
                status,ftp_status,ftp_num,UNIX_TIMESTAMP(ftp_date) ftp_date,is_fee,fee_date,
                priority,add_user_type,add_username,ecid,sign_flag,new_ecid,fee_type,is_remind,
                add_user_id,sp_number FROM ketang.mobile_subject WHERE  id > %s ORDER BY id  LIMIT %s;
                 """ % (minid, psize)
            recode = db.hn_ketang.fetchall_dict(sql)
            if not recode:
                break
            minid = recode[-1].id
            detail_list = []
            subject_dict = {"A": 2,
                            "B": 3,
                            "C": 4,
                            "D": 9,
                            "E": 5,
                            "J": 2,
                            "K": 3,
                            "L": 4,
                            "M": 9,
                            "N": 5,
                            "U": 0,
                            "V": 0}
            for r in recode:
                if r.code not in ("A", "B", "C", "D", "E", "J", "K", "L", "M", "N", "U", "V"):
                    continue
                detail_list.append({
                    "id": r.id,
                    "phone_number": r.phone_number,
                    "subject_id": subject_dict[r.code],
                    "code": r.code,
                    "add_date": r.add_date,
                    "open_date": r.open_date if r.open_date else 0,
                    "cancel_date": r.cancel_date if r.cancel_date else 0,
                    "status": r.status,
                    "ftp_status": r.ftp_status,
                    "ftp_num": r.ftp_num,
                    "ftp_date": r.ftp_date if r.ftp_date else 0,
                    "is_fee": r.is_fee,
                    "fee_date": r.fee_date,
                    "priority": r.priority,
                    "add_user_type": r.add_user_type,
                    "add_username": r.add_username,
                    "ecid": r.ecid,
                    "sign_flag": r.sign_flag,
                    "new_ecid": r.new_ecid,
                    "fee_type": r.fee_type,
                    "is_remind": r.is_remind,
                    "add_user_id": r.add_user_id,
                    "sp_number": r.sp_number
                })
            db.local_ketang.mobile_subject_detail_hn.bulk_create(detail_list, ignore=True)
            print "import mobile_subject_detail_hn", len(detail_list), minid

    def start(self):
        # 清记录 用时1081 秒
        print 'start henan worker'
        # 奥数
        db.local_ketang.execute("truncate tbkt_ketang.mobile_subject_detail_hn")
        self.import_mobile_subject_detail()


if __name__ == '__main__':

    print datetime.datetime.now()
    hnworker = HNWorker()
    st = time.time()
    hnworker.start()
    print 'use time:', time.time() - st
    print datetime.datetime.now()
