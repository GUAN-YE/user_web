#coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import time
import random
import hashlib
import base64
# import MySQLdb
import pymysql
from db import Hub
import json



LOCAL_HOST = '192.168.0.111'
# LOCAL_HOST = '116.255.220.111'

LOCAL_USER = 'duzuyong'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'


HN_HOST = '192.168.0.114'
# HN_HOST = '116.255.220.114'
HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

db = Hub(pymysql)
# 本地新库

db.add_pool('local_ketang',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)

db.add_pool('local_com',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_com',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)

def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        now = int(time.mktime(t))
        if now < 0:
            now = 0
        return now
    except:
        return 0

class HNWorker:
    """
    河南导入类
    """
    def __init__(self):
        self.provinced = {} # {旧地市ID: 新地市ID}
        self.schoold = {} # {旧学校ID: 新学校ID}
        self.classd = {} # {旧班级ID: 新班级ID}

        print 'init ok.'

    def import_table(self, localtable, remotetable, converter={}, callback=None):
        """
        :param localtable: 目标db表(QuerySet)
        :param remotetable: 来源db表(QuerySet)
        :param converter: {'字段名':转换类型('user_id'转为新用户ID, 'unixtime'转为时间戳, 'ignore':忽略该字段, ...)}
        :param callback: 过滤器函数
        """
        minid = 0
        psize = 2000
        while 1:
            rows = remotetable.filter(id__gt=minid)[:psize]
            if not rows:
                break
            minid = rows[-1].id
            details = []
            for r in rows:
                if callback and callable(callback):
                    r = callback(r)
                for fieldname, type in converter.iteritems():
                    if type == 'user_id_strict':
                        pass
                    elif type == 'user_id':
                        pass
                    elif type == 'unixtime':
                        r[fieldname] = unix_timestamp(r[fieldname])
                    elif type == 'ignore':
                        r.pop(fieldname, None)
                if r.has_key('update_date') and not r.update_date:
                    r.update_date = 0
                details.append(r)
            localtable.bulk_create(details, ignore=True)
            print "import table %s: %s %s" % (localtable.table_name, minid, len(details))
        print "import table %s over" % localtable.table_name

    def start(self):
        # 清记录 用时 10741 秒
        print 'start henan worker '

        self.import_table(db.local_com.school_unit_class_20170827, db.local_com.school_unit_class)
        self.import_table(db.local_com.school_unit_class_copy, db.local_com.school_unit_class)

        self.import_table(db.local_ketang.mobile_order_region_20170827, db.local_ketang.mobile_order_region)


if __name__ == '__main__':

    print datetime.datetime.now()
    hnworker = HNWorker()
    st = time.time()
    hnworker.start()
    print 'use time:', time.time() - st
    print datetime.datetime.now()
