#coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import logging
import time
import random
import hashlib
import base64
import pymysql
from db import Hub
import json

LOCAL_HOST = '192.168.0.76'
# LOCAL_HOST = '116.255.220.112'
LOCAL_USER = 'duzuyong'
LOCAL_USER = 'bannei'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'
LOCAL_PASSWORD = 'bannei60279052'


# HN_HOST = '192.168.7.250'
HN_HOST = '116.255.220.112'
HN_HOST = '192.168.0.112'

HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

# JX_HOST = 'rm-2zeso7flj7kkik72r.mysql.rds.aliyuncs.com'
# JX_USER = 'jx_tbkt_db'
# JX_PASSWORD = 'fPhTisS3DvTZZgD'

db = Hub(pymysql)
# 本地新库
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 河南大网老库
db.add_pool('hn_tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)


def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        return int(time.mktime(t))
    except:
        return 0

def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


def encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    try:
        hash = hashlib.sha1(salt + password).hexdigest()
    except:
        logging.info('encode_password: %s' % password)
        # print 'encode_password:', password
        return ''
    return "sha1$%s$%s" % (salt, hash)

def encode_plain_password(password):
    try:
        return base64.b64encode(password)
    except:
        return ''


class HNWorker:
    """
    河南导入类
    """
    def __init__(self):
        print 'init ok.'

    def import_sx_wrong_set(self):
        sx_wrong_title_set_dict = db.local_shuxue.sx_wrong_title_set_dict.last()
        sx_wrong_title_set_dict_id = sx_wrong_title_set_dict.id if sx_wrong_title_set_dict else 1
        sql1 = """
            SELECT DISTINCT user_id from tbkt.u_sx_wrong_title_set
            """
        users = db.hn_tbkt.fetchall_dict(sql1)
        for user in users:
            sql = """
                    SELECT id,user_id,catalog_id,test_id,question_id,from_type,UNIX_TIMESTAMP(add_time) add_time
                    from tbkt.u_sx_wrong_title_set
                     where user_id= %s group by catalog_id;
                   """ % user.user_id
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            wrong_details = []
            catalog_ids = []
            catalog_ids = [d.catalog_id for d in tlist if d.catalog_id not in catalog_ids]
            from_types, from_details = [], []
            for c in catalog_ids:
                text = []
                for t in tlist:
                    if t.catalog_id == c:
                        user_id = t.user_id
                        if t.from_type not in from_types:
                            sx_wrong_title_set_dict_id += 1
                            from_details.append({
                                "id": sx_wrong_title_set_dict_id,
                                "user_id": user_id,
                                "catalog_id": t.catalog_id,
                                "name": t.from_type,
                                "add_time": t.add_time
                            })
                            from_types.append(t.from_type)
                        text.append({"qid": t.question_id, "ftype": sx_wrong_title_set_dict_id})
                text = json.dumps(text)
                if len(text) > 9000:
                    logging.log("> 9000 user %s len %s" % (user.user_id, len(text)))
                wrong_details.append({
                    "user_id": user_id,
                    "catalog_id": c,
                    "text": text,
                })

            print "import sx_wrong_title_set_dict ", len(from_details)
            db.local_shuxue.sx_wrong_title_set_dict.bulk_create(from_details, ignore=True)
            print "import sx_wrong_title_set ", len(wrong_details)
            db.local_shuxue.sx_wrong_title_set.bulk_create(wrong_details, ignore=True)
        print "sx_wrong_title_set over"

    def import_sx2_wrong_set(self):
        sx2_wrong_title_set_dict = db.local_shuxue.sx2_wrong_title_set_dict.last()
        sx2_wrong_title_set_dict_id = sx2_wrong_title_set_dict.id if sx2_wrong_title_set_dict else 1
        sql1 = """
               SELECT DISTINCT user_id from tbkt.u_sx2_wrong_title_set
               """
        users = db.hn_tbkt.fetchall_dict(sql1)
        for user in users:
            sql = """
                       SELECT id,user_id,catalog_id,test_id,question_id,from_type,UNIX_TIMESTAMP(add_time) add_time
                       from tbkt.u_sx2_wrong_title_set
                        where user_id= %s group by catalog_id;
                      """ % user.user_id
            tlist = db.hn_tbkt.fetchall_dict(sql)
            if not tlist:
                break
            wrong_details = []
            catalog_ids = []
            catalog_ids = [d.catalog_id for d in tlist if d.catalog_id not in catalog_ids]
            from_types, from_details = [], []
            for c in catalog_ids:
                text = []
                for t in tlist:
                    if t.catalog_id == c:
                        user_id = t.user_id
                        if t.from_type not in from_types:
                            sx2_wrong_title_set_dict_id += 1
                            from_details.append({
                                "id": sx2_wrong_title_set_dict_id,
                                "user_id": user_id,
                                "catalog_id": t.catalog_id,
                                "name": t.from_type,
                                "add_time": t.add_time
                            })
                            from_types.append(t.from_type)
                        text.append({"qid": t.question_id, "ftype": sx2_wrong_title_set_dict_id})
                text = json.dumps(text)
                if len(text) > 9000:
                    logging.log("> 9000 user %s len %s" % (user.user_id, len(text)))
                wrong_details.append({
                    "user_id": user_id,
                    "catalog_id": c,
                    "text": text,
                })

            print "import sx2_wrong_title_set_dict ", len(from_details)
            db.local_shuxue.sx2_wrong_title_set_dict.bulk_create(from_details, ignore=True)
            print "import sx2_wrong_title_set ", len(wrong_details)
            db.local_shuxue.sx2_wrong_title_set.bulk_create(wrong_details, ignore=True)
        print "sx2_wrong_title_set over"
    def start(self):
        # 清记录
        print 'start henan worker  3011，，sx2  14700'
        st = time.time()
        # # # 导错题集
        # db.local_shuxue.execute("truncate sx_wrong_title_set")
        # db.local_shuxue.execute("truncate sx_wrong_title_set_dict")
        # self.import_sx_wrong_set()
        # print 'took:', time.time() - st
        st1 = time.time()

        db.local_shuxue.execute("truncate sx2_wrong_title_set")
        db.local_shuxue.execute("truncate sx2_wrong_title_set_dict")
        self.import_sx2_wrong_set()
        print 'took:', time.time() - st1


def log_config():
    """配置log输出"""
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s %(filename)s[line:%(lineno)d] %(funcName)s %(message)s',
                        datefmt='%a,%d %b %Y %H:%M:%S',
                        filename='import_data_hn_test.log',
                        filemode='w+')

    logging.info('import_data_hn_test begin log info')

if __name__ == '__main__':
    log_config()
    hnworker = HNWorker()
    hnworker.start()
