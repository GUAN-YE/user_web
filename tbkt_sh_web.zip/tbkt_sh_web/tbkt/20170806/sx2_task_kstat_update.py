#coding: utf-8
"""导河南2017新表数据

school_unit_class.path暂时没导
auth_user.dept_id暂时没导
"""
import datetime
import time
import random
import hashlib
import base64
# import MySQLdb
from collections import defaultdict

import pymysql
from db import Hub
import json

LOCAL_HOST = '116.255.220.112'
LOCAL_HOST = '192.168.0.76'
LOCAL_HOST = '122.114.40.76'

LOCAL_USER = 'duzuyong'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'
PORT = 3306

HN_HOST = '116.255.220.112'
# HN_HOST = '192.168.0.112'
HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

db = Hub(pymysql)
# 本地库
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=PORT, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)

# 河南大网老库
db.add_pool('hn_ziyuan',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ziyuan_new',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_shuxue',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)


def update_k_stat():
    minid = 0
    psize = 50
    while 1:
        task_ids = db.hn_shuxue.sx2_task.select('id').filter(status=1, id__gt=minid).flat('id')[:psize]
        if not task_ids:
            break
        minid = task_ids[-1]

        task_test = db.hn_shuxue.sx2_task_test.select('user_id', 'task_id').filter(task_id__in=task_ids, status=1)[:]
        if not task_test:
            continue
        task_ids = [i.task_id for i in task_test if i.task_id]
        user_ids = [i.user_id for i in task_test if i.user_id]
        sql = """
        select user_id, weak_knowledge weak, task_id from sx2_task_test_detail where user_id in (%s) and task_id in (%s) 
        """ % (join(user_ids), join(task_ids))
        detail = db.hn_shuxue.fetchall_dict(sql)
        stat = db.local_shuxue.sx2_task_kstat.select('task_id', 'knowledge_id').filter(task_id__in=task_ids)[:]

        stat_map = defaultdict(list)
        for i in stat:
            stat_map[i.task_id].append(i.knowledge_id)

        detail_map = defaultdict(list)

        for i in detail:
            if len(i.weak) < 2 or not is_json(i.weak):
                # 格式错误 或者 没有数据
                continue
            detail_map[i.task_id].append(i)
        update_args = []
        task_map = {}
        for task_id, details in detail_map.iteritems():
            for d in details:
                txt = json.loads(d.weak)
                kids = stat_map.get(task_id, [])
                for k in kids:
                    r = task_map.get((task_id, k))
                    # print r
                    if not r:
                        r = task_map[(task_id, k)] = {'f': set(), 'w': set()}
                    for t in txt:
                        kid = t.get('kid', None)
                        if kid == k:
                            r.get('w').add(d.user_id)
                    r.get('f').add(d.user_id)
        for (task_id, kid), d in task_map.iteritems():
            finish = d.get('f', [])
            wrong = d.get('w', [])
            update_args.append((join(list(finish)), join(list(wrong)), kid, task_id))
        if update_args:
            sql = """
            update sx2_task_kstat set finish_student = %s, wrong_student = %s where knowledge_id = %s and task_id = %s
            """
            db.local_shuxue.execute_many(sql, update_args)
            print 'update kstat, len=', len(update_args)
    print 'update finish kstat'


def is_json(d):
    # 是否为json格式
    if not isinstance(d, (int, long)):
        try:
            json.loads(d)
        except ValueError:
            return False
        return True
    else:
        return False


def join(o):
    if isinstance(o, (list, tuple)):
        return ','.join(str(i) for i in o)
    return str(o)


if __name__ == '__main__':
    update_k_stat()
