#coding: utf-8
"""导河南2017新表数据

"""
import time
import pymysql
from db import Hub
from collections import OrderedDict



LOCAL_HOST = '192.168.0.113'
# LOCAL_HOST = '116.255.220.112'
LOCAL_USER = 'duzuyong'
LOCAL_USER = 'bannei'
LOCAL_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'
LOCAL_PASSWORD = 'bannei60279052'


# HN_HOST = '192.168.7.250'
HN_HOST = '116.255.220.112'
HN_HOST = '192.168.0.112'

HN_USER = 'duzuyong'
HN_PASSWORD = 'ohStjN6DK$XqBAfhGzdz'

JX_HOST = 'rm-2zeso7flj7kkik72r.mysql.rds.aliyuncs.com'
JX_USER = 'jx_tbkt_db'
JX_PASSWORD = 'fPhTisS3DvTZZgD'

db = Hub(pymysql)
# 本地新库
db.add_pool('local_user',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_user',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_ketang',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_com',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_com',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_shuxue',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_shuxue',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('local_yingyu',
    host=LOCAL_HOST, port=3306, user=LOCAL_USER, passwd=LOCAL_PASSWORD, db='tbkt_yingyu',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 河南大网老库
db.add_pool('hn_tbkt',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_tbktweb',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='tbkt_web',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_ziyuan',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ziyuan_new',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
db.add_pool('hn_ketang',
    host=HN_HOST, port=3306, user=HN_USER, passwd=HN_PASSWORD, db='ketang',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)
# 江西大网库
db.add_pool('jx_tbkt',
    host=JX_HOST, port=3306, user=JX_USER, passwd=JX_PASSWORD, db='jxtbkt',
    charset='utf8', autocommit=True, pool_size=8, wait_timeout=29
)


def unix_timestamp(dt):
    """datetime或date转时间戳"""
    if not dt:
        return 0
    t = dt.timetuple()
    try:
        now = int(time.mktime(t))
        if now < 0:
            now = 0
        return now
    except:
        return 0

class Worker:
    def get_ck(self):
        """获得所有大小章节下的知识点"""
        sql = """
        select c.book_id, r.knowledge_id, c.path from ziyuan_new.sx_text_book_catalog_relate_knowledge r
        inner join ziyuan_new.sx_text_book_catalog c on c.id=r.catalog_id
        """
        rows = db.hn_ziyuan.fetchall_dict(sql)
        # rows = self.zy.fetchall(sql)
        ckmap = OrderedDict() # {cid:[kid]}
        cbmap = {} # {cid:book_id}
        # print len(rows)
        for obj in rows:
            cids = map(int, obj["path"][1:-1].split('|'))
            for cid in cids:
                kids = ckmap.get(cid, [])
                kids.append(obj["knowledge_id"])
                ckmap[cid] = kids
                cbmap[cid] = obj["book_id"]
        # 去重
        for cid, kids in ckmap.items():
            unikids = list(set(kids))
            if len(unikids) != len(kids):
                ckmap[cid] = unikids
        return ckmap, cbmap

    def get_kq(self, kids):
        """
        获取某一知识点范围的题目
        :return: {kid: qids}
        """
        kids_s = ','.join(str(i) for i in kids)
        sql = """
       select DISTINCT k.knowledge_id, q.id from ziyuan_new.sx_ask_relate_knowledge_new k
       inner join ziyuan_new.sx_question q on k.question_id = q.id and k.knowledge_id in (%s) and q.display_new = 1;
        """ % kids_s
        rows = db.hn_ziyuan.fetchall_dict(sql)

        # rows = self.zy.fetchall(sql)
        out = {}
        for obj in rows:
            row = out.get(obj["knowledge_id"]) or []
            row.append(obj["id"])
            out[obj["knowledge_id"]] = row
        for kid, qids in out.items():
            uniqids = list(set(qids))
            if len(uniqids) != len(qids):
                out[kid] = uniqids
        return out


    def start(self):
        print "start  442秒 17000条左右"
        starttime = time.time()
        # self.default.execute("truncate tbkt_shuxue.sx_knowledge_question")
        db.local_shuxue.execute("truncate tbkt_shuxue.sx_knowledge_question")
        ckmap, cbmap = self.get_ck()
        i = 0
        psize = 1000
        detail = []
        for cid, kids in ckmap.iteritems():
            kq = self.get_kq(kids)
            book_id = cbmap.get(cid)
            for kid in kids:
                qids = kq.get(kid) or []
                qids_s = ','.join(str(i) for i in qids)
                nowt = int(time.time())
                detail.append({"book_id": book_id,
                               "catalog_id": cid,
                               "knowledge_id": kid,
                               "question_ids": qids_s,
                               "add_time": nowt})
                # 每100条写一次数据库
                if len(detail) >= psize:
                    i += psize
                    print i
                    db.local_shuxue.sx_knowledge_question.bulk_create(detail, ignore=True)
                    detail = []
        db.local_shuxue.sx_knowledge_question.bulk_create(detail, ignore=True)
        print (time.time()-starttime)
        print 'finish!'

if __name__ == '__main__':
    worker = Worker()
    worker.start()