# coding=utf-8
import datetime, os, time, sys

# 设置工作目录
sys_base_path = os.path.abspath(__file__)
print os.path.normpath(os.path.join(sys_base_path, '../..'))
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
from twisted.internet import reactor
from twisted.application import service
from config import *
from sms.SendEmail import sendMail


def batch_email():
    """
    功能说明：批量开通群发邮件
    -------------------------------------------------------------
    修改人                    用户数据导出
    -------------------------------------------------------------
    周培林                    2015－05－06
    """  
    while True:
        print '开始处理',datetime.datetime.now()
        try:
            now = datetime.datetime.now()
            if now.hour in (8, 9, 10):
                # 早上8点执行
                pass
            else:
                print '早上8点才执行，现在是%s' % now
                time.sleep(60*60)
                continue

            conn = get_ketang_conn()
            cur = conn.cursor()

            sql = """select id, email_user, email_status, start_date FROM tbkt_ketang.mp_batch_request where batch_type=1 and email_status=0 and DATE_FORMAT(FROM_UNIXTIME(add_date), '%Y-%m-%d')=DATE_FORMAT(DATE_ADD(NOW(),INTERVAL -1 DAY), '%Y-%m-%d')"""
            print sql
            cur.execute(sql)
            bath_data_list = cur.fetchall()

            if not bath_data_list:
                print '群发邮件 没有需要处理的数据'
                time.sleep(5)
                continue
            # print '登陆前一天人数'
            # sql = """update tbkt_ketang.mp_batch_detail d,tbkt_user.auth_user s set d.subject_id=s.id where d.phone_number=s.phone
            # and DATE_FORMAT(FROM_UNIXTIME(d.add_time), '%Y-%m-%d')=DATE_FORMAT(DATE_ADD(NOW(),INTERVAL -1 DAY), '%Y-%m-%d')
            # and DATE_FORMAT(FROM_UNIXTIME(s.last_login_time), '%Y-%m-%d')=DATE_FORMAT(DATE_ADD(NOW(),INTERVAL -1 DAY), '%Y-%m-%d');"""
            # cur.execute(sql)
            # conn.commit()
            # print '登陆前一天人数 成功'
            batch_list = []     # 存储结果. 例如 {['batch_id':1474, 'email_user':xxx@tbkt.cn, 'all_num':17, 'success_num':5, 'login_num':0] ......}
            print 'bath_data_list', bath_data_list
            for obj in bath_data_list:
                sender = {}
                sender['batch_id'] = obj[0]         
                sender['email_user'] = obj[1]
                sender['start_date'] = obj[3]  # 批处理开始执行时间
                sql = """
                  select COUNT(DISTINCT phone_number, subject_id) as num from tbkt_ketang.mp_batch_detail where batch_id=%(id)s
                """ % {'id': obj[0]}
                print sql
                cur.execute(sql)
                sender['all_num'] = cur.fetchone()[0]   # 总共需要开通数
                sql = """
                    select COUNT(DISTINCT s.phone_number, s.code) as num from tbkt_ketang.mp_batch_detail d INNER JOIN tbkt_ketang.mobile_subject_detail_hn s
                    on d.phone_number=s.phone_number and d.subject_id=s.subject_id and d.batch_id=%(id)s and s.status=2 and s.open_date>='%(start_date)s'
                """ % {'id': obj[0], 'start_date': sender['start_date']}
                print sql
                cur.execute(sql)
                sender['success_num'] = cur.fetchone()[0]         # 本次导入后开通数
                sql = """
                        SELECT count(DISTINCT phone_number, subject_id) as num FROM tbkt_ketang.mp_batch_detail mbd WHERE batch_id=%(id)s
                    """ % {'id': obj[0]}
                print sql
                cur.execute(sql)
                sender['login_num'] = cur.fetchone()[0]           # 从表总登陆数
                sql = """
                    select COUNT(DISTINCT s.phone_number, s.code) as num from tbkt_ketang.mp_batch_detail d INNER JOIN tbkt_ketang.mobile_subject_detail_hn s
                    on d.phone_number=s.phone_number and d.subject_id=s.subject_id and d.batch_id=%(id)s and s.status=2 and s.open_date<'%(start_date)s'
                """ % {'id': obj[0], 'start_date': sender['start_date']}
                print sql
                cur.execute(sql)
                sender['old_open_num'] = cur.fetchone()[0]        # 本次导入前开通数
                print sender
                open_percent = 0 if sender['success_num'] == 0 else round(float(sender['success_num'])/sender['all_num'], 2)*100
                batch_list.append(sender)
                sql = """UPDATE tbkt_ketang.mp_batch_request SET email_status = 1, detail_num=%s,open_num=%s,login_num=%s,old_open_num=%s, open_percent=%s where id = %s """ % (sender['all_num'], sender['success_num'], sender['login_num'], sender['old_open_num'], open_percent, obj[0])
                print sql
                cur.execute(sql)
                conn.commit()
            print '获取数据成功！'
            time.sleep(2)
            print '有<%s>个需要发送邮件的批处理！' % len(batch_list)
            i = 1
            for obj in batch_list:
                sql = "select s.name from tbkt_com.school s INNER JOIN tbkt_ketang.mp_batch_request b on s.id=b.sch_id where b.id=%s limit 1" % obj['batch_id']
                cur.execute(sql)
                sch_one = cur.fetchone()
                print obj
                print '开始处理第<%s>个' % i
                subject = '批处理 %s 处理结果' % obj['batch_id']
                if sch_one:
                    subject += ' 学校:%s' % sch_one[0]
                success_rate = 0 if obj['success_num'] == 0 else round(float(obj['success_num'])/obj['all_num'],3)*100
                login_rate = 0 if obj['login_num'] == 0 else round(float(obj['login_num'])/obj['all_num'], 3)*100
                content = '<b>批量开通（id=%(batch_id)s）处理结果：</b><br/>总记录数：%(all_num)s<br/>开通数：%(success_num)s，开通比：%(success_rate)s%%<br/>登陆数：%(login_num)s，登陆比：%(login_rate)s%%' % {'batch_id':obj['batch_id'], 'success_rate': success_rate, 'login_rate': login_rate, 'all_num': obj['all_num'], 'success_num': obj['success_num'], 'login_num': obj['login_num']}
                address_list = [] 
                address_list.append(obj['email_user'])
                # address_list.append('duzuyong@tbkt.cn')
                # address_list.append('chenlong@tbkt.cn')
                # 调用发送邮件函数
                sendMail(address_list, subject, content, 2)
                sql = """UPDATE tbkt_ketang.mp_batch_request SET email_status = 2 where id = %s """ % obj['batch_id']
                cur.execute(sql)
                conn.commit()
                print '第<%s>个邮件发送结束<%s>' % (i, address_list)
                i += 1
            print '批处理邮件提醒结束'
            time.sleep(10)   
        except Exception, e:
            print e
            time.sleep(10)


def main():
    reactor.callInThread(batch_email)
    # batch_email()


if __name__ == "__main__":
    print 'main'
    main()

elif __name__ == '__builtin__':
    print '__builtin__'
    main()
    application = service.Application('client_send_batch_email')