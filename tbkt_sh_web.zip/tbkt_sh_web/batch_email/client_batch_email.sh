#! /usr/bin/env sh  
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/batch_email.py
logfile=/var/log/tbkt_cms_client_batch_email.log
case $1 in  
    start)  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/tbkt_cms_client_batch_email.pid --logfile=$logfile
        ;;  
    stop)  
        kill -9 `cat /var/run/tbkt_cms_client_batch_email.pid`
        ;;  
    restart)  
        kill -9 `cat /var/run/tbkt_cms_client_batch_email.pid`
        sleep 1  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/tbkt_cms_client_batch_email.pid --logfile=$logfile
        ;;  
    log)  
        tail -f $logfile
        ;;  
    *)  
        echo "Usage: ./client_batch_email.sh start | stop | restart | log"
        ;;  
esac  
