#! /usr/bin/env sh
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/province_tea_data.py
logfile=/var/log/province_tea_data.log
case $1 in
    start)
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/province_tea_data1.pid --logfile=$logfile
        ;;
    stop)
        kill -9 `cat /var/run/province_tea_data1.pid`
        ;;
    restart)
        kill -9 `cat /var/run/province_tea_data1.pid`
        sleep 1
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/province_tea_data1.pid --logfile=$logfile
        ;;
    log)
        tail -f $logfile
        ;;
    *)
        echo "Usage: ./province_tea_data.sh start | stop | restart | log"
        ;;
esac