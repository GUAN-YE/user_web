# coding:utf-8
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


class SendMail(object):
    @staticmethod
    def send_mail(the_pattern):
        """发送邮件"""
        try:
            send_mail_type = 'smtp.exmail.qq.com'
            msg = MIMEMultipart()
            msg['Subject'] = u'使用质量统计报表'
            msg['From'] = "songguoyang@tbkt.cn"
            msg['To'] = the_pattern
            print "开始写入邮件"
            xls_part = MIMEText(open('weekly.xls', 'rb').read(), 'xls', 'utf-8')
            xls_part["Content-Type"] = 'application/octet-stream'
            xls_part["Content-Disposition"] = 'attachment; filename="weekly.xls"'
            msg.attach(xls_part)
            try:
                # 发邮件采用默认端口25,不然会报错
                print "开始发送"
                send_server = smtplib.SMTP_SSL(send_mail_type, 465)
                send_server.ehlo()
                send_server.login("songguoyang@tbkt.cn", "sgy19910205")
                send_server.sendmail("songguoyang@tbkt.cn", the_pattern, msg.as_string())
                send_server.quit()
                return "send_ok"
            except Exception as e:
                print "邮件发送失败:%s" % e
        except Exception as e:
            print e
