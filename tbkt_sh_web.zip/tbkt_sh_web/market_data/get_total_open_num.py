# coding:utf-8
# 获取各班级总订购数据,每日凌晨一点执行一次
import os
import sys
import time
import datetime
from retrying import retry
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
from twisted.internet import reactor
from twisted.application import service
# 引入配置文件
from config import *
city_list = ['410100', '410200', '410300', '410400', '410500', '410600', '410700', '410800', '410900', '411000', '411100', '411200', '411300', '411400', '411500', '411600', '411700', '419001']

@retry()
def execute(sql):
	"""
	执行sql的方法
	"""
	conn = get_ketang_conn()
	cur = conn.cursor()
	r = cur.execute(sql)
	conn.commit()
	cur.close()
	conn.close()
	return r

@retry()
def slave_fetchall(sql):
	'''
	从库数据查询方法
	'''
	conn = get_slave_conn()
	cur = conn.cursor()
	cur.execute(sql)
	rows = cur.fetchall()
	cur.close()
	conn.close()
	return rows


class GetTotalOpenNum(object):
	'''
	获取班级订购数据类方法
	'''
	@staticmethod
	def truncate_data():
		'''
		清空已经生成的开通数据
		'''
		sql = "TRUNCATE tbkt_ketang.mobile_open_num;"
		execute(sql)
	
	def get_data(self):
		'''
		开始获取班级订购数据
		:return:((city,county,school_id,unit_class_id,A_num,B_num,C_num,D_num,E_num),...)
		'''
		print "首先清空表中已存在的数据"
		self.truncate_data()
		# 禁用的数据不统计,毕业班和待分班级的统计,永久试用不统计
		for city in city_list:
			print "开始获取数据,city_id=:%s" % city
			sql = """SELECT
				t.city,t.county,t.school_id,t.unit_class_id,
				SUM(CASE WHEN t.`code`='A' THEN num ELSE 0 END) AS A,
				SUM(CASE WHEN t.`code`='B' THEN num ELSE 0 END) AS B,
				SUM(CASE WHEN t.`code`='C' THEN num ELSE 0 END) AS C,
				SUM(CASE WHEN t.`code`='D' THEN num ELSE 0 END) AS D,
				SUM(CASE WHEN t.`code`='E' THEN num ELSE 0 END) AS E
				FROM
				(SELECT
				p.city,p.county,p.school_id,p.unit_class_id,p.`code`,SUM(num) AS num
				FROM
				(SELECT
				r.city,r.county,r.school_id,r.unit_class_id,b.phone,s.`code`,COUNT(DISTINCT s.id) AS num
				FROM tbkt_ketang.mobile_order_region r INNER JOIN tbkt_user.auth_user b ON r.user_id=b.id
				AND b.type=1 AND b.status<>2 AND r.city='%s'
				INNER JOIN tbkt_ketang.mobile_subject_detail_hn s ON b.phone=s.phone_number AND s.`code` IN ('A','B','C','D','E')
				AND s.`status` IN (2,3)
				GROUP BY b.phone,s.`code`) AS p GROUP BY p.city,p.county,p.school_id,p.unit_class_id,p.`code`) AS t
				GROUP BY t.city,t.county,t.school_id,t.unit_class_id;""" % city
			city_data = slave_fetchall(sql)
			print "开始写入数据,city_id=:%s" % city
			self.insert_total_data(city_data)

	@staticmethod
	def insert_total_data(data):
		'''
		写入教师班级开通数据,每次写入1000行
		:param data: ((city,county,school_id,unit_class_id,A_num,B_num,C_num,D_num,E_num),...)
		'''
		data_list = data
		sql = """INSERT INTO tbkt_ketang.mobile_open_num(province,city,county,school_id,unit_class_id,2_num,3_num,4_num,9_num,5_num) VALUES """
		num, num1 = 0, 0
		for obj in data_list:
			num += 1
			num1 += 1
			if len(data_list) == num1 or num >= 1000:
				sql += """(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""" % (int(410000),
						int(obj[0]) if obj[0] else 0, int(obj[1]) if obj[1] else 0, int(obj[2]) if obj[2] else 0,
						int(obj[3]) if obj[3] else 0, int(obj[4]) if obj[4] else 0, int(obj[5]) if obj[5] else 0,
						int(obj[6]) if obj[6] else 0, int(obj[7]) if obj[7] else 0, int(obj[8]) if obj[8] else 0)
				
				execute(sql)
				sql = """INSERT INTO tbkt_ketang.mobile_open_num(province,city,county,school_id,unit_class_id,2_num,3_num,4_num,9_num,5_num) VALUES """
				num = 0
			else:
				sql += """(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s),""" % (int(410000),
				int(obj[0]) if obj[0] else 0, int(obj[1]) if obj[1] else 0, int(obj[2]) if obj[2] else 0,
				int(obj[3]) if obj[3] else 0, int(obj[4]) if obj[4] else 0, int(obj[5]) if obj[5] else 0,
				int(obj[6]) if obj[6] else 0, int(obj[7]) if obj[7] else 0, int(obj[8]) if obj[8] else 0)


def start():
	while True:
		if datetime.datetime.now().hour == 1:
			print "开始执行程序"
			t1 = time.time()
			c = GetTotalOpenNum()
			c.get_data()
			print "程序耗时:", time.time() - t1
			print "程序执行结束,休眠1个小时继续"
			time.sleep(60*60)
		else:
			print "程序不在执行时间,休眠1个小时继续"
			time.sleep(60*60)
			
		
if __name__ == "__main__":
	print "程序本地执行,main()"
	start()
elif __name__ == "__builtin__":
	print "程序服务器执行,builtin()"
	reactor.callInThread(start)
	application = service.Application('get_total_open_num')