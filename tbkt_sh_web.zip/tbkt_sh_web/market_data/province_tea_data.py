# coding:utf-8
# 功能:每日凌晨获取一次全省教师数据,并清空前一天的数据
# --------------------------------------------
# 添加人:宋国洋
# --------------------------------------------
# 添加时间:2016-12-01
import os
import datetime
import sys
from retrying import retry
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')

from twisted.internet import reactor
from twisted.application import service
# 引入数据库配置文件
from config import *
city_list = ['410100', '410200', '410300', '410400', '410500', '410600', '410700', '410800', '410900', '411000', '411100', '411200', '411300', '411400', '411500', '411600', '411700', '419001']


@retry()
def execute(sql):
    conn = get_ketang_conn()
    cur = conn.cursor()
    r = cur.execute(sql)
    conn.commit()
    cur.close()
    conn.close()
    return r


@retry()
def slave_fetchall(sql):
    slave = get_slave_conn()
    cur = slave.cursor()
    cur.execute(sql)
    rows = cur.fetchall()
    cur.close()
    slave.close()
    return rows


class GetProTea(object):
    @staticmethod
    def truncate_yes_data():
        """功能:清空所有教师数据"""
        print "开始清空教师数据"
        sql_ = "TRUNCATE tbkt_ketang.province_tea_data"
        execute(sql_)

    @staticmethod
    def get_tea_data():
        """功能:获取教师数据,并重新写入"""
        try:
            for city in city_list:
                print "开始获取所有教师数据, city_id=:%s" % city
                sql = """SELECT
                t.city,t.county,t.ecid,t.school_id,t.school_name,t.unit_class_id,suc.unit_name,t.user_id,
                t.real_name,t.phone,t.sid,t.`status`,
                CASE WHEN t.mub_status=2 THEN 1 ELSE 0 END AS is_forbid,
                CASE WHEN bp.id>0 THEN 1 ELSE 0 END AS is_black
                FROM
                (SELECT
                mor.city,mor.county,ms.ecid,mor.school_id,mor.school_name,mor.unit_class_id,
                mub.id AS user_id,mub.real_name,mub.phone,mub.`status` AS mub_status,
                mub.sid,ms.`status`,ms.id
                FROM
                tbkt_user.auth_user mub
                INNER JOIN tbkt_ketang.mobile_order_region mor ON mub.id=mor.user_id AND mor.city='%s'
                AND mub.sid IN (2,3,4,5,9) AND mub.type=3 AND mor.unit_class_id>0 AND mor.is_update=0
                INNER JOIN
                tbkt_ketang.mobile_subject_detail_hn ms ON mub.phone=ms.phone_number
                AND ms.`code` IN ('J', 'K', 'L', 'M', 'N')
                GROUP BY mor.school_id,mor.unit_class_id,mub.phone,mub.sid,ms.`code`,ms.id 
                ORDER BY ms.id DESC) AS t
                INNER JOIN tbkt_com.school_unit_class suc ON suc.id=t.unit_class_id
                LEFT JOIN tbkt_ketang.mobile_black_phone bp ON bp.phone=t.phone
                GROUP BY t.school_id,t.unit_class_id,t.phone,t.sid;""" % city
                data_tea = slave_fetchall(sql)
                print "开始批量写入数据, city_id=:%s" % city
                # 批量写入数据
                insert_sql = """INSERT INTO tbkt_ketang.province_tea_data(city,county,ecid,school_id,school_name,
                                unit_class_id,unit_name,user_id,user_name,phone_number,subject_id,status,is_forbid,is_black) VALUES """
                num, num1 = 0, 0
                for obj in data_tea:
                    num += 1
                    num1 += 1
                    if num > 1000 or len(data_tea) == num1:
                        insert_sql += """(%s, %s, %s, %s, '%s', %s, '%s', %s, '%s', %s, %s, %s, %s, %s);""" % \
                                      (obj[0] if obj[0] else 0, obj[1] if obj[1] else 0, obj[2] if obj[2] else 0, obj[3] if obj[3] else 0, str(obj[4]) if obj[4] else '', obj[5] if obj[5] else 0, str(obj[6]) if obj[6] else '', obj[7] if obj[7] else 0, str(obj[8]) if obj[8] else '', obj[9] if obj[9] else 0, obj[10] if obj[10] else 0, obj[11] if obj[11] else 0, obj[12] if obj[12] else 0, obj[13] if obj[13] else 0)
                        execute(insert_sql)
                        insert_sql = """INSERT INTO tbkt_ketang.province_tea_data(city,county,ecid,school_id,school_name,
                                        unit_class_id,unit_name,user_id,user_name,phone_number,subject_id,status,is_forbid,is_black) VALUES """
                        num = 0
                    else:
                        insert_sql += """(%s, %s, %s, %s, '%s', %s, '%s', %s, '%s', %s, %s, %s, %s, %s),""" % \
                                      (obj[0] if obj[0] else 0, obj[1] if obj[1] else 0, obj[2] if obj[2] else 0, obj[3] if obj[3] else 0, str(obj[4]) if obj[4] else '', obj[5] if obj[5] else 0, str(obj[6]) if obj[6] else '', obj[7] if obj[7] else 0, str(obj[8]) if obj[8] else '', obj[9] if obj[9] else 0, obj[10] if obj[10] else 0, obj[11] if obj[11] else 0, obj[12] if obj[12] else 0, obj[13] if obj[13] else 0)
        except Exception as e:
            print e


def start():
    while True:
        now = datetime.datetime.now()
        print "now:", now
        if now.hour == 2:
            do_create = GetProTea()
            print 'the process start:', datetime.datetime.now()
            t1 = time.time()
            do_create.truncate_yes_data()
            do_create.get_tea_data()
            print 'the_process_end:', time.time() - t1
            time.sleep(60*60)
        else:
            print 'time is not the night 1:00,sleep one hour go on'
            time.sleep(60 * 60)
            continue


if __name__ == "__main__":
    start()
elif __name__ == '__builtin__':
    print '__builtin__'
    reactor.callInThread(start)
    application = service.Application('task_service')