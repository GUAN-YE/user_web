#! /usr/bin/env sh
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/batch_send_mobile_quality.py
logfile=/var/log/batch_send_mobile_quality.log
case $1 in
    start)
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/batch_send_mobile_quality.pid --logfile=$logfile
        ;;
    stop)
        kill -9 `cat /var/run/batch_send_mobile_quality.pid` && rm -f /var/run/batch_send_mobile_quality.pid
        ;;
    restart)
        kill -9 `cat /var/run/batch_send_mobile_quality.pid` && rm -f /var/run/batch_send_mobile_quality.pid
        sleep 1
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/batch_send_mobile_quality.pid --logfile=$logfile
        ;;
    log)
        tail -f $logfile
        ;;
    *)
        echo "Usage: ./batch_send_mobile_quality.sh start | stop | restart | log"
        ;;
esac