# coding: utf-8
"""
学生数据汇总
-----------------------------
每天一点写入用户在前一天的的相关数据
"""
import os
import datetime
import sys
import pandas as pd
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
from twisted.internet import reactor
from twisted.application import service
# 引入数据库配置文件
from config import *


class GetStuPro(object):
    def __init__(self):
        if __name__ == "__main__":
            self.conn = get_ketang_conn()
            self.slave = get_slave_conn()
            self.begin_date = datetime.date.today() - datetime.timedelta(days=1)
            self.end_date = datetime.date.today()
        elif __name__ == "__builtin__":
            self.conn = get_ketang_conn()
            self.slave = get_slave_conn()
            self.begin_date = datetime.date.today() - datetime.timedelta(days=1)
            self.end_date = datetime.date.today()

    def execute(self, sql):
        cur = self.conn.cursor()
        r = cur.execute(sql)
        self.conn.commit()
        cur.close()
        self.conn.close()
        return r

    def slave_fetchall(self, sql):
        cur = self.slave.cursor()
        cur.execute(sql)
        rows = cur.fetchall()
        cur.close()
        self.slave.close()
        return rows

    def get_jc(self):
        """教材讲解数据"""
        sql_jc = """SELECT user_id,'jc',COUNT(1) FROM tbkt_shuxue.sx_study_knowledge WHERE add_time 
        BETWEEN UNIX_TIMESTAMP('%s') AND UNIX_TIMESTAMP('%s') GROUP BY user_id;""" % (self.begin_date, self.end_date)
        jc_data = self.slave_fetchall(sql_jc)
        jc_dict = [[obj[0], obj[1], obj[2]] for obj in jc_data if jc_data]
        return jc_dict

    def get_lx(self):
        """练习册数据"""
        sql_lx = """SELECT user_id,'lx',COUNT(1) FROM tbkt_shuxue.sx_test WHERE type=1 AND add_time 
        BETWEEN UNIX_TIMESTAMP('%s') AND UNIX_TIMESTAMP('%s') GROUP BY user_id;""" % (self.begin_date, self.end_date)
        lx_data = self.slave_fetchall(sql_lx)
        lx_dict = [[obj[0], obj[1], obj[2]] for obj in lx_data if lx_data]
        return lx_dict

    def get_ss(self):
        """速算数据"""
        sql_ss = """SELECT user_id,'ss',COUNT(1) FROM tbkt_shuxue.susuan_test WHERE test_time 
        BETWEEN UNIX_TIMESTAMP('%s') AND UNIX_TIMESTAMP('%s') GROUP BY user_id;""" % (self.begin_date, self.end_date)
        ss_data = self.slave_fetchall(sql_ss)
        ss_dict = [[obj[0], obj[1], obj[2]] for obj in ss_data if ss_data]
        return ss_dict

    def get_as(self):
        sql_as = """SELECT user_id,'as',COUNT(1) FROM tbkt_shuxue.think_test WHERE `status`=1 AND add_time 
        BETWEEN UNIX_TIMESTAMP('%s') AND UNIX_TIMESTAMP('%s') GROUP BY user_id;""" % (self.begin_date, self.end_date)
        as_data = self.slave_fetchall(sql_as)
        as_dict = [[obj[0], obj[1], obj[2]] for obj in as_data if as_data]
        return as_dict

    def match_data(self):
        """数据生成"""
        data_list = self.get_as() + self.get_jc() + self.get_lx() + self.get_ss()
        # 将list数据转换成DataFrame格式的数据
        ds = pd.DataFrame(data_list, columns=['user_id', 'th_type', 'th_num'])
        # 将ds中的空值填充为0,并且将user_id作为行,th_type作为列,th_num作为值重新生成DataFrame格式数据
        n_ds = ds.pivot(index='user_id', values='th_num', columns='th_type').fillna(0)
        # 将DataFrame格式的value转换成list
        res_list = n_ds.values.tolist()
        # 将DataFrame格式的index转换成list
        b = n_ds.index.tolist()
        for obj in res_list:
            obj.insert(0, b[res_list.index(obj)])
        return res_list