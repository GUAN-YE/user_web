# coding: utf-8
import os
import sys
import xlwt
import time
import pymysql
from retrying import retry
from send_eamil import SendMail

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
from twisted.internet import reactor
from twisted.application import service
from db_mysql import db


class DataManager(object):
    @staticmethod
    def to_list(data_list):
        the_list = [[v for v in data] for data in data_list]
        return the_list

    @staticmethod
    def to_dict(data_list):
        t_list = [[v for v in data] for data in data_list]
        the_dict = {obj[0]: obj[1:] for obj in t_list}
        return the_dict

    @staticmethod
    def to_dict_temp(data_list):
        t_list = [[v for v in data] for data in data_list]
        t_dict = {(obj[0], obj[1]): obj[2:] for obj in t_list}
        return t_dict


def match_dict(data_base, data_dict, *args):
    """
    功能说明:数据匹配
    ------------------------------
    修改人:宋国洋
    ------------------------------
    修改时间:2016-11-23
    ------------------------------
    参数: data_base-基础数据,data_dict-待匹配数据
    *args第一个是匹配的目标字段下标,第二个是结果值个数
    """
    k_index = args[0]
    v_index = args[1]
    for k in data_base:
        if k[k_index] in data_dict.keys():
            if data_dict.get(k[k_index]):
                for vs in data_dict[k[k_index]]:
                    k.append(vs)
            else:
                k.append(0)
        else:
            for i in range(v_index):
                k.append(0)
    return data_base


def divis(a, b, x):
    """
    Args:
        a: 分子
        b: 分母
        x: 保留几位小数+2（如果要保留两位小数 x=4）
        return: 返回所占百分比 例 23.33%
    """
    if b == 0:
        return 0
    else:
        return str(round(float(a) / float(b), x) * 100) + "%"


def get_operate_conn():
    """
    埋点数据库链接
    :return:
    """
    conn = pymysql.connect(
        host='10.27.74.72',
        port=3307,
        user='tbkt_developer',
        passwd='tbkt@2018develop',
        db='operate',
        charset='utf8')
    return conn


def get_slave_conn():
    conn = pymysql.connect(
        host='10.25.141.231',
        port=3306,
        user='hn_tbkt_cms_user',
        passwd='cms@TbKt!2017RDS',
        db='tbkt_ketang',
        charset='utf8')
    return conn


@retry()
def query_operate_all(sql, args):
    conn = get_operate_conn()
    cur = conn.cursor()
    cur.execute(sql, args)
    r = cur.fetchall()
    cur.close()
    conn.close()
    return r


@retry()
def query_slave_all(sql, args):
    conn = get_slave_conn()
    cur = conn.cursor()
    cur.execute(sql, args)
    r = cur.fetchall()
    cur.close()
    conn.close()
    return r


class GetQualityData(object):
    @staticmethod
    def get_option():
        option = db.tbkt_ketang.mobile_quality.filter(status=0).get()
        return option

    @staticmethod
    def read_mysql_get_data(user_data):
        print "开始获取结果数据"
        try:
            area_type = user_data['area_type']
            area_id = user_data['area_id']
            exact_type = user_data['exact_type']
            begin_date = user_data['begin_date']
            end_date = user_data['end_date']
            and_where = ''
            next_where = ''
            next_where_other = ''
            and_where_other = ''
            #  选择的是 省市区
            # 省选择的是省
            if area_type == 1:
                and_where = ""
                and_where_other = ""
            elif area_type == 2:
                and_where = " AND mor.city = '%s'" % area_id
                and_where_other = " AND p.city_id = '%s'" % area_id
            elif area_type == 3:
                and_where = " AND mor.county = '%s'" % area_id
                and_where_other = " AND p.county_id = '%s'" % area_id
            # 到学校
            if exact_type == 3:
                next_where = "mor.school_id"
                next_where_other = "p.school_id"
            # 到县区
            elif exact_type == 2:
                next_where = "mor.county"
                next_where_other = "p.county_id"
            # 到地市
            elif exact_type == 1:
                next_where = "mor.city"
                next_where_other = "p.city_id"

            #  获取用户总规模 1
            sql_user = """
                SELECT
                  %(next_where)s,
                  count(DISTINCT au.id)
                FROM tbkt_ketang.mobile_order_region mor
                  INNER JOIN  tbkt_user.auth_user au ON mor.user_id = au.id
                  AND mor.province = '410000' AND mor.city !='419000'
                  AND au.type = 1 
                  INNER JOIN tbkt_ketang.mobile_subject_detail_hn mos ON mos.phone_number = au.phone
                  AND mos.status = 2 %(and_where)s
                  AND mos.open_date <= %(end_date)s 
                GROUP BY
                  %(next_where)s
                ORDER BY
                  %(next_where)s
                """ % {"next_where": next_where, "and_where": and_where, "end_date": end_date}

            # 有班级归属的用户规模
            sql_class = """
                SELECT
                    %(next_where)s,
                    count( DISTINCT au.id )
                FROM
                    tbkt_ketang.mobile_open_num op 
                    INNER JOIN 
                    tbkt_com.school_unit_class suc ON suc.id = op.unit_class_id
                    AND op.2_num >= 10
                    AND suc.class_id < 17 
                    INNER JOIN
                    tbkt_ketang.mobile_order_region mor ON suc.id = mor.unit_class_id
                    AND mor.province = '410000'
                    %(and_where)s
                    INNER JOIN tbkt_user.auth_user au ON mor.user_id = au.id
                    AND au.type = 1
                    INNER JOIN tbkt_ketang.mobile_subject_detail_hn mos ON mos.phone_number = au.phone
                    AND mos.`status` = 2 
                    AND mos.open_date < %(end_date)s
                GROUP BY
                    %(next_where)s	
                """ % {"next_where": next_where, "and_where": and_where, "end_date": end_date, "begin_date": begin_date}

            # app停留用户数分钟数查询
            sql_app = """
              SELECT
                %(next_where_other)s,
                SUM( CASE WHEN p.u_min >0 AND p.u_min < 10 THEN 1 ELSE 0 END ) AS mi,
                SUM( CASE WHEN p.u_min >= 10 AND p.u_min < 30 THEN 1 ELSE 0 END ) AS min,
                SUM( CASE WHEN p.u_min >= 30 THEN 1 ELSE 0 END ) AS max
                FROM
                (
                SELECT
                t.city_id,
                t.county_id,
                t.school_id,
                t.unit_class_id,
                t.userid,
                SUM(t.time_diff) / 60 AS u_min
                FROM
                (
                SELECT
                city_id,
                county_id,
                school_id,
                unit_class_id,
                userid,
                (endtime - begintime) AS time_diff
                FROM
                operate.statistics p
                INNER JOIN
                operate.dict_code d ON p.modulecode = d.modulecode
                AND
                p.endtime > 0
                AND p.city_id > 0 %(and_where_other)s
                AND p.begintime BETWEEN %(begin_date)s AND %(end_date)s 
                AND d.usertype = 1
                ) AS t
                GROUP BY
                t.city_id,
                t.county_id,
                t.school_id,
                t.unit_class_id,
                t.userid
                ) AS p
                GROUP BY
                %(next_where_other)s
            """ % {"next_where_other": next_where_other, "and_where_other": and_where_other, "end_date": end_date,
                   "begin_date": begin_date}

            # 查询任课教师数
            sql_teacher = """
              SELECT
               %(next_where)s,
                count(DISTINCT mor.user_id)
                FROM 
                tbkt_ketang.province_tea_data mor
                INNER JOIN tbkt_ketang.mobile_open_num op ON op.unit_class_id = mor.unit_class_id
                AND op.2_num >= 10 
                INNER JOIN tbkt_com.school_unit_class suc ON suc.id = mor.unit_class_id
                AND suc.class_id < 17
                GROUP BY
                %(next_where)s
            """ % {"next_where": next_where, "and_where": and_where, "end_date": end_date, "begin_date": begin_date}

            # 安装app的教师数
            sql_install_app = """
              SELECT
                %(next_where_other)s,
                COUNT(1)
              FROM
                (SELECT
                p.city_id,
                p.county_id,
                p.school_id,
                p.unit_class_id,
                p.userid
                FROM operate.statistics p
                INNER JOIN operate.school_unit_class u ON p.unit_class_id = u.id
                WHERE p.modulecode = 999
                AND u.class_id < 17
                AND p.begintime < %(end_date)s
                AND p.city_id > 0
                GROUP BY
                p.city_id,
                p.county_id,
                p.school_id,
                p.unit_class_id,
                p.userid) AS p 
              GROUP BY 
                  %(next_where_other)s 
            """ % {"next_where_other": next_where_other, "and_where_other": and_where_other, "end_date": end_date,
                   "begin_date": begin_date}

            # 当月应用教师人数
            sql_app_teacher_month = """
                SELECT
                  %(next_where)s,
                  count(DISTINCT mor.user_id)
                FROM 
                tbkt_ketang.province_tea_data mor
                INNER JOIN tbkt_user.tbkt_logins lgn ON lgn.user_id = mor.user_id    
                AND mor.`status` = 2              
                AND lgn.login_type IN (0, 10, 12, 14)
                AND lgn.login_time BETWEEN %(begin_date)s AND %(end_date)s 
                GROUP BY
                  %(next_where)s
                ORDER BY
                  %(next_where)s
            """ % {"next_where": next_where, "and_where": and_where, "end_date": end_date, "begin_date": begin_date}

            # 通过app 布置数学作业的教师数
            sql_tea_task = """    
                SELECT
                  %(next_where)s,
                  count(DISTINCT mor.user_id)
                FROM tbkt_com.message m 
                INNER JOIN  tbkt_ketang.mobile_order_region mor ON m.add_user = mor.user_id
                  AND m.subject_id IN (21, 22)
                  AND m.agent = 2 %(and_where)s
                  AND m.begin_time BETWEEN %(begin_date)s AND %(end_date)s 
                  AND mor.province = '410000'
                GROUP BY
                 %(next_where)s
            """ % {"next_where": next_where, "and_where": and_where, "end_date": end_date, "begin_date": begin_date}

            # 通过app 布置作业达到五次以上的人数
            sql_tea_task_5 = """
                SELECT
                    %(next_where)s,
                    COUNT(DISTINCT mor.user_id) AS tea_num 
                FROM
                    (
                SELECT
                    mor.city,
                    mor.county,
                    mor.school_id,
                    mor.unit_class_id,
                    mor.user_id,
                    COUNT(1) AS num 
                FROM
                    tbkt_com.message m
                    INNER JOIN tbkt_ketang.mobile_order_region mor ON m.add_user = mor.user_id 
                    AND m.subject_id IN (21, 22) 
                    AND m.agent = 2 %(and_where)s
                    AND m.begin_time BETWEEN %(begin_date)s AND %(end_date)s 
                    AND mor.province = '410000'
                GROUP BY
                    mor.city,
                    mor.county,
                    mor.school_id,
                    mor.unit_class_id,
                    mor.user_id
                    ) AS mor 
                WHERE
                    mor.num >= 5 
                GROUP BY
                    %(next_where)s
            """ % {"next_where": next_where, "and_where": and_where, "end_date": end_date, "begin_date": begin_date}

            # 网站发布作业的人数
            sql_web_task = """
                SELECT
                  %(next_where)s,
                  count(DISTINCT mor.user_id)
                FROM tbkt_com.message m
                INNER JOIN tbkt_ketang.province_tea_data mor ON m.add_user = mor.user_id
                  AND m.type IN (1,2,7,8,9)
                  AND m.`status` = 1 %(and_where)s
                  AND m.add_time BETWEEN %(begin_date)s AND %(end_date)s
                GROUP BY
                  %(next_where)s
            """ % {"next_where": next_where, "and_where": and_where, "end_date": end_date, "begin_date": begin_date}

            print "获取基础数据"
            data_user = query_slave_all(sql_user, None)
            print "获取有班级归属用户规模"
            data_class = query_slave_all(sql_class, None)
            print "获取任课教师数据"
            data_teacher = query_slave_all(sql_teacher, None)
            print "获取应用教师人数"
            data_app_teacher_month = query_slave_all(sql_app_teacher_month, None)
            print "获取网站发布作业人数"
            data_web_task = query_slave_all(sql_web_task, None)
            print "通过app发作业人数"
            data_tea_task = query_slave_all(sql_tea_task, None)
            print "app发作业五次以上人数"
            data_tea_task_5 = query_slave_all(sql_tea_task_5, None)
            print "获取app用户登录时间数据"
            data_app = query_operate_all(sql_app, None)
            print "获取安装app教师数"
            data_install_app = query_operate_all(sql_install_app, None)
            # # 数据转换
            print "开始进行数据转换"
            data_user = DataManager.to_list(data_user)
            data_class = DataManager.to_dict(data_class)
            data_app = DataManager.to_dict(data_app)
            data_teacher = DataManager.to_dict(data_teacher)
            data_install_app = DataManager.to_dict(data_install_app)
            data_app_teacher_month = DataManager.to_dict(data_app_teacher_month)
            data_tea_task = DataManager.to_dict(data_tea_task)
            data_tea_task_5 = DataManager.to_dict(data_tea_task_5)
            data_web_task = DataManager.to_dict(data_web_task)
            # 数据拼接
            print "开始进行数据拼接"
            data_list = match_dict(data_user, data_class, 0, 1)
            data_list = match_dict(data_list, data_app, 0, 3)
            data_list = match_dict(data_list, data_teacher, 0, 1)
            data_list = match_dict(data_list, data_install_app, 0, 1)
            data_list = match_dict(data_list, data_app_teacher_month, 0, 1)
            data_list = match_dict(data_list, data_tea_task, 0, 1)
            data_list = match_dict(data_list, data_tea_task_5, 0, 1)
            data_list = match_dict(data_list, data_web_task, 0, 1)
            print "开始计算所需数据, area_id:", area_id
            area_data = db.tbkt_com.common_provincecity.filter(fatherId=area_id).select("cityId", "name")[:]
            data_dict = {obj['cityId']: obj['name'] for obj in area_data}
            if exact_type == 3:
                if area_type == 2:
                    sql = """SELECT s.id,s.`name`
                    FROM tbkt_com.school s 
                    INNER JOIN 
                    tbkt_ketang.common_provincecity p ON s.county=p.cityId AND p.fatherId='%s'
                    GROUP BY s.id;""" % area_id
                    area_data = db.tbkt_com.fetchall_dict(sql)
                else:
                    area_data = db.tbkt_com.school.filter(county=area_id).select('id', 'name')
                data_dict = {int(obj['id']): obj['name'] for obj in area_data}
            if exact_type == 4:
                area_data = db.tbkt_com.school_unit_class.filter(school_id=area_id).select('id', 'unit_name')[:]
                data_dict = {int(obj['id']): obj['unit_name'] for obj in area_data}
            for i in data_list:
                # 生成区域名
                i[0] = data_dict[i[0]] if data_dict.has_key(i[0]) else "---"
                # 计算无感知用户
                no_per = i[1] - i[3] - i[4] - i[5]
                # 计算无感知用户占比
                no_per_pro = divis(no_per, i[1], 4)
                # 计算app占比
                app_pro_min_10 = divis(i[3], i[3] + i[4] + i[5], 4)
                app_pro_min_30 = divis(i[4], i[3] + i[4] + i[5], 4)
                app_pro_max_30 = divis(i[5], i[3] + i[4] + i[5], 4)
                # 计算教师使用率
                tea_pro = divis(i[9], i[7], 4)
                # 计算5次以上app发作业使用率
                if i[9] == 0:
                    tea_pro_5 = 0
                else:
                    tea_pro_5 = divis(i[10], i[9], 4)
                # 0应用教师
                no_tea_per = i[6] - i[9] - i[11]
                # 0应用占比
                no_tea_pro = divis(no_tea_per, i[6], 4)
                i.append(no_per)
                i.append(no_per_pro)
                i.append(app_pro_min_10)
                i.append(app_pro_min_30)
                i.append(app_pro_max_30)
                i.append(tea_pro)
                i.append(tea_pro_5)
                i.append(no_tea_per)
                i.append(no_tea_pro)
            return data_list
        except Exception as e:
            print e

    @staticmethod
    def write_excel(data_list):
        try:
            file_name = "weekly.xls"
            row = 1
            # Excel文件表头
            print "开始写入表头"
            list_table_head = [u'区域', u'用户规模', u'无感用户', u'无感用户占比', u'APP停留十分钟以下用户', u'占比', u'APP停留10到30分钟用户', u'占比',
                               u'APP停留30分钟以上用户',
                               u'占比', u'有班级归属的用户规模', u'任课教师', u'安装APP的教师数', u'通过APP布置作业的教师数', u'APP教师使用率',
                               u'通过App布置作业达到5次以上的教师数',
                               u'APP发作业5次以上教师数占比', u'通过网站布置作业的教师数', u'0应用教师', u'0应用占比', ]
            workbook = xlwt.Workbook()
            sheet = workbook.add_sheet('data', cell_overwrite_ok=True)
            # 写入Excel文件数据
            for i in range(len(list_table_head)):
                sheet.write(0, i, list_table_head[i])
            for data in data_list:
                col = 0
                li = data[0:1] + data[1:2] + data[12:13] + data[13:14] + data[3:4] + data[14:15] + data[4:5] \
                     + data[15:16] + data[5:6] + data[16:17] + data[2:3] + data[6:7] + data[7:8] \
                     + data[9:10] + data[17:18] + data[10:11] + data[18:19] + data[11:12] + data[19:]
                for item in li:
                    sheet.write(row, col, item)
                    col += 1
                row += 1
            # 保存Excel文件
            print "保存文件到本地"
            workbook.save(file_name)
        except Exception as e:
            print e

    def loop(self):
        while 1:
            print "开始处理数据"
            user_data = self.get_option()
            if user_data:
                print "修改数据状态值"
                # 更改数据状态为1,表示处理中
                db.tbkt_ketang.mobile_quality.filter(id=user_data['id']).update(status=1)
                # 获取数据
                data_list = self.read_mysql_get_data(user_data=user_data)
                # 生成Excel文件
                self.write_excel(data_list=data_list)
                send = SendMail()
                print "发送邮件"
                send_ret = send.send_mail(the_pattern=user_data['email'])
                if send_ret == "send_ok":
                    print "邮件发送成功"
                    # os.remove('weekly.xls')
                    # 完成处理结束更新状态为2,表示处理成功
                    db.tbkt_ketang.mobile_quality.filter(id=user_data['id']).update(status=2)
                    print "文件处理结束休眠60s"
                    time.sleep(60)
                else:
                    # 处理异常状态更新为3,表是未处理失败
                    db.tbkt_ketang.mobile_quality.filter(id=user_data['id']).update(status=3)
            else:
                print "没有需要处理的数据休眠60s"
                time.sleep(60)


def start():
    pro = GetQualityData()
    pro.loop()


if __name__ == '__main__':
    start()


elif __name__ == "__builtin__":
    reactor.callInThread(start)
    application = service.Application('batch_send_mobile_quality')