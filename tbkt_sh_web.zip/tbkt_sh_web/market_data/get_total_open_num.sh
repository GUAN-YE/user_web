#! /usr/bin/env sh
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/get_total_open_num.py
logfile=/var/log/get_total_open_num.log
case $1 in
    start)
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/get_total_open_num.pid --logfile=$logfile
        ;;
    stop)
        kill -9 `cat /var/run/get_total_open_num.pid`
        ;;
    restart)
        kill -9 `cat /var/run/get_total_open_num.pid`
        sleep 1
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/get_total_open_num.pid --logfile=$logfile
        ;;
    log)
        tail -f $logfile
        ;;
    *)
        echo "Usage: ./get_total_open_num.sh start | stop | restart | log"
        ;;
esac