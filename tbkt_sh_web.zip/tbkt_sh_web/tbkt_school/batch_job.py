# coding:utf-8
import xlrd
import time
import sys
import re
import random
import string
import datetime
import hashlib
import urllib
import base64
import pymysql
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
# 手机号正则
yidong_mobile_pattern = re.compile("^1(([3][456789])|([5][012789])|([8][23478])|([4][7]))[0-9]{8}$")
class_pattern = re.compile(r'(\d)(\d{2})班')
from twisted.internet import reactor
from twisted.application import service
# 河南阿里云数据库配置
DB_HOST = 'rm-2ze7fsacj5q360kt7.mysql.rds.aliyuncs.com'
DB_UID = 'tbkt_sh_user'
DB_PWD = 'shSCriPT@!2017TbKt'
DB_NAME = 'tbkt_ketang'
DB_PORT = 3306
# 阿里云测试库地址
# DB_HOST = "rm-2zekkuf62c6477n70.mysql.rds.aliyuncs.com"
# DB_UID = "hn_tbkt_cms_user"
# DB_PWD = "cms@TbKt!2017RDS"
# DB_NAME = 'tbkt_ketang'
# DB_PORT = 3306
# 本地测试数据库配置
# DB_HOST = "122.114.40.76"
# DB_UID = "renwanxing"
# DB_PWD = "ohStjN6DKXqdfBAfhGzdz"
# DB_NAME = 'tbkt_ketang'
# DB_PORT = 3306


def get_ketang_conn(db_name=''):
    """
    功能            建立ketang库的mysql连接
    -----------------------------------
    添加人          添加时间           作用
    -----------------------------------
    杜祖永           2016-06-28
    """
    DB_NAME = 'tbkt_ketang'
    if db_name:
        DB_NAME = db_name
    conn = pymysql.connect(host=DB_HOST,
                           db=DB_NAME,
                           user=DB_UID,
                           passwd=DB_PWD,
                           port=DB_PORT,
                           charset="utf8")
    return conn


def encode_password(password, salt=''):
    hash = sha1_encode_password(password)
    return hash


def sha1_encode_password(password, salt=''):
    if not salt:
        salt = get_random_string()
    hash = hashlib.sha1(salt + password).hexdigest()
    return "sha1$%s$%s" % (salt, hash)


def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Returns a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    return ''.join(random.choice(allowed_chars) for i in range(length))


TABLE_HEAD = {
    'tea_add': ['subject', 'name', 'phone', 'to_units'],
    'tea_adjust': ['subject', 'name', 'phone', 'to_units'],
    'stu_add': ['unit', 'name', 'phone', ],
}

add_school_user_TYPE = 3

SUBJECT_NAME = {
    u'数学': 2,
    u'物理': 3,
    u'化学': 4,
    u'英语': 9,
    u'语文': 5,
}

UPLOAD_FILE_KEY_VALUE = 'bannei_upload'
FILE_WEB_URLROOT = 'http://file.tbkt.cn'
PREFIX = "http://file.tbkt.cn/upload_media/"


def get_upload_key():
    """
    上传文件的加密key
    """
    now_time = datetime.datetime.now()
    m = hashlib.md5()
    m.update('%s%s' % (UPLOAD_FILE_KEY_VALUE, now_time.strftime("%Y%m%d")))
    return m.hexdigest()


class Struct(dict):
    """
    - 为字典加上点语法. 例如:
    """
    def __init__(self, dictobj={}):
        self.update(dictobj)

    def __getattr__(self, name):
        if name.startswith('__'):
            raise AttributeError
        return self.get(name)

    def __setattr__(self, name, val):
        self[name] = val

    def __delattr__(self, name):
        self.pop(name, None)

    def __hash__(self):
        return id(self)


def is_chinese_word(s, minlen=2, maxlen=5):
    """
    功能说明：       判断中文和长度
    ---------------------------------------------------
    修改人                修改时间
    ---------------------------------------------------
    王浩                 2016-07-22

    """
    if not s:
        return False
    if not isinstance(s, unicode):
        return False

    for ch in s:
        if u'\u4e00' <= ch <= u'\u9fff':
            pass
        else:
            return False
    if len(s) < minlen or len(s) > maxlen:
        return False
    return True


def is_subject(s, minlen=2):
    """
    功能说明：       判断学科是否正确
    ---------------------------------------------------
    修改人                修改时间
    ---------------------------------------------------
    张帅男                 2016-11-15

    """
    subject_list = [u'英语', u'数学', u'化学', u'物理', u'语文']
    if s not in subject_list:
        return False
    return True


class BaseWorker(object):
    def __init__(self, conn_name=''):
        self.conn = get_ketang_conn()

    def execute(self, sql, args=None, db=''):
        conn = get_ketang_conn(db_name=db)
        cur = conn.cursor()
        r = cur.execute(sql)
        conn.commit()
        cur.close()
        conn.close()
        return r

    def fetchone(self, sql, db=''):
        conn = get_ketang_conn(db_name=db)
        cur = conn.cursor()
        cur.execute(sql)
        row = cur.fetchone()
        cur.close()
        conn.close()
        return row

    def fetchall(self, sql, db=''):
        conn = get_ketang_conn(db_name=db)
        cur = conn.cursor()
        cur.execute(sql)
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return rows

    def call_proc(self, pro_name, params=None, db='tbkt_ketang'):
        try:
            if not params:
                params = []
            conn = get_ketang_conn(db_name=db)
            cur = conn.cursor()
            cur.callproc(pro_name, params)
            result = cur.fetchall()
            cur.close()
            conn.close()
            return result
        except pymysql.Error, e:
            import traceback
            traceback.print_exc()
            self.conn.rollback()


def timer(f):
    def w(*arg, **argv):
        t1 = time.time()
        result = f(*arg, **argv)
        t2 = time.time()
        esp = t2 - t1
        print "fuction_name < %s > ,time used %s" % (f.__name__, esp)
        print esp * 100000
        return result

    return w


class SchoolOperate(BaseWorker):
    def __init__(self, school_id, add_school_user_id, add_school_user_name,school_name, file_url, batch_type, modify_log_id, conn_name=''):
        self.school_id = school_id
        self.add_school_user_id = add_school_user_id
        self.add_school_user_name = add_school_user_name
        self.add_school_name = school_name
        self.file_url = file_url
        self.batch_type = batch_type
        self.modify_log_id = modify_log_id
        self.process_status = 1
        self.school_data = None
        super(SchoolOperate, self).__init__(conn_name)

    def file_reader(self, max_len=3001):
        url = self.file_url
        fp = urllib.urlopen(url)
        file_content = fp.read()
        data = xlrd.open_workbook(file_contents=file_content)
        table = data.sheets()[0]
        # 传毒限制
        if table.nrows < 2:
            self.save_fail('', '', '', info=u'您上传的表格无有效数据')
            return []
        if table.nrows > max_len:
            self.save_fail('', '', '', info=u'您上传的表格中数据超出%s条的限制')
            return []
        result = [table.row_values(row) for row in range(10, table.nrows)]
        return result

    def file_reader_stu(self, max_len=3001):
        url = self.file_url
        fp = urllib.urlopen(url)
        file_content = fp.read()
        data = xlrd.open_workbook(file_contents=file_content)
        table = data.sheets()[0]
        # 传毒限制
        if table.nrows < 2:
            self.save_fail('', '', '', info=u'您上传的表格无有效数据')
            return []
        if table.nrows > max_len:
            self.save_fail('', '', '', info=u'您上传的表格中数据超出%s条的限制')
            return []
        result = [table.row_values(row) for row in range(1, table.nrows)]
        return result

    def pack_info(self, key, value):
        head = TABLE_HEAD.get(key)
        if 'tea' in key:
            v = value[:len(head) - 1]
            try:
                v.append(set(map(self.grade_class_format, filter(lambda x: x, value[len(head) - 1:]))))
            except Exception as e:
                v.append(','.join(map(str, filter(lambda x: x, value[len(head) - 1:]))))
        else:
            v = value
            try:
                v[0] = self.grade_class_format(v[0])
            except Exception as e:
                import traceback
                traceback.print_exc()
        info = Struct(dict(zip(head, v)))
        return info

    def find_user(self, phone, real_name, user_type=1):
        """
        查找用户是否存在, 存在返回 user_id 否则返回空
        Args:
            phone:
            real_name:
            user_type:

        Returns:

        """
        f_sql = """SELECT
                mub.id,
                mub.sid,
                suc.grade_id
            FROM
                tbkt_user.auth_user mub
            INNER JOIN tbkt_ketang.mobile_order_region mor ON mor.user_id = mub.id
            INNER JOIN tbkt_com.school_unit_class suc ON suc.id = mor.unit_class_id
            WHERE
                mub.phone = '%s'
            AND mub.real_name = '%s'
            AND mub.type = %s limit 1;
            """ % (phone, real_name, user_type)
        row = self.fetchall(f_sql)
        if not row:
            return {}
        return Struct({'user_id': row[0][0], 'subject_id': row[0][1], 'grade_id': int(row[0][2])})

    def find_unit(self, grade_id, class_id):
        f_sql = """
        select id from tbkt_com.school_unit_class where school_id = %s and grade_id = %s and class_id = %s
        and is_update = 0 and level_id =3 limit 1;
        """ % (self.school_id, grade_id, class_id)
        row = self.fetchall(f_sql, db='tbkt_com')
        if not row:
            return None
        return row[0][0]

    def find_user_units(self, user_id):
        """
        功能说明：       查找用户班级
        ---------------------------------------------------
        修改人                修改时间
        ---------------------------------------------------
        王浩                 2016-08-01

        Args:
            user_id:

        Returns:

        """
        ftn_sql = """
        select mor.unit_class_id, mub.grade_id, mub.class_id, mub.school_id from tbkt_com.school_unit_class mub
        INNER JOIN tbkt_ketang.mobile_order_region mor ON mor.unit_class_id = mub.id
        where mor.user_id = %s
        and mor.is_update = 0
        """ % user_id
        rows = self.fetchall(ftn_sql)
        units = [Struct({'unit_id': r[0], 'grade_id': r[1], 'class_id': r[2], 'school_id': r[3]}) for r in rows]
        return units

    def unit_subject_tea(self, unit_id, subject_id):
        """
        功能说明：       目标班级是否有老师存在
        ---------------------------------------------------
        修改人                修改时间
        ---------------------------------------------------
        王浩                 2016-08-03

        Args:
            unit_id:
            subject_id:

        Returns:

        """
        cust_sql = """SELECT 
                 mub.id
          FROM tbkt_user.auth_user mub
            INNER JOIN tbkt_ketang.mobile_order_region mor
              ON mub.id = mor.user_id AND mor.unit_class_id = %s AND mub.sid = %s
              and mub.type = 3
          LIMIT 1;
        """ % (unit_id, subject_id)
        row = self.fetchall(cust_sql)
        if not row:
            return 0
        return row[0][0]

    def find_mub_from_phone(self, phone, user_type):
        """
        功能说明：       根据电话找对应类型的用户
        ---------------------------------------------------
        修改人                修改时间
        ---------------------------------------------------
        王浩                 2016-08-01

        Args:
            phone:
            user_type:

        Returns:

        """
        fp_sql = """
        select username, id, real_name,sid from tbkt_user.auth_user where phone = '%s' and type = %s
        """ % (phone, user_type)
        rows = self.fetchall(fp_sql)
        mubs = [Struct({'username': r[0], 'user_id': r[1], 'real_name': r[2], 'subject_id': r[3]}) for r
                in rows]
        return mubs

    def remove_unit(self, user_id, unit_id):
        """
        功能说明：       用户退出班级
        ---------------------------------------------------
        修改人                修改时间
        ---------------------------------------------------
        王浩                 2016-07-25

        Args:
            user_id:
            unit_id: 要退出的班级

        Returns:

        """
        delete_sql = """
                  delete from tbkt_ketang.mobile_order_region where user_id = %s and unit_class_id = %s;
                """ % (user_id, unit_id)
        self.execute(delete_sql)
        return True

    def remove_unit_(self, user_id):
        """
        功能说明：       老师退出班级
        ---------------------------------------------------
        修改人                修改时间
        ---------------------------------------------------
        王浩                 2016-07-25

        Args:
            user_id:
            unit_id: 要退出的班级

        Returns:

        """
        delete_sql = """
                  delete from tbkt_ketang.mobile_order_region where user_id = %s and user_type=3;
                """ % user_id
        self.execute(delete_sql)
        return True

    def grade_class_format(self, unit_name):
        unit_name = str(unit_name)
        name = class_pattern.match(unit_name)
        grade_id, class_id = name.groups()
        return int(grade_id), int(class_id)

    def save_fail(self, phone, subject, real_name, from_unit=None, to_unit=None, info=u''):
        # 设置本次操作为包含包含的操作
        if not from_unit:
            from_unit = ''
        if not to_unit:
            to_unit = ''
        self.save_info(2, phone, subject, real_name, from_unit, to_unit, info)

    def save_success(self, phone, subject, real_name, from_unit='', to_unit='', info=u''):
        self.save_info(1, phone, subject, real_name, from_unit, to_unit, info)

    def save_info(self, status, phone, subject, real_name, from_unit='', to_unit='', info=u''):
        if isinstance(from_unit, list) or isinstance(from_unit, set):
            from_unit = ','.join(map(lambda x: u'%d%02d班' % (x[0], x[1]), from_unit))
        if isinstance(to_unit, list) or isinstance(to_unit, set):
            to_unit = ','.join(map(lambda x: u'%d%02d班' % (x[0], x[1]), to_unit))
        if isinstance(to_unit, tuple):
            to_unit = u'%d%02d班' % (to_unit[0], to_unit[1])
        if status == 2:
            self.process_status = 2
        si_sql = """
            INSERT INTO tbkt_manage.modify_detail (
            modify_log_id,phone,subject,real_name,status,from_unit,to_unit,op_info
            )
              VALUES
            (
            %s,"%s","%s","%s",%s,"%s","%s","%s"
            );
            """ % (self.modify_log_id, phone, subject, real_name, status, from_unit, to_unit, info)
        self.execute(si_sql, db='tbkt_manage')

    def add_school_user(self, real_name, user_type, phone, subject_id, unit_dict, unit_id):
        """
        创建用户

        """
        try:
            sex = 1
            add_school_user_school_id = self.school_id
            school_name = self.add_school_name
            dept_id = {}
            grade_id = {}
            username = {}
            if user_type == 3:
                username = phone + 'js'
                for x in unit_dict:
                    if x in [7, 8, 9]:
                        dept_id = 2
                        grade_id = unit_dict[0]
                    else:
                        dept_id = 1
                        grade_id = unit_dict[0]
            elif user_type == 1:
                subject_id = 0
                username = phone + 'xs'
                if unit_dict[0] > '6':
                    dept_id = 2
                    grade_id = unit_dict[0]
                else:
                    dept_id = 1
                    grade_id = unit_dict[0]
            set_password = {}
            set_password_ = {}
            password = ''.join(random.sample(string.digits, 6))
            set_password_ = encode_password(password)
            set_password = base64.b64encode(password)
            date_time = str(int(time.time()))
            # 查找用户,若用户存在更新,不存在添加
            sql_user = """SELECT id FROM tbkt_user.auth_user WHERE username='%s' LIMIT 1""" % username
            data_user = self.fetchone(sql_user)
            if data_user:
                # 更新用户数据
                sql_up = """UPDATE tbkt_user.auth_user SET real_name='%s', grade_id=%s, sid=%s, dept_id=%s 
                            WHERE username='%s';""" % (real_name, grade_id, subject_id, dept_id, username)
                self.execute(sql_up, db='tbkt_user')
            else:
                # 添加用户数据
                create_sql = """INSERT INTO tbkt_user.auth_user ( username, real_name, password, type, 
                            status, phone, platform_id, grade_id, sid, dept_id, last_login, date_joined )
                            VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');""" % \
                             (username, real_name, set_password_, user_type, 1, phone, 1, grade_id,subject_id, dept_id,
                              date_time, date_time)
                self.execute(create_sql)  # 添加用户
            select_sql = """select id from tbkt_user.auth_user where type=%s and phone='%s' and real_name='%s';""" % (user_type, phone, real_name)
            result_id = self.fetchall(select_sql)  # 查找用户id
            # 查找auth_profile中的数据,有不处理,无添加
            sql_pro = """SELECT id FROM tbkt_user.auth_profile WHERE user_id=%s;""" % result_id[0][0]
            data_pro = self.fetchone(sql_pro, db='tbkt_user')
            if data_pro:
                pass
            else:
                create_sql_ = """INSERT INTO tbkt_user.auth_profile (user_id,sex,password) VALUES ('%s','%s','%s');""" % (result_id[0][0], sex, set_password)
                self.execute(create_sql_)  # 添加用户
            select_sql__ = """select province, city, county,unit_class_id,province_id,city_id,county_id  from tbkt_ketang.mobile_order_region where school_id=%s limit 1;""" % add_school_user_school_id
            result__ = self.fetchall(select_sql__)[0]  # 查找当前添加者的数据
            if user_type == 3:
                for x in unit_id:
                    create_sql__ = """INSERT INTO tbkt_ketang.mobile_order_region (province, city, county, school_name,school_id,school_type,
                              unit_class_id,dept_type,is_update,add_date,del_state,user_type,user_id,
                              province_id,city_id,county_id) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');""" %(result__[0], result__[1], result__[2],school_name, add_school_user_school_id, dept_id, x,0, 0, date_time, 0, user_type, result_id[0][0], result__[4],result__[5], result__[6])
                    self.execute(create_sql__)  # 添加对应班级
            if user_type == 1:
                create_sql__ = """INSERT INTO tbkt_ketang.mobile_order_region (province, city, county, school_name,school_id,school_type,
                          unit_class_id,dept_type,is_update,add_date,del_state,user_type,user_id,
                          province_id,city_id,county_id) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');""" % \
                               (result__[0], result__[1], result__[2],
                                school_name, add_school_user_school_id, dept_id, unit_id,
                                0, 0, date_time, 0, user_type, result_id[0][0], result__[4],result__[5], result__[6])
                self.execute(create_sql__)  # 添加对应班级

            create_sql_ = """INSERT INTO tbkt_ketang.mobile_subject_detail_hn (phone_number) VALUES ('%s');""" % phone
            self.execute(create_sql_)  # 添加开通状态
            user_id = result_id[0][0]
            return user_id
        except Exception as e:
            import traceback
            traceback.print_exc()
            return 0

    def class_change(self, user_id, remove_unit_ids, join_unit_ids, subject_id, real_name, phone):
        info = ''
        if remove_unit_ids:
            info += u'退出班级[%s],' % ','.join(map(str, remove_unit_ids))
            for unit_id in remove_unit_ids:
                self.remove_unit(user_id, unit_id)
        else:
            self.remove_unit_(user_id)
        if join_unit_ids:
            info += u"加入班级[%s]," % ','.join(map(str, join_unit_ids))

        for unit_id in join_unit_ids:
            old_tea_user_id = self.unit_subject_tea(unit_id, subject_id)
            if old_tea_user_id:
                info += u'从班级[unit_id=%s]删除原本老师[user_id=%s],' % (unit_id, old_tea_user_id)
                self.remove_unit(old_tea_user_id, unit_id)
            from_unit_id = 0  # 要调出的班级
            if_out = 0  # 是否把原班级老师调出去
            self.change_unit(user_id, from_unit_id, unit_id, subject_id, real_name, phone)
        return info

    def calc_unit(self, user_id, to_units, is_new=0):
        """

        Args:
            is_new:  是否是新创建的用户
            user_id: 用户的 user_id
            to_units: 要转到的班级 格式 [(1,2),(2,3)] # 102班, 203班
        Returns:

        """
        grade_id = list(to_units)[0][0]
        if is_new:
            user_units = []
        else:
            user_units = self.find_user_units(user_id)
        if not user_units:
            remove_unit_ids = []
            join_units = to_units
        elif user_units[0].school_id != self.school_id:
            remove_unit_ids = [u.unit_id for u in user_units]
            join_units = to_units
        else:
            units_tuple_list = set([(u.grade_id, u.class_id) for u in user_units])
            remove_units = [u for u in units_tuple_list if u not in to_units]  # 移除不在目标班级的用户班级
            remove_unit_ids = [u.unit_id for g, c in remove_units for u in user_units if g == u.grade_id and c == u.class_id and u.grade_id == grade_id]       # 必须和用户同年级
            join_units = [u for u in to_units if u not in units_tuple_list]  # 添加不在用户班级的目标班级
        if not join_units and not remove_unit_ids:
            # 用户本身就在要加入的班级, 成功
            return "success", u'用户已在要加入的班级'
        join_unit_ids = map(lambda x: self.find_unit(*x), join_units)  # 要加入的班级
        if not all(join_unit_ids):
            # 有班级是不存在的, 失败
            return 'fail', u'班级不存在'
        # 重新在管理员系统显示班级
        # self.re_show_unit(*join_unit_ids)
        return remove_unit_ids, join_unit_ids

    def re_show_unit(self, *units):
        print "this re_show_unit process 18"
        if len(units) == 1:
            rs_sql = """
            update tbkt_com.school_unit_class set is_show = 1 where id= %s;
            """ % units[0]
        elif len(units) > 1:
            units_str = ','.join(map(str, units))
            rs_sql = """
                update tbkt_com.school_unit_class set is_show = 1 where id in %s;
                """ % units_str
        else:
            return
        self.execute(rs_sql)

    def find_user_no_class(self, phone, real_name, user_type=1):
        """
                查找用户是否存在, 存在返回 True, 否则返回False
                Args:
                    phone:
                    real_name:
                    user_type:

                Returns:
        """
        sql = """SELECT
                    id
                FROM
                    tbkt_user.auth_user
                WHERE
                    phone = '%s'
                AND real_name = '%s'
                AND type = %s limit 1;
                """ % (phone, real_name, user_type)
        row = self.fetchall(sql, db='tbkt_user')
        if row:
            return True
        else:
            return False

    def process_batch_tea_change(self):
        """
        批量调整教师
        Returns:

        """
        tmp = self.file_reader()[0]                                 # 记录第一行的状态, zsn
        for l in self.file_reader():
            to_unit_flag = False
            len_num = len(l)
            for i in range(3, len_num):
                if isinstance(l[i], float):
                    to_unit_flag = True
                elif len(l[i]) == 0:
                    continue
                elif len(l[i]) != 4:
                    to_unit_flag = True
            info = self.pack_info('tea_adjust', l)
            tmp = l
            if l[:3] == [u'', u'', u'']:
                continue
            to_units = info.to_units
            if l[3:] == [u'', u'', u'', u'', u'', u'']:
                op_info = u'班级不能为空'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue

            if l[0] == u'' or isinstance(l[0], float):
                op_info = u'教师科目错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue
            s = info.subject
            if not isinstance(s, float):
                s = s.encode('utf-8')
                s = s.replace(' ', '')
                info.subject = s.decode('utf-8')
            if not is_subject(info.subject):
                op_info = u'教师科目错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue
            if isinstance(info.phone, float):
                info.phone = int(info.phone)
            if to_unit_flag:
                op_info = u'班级信息错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue
            if (not isinstance(info.to_units, set)) and (not isinstance(info.to_units, list)):
                op_info = u'班级信息错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.to_units, info=op_info)
                continue
            if not all([info.get(x) for x in info]):
                op_info = u'信息不能为空'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.to_units, info=op_info)
                continue
            if not is_chinese_word(info.name):
                op_info = u'姓名只能是2-5个汉字'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.to_units, info=op_info)
                continue
            phone_tmp = ''
            try:
                phone_tmp += str(int(info.phone))
            except Exception, e:
                phone_tmp = info.phone
            info.phone = phone_tmp
            if not yidong_mobile_pattern.match(info.phone):
                op_info = u'手机号码必须为河南移动号码'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue
            if len(to_units) > 6:
                op_info = u'班级个数不能大于 6'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue
            info.subject_id = subject_id = SUBJECT_NAME.get(info.subject) or 0
            user_info = self.find_user(info.phone, info.name, 3)
            primary_list = [1, 2, 3, 4, 5, 6, 7]                    # 小学年级
            middle_list = [7, 8, 9]                     # 初中年级

            to_primary_list = False              # 要调到小学
            to_middle_list = False              # 要调到中学
            for to_unit in to_units:
                if to_unit[0] in primary_list:
                    to_primary_list = True
                if to_unit[0] in middle_list:
                    to_middle_list = True

            user_no_class = self.find_user_no_class(info.phone, info.name, 3)

            if not user_no_class:
                op_info = u'暂无该账号'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue
            if user_info:
                if user_info.grade_id in primary_list and to_middle_list:
                    op_info = u'小学老师信息，调整失败'
                    self.save_fail(info.phone, info.subject, info.name, to_unit=info.to_units, info=op_info)
                    continue
                if user_info.grade_id in middle_list and to_primary_list:
                    op_info = u'初中老师信息，调整失败'
                    self.save_fail(info.phone, info.subject, info.name, to_unit=info.to_units, info=op_info)
                    continue

                if user_info.subject_id != info.subject_id:
                    op_info = u'教师科目错误'
                    self.save_fail(info.phone, info.subject, info.name, to_unit=info.to_units, info=op_info)
                    continue
                calc_info = self.calc_unit(user_info.user_id, to_units, is_new=0)
                if calc_info[0] not in ['success', 'fail']:
                    remove_unit_ids, join_unit_ids = calc_info
                    op_info = self.class_change(user_info.user_id, remove_unit_ids, join_unit_ids, subject_id, info.name, info.phone)
                    self.save_success(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                else:
                    status, op_info = calc_info
                    status = 1 if status == 'success' else 2
                    self.save_info(status, info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                    # break
            else:
                info.subject_id = subject_id = SUBJECT_NAME.get(info.subject) or 0
                unit_name_info = info.to_units
                unit_id = []
                unit_id_ = []
                for x in unit_name_info:
                    unit_id = self.find_unit(x[0], x[1])
                    unit_id_.append(int(unit_id))
                grade_ = []
                for x in unit_name_info:
                    grade_.append(x[0])
                username = info.phone + 'js'
                user_id = self.add_school_user(info.name, 3, info.phone, subject_id, grade_, unit_id_)
                is_new = 1
                if not user_id:
                    op_info = u'创建用户失败'
                    self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                    continue
                else:
                    calc_info = self.calc_unit(user_id, to_units, is_new=is_new)
                    if calc_info[0] not in ['success', 'fail']:
                        remove_unit_ids, join_unit_ids = calc_info
                        op_info = self.class_change(user_info.user_id, remove_unit_ids, join_unit_ids, subject_id, info.name, info.phone)
                        if is_new:
                            op_info = (u'创建用户[user_id=%s],' % user_id) + op_info
                        self.save_success(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                    else:
                        status, op_info = calc_info
                        status = 1 if status == 'success' else 2
                        self.save_info(status, info.phone, info.subject, info.name, to_unit=to_units, info=op_info)

    def process_batch_tea_add(self):
        tmp = self.file_reader()[0]                                 # 记录第一行的状态, zsn
        for l in self.file_reader():
            to_unit_flag = False
            len_num = len(l)
            for i in range(3, len_num):
                if isinstance(l[i], float):
                    to_unit_flag = True
                elif len(l[i]) == 0:
                    continue
                elif len(l[i]) != 4:
                    to_unit_flag = True

            info = self.pack_info('tea_add', l)

            if l[:3] == [u'', u'', u'']:
                continue
            tmp = l
            to_units = info.to_units
            if l[3:] == [u'', u'', u'', u'', u'', u'']:
                op_info = u'班级不能为空'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue
            if l[0] == u'' or isinstance(l[0], float):
                op_info = u'教师科目错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue

            parmary = False
            middle = False
            for unit in to_units:
                if unit[0] in [1, 2, 3, 4, 5, 6]:
                    parmary = True
                if unit[0] in [7, 8, 9]:
                    middle = True
            if parmary and middle:
                op_info = u'教师不能跨阶段带班级'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue

            s = info.subject
            if not isinstance(s, float):
                s = s.encode('utf-8')
                s = s.replace(' ', '')
                info.subject = s.decode('utf-8')
            info.subject = s.decode('utf-8')
            if not is_subject(info.subject):
                op_info = u'教师科目错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue
            if to_unit_flag:
                op_info = u'班级信息错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue
            if (not isinstance(info.to_units, set)) and (not isinstance(info.to_units, list)):
                op_info = u'班级信息错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.to_units, info=op_info)
                continue
            if not all([info.get(x) for x in info]):
                op_info = u'信息不能为空'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.to_units, info=op_info)
                continue
            if not is_chinese_word(info.name):
                op_info = u'姓名只能是2-5个汉字'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.to_units, info=op_info)
                continue
            phone_tmp = ''
            try:
                phone_tmp += str(int(info.phone))
            except Exception, e:
                phone_tmp = info.phone
            info.phone = phone_tmp
            info.subject_id = subject_id = SUBJECT_NAME.get(info.subject) or 0
            if not yidong_mobile_pattern.match(info.phone):
                op_info = u'手机号码必须为河南移动号码'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue
            if len(to_units) > 6:
                op_info = u'不能添加超过6个班级'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                continue

            real_name = info.name
            mubs = self.find_mub_from_phone(info.phone, user_type=3)
            account = [m for m in mubs if m.real_name == real_name]
            unit_name_info = info.to_units
            unit_id = []
            unit_id_ = []
            for x in unit_name_info:
                unit_id = self.find_unit(x[0], x[1])
                unit_id_.append(int(unit_id))
            grade_ = []
            for x in unit_name_info:
                grade_.append(x[0])

            info.subject_id = subject_id = SUBJECT_NAME.get(info.subject) or 0
            if mubs:
                if account:
                    op_info = u'该用户已注册'
                    self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                    continue
                elif len(mubs) >= 2:
                    op_info = u'一个手机号码最多注册两个用户'
                    self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)
                    continue
                else:
                    username = info.phone + 'js%s' % ('1' if len(mubs) == 1 else '')
                    user_id = self.add_school_user(info.name, 3, info.phone, subject_id, grade_, unit_id_)

            else:
                username = info.phone + 'js'
                user_id = self.add_school_user(info.name, 3, info.phone, subject_id, grade_, unit_id_)
                is_new = 1
            if not user_id:
                op_info = u'创建用户失败'
                self.save_fail(info.phone, info.subject, info.name, to_unit=to_units, info=op_info)

    def process_batch_stu_add(self):
        for l in self.file_reader_stu():
            to_unit_flag = False
            if l == [u'', u'', u'']:
                continue
            try:
                if isinstance(l[0], float):
                    to_unit_flag = True
                elif len(l[0]) != 4:
                    to_unit_flag = True
            except Exception, e:
                import traceback
                traceback.print_exc()
            info = self.pack_info('stu_add', l)

            if l[0] == u'':
                op_info = u'班级不能为空'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            if to_unit_flag:
                op_info = u'班级信息错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            if not all([info.get(x) for x in info]):
                op_info = u'信息不能为空'
                info.subject = ''
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            if not is_chinese_word(info.name):
                op_info = u'姓名只能是2-5个汉字'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            info.subject = ''
            phone_tmp = ''
            try:
                phone_tmp += str(int(info.phone))
            except Exception, e:
                phone_tmp = info.phone
            info.phone = phone_tmp
            unit_name_info = info.unit
            if not isinstance(unit_name_info, tuple):
                op_info = u'班级信息错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            if not yidong_mobile_pattern.match(info.phone):
                op_info = u'手机号码必须为河南移动号码'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            unit_id = self.find_unit(*unit_name_info)
            # 重新在管理员系统显示班级
            # self.re_show_unit(unit_id)

            if not unit_id:
                op_info = u'班级错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            real_name = info.name
            mubs = self.find_mub_from_phone(info.phone, user_type=1)
            account = [m for m in mubs if m.real_name == real_name]
            if account:
                op_info = u'该用户已注册'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            elif len(mubs) >= 2:
                op_info = u'一个手机号码最多注册两个用户'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            else:
                is_new = 1
                username = info.phone + 'xs%s' % ('1' if len(mubs) == 1 else '')
                self.add_school_user(info.name, 1, info.phone, info.subject, info.unit, unit_id)

    def process_batch_stu_change(self):
        for l in self.file_reader_stu():
            to_unit_flag = False
            if l == [u'', u'', u'']:
                continue
            try:
                if isinstance(l[0], float):
                    to_unit_flag = True
                elif len(l[0]) != 4:
                    to_unit_flag = True
            except Exception, e:
                import traceback
                traceback.print_exc()

            info = self.pack_info('stu_add', l)
            if l[0] == u'':
                op_info = u'班级不能为空'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            if to_unit_flag:
                op_info = u'班级信息错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            if not all([info.get(x) for x in info]):
                op_info = u'信息不能为空'
                info.subject = ''
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            if not is_chinese_word(info.name):
                op_info = u'姓名只能是2-5个汉字'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            info.subject = ''
            phone_tmp = ''
            try:
                phone_tmp += str(int(info.phone))
            except Exception, e:
                phone_tmp = info.phone
            info.phone = phone_tmp
            unit_name_info = info.unit
            if not isinstance(unit_name_info, tuple):
                op_info = u'班级信息错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            if not yidong_mobile_pattern.match(info.phone):
                op_info = u'手机号码必须为河南移动号码'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            unit_id = self.find_unit(*unit_name_info)

            # 重新在管理员系统显示班级
            # self.re_show_unit(unit_id)

            if not unit_id:
                op_info = u'班级错误'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            real_name = info.name
            mubs = self.find_mub_from_phone(info.phone, user_type=1)
            account = [m for m in mubs if m.real_name == real_name]

            if account:
                is_new = 0
                u = account[0]
                user_id, username = u.user_id, u.username
            elif len(mubs) >= 2:
                op_info = u'一个手机号码最多注册两个用户'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            else:
                is_new = 1
                username = info.phone + 'xs%s' % ('1' if len(mubs) == 1 else '')
                user_id = self.add_school_user(info.name, 1, info.phone, info.subject, info.unit, unit_id)

            if account:
                is_new = 0
                u = account[0]
                user_id, username = u.user_id, u.username
            elif len(mubs) > 1:
                op_info = u'一个学生最多两个账号'
                self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
                continue
            else:
                is_new = 1
                username = info.phone + 'xs%s' % ('1' if len(mubs) == 1 else '')
                user_id = self.add_school_user(info.name, 1, info.phone, info.subject, info.unit, unit_id)
            from_unit_id = 0
            if_out = 0
            old_unit_id = 0
            op_info = u''
            if not is_new:
                user_units = self.find_user_units(user_id)
                if user_units:
                    old_unit_id = user_units[0].unit_id
            else:
                op_info += u'创建新用户,'
            if not str(old_unit_id) == str(unit_id):
                self.change_unit_(unit_id, info.name, info.phone,old_unit_id)
                op_info += u'换班成功'
                self.save_success(info.phone, info.subject, real_name, to_unit=info.unit, info=op_info)
                if not is_new and old_unit_id:
                    op_info += u'退出班级[%s],加入班级[%s],' % (old_unit_id, unit_id)
                else:
                    op_info += u'加入班级[%s],' % unit_id
            else:
                op_info += u'已在要换的班级,'
                # self.save_fail(info.phone, info.subject, info.name, to_unit=info.unit, info=op_info)
            op_info += u'换班成功'

            self.save_success(info.phone, info.subject, real_name, to_unit=info.unit, info=op_info)

    def change_unit(self, user_id, from_unit_id, unit_id, subject_id, real_name, phone):
        # 功能说明：老师调整班级
        try:
            add_school_user_name = self.add_school_user_name
            add_school_user_school_id = self.school_id
            add_school_user_id = self.add_school_user_id
            school_name = self.add_school_name
            type = 3
            date_time = str(int(time.time()))
            select_sql = """select id from tbkt_user.auth_user where sid=%s and phone='%s' and real_name='%s' and type=3;""" % (subject_id, phone, real_name)
            result_id = self.fetchall(select_sql)  # 查找用户id
            select_sql__ = """select province, city, county,unit_class_id,province_id,city_id,county_id from tbkt_ketang.mobile_order_region where school_id=%s limit 1;""" % add_school_user_school_id
            result__ = self.fetchall(select_sql__)[0]  # 查找当前添加者的数据
            if from_unit_id == 0:
                create_sql__ = """INSERT INTO tbkt_ketang.mobile_order_region (province, city, county, school_name,school_id,school_type,
                              unit_class_id,dept_type,is_update,add_date,del_state,user_type,user_id,
                              province_id,city_id,county_id) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');""" % \
                               (result__[0], result__[1], result__[2],school_name, add_school_user_school_id, 0, unit_id, 0, 0, date_time, 0, type, result_id[0][0], result__[4], result__[5], result__[6])
                self.execute(create_sql__)  # 添加对应班级
            else:
                update_sql = """update tbkt_ketang.mobile_order_region set unit_class_id=%s where user_id=%s and unit_class_id=%s;""" % (unit_id, user_id, from_unit_id)
                self.execute(update_sql)  # 更新用户班级
            create_sql = """INSERT INTO tbkt_ketang.mp_exchange_class (user_id,operate_type,sch_id,sch_name,unit_class_id,
                              old_sch_id,old_sch_name,old_unit_class_id,add_user_id,add_username,add_date) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');""" % \
                         (user_id, 2, add_school_user_school_id, school_name, unit_id,add_school_user_school_id, school_name, from_unit_id, add_school_user_id, add_school_user_name, date_time)
            self.execute(create_sql)
        except Exception as e:
            import traceback
            traceback.print_exc()
            return 0, 0

    def change_unit_(self, unit_id, real_name, phone, old_unit_id):
        # 功能说明：       学生调整班级
        try:
            add_school_user_name = self.add_school_user_name
            add_school_user_school_id = self.school_id
            add_school_user_id = self.add_school_user_id
            school_name = self.add_school_name
            type = 1
            date_time = str(int(time.time()))
            select_sql = """select id from tbkt_user.auth_user where phone='%s' and real_name='%s' and type=1;""" % (phone, real_name)
            result_id = self.fetchall(select_sql)  # 查找用户id
            if old_unit_id == 0:
                from_unit = 0
            else:
                from_unit = old_unit_id
            if result_id:
                delete_sql = """
                              delete from tbkt_ketang.mobile_order_region where user_id = %s;
                                 """ % (result_id[0][0])  # 删除班级
                self.execute(delete_sql)
                select_sql__ = """select province, city, county,unit_class_id,province_id,city_id,county_id  from tbkt_ketang.mobile_order_region where school_id=%s limit 1;""" % \
                               add_school_user_school_id
                result__ = self.fetchall(select_sql__)[0]  # 查找当前添加者的数据
                create_sql__ = """INSERT INTO tbkt_ketang.mobile_order_region (province, city, county, school_name,school_id,school_type,
                              unit_class_id,dept_type,is_update,add_date,del_state,user_type,user_id,
                              province_id,city_id,county_id) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');""" % \
                               (result__[0], result__[1], result__[2],school_name, add_school_user_school_id, 0, unit_id,0, 0, date_time, 0, type, result_id[0][0], result__[4], result__[5], result__[6])
                self.execute(create_sql__)  # 添加对应班级
                create_sql = """INSERT INTO tbkt_ketang.mp_exchange_class (user_id,operate_type,sch_id,sch_name,unit_class_id,
                                  old_sch_id,old_sch_name,old_unit_class_id,add_user_id,add_username,add_date) VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');""" % \
                             (result_id[0][0], 2, add_school_user_school_id, school_name, unit_id,
                              add_school_user_school_id, school_name, from_unit, add_school_user_id, add_school_user_name, date_time)
                self.execute(create_sql)
            else:
                print 'no this user data'
        except Exception as e:
            import traceback
            traceback.print_exc()
            return 0, 0

    def run(self):
        type_table = {1: self.process_batch_tea_change, 2: self.process_batch_tea_add,
                      3: self.process_batch_stu_change, 4: self.process_batch_stu_add}
        func = type_table.get(self.batch_type)
        try:
            func()
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.process_status = 2


class FetchJob(BaseWorker):
    def __init__(self, _db_name):
        self.sleep_time = 10
        self.batch_id = 0
        super(FetchJob, self).__init__(_db_name)

    def get_user_info(self, user_id):
        u_sql = """
            SELECT
                id,
                school_id,
                username,
                school_name
            FROM
                tbkt_manage.school_auth_user
            WHERE
                id = %s
        """ % user_id
        result = self.fetchone(u_sql)
        return result

    def get_job(self):
        g_sql = """
        select file_url, user_id, `type`, id from tbkt_manage.modify_log where status=0
        order by add_time limit 1;
        """
        result = self.fetchone(g_sql)
        if not result:
            return None
        file_url = PREFIX + result[0]
        user_id = int(result[1])
        op_type = int(result[2])
        batch_id = int(result[3])
        self.batch_id = batch_id
        user_result = self.get_user_info(user_id)
        if not user_result:
            return None
        school_id = int(user_result[1])
        username = user_result[2]
        school_name = user_result[3]
        return Struct({"file_url": file_url, 'user_id': user_id, 'type': op_type,
                       'username': username, 'school_id': school_id, 'batch_id': batch_id,'school_name':school_name})

    def update_status(self, status):
        us_sql = """
        update tbkt_manage.modify_log set status=%s where id = %s;
        """ % (status, self.batch_id)
        self.execute(us_sql)
        return True

    def start(self):
        while 1:
            print "read the file, if have go else sleep"
            record = self.get_job()
            if record:
                print "start the process"
                t1 = time.time()
                s = SchoolOperate(record.school_id, record.user_id, record.username, record.school_name, record.file_url, record.type,
                                  record.batch_id, db_name)
                s.run()
                self.update_status(s.process_status)
                t2 = time.time()
                print "this process end, and use time:%s" % (t2 - t1)
            else:
                print "sorry, no file, sleep 10s, then go on"
                # 无任务, 则暂停一段时间后重新获取
                time.sleep(self.sleep_time)


if __name__ == "__main__":
    db_name = 'tbkt_ketang'
    f = FetchJob(db_name)
    f.start()

elif __name__ == '__builtin__':
    print '__builtin__'
    db_name = 'tbkt_ketang'
    f = FetchJob(db_name)
    reactor.callInThread(f.start)
    application = service.Application('tbkt_school')
