#!coding=utf8
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
import MySQLdb


class Struct(dict):
    """
    - 为字典加上点语法. 例如:
    >>> o = Struct({'a':1})
    >>> o.a
    >>> 1
    >>> o.b
    >>> None
    """

    def __init__(self, dictobj={}):
        self.update(dictobj)

    def __getattr__(self, name):
        # Pickle is trying to get state from your object, and dict doesn't implement it.
        # Your __getattr__ is being called with "__getstate__" to find that magic method,
        # and returning None instead of raising AttributeError as it should.
        if name.startswith('__'):
            raise AttributeError
        return self.get(name)

    def __setattr__(self, name, val):
        self[name] = val

    def __delattr__(self, name):
        self.pop(name, None)

    def __hash__(self):
        return id(self)


def transaction(f):
    "事务修饰器, 函数完成后关闭连接"

    def wrap(self, *args, **kw):
        if self.conn:
            self.conn.close()
        self.conn = self.create_connection(self.conn_name)
        result = None
        try:
            result = f(self, *args, **kw)
        finally:
            self.conn.close()
            self.conn = None
        return result

    return wrap


class BaseWorker(object):
    def __init__(self, conn_name=''):
        self.conn_name = conn_name
        self.conn = None

    def get_connection_args(self, name):
        "name: 130, 76, 122, local, linux, dawang"
        if name == '130':
            return dict(
                host='192.168.7.250',
                db='tbkt',
                user='dba_user',
                passwd='tbkt123456',
                charset="utf8"
            )
        elif name == '76':
            return dict(
                host='122.114.40.76',
                db='tbkt',
                user='renwanxing',
                passwd='renwanxing60279052',
                charset="utf8"
            )
        elif name == '122':
            return dict(
                host='116.255.220.112',
                db='tbkt',
                user='wangchenguang',
                passwd='wangchenguang8393',
                charset="utf8"
            )
        else:
            from config import *
            return dict(
                host=DB_HOST,
                db=DB_NAME,
                user=DB_UID,
                passwd=DB_PWD,
                charset="utf8"
            )

    def create_connection(self, name=''):
        args = self.get_connection_args(name or self.conn_name)
        conn = MySQLdb.connect(**args)
        return conn

    def execute(self, sql, args=None):
        cur = self.conn.cursor()
        r = cur.execute(sql, args)
        cur.close()
        self.conn.commit()
        return r

    def fetchone(self, sql):
        cur = self.conn.cursor()
        cur.execute(sql)
        row = cur.fetchone()
        cur.close()
        return row

    def fetchall(self, sql):
        cur = self.conn.cursor()
        cur.execute(sql)
        rows = cur.fetchall()
        cur.close()
        return rows

    def fetchone_dict(self, sql):
        cursor = self.conn.cursor()
        cursor.execute(sql)
        desc = cursor.description
        row = cursor.fetchone()
        cursor.close()
        if not row:
            return {}
        row = Struct(zip([col[0] for col in desc], row))
        return row

    def fetchall_to_dict(self, sql):
        cursor = self.conn.cursor()
        cursor.execute(sql)
        desc = cursor.description
        descs = [col[0] for col in desc]
        rows = [
            Struct(zip(descs, row))
            for row in cursor.fetchall()
            ]
        cursor.close()
        return rows

    def executemany(self, sql, args):
        cursor = self.conn.cursor()
        cursor.executemany(sql, args)
        cursor.close()
        self.conn.commit()

    @transaction
    def test(self, x):
        print 'test', x


class InfoDB(BaseWorker):
    def __init__(self, db, conn_name=''):
        super(InfoDB, self).__init__(conn_name)
        self.db = db
        self.conn = self.create_connection(self.conn_name)

    @property
    def tables(self):
        self.execute('use %s' % self.db)
        t_sql = "show tables;"
        rows = self.fetchall(t_sql)
        tables = [r[0] for r in rows]
        return tables

    def table_info(self, table):
        t_info_sql = "desc %s.%s;" % (self.db, table)
        rows = self.fetchall(t_info_sql)
        result = rows
        return result


COMPARE_DB = ['tbkt', 'tbkt_web']
COMPARE_DB = ['tbkt']


def compare_db(d1, d2, force=False):
    def _compare(s1, s2, isiter=False):
        if isiter:
            s1 = set(list(s1))
            s2 = set(list(s2))
        if s1 == s2:
            return True
        else:
            return False

    tables1 = set(d1.tables)
    tables2 = set(d2.tables)
    TABLE_EQUAL = False
    if set(tables1) == set(tables2):
        TABLE_EQUAL = True
        print "\nTable name and num in '%s' and '%s' " % (d1.conn_name, d2.conn_name) + " are equal\n"
    else:
        if (tables1 - tables2):
            print "Those table in %s but not in %s" % (d1.conn_name, d2.conn_name)
            print "%s" % (tables1 - tables2)
        if (tables2 - tables1):
            print "Those table in %s but not in %s" % (d2.conn_name, d1.conn_name)
            print "%s" % (tables2 - tables1)
    print "-" * 20 + "check table end" + "-" * 20
    if TABLE_EQUAL or force:
        for table in tables1 & tables2:
            r = _compare(d1.table_info(table), d2.table_info(table),True)
            if not r:
                print "\nTable info `%s` not equal between conn %s and conn %s" % (table, d1.conn_name, d2.conn_name)
            else:
                print ".",
        print "\n"
    print "-" * 20 + "check table for '%s' and '%s' info end" % (d1.conn_name, d2.conn_name) + "-" * 20


if __name__ == '__main__':
    for db in COMPARE_DB:
        db1 = InfoDB(db=db, conn_name='130')
        db2 = InfoDB(db=db, conn_name='76')
        compare_db(db1, db2, True)
