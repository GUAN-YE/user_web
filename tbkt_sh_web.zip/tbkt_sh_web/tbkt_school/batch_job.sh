#! /usr/bin/env sh  
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/batch_job.py
logfile=/var/log/batch_job.log
case $1 in  
    start)  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/batch_job.pid --logfile=$logfile
        ;;  
    stop)  
        kill -9 `cat /var/run/batch_job.pid`
        ;;  
    restart)  
        kill -9 `cat /var/run/batch_job.pid`
        sleep 1  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/batch_job.pid --logfile=$logfile
        ;;  
    log)  
        tail -f $logfile
        ;;  
    *)  
        echo "Usage: ./batch_job.sh start | stop | restart | log"
        ;;  
esac  
