# coding: utf-8
from db import Hub
import MySQLdb

db = Hub(MySQLdb)
databases = ['tbkt_com', 'tbkt_ketang', 'tbkt_user', 'tbkt_shuxue', 'tbkt_yingyu', 'tbkt_yuwen','tbkt_active', 'tbkt_weixin']


def get_db(args):
    # 获取不同环境数据库连接
    # 默认本地250
    port = 3306

    host = '122.114.40.76'
    user = 'renwanxing'
    password = 'ohStjN6DKXqdfBAfhGzdz'

    # host = '192.168.0.111'
    # user = 'duzuyong'
    # password = 'ohStjN6DK$XqBAfhGzdz'

    # 阿里云数据库配置
    # host = 'rm-2ze7fsacj5q360kt7o.mysql.rds.aliyuncs.com'
    # host = 'rm-2ze7fsacj5q360kt7.mysql.rds.aliyuncs.com'
    # user = 'tbkt_sh_user'
    # password = 'shSCriPT@!2017TbKt'


    # host = '122.114.40.76'
    # user = 'renwanxing'
    # password = 'ohStjN6DKXqdfBAfhGzdz'

    # host = 'rm-2zekkuf62c6477n70o.mysql.rds.aliyuncs.com'
    # user = 'wangshicheng'
    # password = 'shicheng@tbkt2017!'

    for table in databases:
        db.add_pool(table,
                    host=host,
                    port=port,
                    user=user,
                    passwd=password,
                    db=table,
                    charset='utf8',
                    autocommit=True,
                    pool_size=16,
                    wait_timeout=29)
    return db
