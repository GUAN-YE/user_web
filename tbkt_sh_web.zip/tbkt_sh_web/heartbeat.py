#! /usr/bin/env python
#coding=utf8
import xmlrpclib


def heartbeat(mname, desc, interval=600, sh_path=''):
    rpc_url = 'http://192.168.0.71:9801'
    try:
        project_dir = '/home/sh'
        project_name = 'tbktsms1.0'
        service = xmlrpclib.ServerProxy(rpc_url)
        params = {}
        params['mname'] = '%s-%s' % (project_name, mname)
        params['interval'] = interval
        params['desc'] = '%s-%s' % (project_name, desc)

        # 远程重启配置参数
        params['sh_path'] = '%s/%s/%s' % (project_dir, project_name, sh_path)
        params['sh_host'] = ''
        params['sh_password'] = ''
        params['sh_port'] = ''

        service.monitor(params)
    except Exception, e:
        print 'heartbeat-%s-err--%s' % (rpc_url, e)
        pass

            
if __name__ == "__main__":
    print 'heartbeat'
    # 发起心跳检测
    heartbeat(mname='handlerREPORTSTATUS', desc='短信状态报告转发程序')
