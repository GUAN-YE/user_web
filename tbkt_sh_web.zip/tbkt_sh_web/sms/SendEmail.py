# coding=utf-8
import smtplib  
import email
import logging, inspect
from email.message import Message  
from email.mime.multipart import MIMEMultipart  
from email.mime.text import MIMEText  
from email.mime.image import MIMEImage  

EMAIL_ADDRESS_LIST = []

# 发送服务器信息  
smtpserver = 'smtp.exmail.qq.com'
smtpuser = 'baojing@tbkt.cn'
smtppass = 'Tbkt2016!'
smtpport = '465'

log = logging.getLogger(__name__)


def login():  
    '''
    发件人登录到服务器  
    '''  
    # print smtpserver,smtpport
    server = smtplib.SMTP_SSL(smtpserver, smtpport)
    # print server
    server.ehlo()    
    server.login(smtpuser,smtppass)   
    # print server
    return server  


def sendTextEmail(toAdd, subject, content):
    '''  
        功能：发送纯文本邮件  
        参数说明：  
        toAdd:收件人E-mail地址    类型：list  
        subject:主题，类型:string  
        content:邮件内容    类型：string  
        fromAdd:发件人，默认为服务器用户  
        返回值：True/False  
    '''  
    result = False  
    server = login()  
    msg = Message()  
    msg['Mime-Version'] = '1.0'
    msg['From'] = smtpuser
    msg['To'] = toAdd
    msg['Subject'] = subject    
    msg['Date'] = email.Utils.formatdate()          # curr datetime, rfc2822
    msg.set_payload(content)    
    try:        
        server.sendmail(smtpuser, toAdd, str(msg))   # may also raise exc
        result = True  
    except Exception, e:
        log.error("%s:%s" % (inspect.stack()[0][3], e))
          
    return result  
  
  
def sendEmail(toAdd, subject, html):
    '''  
    发送html邮件
    '''  
    result = False  
    try:
        msgRoot = MIMEMultipart('ralated')  
        msgRoot['Subject'] = subject    
        msgRoot['From'] = smtpuser    
        msgRoot['To'] = toAdd    
        msgRoot.preamble = 'This is a multi-part message in MIME format.'   
        msgAlternative = MIMEMultipart('alternative')    
        msgRoot.attach(msgAlternative)  
        # 设定HTML信息
        msgText = MIMEText(html, 'html', 'utf-8')    
        msgAlternative.attach(msgText)  
        # 设定内置图片信息
        # fp = open('test.jpg', 'rb')
        # msgImage = MIMEImage(fp.read())
        # fp.close()
        # msgImage.add_header('Content-ID', '<image1>')
        # msgRoot.attach(msgImage)
        # 发送邮件, 邮箱端口使用25
        smtp = smtplib.SMTP(smtpserver, 25)
        smtp.login(smtpuser, smtppass)    
        smtp.sendmail(smtpuser, toAdd, msgRoot.as_string())    
        smtp.quit()    
        result = True  
    except Exception, e:
        import traceback
        traceback.print_exc()
        log.error("%s:%s" % (inspect.stack()[0][3], e))
        result = False  
          
    return result  


def sendMail(toAdds, subject, html, type=2):
    """
    功能        发送邮件
    -----------------------------------
    添加人          添加时间           作用
    -----------------------------------
    杜祖永           2011-11-07   更新下行短信状态报告
    参数说明
    toAdds    接收邮件列表，格式[,,...]
    subject   主题
    html      内容
    type      1、文本邮件，2、html邮件
    """
    try:
        toAdds = toAdds or EMAIL_ADDRESS_LIST
        for addr in toAdds:
            if type == 1:
                flag = sendTextEmail(addr, subject, html)
            else:
                flag = sendEmail(addr, subject, html)
            log.info('sendMail= %s, %s, %s' % (flag, addr, subject))
    except Exception, e:
        log.error("%s:%s" % (inspect.stack()[0][3], e))


if __name__ == '__main__':  
    list_addr = ['281796995@qq.com','duzuyong@tbkt.cn']
    sendMail(list_addr, '测试标题', '测试内<br/>容dd', type=2)

