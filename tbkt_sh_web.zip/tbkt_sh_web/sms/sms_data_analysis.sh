#! /usr/bin/env sh
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/sms_data_analysis.py
logfile=/var/log/sms_analysis_data.log
case $1 in
    start)
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/sms_data_analysis1.pid --logfile=$logfile
        ;;
    stop)
        kill -9 `cat /var/run/sms_data_analysis1.pid`
        ;;
    restart)
        kill -9 `cat /var/run/sms_data_analysis1.pid`
        sleep 1
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/sms_data_analysis1.pid --logfile=$logfile
        ;;
    log)
        tail -f $logfile
        ;;
    *)
        echo "Usage: ./sms_data_analysis.sh start | stop | restart | log"
        ;;
esac