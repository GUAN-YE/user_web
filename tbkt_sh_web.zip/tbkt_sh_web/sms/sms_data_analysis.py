# coding:utf-8
import re
import os
import sys
import time
import MySQLdb
import datetime
from retrying import retry
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
# 短信数据库数据读取链接
DB_QUERY_HOST = "218.206.202.49"
DB_QUERY_USER = "mobile_gw"
DB_QUERY_PWD = "tbkt60279052"
DB_QUERY_NAME = "ketang_sms"
DB_QUERY_PORT = 3307
# 短信数据库数据写入链接
DB_INSERT_HOST = "218.206.202.49"
DB_INSERT_USER = "hn_mt_user"
DB_INSERT_PWD = "MobileMt@ha2018!"
DB_INSERT_NAME = "tbkt_mt"
DB_INSERT_PORT = 3306


def get_query_conn():
    """
    功能:建立短信库的mysql连接
    """
    conn = MySQLdb.connect(host=DB_QUERY_HOST,
                           db=DB_QUERY_NAME,
                           user=DB_QUERY_USER,
                           passwd=DB_QUERY_PWD,
                           port=DB_QUERY_PORT,
                           charset="utf8")
    return conn


def get_insert_conn():
    """
    功能:建立短信库的mysql连接
    """
    conn = MySQLdb.connect(host=DB_INSERT_HOST,
                           db=DB_INSERT_NAME,
                           user=DB_INSERT_USER,
                           passwd=DB_INSERT_PWD,
                           port=DB_INSERT_PORT,
                           charset="utf8")
    return conn


@retry()
def fetch_one(sql):
    """
    sql查询单条方法
    """
    print "创建单条数据查询链接"
    conn = get_query_conn()
    cur = conn.cursor()
    cur.execute(sql)
    r = cur.fetchone()
    cur.close()
    conn.close()
    return r


@retry()
def fetch_all(sql):
    """
    sql查询多条方法
    """
    print "创建多条数据查询链接"
    conn = get_query_conn()
    cur = conn.cursor()
    cur.execute(sql)
    r = cur.fetchall()
    cur.close()
    conn.close()
    return r


@retry()
def execute(sql):
    """
    sql执行方法
    """
    print "创建数据库执行链接"
    conn = get_insert_conn()
    cur = conn.cursor()
    r = cur.execute(sql)
    conn.commit()
    cur.close()
    conn.close()
    return r


def date_to_unix(obj_value, add=0):
    """
    功能: 把时间字符串转换为时间戳并返回
    ---------------------------------
    接收参数类型: '20180326', '2018-03-26', '2018-03-26 18:00:00', datetime.datetime格式
    ---------------------------------------------------------------------------------
    修改:宋国洋   添加多参数类型的转换,且非datetime格式的数据只精确到天,datetime格式精确到秒
    """
    if isinstance(obj_value, datetime.datetime) or isinstance(obj_value, str) or isinstance(obj_value, unicode):
        if isinstance(obj_value, datetime.datetime):
            if add > 0:
                obj_value += datetime.timedelta(days=add)
            time_stamp = int(time.mktime(obj_value.timetuple()))
        else:
            # 只获取字符串中的数字
            string_obj = ""
            for st in re.findall(r'\d', obj_value):
                string_obj += st
            if len(string_obj) < 8:
                raise ValueError("illegal param")
            y, m, d = string_obj[:4], string_obj[4:6], string_obj[6:8]
            t_date = datetime.date(int(y), int(m), int(d))
            if add > 0:
                t_date += datetime.timedelta(days=add)
            time_stamp = int(time.mktime(t_date.timetuple()))
        return time_stamp
    else:
        raise ValueError("param type must be str or datetime.datetime")


class GetSmsData(object):
    @staticmethod
    def get_mt_data(date1, date2):
        """
        获取短信详情表的总数
        -------------------
        维度为每个小时的数据
        -------------------
        参数为时间戳格式
        """
        try:
            print "获取短信详情表的总数--每小时"
            sql = """SELECT COUNT(1) FROM (SELECT redis_id FROM mobile_mt WHERE add_date BETWEEN %s AND %s 
            GROUP BY redis_id) AS t;""" % (date1, date2)
            data_mt = fetch_one(sql)
            mt_num = data_mt[0] if data_mt else 0
            return mt_num
        except Exception as e:
            print e

    @staticmethod
    def get_submit_data(date1, date2):
        """
        获取向移动提交的数据总数
        -------------------
        维度为每个小时的数据
        -----------------
        参数为时间格式
        """
        try:
            print "获取向移动提交的数据总数--每小时"
            sql = """SELECT COUNT(1) FROM (SELECT redis_id FROM mt_submit WHERE submit_date BETWEEN '%s' AND '%s' 
            GROUP BY redis_id) AS t;""" % (date1, date2)
            data_submit = fetch_one(sql)
            submit_num = data_submit[0] if data_submit else 0
            return submit_num
        except Exception as e:
            print e

    @staticmethod
    def get_response_data(date1, date2):
        """
        获取移动响应的数据总数
        -------------------
        维度为每个小时的数据
        -----------------
        参数为时间格式
        """
        try:
            print "获取移动响应的数据总数--每小时"
            sql = """SELECT COUNT(1) FROM (SELECT redis_id FROM mt_resp WHERE resp_date BETWEEN '%s' AND '%s' 
            GROUP BY redis_id) AS t;""" % (date1, date2)
            data_resp = fetch_one(sql)
            resp_num = data_resp[0] if data_resp else 0
            return resp_num
        except Exception as e:
            print e

    @staticmethod
    def get_report_data(date1, date2):
        """
        获取状态报告的数据总数
        -------------------
        维度为每个小时的数据
        -----------------
        参数为时间格式
        """
        try:
            print "获取状态报告的数据总数--每小时"
            sql = """SELECT COUNT(1) FROM (SELECT redis_id FROM mt_report WHERE report_date BETWEEN '%s' AND '%s' 
            GROUP BY redis_id) AS t;""" % (date1, date2)
            data_rep = fetch_one(sql)
            rep_num = data_rep[0] if data_rep else 0
            return rep_num
        except Exception as e:
            print e

    @staticmethod
    def get_report_all(date1, date2):
        """
        获取状态报告的数据总数
        -------------------
        维度为每天的数据
        -----------------
        参数为时间格式
        """
        try:
            print "获取状态报告的数据总数--每天"
            sql = """SELECT COUNT(1) FROM (SELECT redis_id FROM mobile_mt WHERE report_date BETWEEN '%s' AND '%s' 
            GROUP BY redis_id) AS t;""" % (date1, date2)
            data_rep = fetch_one(sql)
            rep_num = data_rep[0] if data_rep else 0
            return rep_num
        except Exception as e:
            print e

    @staticmethod
    def get_mt_all(date1, date2):
        """
        获取短信详情表的总数
        -------------------
        维度为每天的数据
        -------------------
        参数为时间戳格式
        """
        try:
            print "获取短信详情表的总数--每天"
            sql = """SELECT COUNT(1) FROM (SELECT redis_id FROM mobile_mt WHERE 
            add_date BETWEEN %s AND %s GROUP BY redis_id) AS t""" % (date1, date2)
            data_mt = fetch_one(sql)
            mt_num = data_mt[0] if data_mt else 0
            return mt_num
        except Exception as e:
            print e

    @staticmethod
    def get_mt_ok(date1, date2):
        """
        获取发送成功的短信总数
        -------------------
        维度为每天的数据
        -------------------
        参数为时间戳格式
        """
        try:
            print "获取发送成功的短信总数--每天"
            sql = """SELECT COUNT(1) FROM (SELECT redis_id FROM mobile_mt WHERE status=0 AND 
            add_date BETWEEN %s AND %s GROUP BY redis_id) AS t;""" % (date1, date2)
            data_mt = fetch_one(sql)
            mt_num = data_mt[0] if data_mt else 0
            return mt_num
        except Exception as e:
            print e

    @staticmethod
    def get_mt_fail(date1, date2):
        """
        获取发送失败的短信总数
        -------------------
        维度为每天的数据
        -------------------
        参数为时间戳格式
        """
        try:
            print "获取发送失败的短信总数--每天"
            sql = """SELECT COUNT(1) FROM (SELECT redis_id FROM mobile_mt WHERE status=1 AND 
            add_date BETWEEN %s AND %s GROUP BY redis_id) AS t;""" % (date1, date2)
            data_mt = fetch_one(sql)
            mt_data = data_mt[0] if data_mt else 0
            return mt_data
        except Exception as e:
            print e

    @staticmethod
    def get_mt_detail(date1, date2):
        """
        获取短信明细数据
        -------------------
        维度为每天的数据
        -------------------
        参数为时间戳格式
        """
        try:
            print "获取发送短信的数据明细--每天"
            sql = """SELECT t.report_code,COUNT(1) FROM (SELECT report_code,redis_id FROM mobile_mt WHERE
            add_date BETWEEN %s AND %s GROUP BY report_code,redis_id) AS t GROUP BY t.report_code;""" % (date1, date2)
            data_mt = fetch_all(sql)
            mt_data = [[obj[0], obj[1]] for obj in data_mt if data_mt]
            return mt_data
        except Exception as e:
            print e

    @staticmethod
    def get_no_resp(date1, date2):
        """
        获取未收到状态报告短信总数
        -------------------
        维度为每天的数据
        -------------------
        参数为时间戳格式
        """
        try:
            print "获取未收到状态报告的短信总数--每天"
            sql = """SELECT COUNT(1) FROM (SELECT redis_id FROM mobile_mt WHERE status=-1 AND add_date BETWEEN %s AND %s
                      GROUP BY redis_id) AS t;""" % (date1, date2)
            data_no_resp = fetch_one(sql)
            no_resp = data_no_resp[0] if data_no_resp else 0
            return no_resp
        except Exception as e:
            print e

    @staticmethod
    def get_no_submit(date1, date2):
        """
        获取为提交网关的数据
        -------------------
        维度为每天的数据
        -------------------
        参数为时间戳格式
        """
        sql = """SELECT COUNT(1) FROM
        (SELECT m.redis_id FROM mobile_mt m LEFT JOIN mt_submit s ON m.redis_id=s.redis_id 
        WHERE m.add_date>=%s AND m.add_date<%s AND s.id IS NULL AND m.status<0 GROUP BY m.redis_id) AS t;
        """ % (date1, date2)
        data_no_submit = fetch_one(sql)
        no_submit = data_no_submit[0] if data_no_submit else 0
        return no_submit

    @staticmethod
    def get_no_response(date1, date2):
        """
        获取未收到网关响应的数据
        -------------------
        维度为每天的数据
        -------------------
        参数为时间戳格式
        """
        sql = """SELECT COUNT(1) FROM
            (SELECT m.redis_id FROM mobile_mt m LEFT JOIN mt_resp s ON m.redis_id=s.redis_id 
            WHERE m.add_date>=%s AND m.add_date<%s AND s.id IS NULL AND m.status<0 GROUP BY m.redis_id) AS t;
            """ % (date1, date2)
        data_no_response = fetch_one(sql)
        no_response = data_no_response[0] if data_no_response else 0
        return no_response

    def get_hour_data(self, date_now):
        """
        处理维度为每小时的数据
        """
        try:
            print "开始处理每小时的数据"
            end_date = date_now.replace(minute=0, second=0, microsecond=0)
            end_unix = date_to_unix(end_date)
            begin_date = end_date - datetime.timedelta(hours=1)
            begin_unix = date_to_unix(begin_date)
            # 获取短信详情表的总数
            mt_num = self.get_mt_data(begin_unix, end_unix)
            # 获取向移动提交的数据总数
            submit_num = self.get_submit_data(begin_date, end_date)
            # 获取移动响应的数据总数
            resp_num = self.get_response_data(begin_date, end_date)
            # 获取状态报告的数据总数
            rep_num = self.get_report_data(begin_date, end_date)
            hour_dict = {"mt_num": int(mt_num), "submit_num": submit_num, "resp_num": resp_num, "rep_num": rep_num}
            self.insert_hour_data(hour_dict, begin_date)
        except Exception as e:
            print e

    def get_day_data(self, date_now):
        """
        处理维度为每天的数据
        """
        try:
            print "开始处理每天的数据明细"
            date_day = date_now.replace(hour=0, minute=0, second=0, microsecond=0)
            day_unix = date_to_unix(date_day)
            date_last = date_day - datetime.timedelta(days=1)
            last_unix = date_to_unix(date_last)
            # 获取每日状态报告的数据明细
            mt_detail = self.get_mt_detail(last_unix, day_unix)
            self.insert_day_data(mt_detail, date_last)
            # 获取未提交和响应数据
            no_submit = self.get_no_submit(last_unix, day_unix)
            no_response = self.get_no_response(last_unix, day_unix)
            # 写入未提交和响应数据
            self.insert_day_no(no_submit, no_response, date_last)
        except Exception as e:
            print e

    @staticmethod
    def insert_hour_data(h_dict, the_date):
        """
        维度为每小时的数据写入
        """
        try:
            print "开始写入每小时的数据", the_date
            # data_day = str(the_date)[:10]
            data_day = "%s%.2d%.2d" % (the_date.year, the_date.month, the_date.day)
            data_hour = the_date.hour
            mt_num = h_dict["mt_num"] if h_dict["mt_num"] else 0
            submit_num = h_dict["submit_num"] if h_dict["submit_num"] else 0
            resp_num = h_dict["resp_num"] if h_dict["resp_num"] else 0
            rep_num = h_dict["rep_num"] if h_dict["rep_num"] else 0
            in_sql = """INSERT INTO sms_hour_data(data_day,data_hour,mt,submit,resp,report,add_date) VALUES (%s,%s,%s,%s,%s,%s,%s);""" \
            % (int(data_day), data_hour, mt_num, submit_num, resp_num, rep_num, int(time.time()))
            execute(in_sql)
        except Exception as e:
            print e

    @staticmethod
    def insert_day_no(no_submit, no_response, date_last):
        try:
            print "开始写入每天未提交的数据", date_last
            # data_day = str(the_date)[:10]
            data_day = "%s%.2d%.2d" % (date_last.year, date_last.month, date_last.day)
            in_sql = """INSERT INTO sms_day_data(data_day,no_submit,no_response,add_date) VALUES (%s,%s,%s,%s);""" \
            % (int(data_day), no_submit, no_response, int(time.time()))
            execute(in_sql)
        except Exception as e:
            print e

    @staticmethod
    def insert_day_data(mt_detail, date_last):
        """
        维度为每天的数据写入和状态明细数据写入
        """
        try:
            print "开始写入每天的明细数据"
            # data_day = str(date_last)[:11]
            data_day = "%s%.2d%.2d" % (date_last.year, date_last.month, date_last.day)
            # 写入每天的明细数据
            de_sql = """INSERT INTO sms_rep_detail(data_day,report_code,rep_num,add_date) VALUES """
            num = 0
            for obj in mt_detail:
                num += 1
                if len(mt_detail) == num:
                    de_sql += """(%s, '%s', %s, %s);""" % (int(data_day), str(obj[0]) if obj[0] else '', int(obj[1]) if obj[1] else 0, int(time.time()))
                    execute(de_sql)
                else:
                    de_sql += """(%s, '%s', %s, %s),""" % (int(data_day), str(obj[0]) if obj[0] else '', int(obj[1]) if obj[1] else 0, int(time.time()))
        except Exception as e:
            print e

    def loop(self):
        """
        循环处理每天和每小时数据
        """
        date_now = datetime.datetime.now().replace(hour=21)
        if date_now.hour == 21:
            # 每天凌晨一点时处理每小时和每天的数据
            print "首先理每小时的数据"
            self.get_hour_data(date_now=date_now)
            print "接着处理每天数据"
            self.get_day_data(date_now=date_now)
            print "每天和每小时数据处理结束休眠一个小时"
        else:
            self.get_hour_data(date_now=date_now)
            print "每小时数据处理结束休眠一个小时"


def start():
    pro = GetSmsData()
    pro.loop()


if __name__ == "__main__":
    try:
        start()
    except Exception as e:
        print e
        start()
