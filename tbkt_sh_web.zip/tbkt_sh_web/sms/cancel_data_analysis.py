# coding:utf-8
import re
import os
import sys
import time
import MySQLdb
import datetime
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
# 短信数据库数据读取链接
DB_QUERY_HOST = "47.93.85.37"
DB_QUERY_USER = "guoyang"
DB_QUERY_PWD = "guoyang@tbkt2017"
DB_QUERY_NAME = "tbkt_ketang"
DB_QUERY_PORT = 3306
# 短信数据库数据写入链接
DB_INSERT_HOST = "122.114.40.76"
DB_INSERT_USER = "renwanxing"
DB_INSERT_PWD = "ohStjN6DKXqdfBAfhGzdz"
DB_INSERT_NAME = "tbkt_ketang"
DB_INSERT_PORT = 3307


def get_query_conn():
    """
    功能:建立短信库的mysql连接
    """
    conn = MySQLdb.connect(host=DB_QUERY_HOST,
                           db=DB_QUERY_NAME,
                           user=DB_QUERY_USER,
                           passwd=DB_QUERY_PWD,
                           port=DB_QUERY_PORT,
                           charset="utf8")
    return conn


def get_insert_conn():
    """
    功能:建立短信库的mysql连接
    """
    conn = MySQLdb.connect(host=DB_INSERT_HOST,
                           db=DB_INSERT_NAME,
                           user=DB_INSERT_USER,
                           passwd=DB_INSERT_PWD,
                           port=DB_INSERT_PORT,
                           charset="utf8")
    return conn


def fetch_one(sql):
    """
    sql查询单条方法
    """
    conn = get_query_conn()
    cur = conn.cursor()
    cur.execute(sql)
    r = cur.fetchone()
    cur.close()
    conn.close()
    return r


def execute(sql):
    """
    sql执行方法
    """
    conn = get_insert_conn()
    cur = conn.cursor()
    r = cur.execute(sql)
    conn.commit()
    cur.close()
    conn.close()
    return r


def date_to_unix(obj_value, add=0):
    """
    功能: 把时间字符串转换为时间戳并返回
    ---------------------------------
    接收参数类型: '20180326', '2018-03-26', '2018-03-26 18:00:00', datetime.datetime格式
    ---------------------------------------------------------------------------------
    修改:宋国洋   添加多参数类型的转换,且非datetime格式的数据只精确到天,datetime格式精确到秒
    """
    if isinstance(obj_value, datetime.datetime) or isinstance(obj_value, str) or isinstance(obj_value, unicode):
        if isinstance(obj_value, datetime.datetime):
            if add > 0:
                obj_value += datetime.timedelta(days=add)
            time_stamp = int(time.mktime(obj_value.timetuple()))
        else:
            # 只获取字符串中的数字
            string_obj = ""
            for st in re.findall(r'\d', obj_value):
                string_obj += st
            if len(string_obj) < 8:
                raise ValueError("illegal param")
            y, m, d = string_obj[:4], string_obj[4:6], string_obj[6:8]
            t_date = datetime.date(int(y), int(m), int(d))
            if add > 0:
                t_date += datetime.timedelta(days=add)
            time_stamp = int(time.mktime(t_date.timetuple()))
        return time_stamp
    else:
        raise ValueError("param type must be str or datetime.datetime")


class GetSmsData(object):
    @staticmethod
    def get_cancel_data(date_now):
        try:
            date_now = date_now.replace(minute=0, second=0, microsecond=0)
            begin_date = date_now - datetime.timedelta(hours=1)
            begin_unix = date_to_unix(begin_date)
            end_unix = date_to_unix(date_now)
            sql = """SELECT 
            COUNT(DISTINCT id) AS c_num,
            SUM(CASE WHEN is_falsedata=1 THEN 1 ELSE 0 END) AS f_num
            FROM tbkt_ketang.mobile_subject_detail_hn WHERE cancel_date 
            BETWEEN %s AND %s AND `code` IN ("A", "B", "C", "D", "E") AND `status`=4;""" % (begin_unix, end_unix)
            data_list = fetch_one(sql)
            # 退订总订单数
            c_num = int(data_list[0]) if data_list else 0
            # 假数据订单数
            f_num = int(data_list[1]) if data_list else 0
            return {"data_day": str(begin_date)[:10], "data_hour": date_now.hour, "c_num": c_num, "f_num": f_num}
        except Exception as e:
            print e

    @staticmethod
    def insert_hour_data(data_dict):
        """
        维度为每天的数据写入和状态明细数据写入
        """
        try:
            print "开始写入每小时的数据"
            data_day = data_dict["data_day"]
            data_hour = data_dict["data_hour"]
            c_num = data_dict["c_num"] if data_dict["c_num"] else 0
            f_num = data_dict["f_num"] if data_dict["f_num"] else 0
            # 写入每天的总数据
            in_sql = """INSERT INTO cancel_hour_data(data_day,data_hour,c_num,f_num) 
            VALUES ('%s',%s,%s,%s);""" % (data_day, data_hour, c_num, f_num)
            execute(in_sql)
        except Exception as e:
            print e

    def loop(self):
        """
        循环处理每天和每小时数据
        """
        date_now = datetime.datetime.now()
        date_new = date_now.replace(month=4, day=1, hour=1, minute=0, second=0, microsecond=0)
        while True:
            if date_new < date_now:
                print "本次数据处理时间:%s时" % date_new.hour
                data_dict = self.get_cancel_data(date_new)
                print "本次写入的数据是:", data_dict
                self.insert_hour_data(data_dict)
                date_new = date_new + datetime.timedelta(hours=1)
            else:
                print "数据写入结束,当前时间为:", date_now
                break


def start():
    pro = GetSmsData()
    pro.loop()


if __name__ == "__main__":
    start()