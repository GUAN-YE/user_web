# coding:utf-8
"""
功能:数据批量导入规则调整
-----------------------
添加人:宋国洋
-----------------------
添加时间:2017-12-28
"""
import time
from db_mysql import db


def insert_data_rule(city_id, county_id, sch_id, sch_name, unit_class_id, phone_number, user_name, user_type):
    """
    :param city_id: 地市ID
    :param county_id: 县区ID
    :param sch_id: 学校ID
    :param sch_name: 学校名称
    :param sch_type: 学校类型
    :param unit_class_id: 班级ID
    :param phone_number: 用户手机号
    :param user_name: 用户姓名
    :param user_type: 用户类型 1-学生,3-教师
    :return: 不做继续处理返回None, 需要继续处理返回True
    """
    try:
        # 根据sch_id获取相应的学校类型
        sch_type = db.tbkt_com.school.get(id=sch_id)['type']
        # 判断用户手机号和姓名是否一致
        user_id = judge_phone_name(phone_number, user_name, user_type)
        if user_id:
            print "用户的手机号和姓名完全一致"
            # 手机号和姓名均一致,用户账号信息不做处理,只需要替换用户的班级数据信息
            # 获取该用户最近添加的班级数据信息
            region_data = db.tbkt_ketang.mobile_order_region.filter(user_id=user_id).select('id').order_by('-add_date').get()
            region_id = region_data['id'] if region_data else ''
            print "更新最近添加用户的班级信息,班级信息的region_id为:", region_id
            # 更新最近添加用户的班级信息,并更新班级数据添加时间
            db.tbkt_ketang.mobile_order_region.filter(id=region_id).update(
                city=city_id,
                county=county_id,
                school_id=sch_id,
                school_name=sch_name,
                school_type=sch_type,
                unit_class_id=unit_class_id,
                add_date=int(time.time())
            )
            # 获取本次更新的用户账号
            username = db.tbkt_user.auth_user.filter(id=user_id).get()['username']
            print "本次更新用户的账号为:", username
            # 更新替换用户信息不继续创建相应的班级和用户数据
            tmp_msg = "更新班级数据,班级ID为:%s" % int(unit_class_id)
            ret_val = None
        else:
            print "用户的手机号和姓名不一致"
            # 用户手机号和姓名不一致
            # 获取该手机号下的账号个数
            user_num = db.tbkt_user.auth_user.filter(phone=phone_number, type=user_type).count()
            print "该手机号下的账号数为:", user_num
            # 根据班级ID获取账号待创建的年级
            if user_num == 1:
                old_user_data = db.tbkt_user.auth_user.filter(phone=phone_number, type=user_type).select('id', 'status').get()
                old_user_id = old_user_data['id'] if old_user_data else ''
                old_user_status = old_user_data['status'] if old_user_data else ''
                if old_user_status == 2:
                    # 如果该账号是禁用账号,直接替换账号的用户信息和账号信息
                    region_data = db.tbkt_ketang.mobile_order_region.filter(user_id=old_user_id).select('id').order_by('-add_date').get()
                    region_id = region_data['id'] if region_data else ''
                    # 更新最近添加用户的班级信息,并更新班级数据添加时间
                    print "更新最近添加用户的班级信息,班级信息的region_id为:", region_id
                    db.tbkt_ketang.mobile_order_region.filter(id=region_id).update(
                        city=city_id,
                        county=county_id,
                        school_id=sch_id,
                        school_name=sch_name,
                        school_type=sch_type,
                        unit_class_id=unit_class_id,
                        add_date=int(time.time())
                    )
                    # 更新用户的账号信息,更换名字,若用户为禁用状态,同时解除禁用
                    print "更新用户的账号信息,更换名字,用户user_id为:", old_user_id
                    db.tbkt_user.auth_user.filter(id=old_user_id).update(
                        real_name=user_name, status=0,
                        last_login=int(time.time())
                    )
                    # 获取本次更新的用户账号
                    username = db.tbkt_user.auth_user.filter(id=old_user_id).get()['username']
                    print "本次更新用户的账号为:", username
                    # 更新替换用户信息不继续创建相应的班级和用户数据
                    tmp_msg = "更新班级数据和用户数据,班级ID为:%s,姓名为:%s" % (int(unit_class_id), user_name)
                    ret_val = None
                else:
                    print "同年级替换,不同年级创建"
                    # 如果用户是有效账号,首先判断用户是否在同年级
                    old_unit_class_data = db.tbkt_ketang.mobile_order_region.filter(user_id=old_user_id).select('unit_class_id')[:]
                    old_unit_class_list = [obj["unit_class_id"] for obj in old_unit_class_data if old_unit_class_data]
                    old_grade_id_data = db.tbkt_com.school_unit_class.filter(id__in=old_unit_class_list).select('grade_id')[:]
                    old_grade_id_list = [obj["grade_id"] for obj in old_grade_id_data if old_grade_id_data]
                    print "该手机号下已存在的用户所在的年级列表:", old_grade_id_list
                    # 获取待创建账号的年级ID
                    new_grade_id = db.tbkt_com.school_unit_class.get(id=unit_class_id)['grade_id']
                    if new_grade_id in old_grade_id_list:
                        # 同年级替换
                        print "存在同年级的用户数据"
                        region_data = db.tbkt_ketang.mobile_order_region.filter(user_id=old_user_id).select('id').order_by('-add_date').get()
                        region_id = region_data['id'] if region_data else ''
                        # 更新最近添加用户的班级信息,并更新班级数据添加时间
                        print "更新最近添加用户的班级信息,班级信息的region_id为:", region_id
                        db.tbkt_ketang.mobile_order_region.filter(id=region_id).update(
                            city=city_id,
                            county=county_id,
                            school_id=sch_id,
                            school_name=sch_name,
                            school_type=sch_type,
                            unit_class_id=unit_class_id,
                            add_date=int(time.time())
                        )
                        # 更新用户的账号信息,更换名字,更新最后登录时间
                        print "更新用户的账号信息,更换名字,用户user_id为:", old_user_id
                        db.tbkt_user.auth_user.filter(id=old_user_id).update(
                            real_name=user_name,
                            last_login=int(time.time())
                        )
                        # 获取本次更新的用户账号
                        username = db.tbkt_user.auth_user.filter(id=old_user_id).get()['username']
                        print "本次更新用户的账号为:", username
                        # 更新替换用户信息不继续创建相应的班级和用户数据
                        tmp_msg = "更新班级数据和用户数据,班级ID为:%s,姓名为:%s" % (int(unit_class_id), user_name)
                        ret_val = None
                    else:
                        # 不同年级直接创建
                        tmp_msg = "创建新的用户账号"
                        ret_val = True
                        username = ""
            elif user_num >= 2:
                ret_val, tmp_msg, username = valid_user_create_rule(city_id, county_id, sch_id, sch_name, sch_type, unit_class_id, phone_number, user_name, user_type)
            else:
                print "该手机号下不存在用户账号,直接创建账号"
                # 如果该手机号下存在用户账号数据,直接创建
                tmp_msg = "创建新的用户账号"
                ret_val = True
                username = ""
        return ret_val, tmp_msg, username
    except Exception as e:
        print e
        import traceback
        traceback.print_exc()


def judge_phone_name(phone_number, user_name, user_type):
    """
    功能:判断用户的手机号和姓名是否一致
    :param phone_number: 用户手机号
    :param user_name: 用户姓名
    :param user_type: 用户类型 1-学生,3-教师
    :return: 一致返回用户ID, 不一致返回None
    """
    try:
        print "执行judge_phone_name方法"
        # 获取用户数据,获取数据且区分用户类型,下面的逻辑处理不再做用户类型区分
        user_data = db.tbkt_user.auth_user.filter(phone=phone_number, type=user_type, status__ne=2).select('id', 'username', 'real_name')[:]
        # 获取用户姓名存在一致的结果
        data_list = []
        for obj in user_data:
            if obj["real_name"] == user_name:
                data_list.append(obj["id"])
        print "用户手机号和姓名一致的数据列表:", data_list
        if data_list:
            id_num = len(data_list)
            if id_num == 1:
                print "用户姓名和手机号一致的只有一个"
                # 手机号和姓名一致账号数=1的数据,直接返回用户ID
                user_id = data_list[0]
            else:
                print "用户姓名和手机号一致的超过一个"
                # 用户手机号和姓名一致账号数>=2的数据处理
                # 获取最近登录的用户ID
                last_user_data = db.tbkt_user.auth_user.filter(id__in=data_list).select('id').order_by('-last_login').get()
                last_user_id = last_user_data['id'] if last_user_data else ''
                # 去除最近登录的用户ID
                data_list.remove(last_user_id)
                # 获取一个用户账号用于替换,获取规则:例如剩余账号为xs,xs1,xs2,获取账号xs的用户账号ID
                user_id = db.tbkt_user.auth_user.filter(id__in=data_list).select('id').order_by('username').get()['id']
            return user_id
        return None
    except Exception as e:
        print e
        import traceback
        traceback.print_exc()


def create_user_account(phone_number):
    """
    功能:创建用户账号
    --------------------------------------
    参数是手机号:phone_number
    --------------------------------------
    返回:学生账号
    --------------------------------------
    说明:调用该方法均说明学生用户最多存在一个账号
    """
    try:
        print "开始生成新的学生账号"
        # 首先获取该手机号下是否已经存在账号
        user_data = db.tbkt_user.auth_user.filter(phone=phone_number, type=1).get()
        if user_data:
            # 获取用户账号
            username = user_data['username']
            # 用户账号的后缀,例如xs后缀是空,xs1后缀是1
            account_order = str(username)[13:]
            if account_order:
                new_username = "%sxs" % phone_number
            else:
                new_username = "%sxs1" % phone_number
        else:
            new_username = "%sxs" % phone_number
        return new_username
    except Exception as e:
        print e


def valid_user_create_rule(city_id, county_id, sch_id, sch_name, sch_type, unit_class_id, phone_number, user_name, user_type):
    """
    功能:根据有效账号数来处理数据
    :param city_id: 地市ID
    :param county_id: 县区ID
    :param sch_id: 学校ID
    :param sch_name: 学校名称
    :param sch_type: 学校类型
    :param unit_class_id:班级ID
    :param phone_number: 用户手机号
    :param user_name: 用户姓名
    :param user_type: 用户类型
    """
    try:
        ret_val, tmp_msg, username = "", "", ""       # 初始化定义
        valid_user_num = db.tbkt_user.auth_user.filter(phone=phone_number, type=user_type, status__ne=2).count()
        if valid_user_num == 1:
            print "有效账号个数只有一个"
            valid_user_data = db.tbkt_user.auth_user.filter(phone=phone_number, type=user_type, status__ne=2).select('id').get()
            valid_user_id = valid_user_data['id'] if valid_user_data else ""
            old_unit_class_data = db.tbkt_ketang.mobile_order_region.filter(user_id=valid_user_id).select('unit_class_id')[:]
            old_unit_class_list = [obj["unit_class_id"] for obj in old_unit_class_data if old_unit_class_data]
            old_grade_id_data = db.tbkt_com.school_unit_class.filter(id__in=old_unit_class_list).select('grade_id')[:]
            old_grade_id_list = [obj["grade_id"] for obj in old_grade_id_data if old_grade_id_data]
            print "该手机号下已存在的用户所在的年级列表:", old_grade_id_list
            # 获取待创建账号的年级ID
            new_grade_id = db.tbkt_com.school_unit_class.get(id=unit_class_id)['grade_id']
            print "用户待创建的年级ID:", new_grade_id
            if new_grade_id in old_grade_id_list:
                print "存在同年级的用户数据"
                region_data = db.tbkt_ketang.mobile_order_region.filter(user_id=valid_user_id).select('id').order_by('-add_date').get()
                region_id = region_data['id'] if region_data else ''
                # 更新最近添加用户的班级信息,并更新班级数据添加时间
                print "更新最近添加用户的班级信息,班级信息的region_id为:", region_id
                db.tbkt_ketang.mobile_order_region.filter(id=region_id).update(
                    city=city_id,
                    county=county_id,
                    school_id=sch_id,
                    school_name=sch_name,
                    school_type=sch_type,
                    unit_class_id=unit_class_id,
                    add_date=int(time.time())
                )
                # 更新用户的账号信息,更换名字
                print "更新用户的账号信息,更换名字,用户user_id为:", valid_user_id
                db.tbkt_user.auth_user.filter(id=valid_user_id).update(
                    real_name=user_name,
                    last_login=int(time.time())
                )
                # 获取本次更新的用户账号
                username = db.tbkt_user.auth_user.filter(id=valid_user_id).get()['username']
                print "本次更新用户的账号为:", username
                # 更新替换用户信息不继续创建相应的班级和用户数据
                tmp_msg = "更新班级数据和用户数据,班级ID为:%s,姓名为:%s" % (int(unit_class_id), user_name)
                ret_val = None
            else:
                print "不存在同年级的用户数据"
                # 获取一个禁用用户账号用于替换,获取规则:例如剩余账号为xs,xs1,xs2,获取账号xs的用户账号ID
                invalid_last_user_data = db.tbkt_user.auth_user.filter(phone=phone_number, type=user_type, status=2).select('id').order_by('username').get()
                invalid_last_user_id = invalid_last_user_data['id'] if invalid_last_user_data else ""
                if invalid_last_user_id:
                    # 替换该账号的用户和班级信息,并解除禁用,更新最后登录时间
                    db.tbkt_user.auth_user.filter(id=invalid_last_user_id).update(
                        real_name=user_name,
                        status=0,
                        last_login=int(time.time())
                    )
                    invalid_region_data = db.tbkt_ketang.mobile_order_region.filter(user_id=invalid_last_user_id).select('id').order_by('-add_date').get()
                    invalid_region_id = invalid_region_data['id'] if invalid_region_data else ''
                    print "更新最近添加用户的班级信息,班级信息的region_id为:", invalid_region_id
                    db.tbkt_ketang.mobile_order_region.filter(id=invalid_region_id).update(
                        city=city_id,
                        county=county_id,
                        school_id=sch_id,
                        school_name=sch_name,
                        school_type=sch_type,
                        unit_class_id=unit_class_id,
                        add_date=int(time.time())
                    )
                    # 获取本次更新的用户账号
                    username = db.tbkt_user.auth_user.filter(id=invalid_last_user_id).get()['username']
                    print "本次更新用户的账号为:", username
                    tmp_msg = "更新班级数据和用户数据,班级ID为:%s,姓名为:%s" % (int(unit_class_id), user_name)
                    ret_val = None
        elif valid_user_num == 2:
            print "该手机号下有效账号数等于两个"
            # 首先替换同年级的有效账号数据
            user_data = db.tbkt_user.auth_user.filter(phone=phone_number, type=user_type, status__ne=2).select('id')[:]
            user_id_list = [obj['id'] for obj in user_data if user_data]
            unit_class_data = db.tbkt_ketang.mobile_order_region.filter(user_id__in=user_id_list).select('unit_class_id')[:]
            unit_class_list = [obj["unit_class_id"] for obj in unit_class_data if unit_class_data]
            grade_id_data = db.tbkt_com.school_unit_class.filter(id__in=unit_class_list).select('grade_id')[:]
            grade_id_list = [obj["grade_id"] for obj in grade_id_data if grade_id_data]
            print "该手机号下已存在的用户所在的年级列表:", grade_id_list
            # 班级列表组合
            unit_in = ""
            for unit_id in unit_class_list:
                if unit_in:
                    unit_in += ",'%s'" % int(unit_id)
                else:
                    unit_in = "'%s'" % int(unit_id)
            # 获取待创建账号的年级ID
            new_grade_id = db.tbkt_com.school_unit_class.get(id=unit_class_id)['grade_id']
            # 同班级获取同年级的用户ID
            if new_grade_id in grade_id_list:
                # 获取同年级所有用户ID
                print "存在同年级数据"
                last_user_id = ""
                sql = """SELECT DISTINCT au.id FROM tbkt_user.auth_user au 
                INNER JOIN tbkt_ketang.mobile_order_region mor 
                ON au.id=mor.user_id AND au.phone='%(phone)s' AND au.type=1 AND au.status<>2
                INNER JOIN tbkt_com.school_unit_class suc ON suc.id=mor.unit_class_id
                AND mor.unit_class_id IN (%(unit_in)s) AND suc.grade_id=%(grade_id)s;
                """ % {"phone": phone_number, "unit_in": unit_in, "grade_id": new_grade_id}
                unit_user_data = db.tbkt_ketang.fetchall_dict(sql)
                unit_user_list = [unit["id"] for unit in unit_user_data if unit_user_data]
                if unit_user_list:
                    old_user_data = db.tbkt_user.auth_user.filter(id__in=unit_user_list).select('id').order_by('last_login').get()
                    last_user_id = old_user_data['id'] if old_user_data else ""
            else:
                print "不存在同年级数据"
                # 没有同年级的有效账号,从有效账号中获取一个最后登录时间距离较远的账号替换
                # 获取最后登录时间距离较远的有效账号用户ID
                valid_last_user_data = db.tbkt_user.auth_user.filter(phone=phone_number, type=user_type, status__ne=2).select('id').order_by('last_login').get()
                last_user_id = valid_last_user_data['id'] if valid_last_user_data else ''
            print "更新替换用户数据,待替换的用户user_id为:", last_user_id
            db.tbkt_user.auth_user.filter(id=last_user_id).update(
                real_name=user_name,
                last_login=int(time.time())
            )
            # 获取本次更新的用户账号
            username = db.tbkt_user.auth_user.filter(id=last_user_id).get()['username']
            print "本次更新用户的账号为:", username
            # 获取该有效账户的最近班级信息数据
            region_data = db.tbkt_ketang.mobile_order_region.filter(user_id=last_user_id).select('id').order_by('-add_date').get()
            region_id = region_data['id'] if region_data else ''
            # 更新最近添加用户的班级信息,并更新班级数据添加时间
            print "更新最近添加用户的班级信息,班级信息的region_id为:", region_id
            db.tbkt_ketang.mobile_order_region.filter(id=region_id).update(
                city=city_id,
                county=county_id,
                school_id=sch_id,
                school_name=sch_name,
                school_type=sch_type,
                unit_class_id=unit_class_id,
                add_date=int(time.time()),
                user_id=last_user_id
            )
            # 更新替换用户信息不继续创建相应的班级和用户数据
            tmp_msg = "更新班级数据和用户数据,班级ID为:%s,姓名为:%s" % (int(unit_class_id), user_name)
            ret_val = None
        elif valid_user_num >= 3:
            print "该手机号下有效账号已超过两个"
            # 有效账号个数超过三个
            tmp_msg = "该手机号下有效账号已超过两个,本条不创建账号数据"
            ret_val = None
            # 获取其中一个有效账号的用户账号
            username = db.tbkt_user.auth_user.filter(phone=phone_number, type=user_type, status__ne=2).get()['username']
        else:
            # 不存在有效账号
            # 获取一个用户账号用于替换,获取规则:例如剩余账号为xs,xs1,xs2,获取账号xs的用户账号ID
            last_user_data = db.tbkt_user.auth_user.filter(phone=phone_number, type=user_type, status=2).select('id').order_by('username').get()
            last_user_id = last_user_data['id'] if last_user_data else ''
            # 更新替换禁用账号最后登录时间距离较远的用户数据,并解除禁用
            print "更新替换最后登录时间距离较远的用户数据,用户user_id为:", last_user_id
            db.tbkt_user.auth_user.filter(id=last_user_id).update(
                real_name=user_name,
                staus=0,
                last_login=int(time.time())
            )
            # 获取本次更新的用户账号
            username = db.tbkt_user.auth_user.filter(id=last_user_id).get()['username']
            print "本次更新用户的账号为:", username
            # 获取该有效账户的最近班级信息数据
            region_data = db.tbkt_ketang.mobile_order_region.filter(user_id=last_user_id).select('id').order_by('-add_date').get()
            region_id = region_data['id'] if region_data else ''
            # 更新最近添加用户的班级信息,并更新班级数据添加时间
            print "更新最近添加用户的班级信息,班级信息的region_id为:", region_id
            db.tbkt_ketang.mobile_order_region.filter(id=region_id).update(
                city=city_id,
                county=county_id,
                school_id=sch_id,
                school_name=sch_name,
                school_type=sch_type,
                unit_class_id=unit_class_id,
                add_date=int(time.time()),
                user_id=last_user_id
            )
            # 更新替换用户信息不继续创建相应的班级和用户数据
            tmp_msg = "更新班级数据和用户数据,班级ID为:%s,姓名为:%s" % (int(unit_class_id), user_name)
            ret_val = None
        return ret_val, tmp_msg, username
    except Exception as e:
        print e


def judge_user_name_contain_len(user_name):
    """
    功能:判断用户姓名长度是否是2到5个字节,并且全部是中文
    :param user_name:用户姓名
    :return: 满足返回True,否则返回None
    添加人:宋国洋
    添加时间:2018-1-10
    """
    try:
        user_name_len = len(user_name.decode('utf-8'))
        name_list = []
        if 1 < user_name_len < 6:
            for name_check in user_name.decode('utf-8'):
                if u'\u4e00' <= name_check <= u'\u9fff':
                    name_list.append(1)
                else:
                    name_list.append(0)
        else:
            name_list.append(0)
        if 0 in name_list:
            return None
        return True
    except Exception as e:
        print e
