#! /usr/bin/env sh  
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/batch_deal_open_search.py  
logfile=/var/log/tbkt_cms_batch_deal_open_search.log
case $1 in  
    start)  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/tbkt_cms_batch_deal_open_search.pid --logfile=$logfile
        ;;  
    stop)  
        kill -9 `cat /var/run/tbkt_cms_batch_deal_open_search.pid`  
        ;;  
    restart)  
        kill -9 `cat /var/run/tbkt_cms_batch_deal_open_search.pid`  
        sleep 1  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/tbkt_cms_batch_deal_open_search.pid --logfile=$logfile  
        ;;  
    log)  
        tail -f $logfile
        ;;  
    *)  
        echo "Usage: ./batch_deal_open_search.sh start | stop | restart | log"  
        ;;  
esac  
