# coding:utf-8
import datetime
import os, time, sys
import simplejson as json
import base64
from db_mysql import db

# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')

from config import *


def handler_web_data(batch_request):
    """
    批开学科 网站数据处理
    -------------------------------------------------
    修改人                     修改时间
    -------------------------------------------------
    杜祖永                     2015-03-02
    """
    print "----------开始处理web文件--------------"
    try:
        conn = get_ketang_conn()
        cur = conn.cursor()

        err_msg = []  # 错误日志
        all_num = 0  # 总记录
        ok_num = 0   # 成功处理记录数

        batch_id = batch_request[0]
        user_type = batch_request[3]
        sch_id = batch_request[4]
        parent_id = batch_request[5]  # school_unit_class的自增id
        grade_id = batch_request[6]
        class_id = batch_request[7]
        sms_txt = batch_request[8]
        file_name = batch_request[9]
        email_user = batch_request[13]
        affix_info = json.loads(batch_request[11])
        open_subject = affix_info['open_subject']
        option_select = affix_info['option_select']
        status = affix_info['status']
        system_sms = affix_info['system_sms']  # 下发系统短信
        open_type = ''
        open_option = affix_info['open_option']
        sub_code_list = []
        stu_code = {'2': 'A', '3': 'B', '4': 'C', '9': 'D', '5': 'E'}
        tea_code = {'2': 'J', '3': 'K', '4': 'L', '9': 'M', '5': 'N'}
        for code in open_subject.split(','):
            if user_type == 1:
                sub_code_list.append("'%s'" % stu_code[code])
            elif user_type == 3:
                sub_code_list.append("'%s'" % tea_code[code])
        # 获取后台用户id
        sql_id = "select id from tbkt_ketang.auth_user where email='%s';" % email_user
        cur.execute(sql_id)
        add_user_id = cur.fetchall()[0][0]
        # 获取网站数据,禁用账号不做处理
        sql = """
        select distinct b.id,b.username,ap.`password`,b.phone from tbkt_user.auth_user b
        INNER JOIN tbkt_user.auth_profile ap ON ap.user_id=b.id AND b.status<>2
        INNER JOIN tbkt_ketang.mobile_order_region r on b.id=r.user_id
        INNER JOIN tbkt_ketang.mobile_subject_detail_hn s on s.phone_number=b.phone and s.status in (%s) and s.code in (%s)
        """ % (status, ','.join(sub_code_list))
        path = ''
        if class_id > 0:
            sql += " and r.unit_class_id='%s'" % class_id
        elif grade_id > 0:
            path += '|%s|%s' % (parent_id, grade_id)
            # sql += " and r.path like '" + path + "%%'"
            sql += " INNER JOIN tbkt_com.school_unit_class suc ON r.unit_class_id=suc.id AND suc.path like '" + path + "%%'"
        elif parent_id > 0:
            path = '|%s' % parent_id
            # sql += " and r.path like '" + path + "%%'"
            sql += " INNER JOIN tbkt_com.school_unit_class suc ON r.unit_class_id=suc.id AND suc.path like '" + path + "%%'"
        sql += " where r.school_id=%s and b.type=%s" % (sch_id, user_type)
        sql += " GROUP BY b.phone order by b.username"
        cur.execute(sql)
        phone_list = cur.fetchall()
        nrows = len(phone_list)
        print '总记录数据nrows=', nrows
        all_num = nrows
        j = 0
        row = 1  # 当前处理第几行

        # 更新为处理中状态
        sql = 'UPDATE tbkt_ketang.mp_batch_request SET status=1,num_all=%s,start_date=%s WHERE id=%s' % (all_num, int(time.time()), batch_id)
        cur.execute(sql)
        conn.commit()
        # 获取学校数据
        sch_one = call_proc('sp_get_school', (sch_id, ''))
        school_data = {'sch_id': sch_id, 'sch_name': sch_one[0], 'province': sch_one[1], 'city': sch_one[2], 'county': sch_one[3]}
        school_data['ecid'] = sch_one[4]
        for phone in phone_list:
            try:
                j += 1
                row += 1
                sn_code = ''         # 二次确认码
                bind_id = phone[0]
                username = phone[1]
                password = base64.b64decode(phone[2])
                phone_number = phone[3]  # 手机号
                msg_txt = sms_txt
                # 创建下发账号记录
                if option_select == 'sendaccount':
                    # sms_txt += ' 账号：%s密码：%s' % (username,password)
                    if user_type == 1:
                        msg_txt += """账号：%s，密码：%s。
                        """ % (username, password)
                    else:
                        msg_txt += ' 账号：%s密码：%s' % (username, password)
                    print '下发账号开始'
                    result = call_proc("sp_send_account", (username, password, phone_number, bind_id, batch_id, '批处理'))
                    print result
                    if result[0] > 0:
                        print '下发账号结束'
                if open_type == 'yindao' and msg_txt:
                    print '写入引导短信开始'
                    err_msg.append({'row': row, 'col': 12, 'msg': '下发引导短信'})
                    result = call_proc("sp_send_sms", (phone_number, msg_txt, '10657050500001', batch_id))
                    if result[0] > 0:
                        print '写入引导短信结束, mp_sms_record_id=%s' % result[0]
                for code in open_subject.split(','):
                    print '写入开通学科开始,code=',code
                    result = call_proc("sp_add_phone_subject", (school_data['ecid'], bind_id, user_type, code, open_option, sn_code, phone_number, '', 0, 3, batch_id))
                    # 写入开通途径统计数据,2-后台批量开通
                    open_type_c = 1 if sn_code else 2  # 有验证码即为1否则为2
                    if open_option == "yongjiushiyong":
                        open_type_c = 3
                    call_proc("sp_add_open_census", (bind_id, user_type, phone_number, code, 2, open_type_c))
                    # 写入开通途径统计数据结束
                    if result[0] > 0:
                        print '写入开通学科结束, tmp_subject_id=%s' % result[0]
                print '总记录:%s条,成功处理%s条,处理完第%s条' % (all_num,ok_num,j)
                if bind_id:
                    ok_num += 1
                    err_msg.append({'row': row, 'col': 10, 'msg': '成功'})
                else:
                    err_msg.append({'row': row, 'col': 10, 'msg': '失败'})
                # 下发系统短信
                send_system_sms(open_subject, system_sms, user_type, phone_number, batch_id)
            except Exception, e:
                if str(e).find('MySQL') > 0:
                    time.sleep(10)
                    conn = get_ketang_conn()
                    cur = conn.cursor()
                    cur.execute(sql)
                    print '重新建立数据连接'
                err_msg.append({'row': row, 'col': 10, 'msg': '%s' % e})
                print {'row': row, 'col': 10, 'msg': '%s' % e}

        content = '总记录:%s条,成功处理%s条,处理完第%s条' % (all_num,ok_num,j)
        sql = "UPDATE tbkt_ketang.mp_batch_request SET status=2,num_ok=%s,end_date=%s WHERE id=%s" % (ok_num, int(time.time()), batch_id)
        print "======成功了:======", content
        try:
            cur.execute(sql)
            conn.commit()
        except Exception, ex:
            conn = get_ketang_conn()
            cur = conn.cursor()
            cur.execute(sql)
            conn.commit()

    except Exception, e:
        print "error.handler_web_data:", e
