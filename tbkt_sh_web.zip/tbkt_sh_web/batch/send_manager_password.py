# coding:utf-8
import os
import sys
import time
import datetime
import MySQLdb
# # 设置工作目录
sys_base_path = os.path.abspath(__file__)
print os.path.normpath(os.path.join(sys_base_path, '../..'))
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
# 引入模块
from twisted.internet import reactor
from twisted.application import service
from config import *
from sms.SMSInfo import SMSInfo

class SendManager:

    def __init__(self):
        if __name__ == '__main__':
            self.conn = get_manage_conn()
        elif __name__ == '__builtin__':
            self.conn = get_manage_conn()

    def execute(self, sql):
        """
        建立数据库连接
        """
        cur = self.conn.cursor()
        r = cur.execute(sql)
        self.conn.commit()
        cur.close()
        return r

    def fetchall(self, sql):
        cur = self.conn.cursor()
        cur.execute(sql)
        rows = cur.fetchall()
        cur.close()
        return rows

    def send_manager_password(self):
        """
        功能:校方管理员注册成功下发账号密码
        -----------------------------
        修改人:宋国洋
        -----------------------------
        修改时间:2016-11-24
        """
        try:
            sql = """select phone_number,username,real_password from school_auth_user where send_status=1"""
            phone_data = self.fetchall(sql)
            if not phone_data:
                print u'没有需要下发的管理员账号密码!',u'休眠10秒'
                time.sleep(10)
            else:
                smsInfo = SMSInfo()
                smsInfo.SMS__Priority = 9
                sender = {}
                sender['send_phone'] = ''  # 发送手机号 没有为''
                sender['unit_class_id'] = 0  # 发者班级ID 没有为0
                sender['object_id'] = 0  # 发送对象ID 没有为0
                sender['object_type'] = 8  # 发送类型   没有为0
                sender['send_user'] = ''  # 发送者账号 没有为''
                sender['accept_user'] = ''  # 接收者姓名 没有为''
                sender['flat_type'] = 0
                phone_list = [obj[0] for obj in phone_data]
                user_list = [obj[1:] for obj in phone_data]
                user_dict = dict(zip(phone_list, user_list))
                for phone in user_dict.keys():
                    try:
                        msg_content = u'您的管理员账号已经注册成功,账号:%s,密码:%s,输入账号密码即可登录校方管理员后台' % (user_dict.get(phone)[0], user_dict.get(phone)[1])
                        flag = smsInfo.send_one(phone, msg_content, sender=sender)
                        print flag, '================='
                    except Exception as e:
                        print 'error.send_many-error:', e
                        flag = 0
                    if flag:
                        send_status = 2
                        print u'本次注册用户:%s,下发账号密码短信成功!' % user_dict.get(phone)[0], u'休眠10秒'
                        time.sleep(10)
                    else:
                        send_status = 3
                        print u'本次短信下发失败!', u'休眠10秒'
                        time.sleep(10)
                    # 更新短信下发状态
                    sql_up = """update tbkt_manage.school_auth_user set send_status=%s where username='%s'""" % (send_status, user_dict.get(phone)[0])
                    self.execute(sql_up)
        except Exception as e:
            print 'error:', e
def main():
    # reactor.callInThread(send_manager_password)
    while True:
        send = SendManager()
        send.send_manager_password()
        time.sleep(10)

if __name__ == '__main__':
    print 'main'
    main()

elif __name__ =='__builtin__':
    print '__builtin__'
    main()
    application = service.Application('send_manager_password')