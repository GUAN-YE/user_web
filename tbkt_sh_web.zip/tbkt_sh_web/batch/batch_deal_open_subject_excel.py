# coding:utf-8
import os, time, re, xlrd, sys, random
import simplejson as json
import datetime
import datetime
import base64
from db_mysql import db
# 学生数据新的导入规则
from batch_insert_data_rule import insert_data_rule, create_user_account, judge_user_name_contain_len
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
from xlutils.copy import copy
from config import *
G_GRADE_DICT = {u'学前班':0,u'一年级':1,u'二年级':2,u'三年级':3,u'四年级':4,u'五年级':5,u'六年级':6,u'七年级':7,u'八年级':8,u'九年级':9,u'待分年级':-100}
mobile_pattern = "((((13[5-9]{1})|(15[012789]{1})|178{1}|147{1}|(18[23478]{1})){1}[0-9]{1})|(134[0-8]{1})){1}[0-9]{7}"         # 移动手机正则表达式
user_name_pattern = ""

def modify_file(wb, file_full_path, arr=[]):
    """
    -- -------------------------------------
     添加人          添加时间           作用
    -------------------------------------
     杜祖永           2015-02-27    修改文件
    --------------------------------------
     参数： target_file
    arr 格式:[{'row':1,'col':2, 'text':''}]
    flag:1、学校不存在，2、业务地区不存在,3、数据处理完成
    --------------------------------------
    """
    print '开始修改文件', wb
    try:
        sheet = wb.get_sheet(0)
        i = 0
        for obj in arr:
            try:
                i += 1
                sheet.write(obj['row'],obj['col'], obj['msg'].decode('utf8'))
            except Exception,e:
                print '修改文件第:%s行,异常err:%s' % (i, e)
        wb.save(file_full_path)
        print '此次修改文件成功'
    except Exception, e:
        print '修改文件异常:file_full_name=<%s>, err=<%s>' % (file_full_path, e)


def handler_excel_data(batch_request):
    """
    批开学科 excel文件处理
    -------------------------------------------------
    修改人                     修改时间
    -------------------------------------------------
    杜祖永                     2015-02-27
    """
    try:
        conn = get_ketang_conn()
        cur = conn.cursor()
        err_msg = []  # 错误日志
        ok_num = 0   # 成功处理记录数
        batch_id = batch_request[0]
        user_type = batch_request[3]
        sch_id = batch_request[4]
        parent_id = batch_request[5]        # school_unit_class的自增id
        dept_data = db.tbkt_com.school_unit_class.get(id=parent_id)
        dept_id = dept_data.type if dept_data else 1
        sms_txt = batch_request[8]
        file_path = batch_request[9]
        affix_info = json.loads(batch_request[11])
        data_operate_type = affix_info['data_operate_type']
        open_subject = affix_info['open_subject'] if affix_info.has_key('open_subject') else ''
        open_type = affix_info['open_type'] if affix_info.has_key('open_type') else ''
        option_select = affix_info['option_select'] if affix_info.has_key('option_select') else ''
        open_option = affix_info['open_option'] if affix_info.has_key('open_option') else ''
        tiyan_remind = affix_info['tiyan_remind'] if affix_info.has_key('tiyan_remind') else ''  # 体验到期提醒
        system_sms = affix_info['system_sms'] if affix_info.has_key('system_sms') else ''  # 下发系统短信
        platform_id = int(affix_info['platform_id'] if affix_info.has_key('platform_id') else 0)
        school_dict = {}            # 学校缓存
        unit_class_dict = {}        # 班级缓存
        bk = xlrd.open_workbook(file_path)  # 打开excel文件
        wb = copy(bk)                       # 复制工作表
        sh = bk.sheets()[0]
        nrows = sh.nrows
        print '待处理文件的总记录数:', nrows - 10
        all_num = nrows - 10
        j = 0
        row = 9  # 当前处理第几行
        # 更新为处理中状态
        sql = 'UPDATE tbkt_ketang.mp_batch_request SET status=1,num_all=%s,start_date=%s WHERE id=%s' % (all_num, int(time.time()), batch_id)
        cur.execute(sql)
        conn.commit()
        tea_unit_data = []
        for r in range(10, nrows):
            try:
                j += 1
                row += 1
                phone_number = str(sh.row(r)[0].value).strip()  # 手机号
                sex = 1
                user_name = str(sh.row(r)[1].value).strip()    # 姓名
                grade_name = str(sh.row(r)[2].value).strip()   # 年级名称
                class_id = str(sh.row(r)[3].value).strip()     # 班级ID
                # 二次确认码
                sn_code = ''
                if len(sh.row(r)) > 4:
                    sn_code = str(sh.row(r)[4].value)[:6]   # 二次确认码
                if sn_code.find('.') > -1:
                    sn_code = sn_code[:sn_code.find('.')].zfill(6)
                print "待创建用户信息:", sex, user_name, phone_number, grade_name, class_id, sn_code
                # 验证开始
                if not phone_number:
                    err_msg.append({'row': row, 'col': 10, 'msg': '手机号未填写'})
                    continue
                else:
                    phone_number = phone_number[:11]
                    print "本次处理的用户手机号为:", phone_number
                    if not re.match(mobile_pattern, phone_number):
                        print row, "手机号%s不是移动手机号" % phone_number
                        err_msg.append({'row': row, 'col': 10, 'msg': '手机号不是移动手机号'})
                        continue
                # 新增用户姓名的格式判断
                if user_name:
                    name_ret = judge_user_name_contain_len(user_name)
                    if name_ret is None:
                        err_msg.append({'row': row, 'col': 10, 'msg': '用户姓名格式错误'})
                        continue
                try:
                    if grade_name:
                        grade_id = G_GRADE_DICT[grade_name.decode('utf8')]
                    else:
                        # 没有年级数据
                        raise ValueError
                except Exception as e:
                    print "抛出异常:", e
                    err_msg.append({'row': row, 'col': 10, 'msg': '年级不规范'})
                    continue
                try:
                    if class_id:
                        class_id = int(float(class_id))
                    else:
                        # 没有班级数据
                        raise ValueError
                except Exception as e:
                    print "抛出异常:", e
                    err_msg.append({'row': row, 'col': 10, 'msg': '班级格式不正确'})
                    continue
                key_class = "%s_%s_%s" % (parent_id, grade_id, class_id)
                if sch_id not in school_dict.keys() or key_class not in unit_class_dict.keys():
                    unit_class = get_unit_class(parent_id, grade_id, class_id)
                    if unit_class:
                        unit_class_dict[key_class] = unit_class
                    else:
                        err_msg.append({'row': row, 'col': 10, 'msg': '该部门不存在相应的班级数据'})
                        continue
                    sch_one = call_proc('sp_get_school', (sch_id, ''))
                    school_data = {'sch_id': sch_id, 'sch_name': sch_one[0], 'province': sch_one[1], 'city':sch_one[2], 'county': sch_one[3]}
                    school_data['ecid'] = sch_one[4]
                    school_dict[sch_id] = school_data
                else:
                    school_data = school_dict[sch_id]
                    unit_class = unit_class_dict[key_class]
                if not unit_class:
                    err_msg.append({'row': row, 'col': 10, 'msg': '获取学校班级失败'})
                    continue
                username = ''  # 账号名称
                if user_type == 1:
                    # 在这里添加了学生新的导入规则
                    ret_val, tmp_msg, username = insert_data_rule(school_data['city'], school_data['county'], sch_id, school_data['sch_name'], unit_class['unit_id'], phone_number, user_name, 1)
                    print "学生数据新导入规则返回的参数:%s" % ret_val
                    # 写入处理结果
                    if ret_val is None:
                        err_msg.append({'row': row, 'col': 11, 'msg': "成功"})
                    # 写入此次数据处理的方式
                    err_msg.append({'row': row, 'col': 12, 'msg': tmp_msg})
                    # 获取学生的账号,username不为空使用当前的,为空则去获取新的
                    username = username if username else create_user_account(phone_number=phone_number)
                if user_type == 3:
                    ret_val = True      #   初始值
                    tea_unit_data.append({"phone_number": str(phone_number), "unit_class_id": str(unit_class["unit_id"])})
                    # 判断该该学科教师账号是否已经存在
                    username = subject_tea_exist(phone_number, open_subject)
                    # 判断对应班级是否存在其他任课老师，存在不能创建
                    print "判断班级是否有其他教师"
                    other_phone = unit_class_has_other_teacher(unit_class['unit_id'], open_subject, phone_number)
                    print "设置成待分班级的教师手机号列表:", other_phone
                # 调用获取账号旧密码方法
                password, pw_encode = old_username_password_exist(username=username)
                encrypt_password = encode_password(str(password))
                decode_password = pw_encode
                tmp_option_select = ''  # 下发账号的判断移动 科目创建后处理
                can_send_sms_flag = False  # 是否可以下发短信,只下发未开通的
                ret_deal_status = 'deal_ignore'  # deal_ignore:忽略不处理, deal_ok:处理成功
                # 判断学校是否开通集团
                if not school_data['ecid']:
                    err_msg.append({'row': row, 'col': 11, 'msg': '学校未开通集团'})
                # 判断用户是否在黑名单中
                black_phone = db.tbkt_ketang.mobile_black_phone.filter(phone=phone_number).get()
                # 判断数据返回结果
                if ret_val:
                    print "本次新创建用户账号信息"
                    # 创建账号并处理业务开通请求
                    # 调用开通用户账号数据的存储过程
                    result = call_proc("sp_add_phone_order", (username, user_name, user_type, encrypt_password, password,
                                                              decode_password, platform_id, grade_id, open_subject, dept_id,
                                                              sex, phone_number, school_data['province'], school_data['city'],
                                                              school_data['county'], sch_id, school_data['sch_name'],
                                                              unit_class['sch_type'], unit_class['unit_id'],
                                                              data_operate_type, tmp_option_select, 0, '批处理'))
                    if black_phone:
                        # 黑名单用户不处理开通信息
                        err_msg.append({'row': row, 'col': 11, 'msg': '该用户在黑名单中'})
                        continue
                    bind_id = result[0]
                    tmp_have_account = result[2]
                    print '新创建的用户的user_id=%s' % bind_id
                    for code in open_subject.split(','):
                        print '写入用户开通信息的科目为:', code
                        # 调用开通用户学科的存储过程
                        result = call_proc("sp_add_phone_subject", (school_data['ecid'], bind_id, user_type, code, open_option, sn_code, phone_number, tiyan_remind, 0, 3, batch_id))
                        ret_subject_id = result[0]
                else:
                    print "本次不再创建用户账号信息"
                    # 不创建账号信息,只处理业务开通请求
                    if black_phone:
                        # 黑名单用户不处理开通信息
                        err_msg.append({'row': row, 'col': 11, 'msg': '该用户在黑名单中'})
                        continue
                    bind_data = db.tbkt_user.auth_user.filter(phone=phone_number, type=user_type, status__ne=2).select('id').get()
                    bind_id = bind_data['id'] if bind_data else ''      # 获取对应的用户ID
                    tmp_have_account = db.tbkt_user.auth_user.filter(phone=phone_number, type=user_type).count()       # 获取该手机号下的账号个数
                    print '已经创建的用户的user_id=%s' % bind_id
                    for code in open_subject.split(','):
                        print '写入用户开通信息的科目为:', code
                        # 调用开通用户学科的存储过程
                        result = call_proc("sp_add_phone_subject", (school_data['ecid'], bind_id, user_type, code, open_option, sn_code, phone_number, tiyan_remind, 0, 3, batch_id))
                        ret_subject_id = result[0]
                # 写入开通途径统计数据,2-后台批量开通
                open_type_c = 3 if open_option == "yongjiushiyong" else (1 if sn_code else 2)     # 有验证码即为1否则为2
                open_insert_result = call_proc("sp_add_open_census", (bind_id, user_type, phone_number, code, 2, open_type_c))
                # 如果是永久试用开通,直接同步开通信息
                if open_option == "yongjiushiyong":
                    call_proc("sp_tongbu_mobile_subject", (bind_id, phone_number, user_type))
                # 写入开通途径统计数据结束
                print '写入用户开通信息结束,处理结果:', result
                sub_status = result[2]
                if result[4] == 'deal_ok':
                    ret_deal_status = result[4]
                if sub_status < 2 and ret_subject_id > 0:
                    can_send_sms_flag = True
                if sub_status == 9:
                    # 永久试用
                    can_send_sms_flag = True
                # 账号密码下发
                msg_txt = sms_txt
                if ret_deal_status == 'deal_ok':
                    if option_select == 'sendaccount' or (option_select == 'sendnewaccount' and tmp_have_account == 0):
                        if user_type == 1:
                            msg_txt += """账号:%s,密码:%s.""" % (username, password)
                        else:
                            msg_txt += ' 账号:%s,密码:%s.' % (username, password)
                        open_type = 'yindao'
                print '开始下发引导短信,can_send_sms_flag为:', can_send_sms_flag
                if open_type == 'yindao' and msg_txt and can_send_sms_flag:
                    err_msg.append({'row': row, 'col': 12, 'msg': '下发引导短信'})
                    result = call_proc("sp_send_sms", (phone_number, msg_txt, '10657050500001', batch_id))
                    if result[0] > 0:
                        print '结束下发引导短信, 下发短信结果:%s' % result[0]
                else:
                    err_msg.append({'row': row, 'col': 12, 'msg': ''})
                print '==处理总数为%s条,,已处理成功%s条,,处理完第%s条==' % (all_num, ok_num, j)
                if bind_id:
                    ok_num += 1
                    err_msg.append({'row': row, 'col': 10, 'msg': '成功'})
                else:
                    err_msg.append({'row': row, 'col': 10, 'msg': '失败'})
                # 下发系统短信
                send_system_sms(open_subject, system_sms, user_type, phone_number, batch_id)
            except Exception, e:
                if str(e).find('MySQL') > 0:
                    time.sleep(10)
                    conn = get_ketang_conn()
                    cur = conn.cursor()
                    cur.execute(sql)
                    print '创建新的数据库链接'
                err_msg.append({'row': row, 'col': 10, 'msg': '%s' % e})
                print {'row': row, 'col': 10, 'msg': '%s' % e}
        content = '总记录:%s条,成功处理%s条,处理完第%s条' % (all_num,ok_num,j)
        # 调用教师处理方法
        if user_type == 3:
            print "开始处理教师数据"
            res = unit_class_tea_handle(tea_data=tea_unit_data, subject_id=open_subject)
            if res == "ok":
                print "教师数据处理成功"
            else:
                print "教师数据处理失败:", res
        # 处理完成更新数据状态
        sql = "UPDATE tbkt_ketang.mp_batch_request SET status=2,num_ok=%s,end_date=%s WHERE id=%s" % (ok_num, int(time.time()), batch_id)
        print "本次数据处理完成,处理结果:", content
        try:
            cur.execute(sql)
            conn.commit()
        except Exception as ex:
            conn = get_ketang_conn()
            cur = conn.cursor()
            cur.execute(sql)
            conn.commit()
        # # 写入处理结果
        modify_file(wb, file_path, err_msg)
        # 返回结果处理
    except Exception, e:
        import traceback
        traceback.print_exc()
        print "处理Excel文件失败:", e


def get_unit_class(parent_id, grade_id, class_id):
    """
    功能:获取开通用户的班级数据
    :param parent_id: 学校ID
    :param grade_id: 年级
    :param class_id: 班级
    :return: 学校班级信息
    ----------------------------------------------
    修改人:宋国洋
    ----------------------------------------------
    修改内容:用户创建的班级数据不存在时返回None
    ----------------------------------------------
    修改时间:2018-1-8
    """
    unit_class = {'unit_id': 0}
    unit_class['grade_id'] = grade_id
    unit_class['class_id'] = class_id
    try:
        # 获取年级节点ID
        unit_type = 1
        level_id = 2
        print "存储过程(1)调用参数:", (parent_id, unit_type, level_id, grade_id, class_id, '')
        results = call_proc("sp_get_unit_class", (parent_id, unit_type, level_id, grade_id, class_id, ''))
        # 如果存在对应的班级parent_id为新parent_id,否则沿用老parent_id
        parent_id = results[0]
        if int(parent_id) > 0:
            # 获取班级节点ID
            level_id = 3
            conn = get_ketang_conn()
            cursor = conn.cursor()
            print "存储过程(2)调用参数:", (parent_id, unit_type, level_id, grade_id,  class_id, '')
            results = call_proc("sp_get_unit_class", (parent_id, unit_type, level_id, grade_id,  class_id, ''))
            unit_class['unit_id'] = results[0]
            unit_class['sch_type'] = results[1]
            unit_class['unit_name'] = results[2]
            unit_class['unit_type'] = results[3]
            unit_class['unit_path'] = results[4]
        else:
            return None
    except Exception, e:
        import traceback
        traceback.print_exc()
        print '创建班级异常:%s' % e
        unit_class['sch_type'] = 0
        unit_class['unit_name'] = '待分班级'
        unit_class['unit_type'] = 1
        unit_class['unit_path'] = ''
        unit_class['grade_id'] = -100
        unit_class['class_id'] = -100
    return unit_class