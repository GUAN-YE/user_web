#! /usr/bin/env sh  
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/client_send_sms.py  
logfile=/var/log/tbkt_cms_client_send_sms.log
case $1 in  
    start)  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/tbkt_cms_client_send_sms.pid --logfile=$logfile
        ;;  
    stop)  
        kill -9 `cat /var/run/tbkt_cms_client_send_sms.pid`  
        ;;  
    restart)  
        kill -9 `cat /var/run/tbkt_cms_client_send_sms.pid`  
        sleep 1  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/tbkt_cms_client_send_sms.pid --logfile=$logfile  
        ;;  
    log)  
        tail -f $logfile
        ;;  
    *)  
        echo "Usage: ./client_send_sms.sh start | stop | restart | log"  
        ;;  
esac  
