# coding=utf-8
import os, xlrd, sys
import simplejson as json
from xlutils.copy import copy
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
print os.path.normpath(os.path.join(sys_base_path, '../..'))
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
from config import *
stu_subject_dict = {"2": "A", "3": "B", "4": "C", "9": "D", '5': 'E'}  # 学生科目
tea_subject_dict = {"2": "J", "3": "K", "4": "L", "9": "M", '5': 'E'}  # 教师科目


def modify_file(wb, file_full_path, arr=[]):
    """
    -- -------------------------------------
     添加人          添加时间           作用
    -------------------------------------
     杜祖永           2015-02-27    修改文件
    --------------------------------------
     参数： target_file
    arr 格式:[{'row':1,'col':2, 'text':''}]
    flag:1、学校不存在，2、业务地区不存在,3、数据处理完成
    --------------------------------------
    """
    print '开始修改文件',wb , 'arr len=', len(arr)
    try:
        sheet = wb.get_sheet(0)
        i = 0
        for obj in arr:
            try:
                i += 1
                sheet.write(obj['row'], obj['col'], obj['msg'].decode('utf8'))
            except Exception, e:
                print '修改文件第 %s 行异常 err:%s' % (i, e)
        wb.save(file_full_path)
        print file_full_path       
        print '--------------修改文件成功'
    except Exception, e:
        print '修改文件异常:file_full_name=<%s>, err=<%s>' % (file_full_path, e)


def handler_open_search_excel_data(batch_request):
    """
    批开账号 excel文件处理
    -------------------------------------------------
    修改人                     修改时间
    -------------------------------------------------
    杜祖永                     2015-02-27
    """
    try:
        conn = get_ketang_conn()
        cur = conn.cursor()
        err_msg = []  # 错误日志
        ok_num = 0   # 成功处理记录数
        batch_id = batch_request[0]
        user_type = batch_request[3]
        file_path = batch_request[9]
        affix_info = json.loads(batch_request[11])
        open_subject = affix_info['open_subject']
        bk = xlrd.open_workbook(file_path)  # 打开excel文件
        wb = copy(bk)                      # 复制工作表
        sh = bk.sheets()[0]
        nrows = sh.nrows
        print '总记录数据nrows=', nrows
        all_num = nrows - 10
        j = 0
        row = 9  # 当前处理第几行
        # 更新为处理中状态
        sql = 'UPDATE tbkt_ketang.mp_batch_request SET status=1,num_all=%s,start_date=%s WHERE id=%s' % (all_num, int(time.time()), batch_id)
        cur.execute(sql)
        conn.commit()

        for r in range(10, nrows):
            try:
                j += 1
                row += 1
                phone_number = str(sh.row(r)[0].value).strip()  # 手机号
                phone_number = phone_number[:11]
                column_num = 11
                for code_id in open_subject.split(','):
                    code = ''
                    if user_type == 1:
                        # 学生
                        code = stu_subject_dict[code_id]

                    if user_type == 3:
                        # 教师
                        code = tea_subject_dict[code_id]
                    # 当天是否登录
                    sql = "select 1 from tbkt_user.auth_user where phone='" + phone_number + "' and type=" + str(user_type) + " and last_login>=UNIX_TIMESTAMP(NOW())"
                    cur.execute(sql)
                    if cur.fetchone():
                        err_msg.append({'row': row, 'col': column_num, 'msg': '登录过'})
                    else:
                        err_msg.append({'row': row, 'col': column_num, 'msg': '未登录'})

                    column_num += 1
                    if code:
                        sql ="select status from tbkt_ketang.mobile_subject_detail_hn where phone_number='%s' and code='%s'" % (phone_number, code)
                        cur.execute(sql)
                        status_list = cur.fetchall()
                        status_str = ''
                        for obj in status_list:
                            status_str += ",'%s'" % obj[0]
                        msg = ''
                        if status_str.find('2') > 0:
                            msg = '开通'
                        elif status_str.find('0') > 0 or status_str.find('1') > 0:
                            msg = '未开通'
                        elif status_str.find('9') > 0:
                            msg = '永久试用'
                        elif status_str.find('3') > 0:
                            msg = '待退订'
                        elif status_str.find('4') > 0:
                            msg = '退订'
                        fir_msg = ''
                        if user_type == 1:
                            # 判断学生是否是首次开通
                            sql_fir = """SELECT count(1) FROM tbkt_ketang.mobile_subject_detail_hn WHERE phone_number='%s'
                            AND code='%s' AND status>1""" % (phone_number, code)
                            cur.execute(sql_fir)
                            fir_num = cur.fetchone()[0]
                            fir_msg = '非首次开通' if int(fir_num) > 1 else '首次开通'
                        err_msg.append({'row': row, 'col': column_num, 'msg': '%s' % code})
                        err_msg.append({'row': row, 'col': column_num + 1, 'msg': msg})
                        err_msg.append({'row': row, 'col': column_num + 2, 'msg': fir_msg})
                        column_num += 3

                ok_num += 1
                err_msg.append({'row': row, 'col': 10, 'msg': '成功'})

            except Exception, e:
                if str(e).find('MySQL') > 0:
                    time.sleep(10)
                    conn = get_ketang_conn()
                    cur = conn.cursor()
                    cur.execute(sql)
                    print '重新建立数据连接'
                err_msg.append({'row': row, 'col': 10, 'msg': '%s' % e})
                print {'row': row, 'col': 10, 'msg': '%s' % e}

        content = '总记录:%s条,成功处理%s条,处理完第%s条' % (all_num,ok_num,j)
        sql = "UPDATE tbkt_ketang.mp_batch_request SET status=2,num_ok=%s,end_date=%s WHERE id=%s" % (ok_num, int(time.time()), batch_id)
        print content
        try:
            cur.execute(sql)
            conn.commit()
        except Exception, ex:
            print ex
            conn = get_ketang_conn()
            cur = conn.cursor()
            cur.execute(sql)
            conn.commit()
        # 写入处理结果
        modify_file(wb, file_path, err_msg)
    except Exception, e:
        print "error.handler_open_search_excel_data:", e