# coding=utf-8
import datetime, os, time, sys
import xlrd
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
print os.path.normpath(os.path.join(sys_base_path, '../..'))
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')

from twisted.internet import reactor
from twisted.application import service
from config import *
from sms.SMSInfo import SMSInfo


# 定义数据出查询执行方法
def execute(sql):
    conn = get_ketang_conn()
    cur = conn.cursor()
    r = cur.execute(sql)
    conn.commit()
    cur.close()
    return r


def fetchall(sql):
    conn = get_ketang_conn()
    cur = conn.cursor()
    cur.execute(sql)
    rows = cur.fetchall()
    cur.close()
    return rows


def handler_request_data(sh_script_id):
    """
    短信群发
    -------------------------------------------------
    修改人                     修改时间
    -------------------------------------------------
    杜祖永                     2015-03-02
    """
    heartbeat_num = 0
    while True:
        print "开始处理", datetime.datetime.now()
        print 'sh_script_id=', sh_script_id
        try:
            # 参数设置
            smsInfo = SMSInfo()
            smsInfo.SMS__Priority = 9
            sender = {}
            sender['send_phone'] = ''  # 发送手机号 没有为''
            sender['unit_class_id'] = 0  # 发者班级ID 没有为0
            sender['object_id'] = 0  # 发送对象ID 没有为0
            sender['object_type'] = 8  # 发送类型   没有为0
            sender['send_user'] = ''  # 发送者账号 没有为''
            sender['accept_user'] = ''  # 接收者姓名 没有为''
            sender['flat_type'] = 0
            sp_number = '10657050500001'
            sql = """select id,sms_txt,file_name FROM tbkt_ketang.mp_batch_request WHERE batch_type=100 AND data_source=100 AND status=0 limit 1"""
            batch_request = fetchall(sql)
            if batch_request:
                file_path = batch_request[0][2]
                msg_content = batch_request[0][1]
                batch_id = batch_request[0][0]
                sql_update = """UPDATE tbkt_ketang.mp_batch_request SET sh_script_id=%s, status=1 WHERE id=%s""" % (sh_script_id, batch_id)
                execute(sql_update)
                # 取数据方式
                files = open(file_path)  # 打开txt文件
                data_list = files.readlines()
                phone_list = [s.strip() for s in data_list]
                # print phone_list
                if not phone_list:
                    print '短信群发 没有需要处理的数据'
                    time.sleep(5)
                    continue
                if phone_list[0] or phone_list[1] or phone_list[2]:
                    print '本次需要下发 %s 条' % len(phone_list)
                    num, num1 = 0, 0
                    num_ok = 0
                    phone_lists = []
                    for phone in phone_list:
                        phone_lists.append(phone)
                        num += 1
                        num1 += 1
                        num_ok += 1
                        if num >= 50 or len(phone_list) == num1:
                            print "phone_list:", phone_lists
                            try:
                                flag = smsInfo.send_many(phone_lists, msg_content, sender=sender)
                            except Exception, e:
                                print "error.send_one--error:", e
                                flag = 0
                            if flag:
                                print '本次%s条短信下发成功' % num
                            else:
                                print '本次短信下发失败'
                            num = 0
                            phone_lists = []

                    # 更新处理结果状态
                    sql_end = "update tbkt_ketang.mp_batch_request set status=2, num_all=%s, num_ok=%s where id=%s" % (len(phone_list), num_ok, batch_id)
                    execute(sql_end)
            else:
                print '未找到需要发送短信的数据'
        except Exception, e:
            print "error.handler_request_data:", e
        time.sleep(3)


def main(sh_script_id):
    reactor.callInThread(handler_request_data, sh_script_id)
    # handler_request_data(sh_script_id)


if __name__ == "__main__":
    print 'main'
    sh_script_id = 0
    main(sh_script_id)

elif __name__ == '__builtin__':
    print '__builtin__'
    sh_id = sys.argv[2].split('.')[0][-1:]
    sh_script_id = 0
    if sh_id == 's':
        sh_script_id = 27
    main(sh_script_id)
    application = service.Application('batch_deal_send_sms_un')
