# coding=utf-8
import datetime, os, time, sys, base64
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
print os.path.normpath(os.path.join(sys_base_path, '../..'))
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
from twisted.internet import reactor
from twisted.application import service
from config import *
from sms.SMSInfo import SMSInfo


def handler_requset_data():
    """
    处理账号下发
    -------------------------------------------------
    修改人                     修改时间
    -------------------------------------------------
    杜祖永                     2015-03-02
    """
    heartbeat_num = 0
    while True:
        print "开始处理", datetime.datetime.now()
        try:
            conn = get_ketang_conn()
            cur = conn.cursor()
            sql = """
                select id,batch_id,user_id,username,password,phone_number
                FROM tbkt_ketang.mp_account_record WHERE send_status=0 ORDER BY id limit 50
            """
            cur.execute(sql)
            batch_request = cur.fetchall()
            # print batch_request
            if not batch_request:
                print '账号下发 没有需要处理的数据'
                time.sleep(5)
                continue
            smsInfo = SMSInfo()
            sender = {}
            sender['send_phone'] = ''          # 发送手机号 没有为''
            sender['unit_class_id'] = 0        # 发者班级ID 没有为0
            sender['object_id'] = 0            # 发送对象ID 没有为0
            sender['object_type'] = 8          # 发送类型   没有为0
            sender['send_user'] = ''           # 发送者账号 没有为''
            sender['accept_user'] = ''         # 接收者姓名 没有为''
            sender['flat_type'] = 0
            sp_number = '10657050500001'
            phone_list = []
            id_list = []
            for obj in batch_request:
                id = obj[0]
                id_list.append('%s' % id)
                batch_id = obj[1]
                bind_id = obj[2]
                username = obj[3]
                password = obj[4]
                phone_number = obj[5]
                # 获取发送端口号
                sql_sp = """SELECT sp_number FROM tbkt_ketang.mobile_subject_detail_hn WHERE phone_number='%s' LIMIT 1;""" % phone_number
                cur.execute(sql_sp)
                sp_data = cur.fetchall()
                if sp_data:
                    sp_number = sp_data[0][0]
                msg_content = '您的同步课堂(www.tbkt.cn)账号是：%s密码是:%s,手机客户端下载地址:m.tbkt.cn' % (username, password)   # 短信内容
                phone_number = phone_number
                phone_list.append([phone_number, sp_number, msg_content])
                sender['object_id'] = batch_id            # 发送对象ID 没有为0
            if phone_list:
                # print phone_list
                flag = smsInfo.send_many(phone_list, '', sender=sender)
                # flag = smsInfo.send_batch(phone_list, '', sender=sender)
                if flag:
                    print '本次账号下发成功'
                else:
                    print '本次账号下发失败'

                # 更新下发状态
                sql = "update tbkt_ketang.mp_account_record set send_status=1,send_date=%s where id in (%s)" % (int(time.time()), ','.join(id_list))
                cur.execute(sql)
                conn.commit()
            else:
                print '未找到需要发送的账号数据'
        except Exception, e:
            print "error.handler_requset_data:", e
        finally:
            conn.close()
        time.sleep(3)


def main():
    reactor.callInThread(handler_requset_data)
    # handler_requset_data()


if __name__ == "__main__":
    print 'main'
    main()
    
elif __name__=='__builtin__':
    print '__builtin__'
    main()
    application = service.Application('client_send_account')
