#coding=utf-8
import os, time, sys
import simplejson as json
import datetime
import base64

# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')

from config import *


def handler_txt_data(batch_request):
    """
    批开学科 txt文件处理
    -------------------------------------------------
    修改人                     修改时间
    -------------------------------------------------
    杜祖永                     2015-02-27
    """
    print "------------开始处理txt文件-----------"
    try:
        conn = get_ketang_conn()
        cur = conn.cursor()

        err_msg = []  # 错误日志
        all_num = 0  # 总记录
        ok_num = 0   # 成功处理记录数
        batch_id = batch_request[0]
        user_type = batch_request[3]
        sms_txt = batch_request[8]
        file_name = batch_request[9]
        email_user = batch_request[13]
        affix_info = json.loads(batch_request[11])
        # data_operate_type = affix_info['data_operate_type']
        open_subject = affix_info['open_subject']
        open_type = affix_info['open_type']
        option_select = affix_info['option_select']
        open_option = affix_info['open_option']
        tiyan_remind = affix_info['tiyan_remind']  # 体验到期提醒
        system_sms = affix_info['system_sms']  # 下发系统短信
        file_path = os.path.join(G_IMPORT_DIR, file_name)
        bk = open(file_path)  # 打开txt文件
        phone_list = bk.readlines()
        # file_path = "http://file.tbkt.cn/upload_media/" + file_name
        # import urllib
        # fp = urllib.urlopen(file_path)
        # phone_list = fp.readlines()
        nrows = len(phone_list)
        print '总记录数据nrows=',nrows
        all_num = nrows
        j = 0
        row = 1  # 当前处理第几行
        # 获取后台用户id
        sql_id = "select id from tbkt_ketang.auth_user where email='%s';" % email_user
        cur.execute(sql_id)
        add_user_id = cur.fetchall()[0][0]
        # 更新为处理中状态
        sql = 'UPDATE tbkt_ketang.mp_batch_request SET status=1,num_all=%s,start_date=%s WHERE id=%s' % (all_num, int(time.time()), batch_id)
        cur.execute(sql)
        conn.commit()

        for phone in phone_list:
            try:
                j += 1
                row += 1
                phone_number = phone.replace('\n','').replace('\r', '')  # 手机号
                sn_code = ''         # 二次确认码
                # 验证开始
                if not phone_number:
                    err_msg.append({'row': row, 'col': 10, 'msg': '手机号未填写'})
                    continue
                print '读取订单信息开始,phone_number=', phone_number, 'user_type=', user_type
                # 禁用账号不做处理
                sql = """
                select b.id,b.username,ap.password,r.school_id from tbkt_user.auth_user b
                INNER JOIN tbkt_user.auth_profile ap ON b.id=ap.user_id
                INNER join tbkt_ketang.mobile_order_region r on b.id=r.user_id where
                b.phone='%s' and b.type=%s AND b.status<>2 GROUP BY b.phone order by b.username LIMIT 1
                """ % (phone_number, user_type)
                cur.execute(sql)
                result = cur.fetchone()
                if not result:
                    print '%s 无对应订单信息' % phone_number
                    continue
                bind_id = result[0]
                username = result[1]
                password = base64.b64decode(result[2])
                school_id = result[3]
                # 获取集团号
                sql = 'select ecid from tbkt_com.school where id=%s' % school_id
                cur.execute(sql)
                result = cur.fetchone()
                if result:
                    ecid = result[0]
                else:
                    ecid = ''
                can_send_sms_flag = False # 是否可以下发短信,只下发未开通的
                ret_subject_id = 0
                ret_deal_status = 'deal_ignore'  # deal_ignore:忽略不处理, deal_ok:处理成功
                for code in open_subject.split(','):
                    print '写入开通学科开始,code=',code
                    result = call_proc("sp_add_phone_subject", (ecid, bind_id, user_type, code, open_option, sn_code, phone_number, tiyan_remind, 0, 3, batch_id))
                    ret_subject_id = result[0]
                    # 写入开通途径统计数据,2-后台批量开通
                    open_type_c = 1 if sn_code else 2  # 有验证码即为1否则为2
                    if open_option == "yongjiushiyong":
                        open_type_c = 3
                    call_proc("sp_add_open_census", (bind_id, user_type, phone_number, code, 2, open_type_c))
                    # 写入开通途径统计数据结束
                    print '写入开通学科结束, tmp_subject_id=%s' % result[0]
                    sub_status = result[2]
                    if result[4] == 'deal_ok':
                        ret_deal_status = result[4]

                    if sub_status < 2 and ret_subject_id > 0:
                        can_send_sms_flag = True
                    if sub_status == 9:
                        # 永久试用
                        can_send_sms_flag = True
                # 账号密码下发
                msg_txt = sms_txt
                if ret_deal_status == 'deal_ok' and option_select == 'sendaccount':
                    if user_type == 1:
                        msg_txt += """账号：%s，密码：%s。""" % (username, password)
                    else:
                        msg_txt += ' 账号：%s密码：%s' % (username, password)

                    open_type = 'yindao'

                print '写入引导短信开始,can_send_sms_flag=',can_send_sms_flag
                if open_type == 'yindao' and msg_txt and can_send_sms_flag:

                    err_msg.append({'row': row, 'col': 12, 'msg': '下发引导短信'})
                    result = call_proc("sp_send_sms", (phone_number, msg_txt, '10657050500001', batch_id))
                    if result[0] > 0:
                        print '写入引导短信结束, mp_sms_record_id=%s' % result[0]
                print '总记录:%s条,成功处理%s条,处理完第%s条' % (all_num,ok_num,j)
                if bind_id:
                    ok_num += 1
                    err_msg.append({'row': row, 'col': 10, 'msg': '成功'})
                else:
                    err_msg.append({'row': row, 'col': 10, 'msg': '失败'})

                # 下发系统短信
                send_system_sms(open_subject, system_sms, user_type, phone_number, batch_id)
            except Exception, e:
                if str(e).find('MySQL') > 0:
                    time.sleep(10)
                    conn = get_ketang_conn()
                    cur = conn.cursor()
                    cur.execute(sql)
                    print '重新建立数据连接'
                err_msg.append({'row':row,'col':10,'msg':'%s' % e})
                print {'row':row,'col':10,'msg':'%s' % e}

        content = '总记录:%s条,成功处理%s条,处理完第%s条' % (all_num,ok_num,j)
        sql = "UPDATE tbkt_ketang.mp_batch_request SET status=2,num_ok=%s,end_date=%s WHERE id=%s" % (ok_num, int(time.time()), batch_id)
        print "========成功了========:", content
        try:
            cur.execute(sql)
            conn.commit()
        except Exception, ex:
            conn = get_ketang_conn()
            cur = conn.cursor()
            cur.execute(sql)
            conn.commit()

    except Exception, e:
        print "error.handler_txt_data:", e
