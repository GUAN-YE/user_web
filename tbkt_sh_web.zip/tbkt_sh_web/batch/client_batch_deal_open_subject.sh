#! /usr/bin/env sh  
filepath=$(cd "$(dirname "$0")"; pwd)
MAIN_MODULE=$filepath/batch_deal_open_subject.py  
logfile=/var/log/tbkt_cms_batch_deal_open_subject.log
case $1 in  
    start)  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/tbkt_cms_batch_deal_open_subject.pid --logfile=$logfile
        ;;  
    stop)  
        kill -9 `cat /var/run/tbkt_cms_batch_deal_open_subject.pid`  
        ;;  
    restart)  
        kill -9 `cat /var/run/tbkt_cms_batch_deal_open_subject.pid`  
        sleep 1  
        PYTHONPATH=.:$PYTHONPATH twistd --python=$MAIN_MODULE --pidfile=/var/run/tbkt_cms_batch_deal_open_subject.pid --logfile=$logfile  
        ;;  
    log)  
        tail -f $logfile
        ;;  
    *)  
        echo "Usage: ./batch_deal_open_subject.sh start | stop | restart | log"  
        ;;  
esac  
