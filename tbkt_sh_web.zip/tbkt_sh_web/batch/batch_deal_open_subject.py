# coding=utf-8
import datetime, os, time, sys

# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
from twisted.internet import reactor
from twisted.application import service
from config import *
from batch.batch_deal_open_subject_excel import handler_excel_data
from batch.batch_deal_open_subject_school_excel import handler_school_excel_data
from batch.batch_deal_open_subject_txt import handler_txt_data
from batch.batch_deal_open_subject_web import handler_web_data
from batch.batch_deal_open_account_excel import handler_account_excel_data
from batch.batch_deal_open_account_web import handler_account_web_data
from batch.batch_deal_open_account_school_excel import handler_school_excel_data as handler_account_school_web_data


def handler_requset_data(sh_script_id):
	"""
	查询出待处理的请求数据进行处理
	-------------------------------------------------
	修改人                     修改时间
	-------------------------------------------------
	杜祖永                     2015-02-27
	"""
	heartbeat_num = 0
	while True:
		print "开始处理", datetime.datetime.now()
		print 'sh_script_id=', sh_script_id
		try:
			now_time = int(time.time())
			unix_time = now_time - 180
			conn = get_ketang_conn()
			cur = conn.cursor()
			sql = """select
                id,
                batch_type,
                data_source,
                user_type,
                sch_id,
                dept_id,
                grade_id,
                class_id,
                sms_txt,
                file_name,
                status,
                affix_info,
                timer_date,
                email_user,
                add_date,
                add_username FROM tbkt_ketang.mp_batch_request WHERE status=0 and batch_type in (1,2) and add_date<%s ORDER BY priority, id  limit 1
            """ % unix_time
			if sh_script_id == 32:
				sql = """select
                id,
                batch_type,
                data_source,
                user_type,
                sch_id,
                dept_id,
                grade_id,
                class_id,
                sms_txt,
                file_name,
                status,
                affix_info,
                timer_date,
                email_user,
                add_date,
                add_username FROM tbkt_ketang.mp_batch_request WHERE username<>'songguoyang' and status=0 and batch_type in (1,2) and add_date<%s ORDER BY priority, id  limit 1
            """ % unix_time
			cur.execute(sql)
			batch_request = cur.fetchone()
			# print batch_request
			if not batch_request:
				print '没有需要处理的批处理请求'
				time.sleep(20)
				continue
			
			batch_id = batch_request[0]
			batch_type = batch_request[1]
			data_source = batch_request[2]
			print 'batch_id=%s,batch_type=%s,data_source=%s' % (batch_id, batch_type, data_source)
			cur_date = datetime.datetime.now()
			if (cur_date.hour < 8 or cur_date.hour >= 20) and batch_type == 1:
				print '早上8点以前，晚上20点以后不处理 批开学科'
				time.sleep(60)
				continue
			# 更新为处理中状态
			sql = 'UPDATE tbkt_ketang.mp_batch_request SET sh_script_id=%s,status=1 WHERE id=%s' % (sh_script_id, batch_id)
			cur.execute(sql)
			conn.commit()
			if data_source == 1 and batch_type == 1:
				# 开通学科 网站数据
				handler_web_data(batch_request)
			elif data_source == 2 and batch_type == 1:
				# 开通学科 excel数据
				handler_excel_data(batch_request)
			elif data_source == 3 and batch_type == 1:
				# 开通学科 txt数据
				handler_txt_data(batch_request)
			elif data_source == 99 and batch_type == 1:
				# 开通学科 excel数据 学校模板
				handler_school_excel_data(batch_request)
			
			elif data_source == 1 and batch_type == 2:
				# 开通账号 网站数据
				handler_account_web_data(batch_request)
			elif data_source == 2 and batch_type == 2:
				# 开通账号 excel数据
				handler_account_excel_data(batch_request)
			elif data_source == 99 and batch_type == 2:
				# 开通账号 excel数据 学校模板
				handler_account_school_web_data(batch_request)
		
		except Exception, e:
			print "error.handler_requset_data:", e
		print 'success', datetime.datetime.now()
		time.sleep(3)


def main(sh_script_id):
	reactor.callInThread(handler_requset_data, sh_script_id)
	# handler_requset_data(0)


if __name__ == "__main__":
	print 'main'
	main(0)

elif __name__ == '__builtin__':
	print '__builtin__'
	sh_id = sys.argv[2].split('.')[0][-1:]
	sh_script_id = 0
	if sh_id == 't':
		sh_script_id = 26
	elif sh_id == '2':
		sh_script_id = 30
	elif sh_id == '3':
		sh_script_id = 31
	elif sh_id == '4':
		sh_script_id = 31
	main(sh_script_id)
	application = service.Application('open_subject')
