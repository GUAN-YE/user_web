# coding=utf-8
import os, time, sys, random, base64
import simplejson as json
from db_mysql import db
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
from config import *


def handler_account_web_data(batch_request):
    """
    批量账号下发 网站数据处理
    -------------------------------------------------
    修改人                     修改时间
    -------------------------------------------------
    杜祖永                     2015-03-02
    """
    try:
        conn = get_ketang_conn()
        cur = conn.cursor()
        err_msg = [] # 错误日志
        all_num = 0  # 总记录
        ok_num = 0   # 成功处理记录数
        batch_id = batch_request[0]
        user_type = batch_request[3]
        sch_id = batch_request[4]
        parent_id = batch_request[5]  # school_unit_class的自增id
        grade_id = batch_request[6]
        class_id = batch_request[7]
        affix_info = json.loads(batch_request[11])
        option_select = affix_info['option_select']

        # 获取网站数据
        sql = """
        select distinct b.id,b.username,ap.`password`,b.phone from tbkt_user.auth_user b
        INNER JOIN tbkt_user.auth_profile ap ON b.id=ap.user_id
        INNER JOIN tbkt_ketang.mobile_order_region r  on b.id=r.user_id
        """
        path = ''

        if class_id > 0:
            sql += " and r.unit_class_id='%s'" % class_id
        elif grade_id > 0:
            path += '|%s|%s' % (parent_id, grade_id)
            sql += " INNER JOIN tbkt_com.school_unit_class suc ON r.unit_class_id=suc.id AND suc.path like '" + path + "%%'"
            # sql += " and r.path like '" + path + "%%'"
        elif parent_id > 0:
            path = '|%s' % parent_id
            sql += " INNER JOIN tbkt_com.school_unit_class suc ON r.unit_class_id=suc.id AND suc.path like '" + path + "%%'"
            # sql += " and r.path like '" + path + "%%'"
        sql += " where r.school_id=%s and b.type=%s" % (sch_id, user_type)
        sql += " GROUP BY b.phone order by b.username"
        print sql
        cur.execute(sql)
        phone_list = cur.fetchall()
        nrows = len(phone_list)
        print '总记录数据nrows=',nrows
        all_num = nrows
        j = 0
        row = 1  # 当前处理第几行
        # 更新为处理中状态
        sql = 'UPDATE tbkt_ketang.mp_batch_request SET status=1,num_all=%s,start_date=%s WHERE id=%s' % (all_num, int(time.time()), batch_id)
        cur.execute(sql)
        conn.commit()
        for phone in phone_list:
            try:
                j += 1
                row += 1
                bind_id = phone[0]
                username = phone[1]
                password = base64.b64decode(phone[2])
                phone_number = phone[3]  # 手机号

                # 创建下发账号记录
                if option_select == 'sendaccount':
                    print '下发账号开始'
                    result = call_proc("sp_send_account", (username, password, phone_number, bind_id, batch_id, '批处理'))
                    print result
                    # if result[0] > 0:
                    print '下发账号结束'
                print '总记录:%s条,成功处理%s条,处理完第%s条' % (all_num,ok_num,j)
                if bind_id:
                    ok_num += 1
                    err_msg.append({'row': row, 'col': 10, 'msg': '成功'})
                else:
                    err_msg.append({'row': row, 'col': 10, 'msg': '失败'})
            except Exception, e:
                if str(e).find('MySQL') > 0:
                    time.sleep(10)
                    conn = get_ketang_conn()
                    cur = conn.cursor()
                    cur.execute(sql)
                    print '重新建立数据连接'
                err_msg.append({'row': row, 'col': 10, 'msg': '%s' % e})
                print {'row': row, 'col': 10, 'msg': '%s' % e}

        content = '总记录:%s条,成功处理%s条,处理完第%s条' % (all_num,ok_num,j)
        sql = "UPDATE tbkt_ketang.mp_batch_request SET status=2,num_ok=%s,end_date=%s WHERE id=%s" % (ok_num, int(time.time()), batch_id)
        print "====处理成功:=====", content
        try:
            cur.execute(sql)
            conn.commit()
        except Exception, ex:
            conn = get_ketang_conn()
            cur = conn.cursor()
            cur.execute(sql)
            conn.commit()
        cur.execute(sql)
        conn.commit()

    except Exception, e:
        print "error.handler_web_data:", e
