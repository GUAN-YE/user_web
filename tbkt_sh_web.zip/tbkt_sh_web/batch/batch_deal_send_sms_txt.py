# coding=utf-8
import os, time, sys, base64
import simplejson as json

# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
from config import *


def handler_txt_data(batch_request):
    """
    群发短信 txt文件处理
    -------------------------------------------------
    修改人                     修改时间
    -------------------------------------------------
    杜祖永                     2015-02-27
    """
    try:
        conn = get_ketang_conn()
        cur = conn.cursor()

        err_msg = [] # 错误日志
        all_num = 0  # 总记录
        ok_num = 0   # 成功处理记录数

        batch_id = batch_request[0]
        batch_type = batch_request[1]
        data_source = batch_request[2]
        user_type = batch_request[3]
        sch_id = batch_request[4]
        dept_id = batch_request[5]
        grade_id = batch_request[6]
        class_id = batch_request[7]
        sms_txt = batch_request[8]
        file_name = batch_request[9]
        affix_info = json.loads(batch_request[11])
        status = affix_info['status']
        option_select = affix_info['option_select']
        has_subject = affix_info['has_subject']  # 有无科目

        is_fee = -1
        fee_sql = ''
        if status.find('isfee0') > -1:
            is_fee = 0
            fee_sql = '0'
            status = status.replace('isfee0','2')
        if status.find('isfee1') > -1:
            is_fee = 1
            status = status.replace('isfee1','2')
            if fee_sql:
                fee_sql += ',1'
            else:
                fee_sql = '1'
        file_path = os.path.join(G_IMPORT_DIR, file_name)
        bk = open(file_path)  # 打开txt文件
        phone_list = bk.readlines()
        nrows = len(phone_list)
        print '总记录数据nrows=',nrows
        all_num = nrows
        j = 0
        row = 1  # 当前处理第几行
        # 更新为处理中状态
        sql = 'UPDATE tbkt_ketang.mp_batch_request SET status=1,num_all=%s,start_date=%s WHERE id=%s' % (all_num, int(time.time()),batch_id)
        cur.execute(sql)
        conn.commit()
        tmp_phone_list = []  # 临时手机号列表，防止重复处理
        for phone in phone_list:
            try:
                j += 1
                row += 1
                phone_number = phone.replace('\n', '').replace('\r', '')  # 手机号
                # 验证开始
                if not phone_number:
                    err_msg.append({'row': row, 'col': 10, 'msg': '手机号未填写'})
                    continue
                if phone_number in tmp_phone_list:
                    # 防止重复处理
                    continue
                else:
                    tmp_phone_list.append(phone_number)
                print '读取订单信息开始,phone_number=', phone_number, 'user_type=', user_type
                sql = """select b.id,b.username,ap.`password`,s.sp_number from tbkt_user.auth_user b
                        INNER JOIN tbkt_user.auth_profile ap ON b.id=ap.user_id"""

                if status:
                    sql += """ INNER JOIN tbkt_ketang.mobile_subject_detail_hn s on b.phone=s.phone_number and s.status in (%s)
                """ % status

                if fee_sql:
                    sql += ' and s.is_fee in (%s) ' % fee_sql

                sql += """ where b.type=%s and b.phone='%s' """ % (user_type, phone_number)

                sql += '  ORDER BY b.username LIMIT 1'
                print sql
                cur.execute(sql)
                result = cur.fetchone()
                if not result:
                    print '%s 无对应订单信息' % phone_number
                    continue
                bind_id = result[0]
                username = result[1]
                password = base64.b64decode(result[2])
                if result[3]:
                    sp_number = result[3]
                else:
                    sp_number = '10657050500001'
                msg_txt = ''
                msg_txt = sms_txt
                if option_select == 'sendaccount':
                    msg_txt += ' 账号：%s密码：%s' % (username, password)

                if msg_txt:
                    print '写入短信开始'
                    err_msg.append({'row': row, 'col': 12,'msg': '下发短信'})
                    result = call_proc("sp_send_sms", (phone_number, msg_txt, '10657050500001', batch_id))
                    if result[0] > 0:
                        print '写入短信结束, mp_sms_record_id=%s' % result[0]

                print '总记录:%s条,成功处理%s条,处理完第%s条' % (all_num,ok_num,j)
                if bind_id:
                    ok_num += 1
                    err_msg.append({'row': row, 'col': 10, 'msg': '成功'})
                else:
                    err_msg.append({'row': row, 'col': 10, 'msg': '失败'})
            except Exception, e:
                if str(e).find('MySQL') > 0:
                    time.sleep(10)
                    conn = get_ketang_conn()
                    cur = conn.cursor()
                    cur.execute(sql)
                    print '重新建立数据连接'
                err_msg.append({'row': row, 'col': 10, 'msg': '%s' % e})
                print {'row': row, 'col': 10, 'msg': '%s' % e}

        content = '总记录:%s条,成功处理%s条,处理完第%s条' % (all_num,ok_num,j)
        sql = "UPDATE tbkt_ketang.mp_batch_request SET status=2,num_ok=%s,end_date=%s WHERE id=%s" % (ok_num, int(time.time()), batch_id)
        print content
        try:
            cur.execute(sql)
            conn.commit()
        except Exception, ex:
            conn = get_ketang_conn()
            cur = conn.cursor()
            cur.execute(sql)
            conn.commit()

    except Exception, e:
        print "error.handler_txt_data:", e
