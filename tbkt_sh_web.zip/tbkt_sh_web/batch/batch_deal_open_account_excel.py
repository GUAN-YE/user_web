# coding=utf-8
import os, time, re, xlrd, sys, random, base64
import simplejson as json
from db_mysql import db
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
print os.path.normpath(os.path.join(sys_base_path, '../..'))
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
from xlutils.copy import copy
from config import *

G_GRADE_DICT = {u'学前班': 0, u'一年级': 1, u'二年级': 2, u'三年级': 3, u'四年级': 4, u'五年级': 5, u'六年级': 6, u'七年级': 7, u'八年级': 8,
				u'九年级': 9, u'待分年级': -100}
mobile_pattern = "((((13[5-9]{1})|(15[012789]{1})|178{1}|(18[23478]{1})){1}[0-9]{1})|(134[0-8]{1})){1}[0-9]{7}"  # 移动手机正则表达式


def modify_file(wb, file_full_path, arr=[]):
	"""
	-- -------------------------------------
	 添加人          添加时间           作用
	-------------------------------------
	 杜祖永           2015-02-27    修改文件
	--------------------------------------
	 参数： target_file
	arr 格式:[{'row':1,'col':2, 'text':''}]
	flag:1、学校不存在，2、业务地区不存在,3、数据处理完成
	--------------------------------------
	"""
	print '开始修改文件', wb, 'arr len=', len(arr)
	try:
		sheet = wb.get_sheet(0)
		i = 0
		for obj in arr:
			try:
				i += 1
				# print 'write---', i
				# print obj['row'],obj['col'], obj['msg']
				sheet.write(obj['row'], obj['col'], obj['msg'].decode('utf8'))
			except Exception, e:
				print '修改文件第 %s 行异常 err:%s' % (i, e)
		# print 'file_full_path'
		wb.save(file_full_path)
		print file_full_path
		print '--------------修改文件成功'
	except Exception, e:
		print '修改文件异常:file_full_name=<%s>, err=<%s>' % (file_full_path, e)


def handler_account_excel_data(batch_request):
	"""
	批开账号 excel文件处理
	-------------------------------------------------
	修改人                     修改时间
	-------------------------------------------------
	杜祖永                     2015-02-27
	"""
	print "=====account_excel文件======"
	try:
		conn = get_ketang_conn()
		cur = conn.cursor()
		err_msg = []  # 错误日志
		all_num = 0  # 总记录
		ok_num = 0  # 成功处理记录数
		batch_id = batch_request[0]
		user_type = batch_request[3]
		sch_id = batch_request[4]
		parent_id = batch_request[5]  # school_unit_class的自增id
		dept_id = db.tbkt_com.school_unit_class.get(id=parent_id).type
		grade_id = batch_request[6]
		class_id = batch_request[7]
		file_path = batch_request[9]
		affix_info = json.loads(batch_request[11])
		open_subject = affix_info['open_subject']
		data_operate_type = affix_info['data_operate_type']
		option_select = affix_info['option_select']
		platform_id = int(affix_info['platform_id'] if affix_info.has_key('platform_id') else 0)
		# file_path = os.path.join(G_IMPORT_DIR, file_name)
		school_dict = {}  # 学校缓存
		unit_class_dict = {}  # 班级缓存
		bk = xlrd.open_workbook(file_path)  # 打开excel文件
		wb = copy(bk)  # 复制工作表
		sh = bk.sheets()[0]
		nrows = sh.nrows
		print '总记录数据nrows=', nrows
		all_num = nrows - 10
		j = 0
		row = 9  # 当前处理第几行
		# 更新为处理中状态
		sql = 'UPDATE tbkt_ketang.mp_batch_request SET status=1,num_all=%s,start_date=%s WHERE id=%s' % (all_num, int(time.time()), batch_id)
		cur.execute(sql)
		conn.commit()
		for r in range(10, nrows):
			try:
				j += 1
				row += 1
				phone_number = str(sh.row(r)[0].value).strip()  # 手机号
				phone_number = phone_number[:11]
				sex = 1
				user_name = str(sh.row(r)[1].value).strip()  # 姓名
				grade_name = sh.row(r)[2].value  # 年级名称
				class_id = str(sh.row(r)[3].value).strip()  # 班级ID
				# 二次确认码
				sn_code = ''
				if len(sh.row(r)) > 4:
					sn_code = str(sh.row(r)[4].value)[:6]  # 二次确认码
				print sex, user_name, phone_number, grade_name, class_id
				# 验证开始
				if not phone_number:
					err_msg.append({'row': row, 'col': 10, 'msg': '手机号未填写'})
					continue
				else:
					phone_number = phone_number[:11]
					if not re.match(mobile_pattern, phone_number):
						print row, "手机号%s不是移动手机号" % phone_number
						err_msg.append({'row': row, 'col': 10, 'msg': '手机号不是移动手机号'})
						continue
				try:
					if grade_name:
						grade_id = G_GRADE_DICT[grade_name]
					else:
						grade_id = 0
				except Exception, e:
					print '年级不规范-%s' % e
					err_msg.append({'row': row, 'col': 10, 'msg': '年级不规范'})
					continue
				try:
					if class_id:
						class_id = int(float(class_id))
					else:
						class_id = 0
				except Exception, e:
					print '班级格式不正确-%s' % e
					err_msg.append({'row': row, 'col': 10, 'msg': '班级格式不正确'})
					continue
				
				school_data = None  # 学校
				unit_class = ''  # 班级
				key_class = "%s_%s_%s" % (parent_id, grade_id, class_id)
				if sch_id not in school_dict.keys() or key_class not in unit_class_dict.keys():
					unit_class = get_unit_class(parent_id, grade_id, class_id)
					if unit_class:
						unit_class_dict[key_class] = unit_class
					sch_one = call_proc('sp_get_school', (sch_id, ''))
					school_data = {'sch_id': sch_id, 'sch_name': sch_one[0], 'province': sch_one[1], 'city': sch_one[2], 'county': sch_one[3]}
					school_data['ecid'] = sch_one[4]
					school_dict[sch_id] = school_data
				else:
					school_data = school_dict[sch_id]
					unit_class = unit_class_dict[key_class]
				print 'unit_class', unit_class
				print 'school_data', school_data
				if not unit_class:
					err_msg.append({'row': row, 'col': 10, 'msg': '获取学校班级失败'})
					continue
				if user_type == 1:
					# 学生
					sql = "select DISTINCT b.username,s.status from tbkt_user.auth_user b left join tbkt_ketang.mobile_subject_detail_hn s on b.phone=s.phone_number and s.status in (0,1,2,9) where b.type=1 and b.phone='%s'" % phone_number
					cur.execute(sql)
					user_list = cur.fetchall()
					tmp_user = {}
					for u_obj in user_list:
						if not tmp_user.has_key(u_obj[0]):
							tmp_user[u_obj[0]] = '未开通'
						if u_obj[1] in [2, 9]:
							tmp_user[u_obj[0]] = '已开通'
					if len(tmp_user.keys()) >= 2:
						# 已经有两个以上账号，不能再创建账号
						tmp_msg = ''
						for key in tmp_user.keys():
							tmp_msg += '%s:%s ' % (key, tmp_user[key])
						err_msg.append({'row': row, 'col': 11, 'msg': tmp_msg})
						continue
					elif len(tmp_user.keys()) == 1:
						xs_num = tmp_user.keys()[0][13:]
						if xs_num:
							username = '%sxs' % phone_number
						else:
							username = '%sxs1' % phone_number
					else:
						username = '%sxs' % phone_number
				if user_type == 3:
					username = '%sjs' % phone_number
				password = random.randint(123456, 987654)
				encrypt_password = encode_password(str(password))
				decode_password = base64.b64encode(str(password))
				print '创建订单开始,username=', username, 'data_operate_type=', data_operate_type
				result = call_proc("sp_add_phone_order",
								    (username,
									user_name,
									user_type,
									encrypt_password,
									password,
									decode_password,
									platform_id,
									grade_id,
									open_subject,
									dept_id,
									sex,
									phone_number,
									school_data['province'],
									school_data['city'],
									school_data['county'],
									sch_id,
									school_data['sch_name'],
									unit_class['sch_type'],
									unit_class['unit_id'],
									data_operate_type,
									option_select,
									0,
									'批处理'))
				print '创建订单结果', result
				bind_id = result[0]
				region_id = result[1]
				print '创建订单结束,bind_id=%s,region_id=%s' % (bind_id, region_id)
				print '总记录:%s条,成功处理%s条,处理完第%s条' % (all_num, ok_num, j)
				if bind_id:
					ok_num += 1
					err_msg.append({'row': row, 'col': 10, 'msg': '成功'})
				else:
					err_msg.append({'row': row, 'col': 10, 'msg': '失败'})
			except Exception, e:
				import traceback
				traceback.print_exc()
				if str(e).find('MySQL') > 0:
					time.sleep(10)
					conn = get_ketang_conn()
					cur = conn.cursor()
					cur.execute(sql)
					print '重新建立数据连接'
				err_msg.append({'row': row, 'col': 10, 'msg': '%s' % e})
				print {'row': row, 'col': 10, 'msg': '%s' % e}
		
		content = '总记录:%s条,成功处理%s条,处理完第%s条' % (all_num, ok_num, j)
		sql = "UPDATE tbkt_ketang.mp_batch_request SET status=2,num_ok=%s,end_date=%s WHERE id=%s" % (ok_num, int(time.time()), batch_id)
		print "=======处理成功====:", content
		try:
			cur.execute(sql)
			conn.commit()
		except Exception, ex:
			conn = get_ketang_conn()
			cur = conn.cursor()
			cur.execute(sql)
			conn.commit()
		# 写入处理结果
		modify_file(wb, file_path, err_msg)
	except Exception, e:
		import traceback
		traceback.print_exc()
		print "error.handler_excel_data:", e


def get_unit_class(parent_id, grade_id, class_id):
	unit_class = {'unit_id': 0}
	unit_class['grade_id'] = grade_id
	unit_class['class_id'] = class_id
	try:
		# 获取年级节点ID
		unit_type = 1
		level_id = 2
		results = call_proc("sp_get_unit_class", (parent_id, unit_type, level_id, grade_id, class_id, ''))
		parent_id = results[0]
		# 获取班级节点ID
		level_id = 3
		conn = get_ketang_conn()
		cursor = conn.cursor()
		results = call_proc("sp_get_unit_class", (parent_id, unit_type, level_id, grade_id, class_id, ''))
		unit_class['unit_id'] = results[0]
		unit_class['sch_type'] = results[1]
		unit_class['unit_name'] = results[2]
		unit_class['unit_type'] = results[3]
		unit_class['unit_path'] = results[4]
	except Exception, e:
		print '创建班级异常:%s' % e
		unit_class['sch_type'] = 0
		unit_class['unit_name'] = '待分班级'
		unit_class['unit_type'] = 1
		unit_class['unit_path'] = ''
		unit_class['grade_id'] = -100
		unit_class['class_id'] = -100
	
	return unit_class
