# -*- coding: utf-8 -*-
import datetime, os, time, sys
import simplejson as json
import xlrd
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
from twisted.internet import reactor
from twisted.application import service
from config import *


def change_num_to_subject_code(user_type, cancel_subject):
    """将数字转换成对应科目号"""
    STUDENT_SUBJECT_CODE = {2: 'A', 3: 'B', 4: 'C', 9: 'D', 5: 'E'}
    TEACHER_SUBJECT_CODE = {2: 'J', 3: 'K', 4: 'L', 9: 'M', 5: 'N'}
    code_list = cancel_subject.split(',')
    if user_type == 1:
        code_list = [STUDENT_SUBJECT_CODE.get(int(c), '') for c in code_list ]
    else:
        code_list = [TEACHER_SUBJECT_CODE.get(int(c), '') for c in code_list ]
    return code_list


def map_to_char(code):
    """
    将A B C D 转换为'A' 'B' 'C' 'D'  
    不转换sql报异常
    """
    return "'%s'" % code


def up_mp_batch_detail(batch_id, phone_list, code_list, user_type):
    """
    增加批处理详情
    """
    if int(user_type) == 1:
        code_dict = {"A": 2, "B": 3, "C": 4, "D": 9, "E": 5}
    if int(user_type) == 3:
        code_dict = {"J": 2, "K": 3, "L": 4, "M": 9, "N": 5}
    batch_id = int(batch_id)
    sql_col = []
    for code in code_list:
        for phone in phone_list:
            sql_col.append((batch_id, code_dict[code], str(phone), int(time.time())))
    sql_str = ''
    for i, col in enumerate(sql_col):
        if i == 0:
            sql_str = str(col)
        else:
            sql_str += ","+str(col)
    try:
        conn = get_ketang_conn()
        cur = conn.cursor()
        sql = """
            INSERT INTO 
                tbkt_ketang.mp_batch_detail(batch_id, subject_id, phone_number, add_time)
            VALUES %s
        """ % (sql_str)
        num = cur.execute(sql)
        conn.commit()
        print "成功向mp_batch_detail插入%s数据!" % num
    except Exception, e:
        print "增加批处理详情失败:",e


def handler_requset_data():
    """
    批量退订学科
    -------------------------------------------------
    修改人                     修改时间
    -------------------------------------------------
    周培林                     2015-09-07
    """
    while True:
        print '批量退订 开始处理：', datetime.datetime.now()
        try:
            now_time = int(time.time())
            unix_time = now_time - 180
            conn = get_ketang_conn()
            cur = conn.cursor()
            sql = """select
                id,
                user_type,
                sms_txt,
                file_name,
                affix_info,
                email_user,
                add_username FROM tbkt_ketang.mp_batch_request WHERE status=0 and batch_type =88 and add_date<%s ORDER BY id  limit 1
            """ % unix_time

            cur.execute(sql)
            batch_request = cur.fetchone()
            if not batch_request:
                print '没有需要处理的批处理请求！'
                time.sleep(20)
                continue
            batch_id = batch_request[0]
            print 'batch_id =%s' % batch_id
            cur_date = datetime.datetime.now()
            if cur_date.hour < 8 or cur_date.hour >= 20:
                print '早上8点以前，晚上20点以后不处理 批开学科'
                time.sleep(60)
                continue
            # 更新批处理状态
            sql = 'UPDATE tbkt_ketang.mp_batch_request SET status =1 WHERE id=%s' % batch_id
            cur.execute(sql)
            conn.commit()
            # 新增批处理日志
            sql = "insert into tbkt_ketang.mp_batch_request_log(id,sh_script_id,add_date) values(%s,%s,NOW())" % (batch_id, 0)
            cur.execute(sql)
            conn.commit()
            # 处理数据
            handler_cancel_txt_data(batch_request)
        except Exception, e:
            import traceback
            traceback.print_exc()
            print "error.handler_requset_data:", e


def handler_cancel_txt_data(batch_request):
    """
    批量退订学科 txt文件处理
    -------------------------------------------------
    修改人                     修改时间
    -------------------------------------------------
    周培林                     2015-09-07
    """
    try:
        conn = get_ketang_conn()
        cur = conn.cursor()
    except Exception, e:
        print '数据库连接异常:', e
    try:
        batch_id = batch_request[0]
        user_type = batch_request[1]
        sms_txt = batch_request[2]
        file_path = batch_request[3]
        affix_info = batch_request[4]
        email_user = batch_request[5]
        # 要退订的科目
        affix_info = json.loads(affix_info)
        open_option = affix_info['open_option']
        cancel_subject = affix_info['open_subject']
        code_list = change_num_to_subject_code(user_type, cancel_subject)
        # file_path = os.path.join(G_IMPORT_DIR, file_name)
        bk = xlrd.open_workbook(file_path)  # 打开excel文件
        sh = bk.sheets()[0]
        nrows = sh.nrows
        all_num = nrows - 1
        print '总记录数nrows==', all_num
        j = 0
        row = 1  # 当前处理第几行
        # 更新处理状态
        sql = 'UPDATE tbkt_ketang.mp_batch_request SET status=1, num_all=%s, start_date=%s WHERE id=%s' % (all_num, int(time.time()), batch_id)
        cur.execute(sql)
        conn.commit()
        all_phone = []
        for r in range(1, nrows):
            phone = str(sh.row(r)[0].value).strip()[:11]  # 手机号
            print phone
            try:
                j += 1
                row += 1
                all_phone.append(str(phone))
            except Exception, e:
                print '手机号列表异常:', e
        print "需要处理的手机:", all_phone

        try:
            if open_option == 'open':
                # 当前是开通状态
                cur_status = 2
                sql = """
                    UPDATE
                         tbkt_ketang.mobile_subject_detail_hn
                    SET
                        ftp_status = 0,
                        status = 3
                    WHERE
                        phone_number in  (%s)
                    AND
                        code in (%s) and status=%s
                """ % (','.join(map(map_to_char, all_phone)), ','.join(map(map_to_char, code_list)), cur_status)
            # 当前状态是永久试用
            else:
                cur_status = 9
                sql = """
                    UPDATE
                         tbkt_ketang.mobile_subject_detail_hn
                    SET
                        ftp_status = 1,
                        status = 4,
                        cancel_date='%s'
                    WHERE
                        phone_number in  (%s)
                    AND
                        code in (%s) and status=%s
                """ % (int(time.time()), ','.join(map(map_to_char, all_phone)), ','.join(map(map_to_char, code_list)), cur_status)
            ok_num = cur.execute(sql)
            conn.commit()
            # 更新处理状态
            sql = 'UPDATE tbkt_ketang.mp_batch_request SET status=2, num_ok=%s, end_date=%s WHERE id=%s' % (ok_num, int(time.time()), batch_id)
            cur.execute(sql)
            conn.commit()
            print "批量退订学科 处理成功，总%s记录，其中成功%s条！" % (all_num, ok_num)
            # 更新mp_batch_detail数据
            up_mp_batch_detail(batch_id, all_phone, code_list, user_type)
        except Exception, e:
            print "获取需要退订的信息错误:", e
    except Exception, e:
        print 'handler_txt_data:', e


def main():
    # handler_requset_data()
    reactor.callInThread(handler_requset_data)


if __name__ == '__main__':
    print 'main'
    main()

elif __name__ == '__builtin__':
    print '__builtin__'
    main()
    application = service.Application('client_cancel_subject')