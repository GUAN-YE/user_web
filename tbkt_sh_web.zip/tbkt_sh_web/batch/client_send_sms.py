# coding=utf-8
import datetime, os, time, sys
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
print os.path.normpath(os.path.join(sys_base_path, '../..'))
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
from twisted.internet import reactor
from twisted.application import service
from config import *
from sms.SMSInfo import SMSInfo


def handler_requset_data():
    """
    短信群发
    -------------------------------------------------
    修改人                     修改时间
    -------------------------------------------------
    杜祖永                     2015-03-02
    """
    heartbeat_num = 0
    while True:
        # print "开始处理", datetime.datetime.now()
        try:
            conn = get_ketang_conn()
            cur = conn.cursor()
            sql = """SELECT id,phone_number,msg_txt,sp_number,batch_id,add_date FROM tbkt_ketang.mp_sms_record WHERE send_status=0 AND add_date>UNIX_TIMESTAMP(DATE_ADD(NOW(), INTERVAL -1 DAY)) limit 100;"""
            cur.execute(sql)
            batch_request = cur.fetchall()
            # print batch_request
            if not batch_request:
                print '短信群发 没有需要处理的数据'
                time.sleep(5)
                continue
            smsInfo = SMSInfo()
            smsInfo.SMS__Priority = 9
            sender = {}
            sender['send_phone'] = ''          # 发送手机号 没有为''
            sender['unit_class_id'] = 0        # 发者班级ID 没有为0
            sender['object_id'] = 0            # 发送对象ID 没有为0
            sender['object_type'] = 8          # 发送类型   没有为0
            sender['send_user'] = ''           # 发送者账号 没有为''
            sender['accept_user'] = ''         # 接收者姓名 没有为''
            sender['flat_type'] = 0
            sp_number = '10657050500001'
            phone_list_ori = []
            phone_list_tea = []  # 教师金豆短信
            id_list = []
            for obj in batch_request:
                id = obj[0]
                id_list.append('%s' % id)
                phone_number = obj[1]
                msg_content = obj[2]   # 短信内容
                sender['object_id'] = obj[4]            # 发送对象ID 没有为0
                # 获取发送端口号
                sql_sp = """SELECT sp_number FROM tbkt_ketang.mobile_subject_detail_hn WHERE phone_number='%s' LIMIT 1;""" % phone_number
                cur.execute(sql_sp)
                sp_data = cur.fetchall()
                if sp_data:
                    sp_number = sp_data[0][0]
                if obj[3]:
                    sp_number = obj[3]
                if obj[4] > 0:
                    phone_list_ori.append([phone_number, sp_number, msg_content])
                else:
                    phone_list_tea.append([phone_number, sp_number, msg_content])
            if datetime.datetime.now().hour == 9:
                print '本次需要下发教师金豆短信%s条' % len(phone_list_tea)
                phone_list = phone_list_tea
            else:
                print '本次需要下发普通短信%s条' % len(phone_list_ori)
                phone_list = phone_list_ori
            if phone_list:
                try:
                    flag = smsInfo.send_many(phone_list, '', sender=sender)
                except Exception, e:
                    print "error.send_many--error:", e
                    flag = 0
                print flag
                send_status = 1
                if flag:
                    print '本次--%s条-短信下发成功' % (len(phone_list))
                else:
                    print '本次短信下发失败'
                    send_status = 3
                # 更新下发状态
                sql = "update tbkt_ketang.mp_sms_record set send_status=%s,send_date=%s where id in (%s)" % (send_status, int(time.time()), ','.join(id_list))
                cur.execute(sql)
                conn.commit()
            else:
                print '未找到需要发送短信的数据'
        except Exception, e:
            print "error.handler_requset_data:", e
        time.sleep(3)


def main():
    reactor.callInThread(handler_requset_data)
    # handler_requset_data()

if __name__ == "__main__":
    print 'main'
    main()
    
elif __name__=='__builtin__':
    print '__builtin__'
    main()
    application=service.Application('client_send_sms')
