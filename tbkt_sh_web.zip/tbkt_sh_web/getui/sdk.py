#coding: utf-8
"""
个推-消息推送平台sdk
http://gepush.com/cn/getui.html
"""
import os
import GtConfig
from igt_push import IGeTui
from payload.APNPayload import DictionaryAlertMsg, APNPayload, SimpleAlertMsg
from igetui.igt_message import IGtSingleMessage, IGtListMessage
from igetui.igt_target import Target
from igetui.template.igt_notification_template import NotificationTemplate
from igetui.template.igt_transmission_template import TransmissionTemplate

__all__ = ['sendone', 'sendmany']

# 开启异步模式
os.environ["gexin_pushList_needAsync"] = "1"

# 配置每个应用的 {config_id: APPKEY, APPID, MASTERSECRET}
APP_CONFIG = {
    # demo
    1: {
        'key':      'ULXG9iBzTD9GrlafDZZKC2',
        'id':       'pEbzdoOL6V9oFoVX1eEuF1',
        'secret':   'TQbq06eObi7SfCVFJQMWr4',
    },
    # student
    2: {
        'key':      'SzonBi53xn8d6lVZG5hOR8',
        'id':       '8p3bjH03um5sWKssRcszf8',
        'secret':   'TKCwvJndsE9gHw0IYA3WB'
    },
    # teacher
    3: {
        'key':      'ugT0HGgtDj8Hrtp2iluMI7',
        'id':       'KsulER4nCj9OSV3UYPdmQ1',
        'secret':   'X7nD6RIDnl7t4ploNP7Fo2',
    },
}



app_cache = {}


def get_app(config_id):
    return APP_CONFIG.get(config_id)


def get_pusher(config_id):
    if config_id in app_cache:
        return app_cache[config_id]

    app = APP_CONFIG[config_id]
    pusher = IGeTui('', app['key'], app['secret'])
    app_cache[config_id] = pusher
    return pusher


def create_template(type, title, text, transmission_content="", logo_url=""):
    """
    创建推送模板

    :param type: 
        1: 点击通知打开应用模板
        2: 透传模板
    :param transmission_content: 透传参数
    """
    if type == 1:
        template = NotificationTemplate()
        template.appId = ""
        template.appKey = ""
        template.transmissionType = 1
        template.transmissionContent = transmission_content
        template.title = ''
        template.text = ''
        template.logo = 'logo.png'
        template.logoURL = 'logo.png'
        template.isRing = True
        template.isVibrate = True
        template.isClearable = True
    elif type == 2:
        template = TransmissionTemplate()
        template.transmissionType = 1
        template.appId = ""
        template.appKey = ""
        template.transmissionContent = transmission_content
        # iOS 推送需要的PushInfo字段 前三项必填，后四项可以填空字符串
        #template.setPushInfo('actionLockey', 4, 'body', 'sound', '', '', '', '')

    # iOS
    apnpayload = APNPayload()
    apnpayload.badge = 1  # 图标上的红字
    apnpayload.sound = "sound"
    apnpayload.addCustomMsg("payload", transmission_content)
    apnpayload.contentAvailable = 1
    apnpayload.category = "ACTIONABLE"
    
    alertMsg = DictionaryAlertMsg()
    alertMsg.title = title
    alertMsg.body = text
    alertMsg.actionLocKey = ''
    alertMsg.locKey = title
    alertMsg.locArgs=['locArgs']
    alertMsg.launchImage = 'ic_launcher.png'
    # iOS8.2以上版本支持
    # alertMsg.title = 'Title'
    # alertMsg.titleLocArgs = ['TitleLocArg']
    # alertMsg.titleLocKey = 'TitleLocKey'
    apnpayload.alertMsg = alertMsg
    template.setApnInfo(apnpayload)

    return template


def sendone(config_id, client_id, title, text, template_type=1, transmission_content="", logoURL=""):
    """
    单发

    :param config_id: 用于获取appkey, appid等信息
        1       Demo演示程序
        2       学生端APP
        3       教师端APP
    :param client_id: 客户端ID
    :param title: 标题(unicode)
    :param text: 消息内容(unicode)
    :param template_type: 模板类型
        1       通知模板

    :return: {'status': 'successed_online', 'result': 'ok', 'taskId': 'OSS-0122_3809c206b20546680c5723350c9cfb6c'}
    """
    app = get_app(config_id)
    push = get_pusher(config_id)

    template = create_template(template_type, title, text, transmission_content)
    template.appId = app['id']
    template.appKey = app['key']
    template.title = title
    template.text = text
    template.logoURL = logoURL

    message = IGtSingleMessage()
    message.isOffline = True
    message.offlineExpireTime = 5 * 60 * 1000 # 离线消息过期时间(毫秒)
    message.data = template
    message.pushNetWorkType = 0  # 2为4G/3G/2G 1为wifi推送，0为不限制推送
    
    target = Target()
    target.appId = app['id']
    target.clientId = client_id

    ret = push.pushMessageToSingle(message, target)
    return ret


def sendmany(config_id, client_ids, title, text, template_type=1, transmission_content="", logoURL=""):
    """
    群发

    :param config_id: 用于获取appkey, appid等信息
        1       Demo演示程序
        2       学生端APP
        3       教师端APP
    :param client_ids: 客户端ID列表
    :param title: 标题(unicode)
    :param text: 消息内容(unicode)
    :param template_type: 模板类型
        1       通知模板

    :return: {'contentId': 'OSL-0122_fsENjqUbgr8Nif3uwTTbW4', 'result': 'ok'}
    """
    app = get_app(config_id)
    push = get_pusher(config_id)

    template = create_template(template_type, title, text, transmission_content)
    template.appId = app['id']
    template.appKey = app['key']
    template.title = title
    template.text = text
    template.logoURL = logoURL

    message = IGtListMessage()
    message.isOffline = True
    message.offlineExpireTime = 5 * 60 * 1000 # 离线消息过期时间(毫秒)
    message.data = template
    message.pushNetWorkType = 0  # 2为4G/3G/2G 1为wifi推送，0为不限制推送

    targets = []
    for client_id in client_ids:
        t = Target()
        t.appId = app['id']
        t.clientId = client_id
        targets.append(t)
    
    try:
        content_id = push.getContentId(message, '')
    except Exception, e:
        print "GeTuiSDK Error:", e
        return
    ret = push.pushMessageToList(content_id, targets)
    return ret


if __name__ == '__main__':
    import json
    arg = json.dumps({"type":1})
    logo = 'http://stu.m.tbkt.cn/static/notice/logo.png'
    #print sendone(1, '3a74a306849fef1f6c86188440e2768', u'hi', u'好', 1, arg, logo)
    #print sendone(2, '7c0b3e52ba4b78590380975190d950c4', u'hi', u'好', 1, arg, logo)
    #print sendmany(2, ['383748db36c4026916958cb9f6f9de49', 'ce03045336d46e9dc665c16054251cae', '15e8e490716b54d1168c2f9d5629bbbb'], u'hi2', u'好', 1, arg, logo)
    print sendmany(2, ['d82fe4b07c207ba46b9ac1dbd17c2938'], u'hi', u'好', 1, {"type":1})
    #print sendmany(2, ['19eecd9f991a6be7a1c2cda2ce3c9fed', '15e8e490716b54d1168c2f9d5629bbbb'], u'hi', u'好', 2, {"task":"1"})