#coding: utf-8
import lorm
import sys
import os

import config

reload(sys)
sys.setdefaultencoding('utf-8')


def list_group(l, m):
    """
    列表按一定数量分组

    :example:
    >>> group([1,2,3,4,5], 2)
    >>> [[1,2], [3,4], [5]]

    :param m: 每组几个元素
    :returns: [(...), (...), ...]
    """
    groups = []
    n = len(l) / m + 1
    for i in xrange(n):
        row = l[i*m:i*m+m]
        if row:
            groups.append(row)
    return groups


def connect(alias=''):
    args = ()
    if alias == '130':
        args = ('192.168.0.130', 3306, 'dba_user', 'tbkt123456', 'tbkt')
    elif alias == '76':
        args = ('122.114.40.76', 3306, 'renwanxing', 'renwanxing60279052', 'tbkt')
    elif alias == '112':
        args = ('116.255.220.112', 3306, 'wangchenguang', 'wangchenguang8393', 'tbkt')
    elif alias == '130jx':
        args = ('192.168.7.250', 3306, 'dba_user', 'tbkt123456', 'jxtbkt')
    else:
        args = (config.DB_HOST, 3306, config.DB_UID, config.DB_PWD, config.DB_NAME)
    assert args
    return lorm.mysql_connect(*args, autoreconnect=1)


def twisted_run(f, *args, **kw):
    from twisted.internet import reactor
    from twisted.application import service

    app_name = kw.pop('app_name') or ''
    reactor.callInThread(f, *args, **kw)
    return service.Application(app_name)
