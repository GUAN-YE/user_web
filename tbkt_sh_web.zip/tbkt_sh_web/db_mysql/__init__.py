# coding: utf-8
# 初始化数据库链接
from db import Hub
from config import *
db = Hub(pymysql)
databases = ['tbkt_com', 'tbkt_ketang', 'tbkt_user', 'tbkt_manage']
# 初始化db数库链接方式
for table in databases:
	db.add_pool(table,
				host=DB_HOST,
				port=DB_PORT,
				user=DB_UID,
				passwd=DB_PWD,
				db=table,
				charset='utf8',
				autocommit=True,
				pool_size=8,
				wait_timeout=30)


