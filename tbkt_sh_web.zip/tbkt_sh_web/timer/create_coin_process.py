# coding:utf-8
# 金币返还整理流程脚本
# 处理流程:
# 1.拉取备份相关数据表;
# 2.返费目录生成;
# 3.金币返还数据表生成;
# 4.教师金币数据返还
# 5.重命名备份表;
import os
import sys
import time
import inspect
import pymysql
import logging
import datetime
# 获取文件目录
dir_name, _ = os.path.split(os.path.abspath(sys.argv[0]))
# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')
# 设置文件保存路径
BACKUP_PATH = '/data/backup/dbbackup/'
# 文件目录后缀
DATETIME = time.strftime('%Y%m%d-%H%M%S')
TODAY_BACKUP_PATH = BACKUP_PATH + DATETIME
# 重命名表后缀
DATE_DAY = datetime.datetime.now() - datetime.timedelta(days=10)
DB_DATETIME = "%s%.2d" % (DATE_DAY.year, DATE_DAY.month)
# 日志文件名
logfile = dir_name + '/' + 'exec_%s.log' % DB_DATETIME
# 创建日志方法
log = logging.getLogger('create_coin_process.py')
log.setLevel(logging.DEBUG)
# 日志生成住方法
ch = logging.FileHandler(logfile)
ch.setLevel(logging.DEBUG)
# 生成日志文件格式
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
# 添加日志
log.addHandler(ch)
# 建目录
if not os.path.exists(TODAY_BACKUP_PATH):
    os.makedirs(TODAY_BACKUP_PATH)

# 返金币数据链接
DB_HOST = '127.0.0.1'
DB_USER = 'wcs'
DB_NAME = 'fanfei_detail_his'
DB_USER_PASSWORD = 'wcs@109201'
DB_PORT = 3306
# 源数据链接
S_DB_HOST = '10.25.141.231'
S_DB_USER = 'guoyang'
S_DB_USER_PASSWORD = 'guoyang@tbkt2017'
S_DB_PORT = 3306
# 写入数据链接
RDS_DB_HOST = 'rm-2zekkuf62c6477n70.mysql.rds.aliyuncs.com'
RDS_DB_USER = 'guoyang'
RDS_DB_NAME = 'tbkt_com'
RDS_DB_USER_PASSWORD = 'guoyang@tbkt2017'
RDS_DB_PORT = 3306
# 第一次初始化时候需要提前备份拉取的表
# ['tbkt_ketang.n_fanfei',
# 'tbkt_ketang.n_fanfei_tea',
# 'tbkt_ketang.n_fanfei_school_num',
# 'tbkt_ketang.n_fanfei_class_num',
# 'tbkt_com.score_user',
# 'tbkt_com.score_user_detail',
# 'tbkt_manage.month_fee_data']

# 需要备份的数据表
data_list = [
    'tbkt_user.auth_user',
    'tbkt_ketang.mobile_subject_detail_hn',
    'tbkt_ketang.mobile_order_region',
    'tbkt_com.school',
    'tbkt_com.school_unit_class',
    'tbkt_com.common_provincecity',
    'tbkt_com.message',
    'tbkt_com.score_user_detail'
]


def get_db_conn():
    """
    功能:建立返费库的mysql连接
    --------------------------
    返费流程处理
    """
    conn = pymysql.connect(host=DB_HOST,
                           db=DB_NAME,
                           user=DB_USER,
                           passwd=DB_USER_PASSWORD,
                           port=3306,
                           charset="utf8")
    return conn


def get_rds_conn():
    """
    功能:建立测试环境的mysql链接
    -----------------------------
    做返费结果数据写入
    """
    conn = pymysql.connect(
        host=RDS_DB_HOST,
        db=RDS_DB_NAME,
        user=RDS_DB_USER,
        passwd=RDS_DB_USER_PASSWORD,
        port=3306,
        charset="utf8"
    )
    return conn


def call_pro(pro_name, parameter):
    """
    功能:返费库执行存储过程
    """
    conn = get_db_conn()
    cursor = conn.cursor()
    cursor.callproc(pro_name, parameter)
    results = cursor.fetchone()
    return results


class CreateCoinProcess(object):
    @staticmethod
    def execute(sql):
        conn = get_db_conn()
        cur = conn.cursor()
        r = cur.execute(sql)
        conn.commit()
        cur.close()
        conn.close()
        return r

    @staticmethod
    def rds_execute(sql):
        conn = get_rds_conn()
        cur = conn.cursor()
        r = cur.execute(sql)
        conn.commit()
        cur.close()
        conn.close()
        return r

    @staticmethod
    def fetchone(sql):
        conn = get_db_conn()
        cur = conn.cursor()
        cur.execute(sql)
        rows = cur.fetchone()
        cur.close()
        conn.close()
        return rows

    @staticmethod
    def fetchall(sql):
        conn = get_db_conn()
        cur = conn.cursor()
        cur.execute(sql)
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return rows

    @staticmethod
    def rds_fetchone(sql):
        conn = get_rds_conn()
        cur = conn.cursor()
        cur.execute(sql)
        rows = cur.fetchone()
        cur.close()
        conn.close()
        return rows

    @staticmethod
    def data_backups():
        """
        功能:数据表备份
        """
        try:
            log.info("数据表备份data_backups")
            for obj in data_list:
                log.info("本次备份的数据表:%s" % obj)
                be_time = int(time.time())
                # 获取数据库名和对应表名
                db_name, tb_name = obj.split('.')
                # 数据拉取命令
                dump_cmd = "/usr/local/mysql/bin/mysqldump -u" + S_DB_USER + " -h" + S_DB_HOST + " -p" + S_DB_USER_PASSWORD + " -P" + bytes(S_DB_PORT) + " --single-transaction --set-gtid-purged=off --databases " + db_name + " --tables " + tb_name + " >" + TODAY_BACKUP_PATH + "/" + db_name + "_" + tb_name + ".sql"
                # 数据备份命令
                restore_cmd = "/usr/local/mysql/bin/mysql -u" + DB_USER + " -h" + DB_HOST + " -p" + DB_USER_PASSWORD + " -P" + bytes(DB_PORT) + " " + DB_NAME + " <" + TODAY_BACKUP_PATH + "/" + db_name + "_" + tb_name + ".sql"
                # 类linux命令执行
                os.system(dump_cmd)
                os.system(restore_cmd)
                log.info("数据表%s备份耗时:%s秒" % (obj, int(time.time()) - be_time))
            return "ok"
        except Exception as e:
            log.error("%s:%s" % (inspect.stack()[0][3], e))
            return 'err'

    def data_title(self):
        """
        功能:生成返费表目录数据
        """
        try:
            log.info("返费表目录数据生成data_title")
            fee_month = datetime.datetime.now().date().replace(day=1)
            if fee_month.month == 1:
                # 当前是1月份，则是上一年12月份
                fee_month = datetime.date(fee_month.year - 1, 12, 1)
            else:
                fee_month = datetime.date(fee_month.year, fee_month.month - 1, 1)
            # 生成返费表中的返费目录
            now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            # 添加类似订单号的格式标志
            date_number = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
            title = '%s年%s月份 返费数据[%s]' % (fee_month.year, fee_month.month, now)
            sql = """INSERT INTO n_fanfei(title, status, add_date, add_username,date_number)
            VALUES ('%s', 0, now(), 'system',%s);""" % (title, date_number)
            self.execute(sql)
        except Exception as e:
            log.error("%s:%s" % (inspect.stack()[0][3], e))

    def coin_create(self):
        """
        功能:金币相关数据表生成
        """
        try:
            log.info("金币数据生成coin_create")
            b_time = int(time.time())
            # 获取month_fee_id
            sql = """SELECT id FROM n_fanfei ORDER BY id DESC LIMIT 1;"""
            month_fee_id = int(self.fetchone(sql)[0])
            log.info("本次的month_fee_id为:%s" % month_fee_id)
            date_param = datetime.datetime.now().date().replace(day=1)
            log.info("输入参数month_fee_id:%s;date_param:%s" % (month_fee_id, date_param))
            call_pro('sp_create_fanfei_jindou', (month_fee_id, date_param))
            u_time = (int(time.time()) - b_time) / 60
            log.info("金币数据表生成过程耗时:%s分" % u_time)
            return month_fee_id
        except Exception as e:
            log.error("%s:%s" % (inspect.stack()[0][3], e))
            return ''

    def score_create(self, month_fee_id):
        """
        功能:教师金币数据返还
        """
        log.info("教师金币返还score_create")
        try:
            s_time = int(time.time())
            sql = """SELECT 
            tea.id, tea.phone_number,tea.status,cl.all_num,tea.unit_class_id,tea.s_name 
            FROM n_fanfei_tea tea
            INNER JOIN n_fanfei_class_num cl ON tea.unit_class_id=cl.unit_class_id AND tea.s_name=cl.s_name
            AND tea.month_fee_id=cl.month_fee_id AND tea.city NOT IN ('411200') AND tea.sch_id<>13913
            AND tea.month_fee_id=%s AND tea.works>=2 AND tea.is_fan=0 
            GROUP BY tea.unit_class_id,tea.s_name;""" % month_fee_id
            fee_data = self.fetchall(sql)
            rows_num = len(fee_data)
            user_id_num = 0
            month = datetime.datetime.now().month
            if month == 1:
                month = 12
            msg_txt = "老师您好！%s月的金豆已返还您的帐号，请登录同步课堂网站www.tbkt.cn查询。" % month
            log.info("待处理的总数据量为:%s" % rows_num)
            for row in fee_data:
                try:
                    tea_id = row[0]
                    phone_number = row[1]
                    status = row[2]
                    all_num = row[3]
                    unit_class_id = row[4]
                    s_name = row[5]
                    log.info("本次待添加金币的教师手机号为:%s" % phone_number)
                    # 获取用户手机号对应账号,多个手机号多个账号只返给第一个账号
                    sql = """SELECT id,username FROM auth_user WHERE phone ='%s' 
                    AND type=3 AND status<>2 ORDER BY username LIMIT 1""" % phone_number
                    tea_user = self.fetchone(sql)
                    if tea_user:
                        user_id = tea_user[0]
                        log.info("本次待添加金币的教师user_id为:%s" % user_id)
                        if user_id:
                            # 开始处理积分数据
                            score = all_num
                            log.info("本次需添加的金币数:%s" % score)
                            affix_info = '[%s][%s]' % (unit_class_id, s_name)
                            if status == 2:
                                # 开通用户
                                self.deal_tea_score(tea_id, user_id, score, affix_info)
                                self.deal_sms_record(phone_number, msg_txt)
                                user_id_num += 1
                            elif all_num >= 5:
                                # 未开通，但班级开通人数>=5
                                self.deal_tea_score(tea_id, user_id, score, affix_info)
                                self.deal_sms_record(phone_number, msg_txt)
                                user_id_num += 1
                        else:
                            log.info('没有对应的账号,不返还金币,手机号:%s' % phone_number)
                    else:
                        log.info("没有对应的教师数据")
                except Exception as e:
                    log.error("%s:%s" % (inspect.stack()[0][3], e))
            log.info("总记录数:%s,处理数:%s" % (rows_num, user_id_num))
            log.info("结束给教师返还金币数据:%s" % datetime.datetime.now())
            su_time = (int(time.time()) - s_time) / 60
            log.info("教师返还金币过程总耗时:%s分" % su_time)
        except Exception as e:
            log.error("%s:%s" % (inspect.stack()[0][3], e))

    def deal_tea_score(self, tea_id, user_id, score, affix_info):
        """
        功能:教师金币数据写入
        :param tea_id: 教师返费表id
        :param user_id: 教师的user_id
        :param score: 金币数
        :param affix_info: 添加信息
        """
        try:
            log.info("开始进行教师金币数据写入deal_tea_score")
            # 首先写入金币明细数据
            sql_insert_dt = """INSERT INTO tbkt_com.score_user_detail(user_id, item_no, score, cycle_num, remark, 
            add_date,app_id,add_username,affix_info) VALUES (%s,'tea_voucher_bak',%s,1,'系统发放',%s,7,'系统发放','%s');
            """ % (user_id, score, int(time.time()), affix_info)
            log.info("写入教师金币明细数据")
            self.rds_execute(sql_insert_dt)
            # 判断score_user表中该教师账号金币数据是否存在
            sql_exist = """SELECT score FROM tbkt_com.score_user WHERE user_id=%s AND app_id=7;""" % user_id
            score_data = self.rds_fetchone(sql_exist)
            if score_data:
                log.info("更新教师金币数据:%s" % user_id)
                score += int(score_data[0])
                sql_up_score = """UPDATE tbkt_com.score_user SET score=%s WHERE user_id=%s AND app_id=7;""" % (score, user_id)
                self.rds_execute(sql_up_score)
            else:
                log.info("添加教师金币数据:%s" % user_id)
                sql_insert_score = """INSERT INTO tbkt_com.score_user(user_id, score, app_id) VALUES (%s,%s,7);""" % (user_id, score)
                self.rds_execute(sql_insert_score)
            # 最后更新本次教师返费表中的数据表示0-未返还,1-已返还
            log.info("教师金币数据处理完成,更新is_fan的值=1")
            sql_up = """UPDATE n_fanfei_tea SET is_fan=1 WHERE id=%s;""" % tea_id
            self.execute(sql_up)
        except Exception as e:
            log.error("%s:%s" % (inspect.stack()[0][3], e))

    def deal_sms_record(self, phone_number, msg_txt):
        """
        功能:短信下发数据写入
        :param phone_number: 手机号
        :param msg_txt: 短信内容
        """
        try:
            log.info("开始进行短信下发数据写入deal_sms_record")
            sql = """INSERT INTO tbkt_ketang.mp_sms_record(phone_number, sp_number, msg_txt, send_status, add_date, batch_id)
            VALUES ('%s','10657050500001','%s',0,%s,0);""" % (phone_number, msg_txt, int(time.time()))
            self.rds_execute(sql)
        except Exception as e:
            log.error("%s:%s" % (inspect.stack()[0][3], e))

    def rename_tb(self):
        """
        功能:数据表重命名
        """
        try:
            log.info("数据表重命名rename_tb")
            for obj in data_list:
                # 获取数据库名和对应表名
                tb_name = DB_NAME + '.' + obj.split('.')[1]
                tb_name_new = tb_name + DB_DATETIME
                sql_re = """RENAME TABLE %s TO %s;""" % (tb_name, tb_name_new)
                log.info("重命名SQL: %s" % sql_re)
                self.execute(sql_re)
        except Exception as e:
            log.error("%s:%s" % (inspect.stack()[0][3], e))

    def start_pro(self):
        """
        功能:程序执行流程
        """
        # 首先执行数据表备份
        ret_val = self.data_backups()
        if ret_val == "ok":
            # 首先生成返费目录数据
            self.data_title()
            # 生成返费金币数据
            month_fee_id = self.coin_create()
            if month_fee_id:
                # 开始给教师返还金币
                self.score_create(month_fee_id=month_fee_id)
                # 数据表重命名
                self.rename_tb()
            else:
                log.info("金币数据生成失败")
        else:
            log.info("数据备份失败")


def start():
    # 执行金币数据生成程序
    pro = CreateCoinProcess()
    pro.start_pro()


if __name__ == "__main__":
    begin_time = int(time.time())
    start()
    use_time = (int(time.time()) - begin_time) / 60
    log.info('程序执行总耗时:%s分' % use_time)





