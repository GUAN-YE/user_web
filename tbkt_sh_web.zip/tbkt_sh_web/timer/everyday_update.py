#coding=utf-8
"""
每日定时更新call_tea表中教师营销数据
"""
import os
import datetime
from tools import time_stamp_first_day, time_to_stamp

import sys
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')


from config import *


class DoUpdate():
    def __init__(self):
        self.first_date = str(datetime.date.today())[:-2] + '01'
        self.call_month = str(datetime.date.today().strftime("%Y-%m"))

        if __name__ == '__main__':
            self.conn = get_ketang_conn()
        elif __name__ == '__builtin__':
            self.conn = get_ketang_conn()

    def execute(self, sql):
        cur = self.conn.cursor()
        r = cur.execute(sql)
        self.conn.commit()
        cur.close()
        return r

    def fetchall(self, sql):
        cur = self.conn.cursor()
        cur.execute(sql)
        rows = cur.fetchall()
        cur.close()
        return rows

    def clear(self):
        """
        删除昨日数据
        """
        sql = """delete from tbkt_ketang.call_tea where call_month='%s'""" % self.call_month


        self.execute(sql)

    def get_teacher_data(self):
        """
        获取全省教师数据
        """
        sql = '''
        SELECT mor.city,(SELECT cp.`name` FROM tbkt_com.common_provincecity cp WHERE cp.cityId=mor.city) AS city_name,mor.county,(SELECT cp.`name` FROM tbkt_com.common_provincecity cp WHERE cp.cityId=mor.county) AS county_name,
    		mor.school_id AS sch_id,mor.school_name AS sch_name,mor.unit_class_id,mor.unit_name,ms.`code` AS s_code,ms.`status` AS status,
    		CASE ms.`code`
    		WHEN 'J' THEN '数学'
    		WHEN 'K' THEN '物理'
    		WHEN 'L' THEN '化学'
    		WHEN 'M' THEN '英语'
    		END AS s_name,mub.user_name,mub.phone_number,mub.username,mub.password,mub.last_login_time,ms.open_date,mub.add_date,mub.user_id
    		FROM
    		tbkt_ketang.mobile_user_bind mub INNER JOIN tbkt_ketang.mobile_subject ms ON ms.order_id=mub.order_id AND ms.`code` in ('J','K','L','M') AND mub.type=3 AND mub.user_id !=0
    		INNER JOIN tbkt_ketang.mobile_order_region mor ON mub.id=mor.user_bind_id AND mor.unit_class_id>0 AND mor.is_update=0
    		GROUP BY mor.school_id,mor.unit_class_id,ms.`code`
        '''


        tea_data = self.fetchall(sql)

        # 批量插入数据
        _sql = """ INSERT INTO tbkt_ketang.call_tea(call_month,city,city_name,county,county_name,sch_id,sch_name,unit_class_id,unit_name,s_code,status,s_name,user_name,phone_number,username,password,last_login_time,open_date,add_date,user_id)
            VALUES """
        num, num1 = 0, 0
        err_num = 0
        for obj in tea_data:
            try:
                num += 1
                num1 += 1

                last_login = time_to_stamp(obj[15]) if obj[15] else "0"
                op_date = time_to_stamp(obj[16]) if obj[16] else "0"
                ad_date = time_to_stamp(obj[17]) if obj[17] else "0"


                if len(tea_data) == num1 or num >= 1000:
                    _sql += """('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');""" % \
                            (self.call_month, str(obj[0]) if obj[0] else "", str(obj[1]) if obj[1] else "",
                             str(obj[2]) if obj[2] else "",str(obj[3]) if obj[3] else "", int(obj[4]), str(obj[5]) if obj[5] else "",
                             int(obj[6]) if obj[6] else 0, str(obj[7]) if obj[7] else "", str(obj[8]),
                             int(obj[9]), str(obj[10]), str(obj[11]), str(obj[12]), str(obj[13]), str(obj[14]), last_login,op_date, ad_date, int(obj[18]))

                    self.execute(_sql)

                    _sql = """ INSERT INTO tbkt_ketang.call_tea(call_month,city,city_name,county,county_name,sch_id,sch_name,unit_class_id,unit_name,s_code,status,s_name,user_name,phone_number,username,password,last_login_time,open_date,add_date,user_id)
                        VALUES """
                    num = 0

                else:
                    _sql += """('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s'),""" % \
                            (self.call_month, str(obj[0]) if obj[0] else "", str(obj[1]) if obj[1] else "",str(obj[2]) if obj[2] else "",
                             str(obj[3]) if obj[3] else "", int(obj[4]), str(obj[5]) if obj[5] else "",
                             int(obj[6]) if obj[6] else 0, str(obj[7]) if obj[7] else "", str(obj[8]),
                             int(obj[9]), str(obj[10]), str(obj[11]), str(obj[12]), str(obj[13]), str(obj[14]), last_login, op_date, ad_date, int(obj[18]))
            except Exception, e:
                err_num += 1
                print 'err=%s' % e
                print 'err_num=', err_num
                print obj

    def get_stu_num(self):
        """
        获取班级学生人数
        """
        sql = """UPDATE tbkt_ketang.call_tea AS ct,(SELECT mor.school_id,mor.unit_class_id,
    			CASE ms.`code`
    			WHEN 'A' THEN 'J'
    			WHEN 'B' THEN 'K'
    			WHEN 'C' THEN 'L'
    			WHEN 'D' THEN 'M'
    			END AS `code`,
    			count(DISTINCT mub.phone_number) AS stu_num FROM tbkt_ketang.mobile_subject ms INNER JOIN tbkt_ketang.mobile_user_bind mub ON ms.order_id=mub.order_id AND ms.`code` in ('A','B','C','D') AND mub.type=1 AND mub.user_id !=0
    			INNER JOIN tbkt_ketang.mobile_order_region mor ON mub.id=mor.user_bind_id AND mor.unit_class_id>0 AND mor.is_update=0
    			GROUP BY mor.school_id,mor.unit_class_id,ms.`code`) AS t
    			SET ct.stu_num=t.stu_num WHERE ct.sch_id=t.school_id AND ct.unit_class_id=t.unit_class_id AND ct.s_code=t.`code` AND ct.call_month='%s'""" % self.call_month
        self.execute(sql)

    def get_stu_open_num(self):
        """
        获取班级开通总人数
        """
        sql = """UPDATE tbkt_ketang.call_tea AS ct,(SELECT mor.school_id,mor.unit_class_id,
        			CASE ms.`code`
        			WHEN 'A' THEN 'J'
        			WHEN 'B' THEN 'K'
        			WHEN 'C' THEN 'L'
        			WHEN 'D' THEN 'M'
        			END AS `code`,
        			count(DISTINCT mub.phone_number) AS stu_open_num FROM tbkt_ketang.mobile_subject ms INNER JOIN tbkt_ketang.mobile_user_bind mub ON ms.order_id=mub.order_id AND ms.`code` in ('A','B','C','D') AND mub.type=1 AND ms.`status`=2 AND mub.user_id !=0
        			INNER JOIN tbkt_ketang.mobile_order_region mor ON mub.id=mor.user_bind_id AND mor.unit_class_id>0 AND mor.is_update=0
        			GROUP BY mor.school_id,mor.unit_class_id,ms.`code`) AS t
        			SET ct.stu_open_num=t.stu_open_num WHERE ct.sch_id=t.school_id AND ct.unit_class_id=t.unit_class_id AND ct.s_code=t.`code` AND ct.call_month='%s'""" % self.call_month

        self.execute(sql)

    def get_works(self):
        """
        获取发作业次数
        """
        sql = """UPDATE tbkt_ketang.call_tea AS ct,(SELECT ut.add_user,
                    CASE ut.subject_id
                    WHEN '21' THEN 'J'
                    WHEN '22' THEN 'J'
                    WHEN '91' THEN 'M'
                    WHEN '91' THEN 'M'
                    END AS ut_code,
                    count(*) AS works FROM tbkt.u_task ut WHERE ut.begin_time>='%s' AND ut.`status`=1
                    GROUP BY ut.add_user) AS t
                    SET ct.works=t.works WHERE ct.user_id=t.add_user AND ct.s_code=t.ut_code AND ct.call_month='%s'""" % (self.first_date, self.call_month)

        self.execute(sql)

    def get_call_num(self):
        """
        获取外呼次数
        """
        sql = """UPDATE tbkt_ketang.call_tea AS ct,
            (SELECT phone_number,count(*) AS call_num FROM tbkt_ketang.call_record WHERE call_date>='%s'
            GROUP BY phone_number) AS t
            SET ct.call_num=t.call_num WHERE ct.phone_number=t.phone_number AND ct.call_month='%s'""" % (self.first_date, self.call_month)

        self.execute(sql)

    def get_sms_num(self):
        """
        获取营销短信下发次数
        """
        sql = """UPDATE tbkt_ketang.call_tea AS ct,
            (SELECT
            t.phone_number,COUNT(*) AS sms_num
            FROM
            (SELECT phone_number FROM tbkt_ketang.mobile_mt  mt WHERE mt.add_date>=UNIX_TIMESTAMP('%s')AND mt.send_phone='waihu'
            UNION
            SELECT phone_number FROM call_record cd WHERE cd.call_date>='%s') AS t
            GROUP BY t.phone_number) AS t1
            SET ct.sms_num=t1.sms_num WHERE ct.phone_number=t1.phone_number AND ct.call_month='%s'""" % (self.first_date, self.first_date, self.call_month)

        self.execute(sql)

    def get_do_works(self):
        """
        获取班级做作业学生人数
        """

        sql = """UPDATE tbkt_ketang.call_tea AS ct,
            (SELECT	mor.school_id,mor.unit_class_id,
    			CASE ms.`code`
    			WHEN 'A' THEN 'J'
    			WHEN 'B' THEN 'K'
    			WHEN 'C' THEN 'L'
    			WHEN 'D' THEN 'M'
    			END AS `code`,
    			COUNT(DISTINCT zy.user_id) AS do_works
    			FROM
    			(SELECT user_id FROM tbkt.u_sx_test us1 WHERE us1.type=5 and us1.add_time>'%s'
    			UNION
    			SELECT user_id FROM tbkt.u_sx2_test us2 WHERE us2.type=5 and us2.add_time>='%s'
    			UNION
    			SELECT user_id FROM tbkt.u_yy_test uy1 where uy1.type=5 and uy1.add_time>='%s'
    			UNION
    			SELECT user_id FROM tbkt.u_yy2_test uy2 where uy2.type=5 and uy2.add_time>='%s') zy
    			INNER JOIN
    			tbkt_ketang.mobile_user_bind mub ON zy.user_id=mub.user_id AND mub.type=1
    			INNER JOIN tbkt_ketang.mobile_order_region mor ON mub.id=mor.user_bind_id AND mor.unit_class_id>0 AND mor.is_update=0
    			INNER JOIN tbkt_ketang.mobile_subject ms ON mub.order_id=ms.order_id AND ms.`code` in ('A','B','C','D')
    			GROUP BY mor.school_id,mor.unit_class_id,ms.`code`) AS t
    			SET ct.do_works=t.do_works WHERE ct.sch_id=t.school_id AND ct.unit_class_id=t.unit_class_id AND ct.s_code=t.`code` AND ct.call_month='%s'""" % (self.first_date, self.first_date, self.first_date, self.first_date, self.call_month)

        self.execute(sql)


if __name__ == '__main__':
    import time
    t1 = time.time()
    do_update = DoUpdate()
    do_update.clear()
    do_update.get_teacher_data()
    do_update.get_stu_num()
    do_update.get_stu_open_num()
    do_update.get_works()
    do_update.get_call_num()
    do_update.get_sms_num()
    do_update.get_do_works()
    print "------------------------"
    print "the process is taken:",
    print time.time() - t1
    print "------------------------"
