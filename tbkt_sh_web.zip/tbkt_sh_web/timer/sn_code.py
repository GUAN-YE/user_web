# coding: utf-8
""" 对7天内容 有验证码但没有开通的手机号再次下发开通请求 """
from datetime import datetime
import time, os
import MySQLdb
import sys
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')

sys.path.insert(0, '..')

from config import *


class Worker:
    def __init__(self):
        self.conn = None
    
    def execute(self, sql, args=None):
        cur = self.conn.cursor()
        cur.execute(sql, args)
        id = cur.lastrowid
        cur.close()
        self.conn.commit()
        return id
    
    def fetchone(self, sql):
        cur = self.conn.cursor()
        cur.execute(sql)
        row = cur.fetchone()
        cur.close()
        return row
    
    def fetchall(self, sql):
        cur = self.conn.cursor()
        cur.execute(sql)
        rows = cur.fetchall()
        cur.close()
        return rows

    def handle(self):
        """
        对7天内容 有验证码但没有开通的手机号再次下发开通请求
        -------------------------------------------------
        修改人                     修改时间
        -------------------------------------------------
        杜祖永                     2016-03-14
        """
        sql = """
            select DISTINCT s.phone_number,s.code from mobile_sn_code sn
            INNER join mobile_subject s on sn.phone_number=s.phone_number
            and sn.sub_code=s.code and sn.sub_code<>'' and sn.status=1 and s.status<2
            and sn.add_date>=DATE_FORMAT(DATE_ADD(now(),INTERVAL -7 day), '%Y-%m-%d')
            and sn.add_date<=DATE_FORMAT(now(), '%Y-%m-%d')
        """
        # print sql

        # 更新最近7天有验证码未成功开通的ftp_status=0,sn.status=0
        sql = """
            update mobile_sn_code sn,mobile_subject s set s.ftp_status=0, sn.status=0
            where sn.phone_number=s.phone_number and sn.sub_code=s.code and  sn.sub_code<>''
            and sn.status=1 and s.status<2
            and sn.add_date>=DATE_FORMAT(DATE_ADD(now(),INTERVAL -2 day), '%Y-%m-%d')
            and sn.add_date<=DATE_FORMAT(now(), '%Y-%m-%d')
        """
        print datetime.now()
        print sql
        self.conn = get_ketang_conn()
        rows = self.execute(sql)
        # rows = self.fetchall(sql)
        print 'rows=', rows
        self.conn.close()
        print datetime.now()
        

if __name__ == '__main__':
    worker = Worker()
    worker.handle()