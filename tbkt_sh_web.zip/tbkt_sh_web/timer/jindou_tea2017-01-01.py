# coding: utf-8
"""
教师金豆商城 返金豆处理
教师金豆商城积分生成规则
1、	获取全部教师（已开通和未开通）明细，未毕业非待分
2、	更新教师发作业（含发短信通知）次数，上月内累计发送次数>=2
3、	获取班级开通人数，提取当时是开通状态且开通满一个月，未毕业非待分
4、	根据上述获取积分后，如教师是开通状态，则返积分。如教师是未开通状态，积分数>=5的才返积分

补充说明
1、	对于开错集团的返积分办法
如：101班所在正确集团为8887，101班有20个人，10个是集团是8887，10个不是，那么老师的积分是10，而不是20
2、	提取时，班级用户开通不满一个月的，不返积分
3、	教师为未开通状态，且班级本月所获积分数小于5，不返积分。
"""
import datetime
import time, os
import MySQLdb
import sys
# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')

sys.path.insert(0, '..')

from config import *

from sms import SMSInfo

sms = SMSInfo.SMSInfo()


class Worker:
    def __init__(self):
        self.conn = None
    
    def execute(self, sql, args=None):
        cur = self.conn.cursor()
        cur.execute(sql, args)
        id = cur.lastrowid
        cur.close()
        self.conn.commit()
        return id
    
    def fetchone(self, sql):
        cur = self.conn.cursor()
        cur.execute(sql)
        row = cur.fetchone()
        cur.close()
        return row
    
    def fetchall(self, sql):
        cur = self.conn.cursor()
        cur.execute(sql)
        rows = cur.fetchall()
        cur.close()
        return rows

    def createFanFei(self):
        """
        生成教师返费明细
        -------------------------------------------------
        修改人                     修改时间
        -------------------------------------------------
        杜祖永                     2016-03-18
        """
        fee_month = datetime.datetime.now()
        fee_month = datetime.date(fee_month.year, fee_month.month, 1)  # 当前月的1号
        if fee_month.month == 1:
            # 当前是1月份，则是上一年12月份
            fee_month = datetime.date(fee_month.year - 1, 12, 1)
        else:
            fee_month = datetime.date(fee_month.year, fee_month.month - 1, 1)
        now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        title = '%s年%s月份 返费数据[%s]' % (fee_month.year, fee_month.month, now)
        sql = """
            insert into ketang.n_fanfei(title, status, add_date, add_username)
            VALUES ('%s', 0, now(), 'system')
        """ % title
        self.conn = get_ketang_conn()
        cur = self.conn.cursor()
        cur.execute(sql)
        self.conn.commit()

        sql = """select LAST_INSERT_ID()"""
        cur.execute(sql)
        month_fee_id = cur.fetchone()[0]
        print 'month_fee_id=', month_fee_id

        # 调用 存储过程生成教师返费明细
        print '开始生成返费明细', datetime.datetime.now()
        now = datetime.datetime.now()
        date_end = datetime.date(now.year, now.month, 1)  # 当前月的1号，
        print 'date_end=', date_end
        cur.callproc('sp_create_fanfei_jindou', (month_fee_id, date_end))
        results = cur.fetchone()
        print results

        print '结束生成返费明细', datetime.datetime.now()

        # 开始给教师返金豆

        self.handle(month_fee_id)

    def dealTeaScore(self, tea_id, user_id, score, remark, add_username, affix_info):
        """
        处理单个用户的积分
        -------------------------------------------------
        修改人                     修改时间
        -------------------------------------------------
        杜祖永                     2016-03-18
        """

        self.conn = get_ketang_conn()
        cur = self.conn.cursor()

        # 调用 存储过程添加教师金豆
        print '开始添加教师金豆', datetime.datetime.now()
        cur.callproc('sp_create_fanfei_jindou_user', (tea_id, user_id, score, remark, add_username, affix_info))
        results = cur.fetchone()
        print 'results=', results

    def handle(self, month_fee_id=45):
        """
        教师金豆商城 返金豆处理
        -------------------------------------------------
        修改人                     修改时间
        -------------------------------------------------
        杜祖永                     2016-03-18
        """
        print '开始给教师返金豆', datetime.datetime.now()
        sql = """
            select f.id, f.phone_number,f.status,t.all_num,f.unit_class_id,f.s_name from  ketang.n_fanfei_tea f
            INNER join ketang.n_fanfei_class_num t on f.unit_class_id=t.unit_class_id and f.s_name=t.s_name
            and f.month_fee_id=t.month_fee_id and f.city not in ('411200') and f.sch_id not in (6737)
            and f.month_fee_id=%s and f.works>=2 and f.is_fan=0 group by f.phone_number,f.unit_class_id,f.s_name
        """ % month_fee_id

        print datetime.datetime.now()
        print sql
        self.conn = get_ketang_conn()
        rows = self.fetchall(sql)
        rows_num = len(rows)
        print 'rows=', rows_num
        user_id_num = 0
        for row in rows:
            try:
                tea_id = row[0]
                phone_number = row[1]
                status = row[2]
                all_num = row[3]
                unit_class_id = row[4]
                s_name = row[5]
                # 获取用户手机号对应账号,多个手机号多个账号只返给第一个账号
                sql = "select user_id,username from mobile_user_bind where phone_number ='%s' and type=3 order by username limit 1" % phone_number
                tea_user = self.fetchone(sql)
                if tea_user:
                    user_id = tea_user[0]
                    username = tea_user[1]
                    if user_id and username.endswith('js'):
                        # 处理积分
                        score = all_num
                        remark = '系统发放'
                        add_username = '系统发放'
                        affix_info = '[%s][%s]' % (unit_class_id, s_name)
                        if status == 2:
                            # 开通用户
                            self.dealTeaScore(tea_id, user_id, score, remark, add_username, affix_info)
                            self.send_sms(phone_number, username, unit_class_id)
                            user_id_num += 1
                        elif all_num >= 5:
                            # 未开通，但班级开通人数>=5
                            self.dealTeaScore(tea_id, user_id, score, remark, add_username, affix_info)
                            self.send_sms(phone_number, username, unit_class_id)
                            user_id_num += 1
                    else:
                        print 'no user_id,', phone_number
                else:
                    print 'tea_user', tea_user
                print '总记录rows=%s, 处理num=%s' % (user_id_num, rows_num)
            except Exception, e:
                print '%s,报错=%s' % (phone_number, e)
                self.conn = get_ketang_conn()

        print '总记录rows=%s, 处理num=%s' % (rows_num, user_id_num)
        print 'user_id_num=', user_id_num

        self.conn.close()
        print '结束给教师返金豆', datetime.datetime.now()

    def send_sms(self, phone, username, unit_class_id):

        month = datetime.datetime.now().month
        if month == 1:
            # 当前是1月份，则是上一年12月份
            month = 12
        msg_txt = "老师您好！，%s月的金豆已返还您的帐号，请登录同步课堂网站www.tbkt.cn查询。" % month
        result = call_proc("sp_send_sms", (phone, msg_txt, '10657050500001', 0, 0, 0, '批处理'))
        if result[0] > 0:
            print 'write_yindao_sms_end, mp_sms_record_id=%s' % result[0]

        # sms.flat_type = 1  # 短信平台类型
        #
        # sender = {}
        # sender['send_phone'] = phone or "" # 发送手机号 没有为''
        # sender['unit_class_id'] = unit_class_id or 0  # 发者班级ID 没有为0
        # sender['object_id'] = 888  # 发送对象ID 没有为0
        # sender['object_type'] = 888  # 发送类型   没有为0
        # sender['send_user'] = '发送者'  # 发送者账号 没有为''
        # sender['accept_user'] = username or ""  # 接收者姓名 没有为''
        # sender['flat_type'] = sms.flat_type
        #
        # sms.send_one(phone, "老师您好！，%s月的金豆已返还您的帐号，请登录同步课堂网站www.tbkt.cn查询。" % month, sender=sender)

if __name__ == '__main__':
    worker = Worker()
    worker.handle(month_fee_id=83)
    # try:
    #     worker.createFanFei()
    # except Exception, e:
    #     print '程序异常,%s,%s' % (datetime.datetime.now(),e)