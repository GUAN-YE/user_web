# coding:utf-8
import requests, sys, os
import json
import datetime
from urlparse import urljoin


# 设置工作目录
sys_base_path = os.path.abspath(__file__)
sys.path.append(os.path.normpath(os.path.join(sys_base_path, '../..')))

# 设置编码
reload(sys)
sys.setdefaultencoding('utf-8')

sys.path.insert(0, '..')

from config import *
base_url = "https://ywapi.m.jxtbkt.cn/system/"


# 定义sql执行方法
def execute(sql):
	conn = get_ketang_conn()
	cur = conn.cursor()
	r = cur.execute(sql)
	conn.commit()
	cur.close()
	return r


# 通过url获取json数据
def get_json(url, the_month, month_fee_id):
	requests.packages.urllib3.disable_warnings()  # 解决通过url获取数据的警告问题
	r = requests.get(url, verify=False)  # verify=False忽略证书的验证
	data_json = r.text
	data_list = json.loads(data_json)
	print 'data_json=', data_json
	for obj in data_list:
		user_id = obj['t_Id']
		task_times = obj['statisticTimes']
		sql = """INSERT INTO tbkt_ketang.u_yw_task_fee(month_fee_id,province, user_id, month, times) VALUES (%s,%s, %s, '%s', %s);"""\
		% (month_fee_id, 410000, user_id, the_month, task_times)
		print sql
		execute(sql)


# 执行程序方法
def task_process(month_fee_id):
	try:
		begin_time = (datetime.date.today().replace(day=1) - datetime.timedelta(1)).replace(day=1)
		the_month = str(begin_time)[:7]
		end_time = datetime.date.today().replace(day=1)
		the_params = "GetSendMsgCount?strSTime=%s&strETime=%s" % (begin_time, end_time)
		url = urljoin(base_url, the_params)
		get_json(url=url, the_month=the_month, month_fee_id=month_fee_id)
	except Exception, e:
		print 'task_process', e

if __name__ == '__main__':
	task_process(127)