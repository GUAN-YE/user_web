#coding=utf-8
from datetime import datetime
import re
import hashlib

def str2date(timestr):
    """
    接收任意长度的时间格式
    """
    t = str(timestr)
    timeformat = re.compile(r'(\d{1,4})+')
    restr = timeformat.findall(t)
    if len(restr) == 1:
        restr += [1,1]
    if len(restr) == 2:
        restr.append(1)
    d = None
    if restr:
        d = datetime( * map( int , restr))
    return d

def time_to_stamp(_date=''):
    """
    时间转换成时间戳
    """
    import time
    t = str2date(_date)
    ts = int(time.mktime(t.timetuple()))
    return ts if ts > 0 else 0


def time_stamp_first_day():
    """
    时间转换成当月初
    """
    from datetime import date, datetime
    import time
    today = date.today()
    first_day = today.replace(day=1)
    return int(time.mktime(first_day.timetuple()))

def stamp_to_time(_ltime):
    """
    时间戳转换成时间
    """
    import datetime,time
    _date = time.localtime(_ltime)
    ts = time.strftime("%Y-%m-%d",_date)
    return ts



def encryption(user_id):
    "加密函数"
    _md5 = hashlib.md5()
    _KEY = "hello_world"  # 密钥
    _s = "%s%s" % (user_id, _KEY)
    _md5.update(_s)
    h = _md5.hexdigest()
    return h

